#include "Closeable.h"
#include "../../../strings.h"

int32_t supertypeof_ji_Closeable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 381 || tag >= 1953) return INT32_C(0);
    if (tag >= 383 && tag < 481) return INT32_C(0);
    if (tag >= 491 && tag < 569) return INT32_C(0);
    if (tag >= 571 && tag < 1593) return INT32_C(0);
    if (tag >= 1597 && tag < 1909) return INT32_C(0);
    if (tag >= 1913 && tag < 1951) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class ji_Closeable_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 381,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_ji_Closeable,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_ji_Closeable() {
}
