#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Writer.h"

extern void sysinitclass_ji_Writer();
typedef struct cls_ji_Writer {
    struct TeaVM_Object parent;
    void* fld_lock;
} cls_ji_Writer;
extern void meth_ji_Writer__init_(void*);
extern int32_t supertypeof_ji_Writer(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_Writer_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_write_0)(void*, int32_t); // 11
    void (*virt_write_1)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*virt_write_2)(void*, void*, int32_t, int32_t); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void* (*virt_append_31)(void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    void* (*virt_append_32)(void*, int32_t); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*virt_close)(void*); // 33
    void (*pad17)(); // 34
    void (*pad18)(); // 35
    void (*pad19)(); // 36
    void (*pad20)(); // 37
    void (*pad21)(); // 38
    void (*pad22)(); // 39
    void (*pad23)(); // 40
    void (*pad24)(); // 41
    void (*pad25)(); // 42
    void (*pad26)(); // 43
    void (*pad27)(); // 44
    void (*pad28)(); // 45
    void* (*virt_append_19)(void*, void*); // 46
    void (*pad29)(); // 47
    void (*pad30)(); // 48
    void (*pad31)(); // 49
} ji_Writer_VT;
extern ji_Writer_VT ji_Writer_Cls;
