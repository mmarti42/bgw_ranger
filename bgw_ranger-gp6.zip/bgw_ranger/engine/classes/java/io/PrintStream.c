#include "PrintStream.h"
#include "FilterOutputStream.h"
#include "../lang/StringBuilder.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrays/primitives/char.h"
#include "../nio/charset/impl/UTF8Charset.h"
#include "OutputStream.h"
#include "../nio/CharBuffer.h"
#include "../../../arrays/primitives/byte.h"
#include "../lang/Math.h"
#include "../nio/ByteBuffer.h"
#include "../nio/charset/Charset.h"
#include "../nio/charset/CodingErrorAction.h"
#include "../nio/charset/CharsetEncoder.h"
#include "../nio/charset/CoderResult.h"
#include "../nio/Buffer.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_ji_PrintStream__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5284, meth_ji_FilterOutputStream__init_(teavm_this_, teavm_local_1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5285, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(5286, meth_jl_StringBuilder__init_(teavm_local_3));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb) = teavm_local_3;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5287, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(32)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_buffer) = teavm_local_4;
    TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_autoFlush) = teavm_local_2;
    TEAVM_WITH_CALL_SITE_ID(5288, teavm_initializeClass((TeaVM_Class*) &jnci_UTF8Charset_Cls, &initclass_jnci_UTF8Charset));
    teavm_local_3 = sfld_jnci_UTF8Charset_INSTANCE;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_charset) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_write(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if (TEAVM_WITH_CALL_SITE_ID(5289, meth_ji_PrintStream_check(teavm_this_))) {
        TEAVM_TRY
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ji_FilterOutputStream, fld_out);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(5290, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5291, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_OutputStream_VT, virt_write)(teavm_tmp_ptr_0, teavm_local_1, teavm_local_2, teavm_local_3)));
            TEAVM_RESTORE_JUMP_BUFFER;
            goto teavm_label_1;
        TEAVM_CATCH
            // CATCH java.io.IOException
            case 1: {
                goto teavm_label_2;
                break;
            }
        TEAVM_END_TRY
    teavm_label_2:;
        TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_errorState) = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_ji_PrintStream_check(void* teavm_this_) {
    if ((TEAVM_FIELD(teavm_this_, cls_ji_FilterOutputStream, fld_out) == NULL)) {
        TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_errorState) = INT32_C(1);
    }
    return (TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_errorState) ? INT32_C(0) : INT32_C(1));
}
void meth_ji_PrintStream_print(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_4 = (teavm_local_3 - teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5292, meth_jn_CharBuffer_wrap(teavm_local_1, teavm_local_2, teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(5293, meth_ji_PrintStream_printCharBuffer(teavm_this_, teavm_local_5, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_printCharBuffer(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_4 = (teavm_local_3 - teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5294, meth_otr_Allocator_allocateArray(&Arr_B_Cls, TEAVM_WITH_CALL_SITE_ID(5295, meth_jl_Math_max(INT32_C(16), TEAVM_WITH_CALL_SITE_ID(5296, meth_jl_Math_min(teavm_local_4, INT32_C(1024)))))));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5297, meth_jn_ByteBuffer_wrap(teavm_local_5));
    teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_charset);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5298, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5299, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jnc_Charset_VT, virt_newEncoder)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(5300, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
    teavm_local_8 = sfld_jnc_CodingErrorAction_REPLACE;
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5301, meth_jnc_CharsetEncoder_onMalformedInput(TEAVM_WITH_CALL_SITE_ID(5302, teavm_nullCheck(teavm_local_7)), teavm_local_8));
    teavm_local_8 = sfld_jnc_CodingErrorAction_REPLACE;
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(5303, meth_jnc_CharsetEncoder_onUnmappableCharacter(TEAVM_WITH_CALL_SITE_ID(5304, teavm_nullCheck(teavm_local_7)), teavm_local_8));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_6);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(5305, teavm_nullCheck(teavm_local_9));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5306, meth_jnc_CharsetEncoder_encode(teavm_local_9, teavm_local_1, teavm_local_6, INT32_C(1)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(5307, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5308, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jnc_CoderResult_VT, virt_isOverflow)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5309, teavm_nullCheck(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(5310, TEAVM_METHOD(teavm_this_, ji_PrintStream_VT, virt_write)(teavm_this_, teavm_local_5, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(5311, meth_jn_Buffer_position(teavm_local_6))));
        TEAVM_WITH_CALL_SITE_ID(5312, meth_jn_ByteBuffer_clear(teavm_local_6));
        if ((!teavm_local_10)) {
            goto teavm_label_1;
        }
    }
teavm_label_1:;
    while (1) {
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5313, meth_jnc_CharsetEncoder_flush(teavm_local_9, teavm_local_6));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(5314, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5315, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jnc_CoderResult_VT, virt_isOverflow)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(5316, TEAVM_METHOD(teavm_this_, ji_PrintStream_VT, virt_write)(teavm_this_, teavm_local_5, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(5317, meth_jn_Buffer_position(teavm_local_6))));
        TEAVM_WITH_CALL_SITE_ID(5318, meth_jn_ByteBuffer_clear(teavm_local_6));
        if ((!teavm_local_10)) {
            goto teavm_label_2;
        }
    }
teavm_label_2:;
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_print_0(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_buffer);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5319, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, char16_t, TEAVM_WITH_CALL_SITE_ID(5320, teavm_checkUpperBound(INT32_C(0), teavm_local_2))) = teavm_local_1;
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_buffer);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5321, TEAVM_METHOD(teavm_this_, ji_PrintStream_VT, virt_print)(teavm_this_, teavm_local_2, INT32_C(0), INT32_C(1)));
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_print_1(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5322, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5323, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5324, meth_ji_PrintStream_printSB(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_println(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5325, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5326, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5327, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5328, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_28)(teavm_tmp_ptr_0, INT32_C(10))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5329, meth_ji_PrintStream_printSB(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_println_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5330, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5331, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5332, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5333, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_28)(teavm_tmp_ptr_0, INT32_C(10))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5334, meth_ji_PrintStream_printSB(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_println_1(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5335, TEAVM_METHOD(teavm_this_, ji_PrintStream_VT, virt_print_0)(teavm_this_, INT32_C(10)));
    TEAVM_RELEASE_STACK;
}
void meth_ji_PrintStream_printSB(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5336, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5337, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_length)(teavm_tmp_ptr_0)));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_buffer);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 <= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5338, teavm_nullCheck(teavm_local_3))))) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_buffer);
    } else {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5339, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5340, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_length)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5341, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5342, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5343, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_length)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(5344, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5345, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_getChars)(teavm_tmp_ptr_0, INT32_C(0), teavm_local_6, teavm_local_4, INT32_C(0))));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5346, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5347, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_length)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(5348, TEAVM_METHOD(teavm_this_, ji_PrintStream_VT, virt_print)(teavm_this_, teavm_local_4, INT32_C(0), teavm_local_7));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ji_PrintStream, fld_sb);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(5349, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(5350, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_setLength)(teavm_tmp_ptr_0, INT32_C(0))));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ji_PrintStream(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 487 || tag >= 489) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ji_PrintStream_Cls[4];
alignas(8) ji_PrintStream_VT ji_PrintStream_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ji_PrintStream), sizeof(void*)),
        .flags = 0,
        .tag = 487,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ji_PrintStream,
        .superclass = (TeaVM_Class*) &ji_FilterOutputStream_Cls,
        .layout = teavm_classLayouts_ji_PrintStream_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_println = &meth_ji_PrintStream_println,
    .virt_write = &meth_ji_PrintStream_write,
    .virt_print_0 = &meth_ji_PrintStream_print_0,
    .virt_println_0 = &meth_ji_PrintStream_println_1,
    .virt_print = &meth_ji_PrintStream_print,
    .virt_print_1 = &meth_ji_PrintStream_print_1,
    .virt_println_1 = &meth_ji_PrintStream_println_0
};
static int16_t teavm_classLayouts_ji_PrintStream_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_ji_PrintStream, fld_sb), (int16_t) offsetof(cls_ji_PrintStream, fld_buffer), (int16_t) offsetof(cls_ji_PrintStream, fld_charset)
};
void sysinitclass_ji_PrintStream() {
}
