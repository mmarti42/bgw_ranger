#include "StringReader.h"
#include "Reader.h"
#include "../lang/NullPointerException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/String.h"
#include "../lang/Math.h"
#include "IOException.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_ji_StringReader__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(21969, meth_ji_Reader__init_(teavm_this_));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21970, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(21971, meth_jl_NullPointerException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(21972, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_string) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_ji_StringReader_read(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(21973, meth_ji_StringReader_checkOpened(teavm_this_));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_index);
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    if ((teavm_local_4 >= TEAVM_WITH_CALL_SITE_ID(21974, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(21975, teavm_nullCheck(teavm_local_5)))))) {
        teavm_local_6 = -INT32_C(1);
    } else {
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_string);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_4 = (TEAVM_WITH_CALL_SITE_ID(21976, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(21977, teavm_nullCheck(teavm_local_5)))) - TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_index));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(21978, meth_jl_Math_min(teavm_local_4, teavm_local_3));
        teavm_local_7 = INT32_C(0);
        while (1) {
            if (!(teavm_local_7 < teavm_local_6)) break;
            teavm_local_4 = (teavm_local_2 + INT32_C(1));
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_string);
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_index);
            TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_index) = (teavm_local_8 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(21979, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(21980, teavm_nullCheck(teavm_local_5)), teavm_local_8));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21981, teavm_nullCheck(teavm_local_1));
            teavm_local_9 = teavm_local_1;
            TEAVM_ARRAY_AT(teavm_local_9, char16_t, TEAVM_WITH_CALL_SITE_ID(21982, teavm_checkBounds(teavm_local_2, teavm_local_9))) = teavm_local_8;
            teavm_local_7 = (teavm_local_7 + INT32_C(1));
            teavm_local_2 = teavm_local_4;
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void meth_ji_StringReader_close(void* teavm_this_) {
    TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_string) = NULL;
}
void meth_ji_StringReader_checkOpened(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ji_StringReader, fld_string) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21983, meth_otr_Allocator_allocate(&ji_IOException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(21984, meth_ji_IOException__init__0(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(21985, meth_otr_ExceptionHandling_throwException(teavm_local_1));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ji_StringReader(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1910 || tag >= 1912) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ji_StringReader_Cls[2];
alignas(8) ji_StringReader_VT ji_StringReader_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ji_StringReader), sizeof(void*)),
            .flags = 0,
            .tag = 1910,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ji_StringReader,
            .superclass = (TeaVM_Class*) &ji_Reader_Cls,
            .layout = teavm_classLayouts_ji_StringReader_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_read_4 = &meth_ji_StringReader_read,
        .virt_close = &meth_ji_StringReader_close
    }
};
static int16_t teavm_classLayouts_ji_StringReader_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ji_StringReader, fld_string)
};
void sysinitclass_ji_StringReader() {
}
