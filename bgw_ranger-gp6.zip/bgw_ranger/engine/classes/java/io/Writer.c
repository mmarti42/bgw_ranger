#include "Writer.h"
#include "../lang/Object.h"
#include "../../../strings.h"

void meth_ji_Writer__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(31479, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_Writer, fld_lock) = teavm_this_;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ji_Writer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1593 || tag >= 1597) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ji_Writer_Cls[2];
alignas(8) ji_Writer_VT ji_Writer_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ji_Writer), sizeof(void*)),
        .flags = 0,
        .tag = 1593,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ji_Writer,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ji_Writer_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
static int16_t teavm_classLayouts_ji_Writer_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ji_Writer, fld_lock)
};
void sysinitclass_ji_Writer() {
}
