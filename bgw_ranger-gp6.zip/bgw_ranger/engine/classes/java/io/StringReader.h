#pragma once
#include "../../../runtime.h"
#include "Reader.h"
#include "StringReader.h"

extern void sysinitclass_ji_StringReader();
typedef struct cls_ji_StringReader {
    struct cls_ji_Reader parent;
    void* fld_string;
    int32_t fld_index;
} cls_ji_StringReader;
extern void meth_ji_StringReader__init_(void*, void*);
extern int32_t meth_ji_StringReader_read(void*, TeaVM_Array*, int32_t, int32_t);
extern void meth_ji_StringReader_close(void*);
extern void meth_ji_StringReader_checkOpened(void*);
extern int32_t supertypeof_ji_StringReader(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_StringReader_VT {
    ji_Reader_VT parent;
} ji_StringReader_VT;
extern ji_StringReader_VT ji_StringReader_Cls;
