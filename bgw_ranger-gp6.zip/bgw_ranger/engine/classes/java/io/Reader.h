#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Reader.h"

extern void sysinitclass_ji_Reader();
typedef struct cls_ji_Reader {
    struct TeaVM_Object parent;
    void* fld_lock;
} cls_ji_Reader;
extern void meth_ji_Reader__init_(void*);
extern void meth_ji_Reader__init__0(void*, void*);
extern int32_t supertypeof_ji_Reader(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_Reader_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    int32_t (*virt_read_4)(void*, TeaVM_Array*, int32_t, int32_t); // 12
    void (*pad1)(); // 13
    void (*pad2)(); // 14
    void (*pad3)(); // 15
    void (*pad4)(); // 16
    void (*pad5)(); // 17
    void (*pad6)(); // 18
    void (*pad7)(); // 19
    void (*pad8)(); // 20
    void (*pad9)(); // 21
    void (*pad10)(); // 22
    void (*pad11)(); // 23
    void (*pad12)(); // 24
    void (*pad13)(); // 25
    void (*pad14)(); // 26
    void (*pad15)(); // 27
    void (*pad16)(); // 28
    void (*pad17)(); // 29
    void (*pad18)(); // 30
    void (*pad19)(); // 31
    void (*pad20)(); // 32
    void (*virt_close)(void*); // 33
    void (*pad21)(); // 34
    void (*pad22)(); // 35
    void (*pad23)(); // 36
    void (*pad24)(); // 37
    void (*pad25)(); // 38
    void (*pad26)(); // 39
    void (*pad27)(); // 40
    void (*pad28)(); // 41
    void (*pad29)(); // 42
    void (*pad30)(); // 43
    void (*pad31)(); // 44
    void (*pad32)(); // 45
    void (*pad33)(); // 46
    void (*pad34)(); // 47
    void (*pad35)(); // 48
    void (*pad36)(); // 49
} ji_Reader_VT;
extern ji_Reader_VT ji_Reader_Cls;
