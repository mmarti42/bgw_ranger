#include "File.h"
#include "../lang/Object.h"
#include "../../org/teavm/runtime/fs/VirtualFileSystemProvider.h"
#include "../../org/teavm/runtime/fs/VirtualFileSystem.h"
#include "../lang/String.h"
#include "../../../strings.h"

char16_t sfld_ji_File_separatorChar;
void* sfld_ji_File_separator;
char16_t sfld_ji_File_pathSeparatorChar;
void* sfld_ji_File_pathSeparator;
void* meth_ji_File_fs() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(17947, teavm_initializeClass((TeaVM_Class*) &ji_File_Cls, &initclass_ji_File));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17948, meth_otrf_VirtualFileSystemProvider_getInstance());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ji_File__clinit_() {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17949, meth_ji_File_fs());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    sfld_ji_File_separatorChar = ((!TEAVM_WITH_CALL_SITE_ID(17950, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17951, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, otrf_VirtualFileSystem_VT, virt_isWindows)(teavm_tmp_ptr_0)))) ? INT32_C(47) : INT32_C(92));
    teavm_local_2 = sfld_ji_File_separatorChar;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_ji_File_separator = TEAVM_WITH_CALL_SITE_ID(17952, meth_jl_String_valueOf_2(teavm_local_2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17953, meth_ji_File_fs());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    sfld_ji_File_pathSeparatorChar = ((!TEAVM_WITH_CALL_SITE_ID(17954, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17955, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, otrf_VirtualFileSystem_VT, virt_isWindows)(teavm_tmp_ptr_0)))) ? INT32_C(58) : INT32_C(59));
    teavm_local_2 = sfld_ji_File_pathSeparatorChar;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_ji_File_pathSeparator = TEAVM_WITH_CALL_SITE_ID(17956, meth_jl_String_valueOf_2(teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void initclass_ji_File() {
    TeaVM_Class* cls = (TeaVM_Class*) &ji_File_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_ji_File__clinit_();
    }
}
int32_t supertypeof_ji_File(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1013 || tag >= 1015) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ji_File_VT ji_File_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ji_File), sizeof(void*)),
        .flags = 0,
        .tag = 1013,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ji_File,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
static void** teavm_gc_localStaticRoots_ji_File_Cls[2] = {
(void**) &sfld_ji_File_separator, (void**) &sfld_ji_File_pathSeparator
};
void sysinitclass_ji_File() {
sfld_ji_File_separatorChar = INT32_C(0);
sfld_ji_File_separator = NULL;
sfld_ji_File_pathSeparatorChar = INT32_C(0);
sfld_ji_File_pathSeparator = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_ji_File_Cls, 2);
}
