#pragma once
#include "../../../runtime.h"
#include "Writer.h"
#include "StringWriter.h"

extern void sysinitclass_ji_StringWriter();
typedef struct cls_ji_StringWriter {
    struct cls_ji_Writer parent;
    void* fld_buf;
} cls_ji_StringWriter;
extern void meth_ji_StringWriter__init_(void*);
extern void meth_ji_StringWriter_close(void*);
extern void* meth_ji_StringWriter_toString(void*);
extern void meth_ji_StringWriter_write(void*, int32_t);
extern void meth_ji_StringWriter_write_0(void*, void*);
extern void meth_ji_StringWriter_write_1(void*, void*, int32_t, int32_t);
extern void* meth_ji_StringWriter_append(void*, int32_t);
extern void* meth_ji_StringWriter_append_0(void*, void*);
extern void* meth_ji_StringWriter_append_1(void*, int32_t);
extern void* meth_ji_StringWriter_append_2(void*, void*);
extern int32_t supertypeof_ji_StringWriter(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_StringWriter_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_write_0)(void*, int32_t); // 11
    void (*virt_write_1)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*virt_write_2)(void*, void*, int32_t, int32_t); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_append_29)(void*, int32_t); // 21
    void* (*virt_append_31)(void*, void*); // 22
    void* (*virt_append_30)(void*, void*); // 23
    void (*pad7)(); // 24
    void (*pad8)(); // 25
    void (*pad9)(); // 26
    void (*pad10)(); // 27
    void* (*virt_append_32)(void*, int32_t); // 28
    void (*pad11)(); // 29
    void (*pad12)(); // 30
    void (*pad13)(); // 31
    void (*pad14)(); // 32
    void (*virt_close)(void*); // 33
    void (*pad15)(); // 34
    void (*pad16)(); // 35
    void (*pad17)(); // 36
    void (*pad18)(); // 37
    void (*pad19)(); // 38
    void (*pad20)(); // 39
    void (*pad21)(); // 40
    void (*pad22)(); // 41
    void (*pad23)(); // 42
    void (*pad24)(); // 43
    void (*pad25)(); // 44
    void (*pad26)(); // 45
    void* (*virt_append_19)(void*, void*); // 46
    void (*pad27)(); // 47
    void (*pad28)(); // 48
    void (*pad29)(); // 49
} ji_StringWriter_VT;
extern ji_StringWriter_VT ji_StringWriter_Cls;
