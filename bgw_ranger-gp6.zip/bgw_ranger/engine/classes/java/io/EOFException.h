#pragma once
#include "../../../runtime.h"
#include "IOException.h"
#include "EOFException.h"

extern void sysinitclass_ji_EOFException();
typedef struct cls_ji_EOFException {
    struct cls_ji_IOException parent;
} cls_ji_EOFException;
extern void meth_ji_EOFException__init_(void*, void*);
extern int32_t supertypeof_ji_EOFException(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_EOFException_VT {
    ji_IOException_VT parent;
} ji_EOFException_VT;
extern ji_EOFException_VT ji_EOFException_Cls;
