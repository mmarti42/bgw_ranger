#pragma once
#include "../../../runtime.h"
#include "Flushable.h"

extern void sysinitclass_ji_Flushable();
extern int32_t supertypeof_ji_Flushable(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_Flushable_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
} ji_Flushable_VT;
extern TeaVM_Class ji_Flushable_Cls;
