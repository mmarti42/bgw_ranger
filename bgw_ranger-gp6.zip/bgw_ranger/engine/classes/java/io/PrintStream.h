#pragma once
#include "../../../runtime.h"
#include "FilterOutputStream.h"
#include "PrintStream.h"

extern void sysinitclass_ji_PrintStream();
typedef struct cls_ji_PrintStream {
    struct cls_ji_FilterOutputStream parent;
    int8_t fld_autoFlush;
    int8_t fld_errorState;
    void* fld_sb;
    TeaVM_Array* fld_buffer;
    void* fld_charset;
} cls_ji_PrintStream;
extern void meth_ji_PrintStream__init_(void*, void*, int32_t);
extern void meth_ji_PrintStream_write(void*, TeaVM_Array*, int32_t, int32_t);
extern int32_t meth_ji_PrintStream_check(void*);
extern void meth_ji_PrintStream_print(void*, TeaVM_Array*, int32_t, int32_t);
extern void meth_ji_PrintStream_printCharBuffer(void*, void*, int32_t, int32_t);
extern void meth_ji_PrintStream_print_0(void*, int32_t);
extern void meth_ji_PrintStream_print_1(void*, void*);
extern void meth_ji_PrintStream_println(void*, void*);
extern void meth_ji_PrintStream_println_0(void*, void*);
extern void meth_ji_PrintStream_println_1(void*);
extern void meth_ji_PrintStream_printSB(void*);
extern int32_t supertypeof_ji_PrintStream(TeaVM_Class*, TeaVM_Class*);
typedef struct ji_PrintStream_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_println)(void*, void*); // 11
    void (*virt_write)(void*, TeaVM_Array*, int32_t, int32_t); // 12
    void (*pad0)(); // 13
    void (*virt_print_0)(void*, int32_t); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*virt_println_0)(void*); // 21
    void (*virt_print)(void*, TeaVM_Array*, int32_t, int32_t); // 22
    void (*virt_print_1)(void*, void*); // 23
    void (*pad7)(); // 24
    void (*pad8)(); // 25
    void (*pad9)(); // 26
    void (*pad10)(); // 27
    void (*virt_println_1)(void*, void*); // 28
    void (*pad11)(); // 29
    void (*pad12)(); // 30
    void (*pad13)(); // 31
    void (*pad14)(); // 32
    void (*pad15)(); // 33
    void (*pad16)(); // 34
    void (*pad17)(); // 35
    void (*pad18)(); // 36
    void (*pad19)(); // 37
    void (*pad20)(); // 38
    void (*pad21)(); // 39
    void (*pad22)(); // 40
    void (*pad23)(); // 41
    void (*pad24)(); // 42
    void (*pad25)(); // 43
    void (*pad26)(); // 44
    void (*pad27)(); // 45
    void* (*virt_append_19)(void*, void*); // 46
    void (*pad28)(); // 47
    void (*pad29)(); // 48
    void (*pad30)(); // 49
} ji_PrintStream_VT;
extern ji_PrintStream_VT ji_PrintStream_Cls;
