#include "StringWriter.h"
#include "Writer.h"
#include "../lang/StringBuffer.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/String.h"
#include "../../../strings.h"
#include "../lang/CharSequence.h"
#include "../lang/Object.h"

void meth_ji_StringWriter__init_(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9000, meth_ji_Writer__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9001, meth_otr_Allocator_allocate(&jl_StringBuffer_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9002, meth_jl_StringBuffer__init_(teavm_local_1, INT32_C(16)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_StringWriter, fld_buf) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ji_Writer, fld_lock) = TEAVM_FIELD(teavm_this_, cls_ji_StringWriter, fld_buf);
    TEAVM_RELEASE_STACK;
}
void meth_ji_StringWriter_close(void* teavm_this_) {
    return;
}
void* meth_ji_StringWriter_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ji_StringWriter, fld_buf);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9003, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(9004, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ji_StringWriter_write(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_StringWriter, fld_buf);
    teavm_local_3 = TEAVM_TO_CHAR(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(9005, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(9006, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_3)(teavm_tmp_ptr_0, teavm_local_3)));
    TEAVM_RELEASE_STACK;
}
void meth_ji_StringWriter_write_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ji_StringWriter, fld_buf);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(9007, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(9008, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_22)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
}
void meth_ji_StringWriter_write_1(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_4 = (teavm_local_2 + teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9009, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9010, meth_jl_String_substring_0(teavm_local_1, teavm_local_2, teavm_local_4));
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ji_StringWriter, fld_buf);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(9011, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(9012, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_22)(teavm_tmp_ptr_0, teavm_local_5)));
    TEAVM_RELEASE_STACK;
}
void* meth_ji_StringWriter_append(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9013, TEAVM_METHOD(teavm_this_, ji_StringWriter_VT, virt_write_0)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_ji_StringWriter_append_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((NULL == teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(9014, TEAVM_METHOD(teavm_this_, ji_StringWriter_VT, virt_write_1)(teavm_this_, TEAVM_GET_STRING(498)));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9015, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9016, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_toString)(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(9017, TEAVM_METHOD(teavm_this_, ji_StringWriter_VT, virt_write_1)(teavm_this_, teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_ji_StringWriter_append_1(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9018, TEAVM_METHOD(teavm_this_, ji_StringWriter_VT, virt_append_29)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ji_StringWriter_append_2(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9019, TEAVM_METHOD(teavm_this_, ji_StringWriter_VT, virt_append_30)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ji_StringWriter(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1594 || tag >= 1596) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ji_StringWriter_Cls[2];
alignas(8) ji_StringWriter_VT ji_StringWriter_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ji_StringWriter), sizeof(void*)),
        .flags = 0,
        .tag = 1594,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ji_StringWriter,
        .superclass = (TeaVM_Class*) &ji_Writer_Cls,
        .layout = teavm_classLayouts_ji_StringWriter_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_ji_StringWriter_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_write_0 = &meth_ji_StringWriter_write,
    .virt_write_1 = &meth_ji_StringWriter_write_0,
    .virt_write_2 = &meth_ji_StringWriter_write_1,
    .virt_append_29 = &meth_ji_StringWriter_append,
    .virt_append_31 = &meth_ji_StringWriter_append_2,
    .virt_append_30 = &meth_ji_StringWriter_append_0,
    .virt_append_32 = &meth_ji_StringWriter_append_1,
    .virt_close = &meth_ji_StringWriter_close
};
static int16_t teavm_classLayouts_ji_StringWriter_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ji_StringWriter, fld_buf)
};
void sysinitclass_ji_StringWriter() {
}
