#include "FilterOutputStream.h"
#include "OutputStream.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_ji_FilterOutputStream__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41111, meth_ji_OutputStream__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ji_FilterOutputStream, fld_out) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ji_FilterOutputStream(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 486 || tag >= 490) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ji_FilterOutputStream_Cls[2];
alignas(8) ji_FilterOutputStream_VT ji_FilterOutputStream_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ji_FilterOutputStream), sizeof(void*)),
            .flags = 0,
            .tag = 486,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ji_FilterOutputStream,
            .superclass = (TeaVM_Class*) &ji_OutputStream_Cls,
            .layout = teavm_classLayouts_ji_FilterOutputStream_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_ji_FilterOutputStream_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ji_FilterOutputStream, fld_out)
};
void sysinitclass_ji_FilterOutputStream() {
}
