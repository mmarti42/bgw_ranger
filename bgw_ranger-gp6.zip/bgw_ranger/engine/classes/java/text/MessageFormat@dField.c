#include "MessageFormat@dField.h"
#include "Format@dField.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void* sfld_jt_MessageFormat_Field_ARGUMENT;
void meth_jt_MessageFormat_Field__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33906, teavm_initializeClass((TeaVM_Class*) &jt_MessageFormat_Field_Cls, &initclass_jt_MessageFormat_Field));
    TEAVM_WITH_CALL_SITE_ID(33907, meth_jt_Format_Field__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_MessageFormat_Field__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33908, meth_otr_Allocator_allocate(&jt_MessageFormat_Field_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(33909, meth_jt_MessageFormat_Field__init_(teavm_local_1, TEAVM_GET_STRING(7672)));
    sfld_jt_MessageFormat_Field_ARGUMENT = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jt_MessageFormat_Field() {
    TeaVM_Class* cls = (TeaVM_Class*) &jt_MessageFormat_Field_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jt_MessageFormat_Field__clinit_();
    }
}
int32_t supertypeof_jt_MessageFormat_Field(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 107 || tag >= 109) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_MessageFormat_Field_VT jt_MessageFormat_Field_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_MessageFormat_Field), sizeof(void*)),
                    .flags = 0,
                    .tag = 107,
                    .modifiers = 1,
                    .name = NULL,
                    .simpleName = NULL,
                    .arrayType = NULL,
                    .itemType = NULL,
                    .isSupertypeOf = &supertypeof_jt_MessageFormat_Field,
                    .superclass = (TeaVM_Class*) &jt_Format_Field_Cls,
                    .layout = NULL,
                    .enumValues = NULL,
                    .declaringClass = NULL,
                    .enclosingClass = NULL,
                    .init = NULL
                },
                .virt_clone = &meth_jl_Object_clone,
                .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                .virt_getClass = &meth_jl_Object_getClass,
                .virt_identity = &meth_jl_Object_identity,
                .virt_notifyAll = &meth_jl_Object_notifyAll,
                .virt_wait = &meth_jl_Object_wait,
                .virt_waitImpl = &meth_jl_Object_waitImpl,
                .virt_wait_0 = &meth_jl_Object_wait_0
            }
        }
    }
};
static void** teavm_gc_localStaticRoots_jt_MessageFormat_Field_Cls[1] = {
(void**) &sfld_jt_MessageFormat_Field_ARGUMENT
};
void sysinitclass_jt_MessageFormat_Field() {
sfld_jt_MessageFormat_Field_ARGUMENT = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jt_MessageFormat_Field_Cls, 1);
}
