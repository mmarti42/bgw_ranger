#include "DecimalFormat@dPercentField.h"
#include "../lang/Object.h"
#include "DecimalFormat.h"
#include "DecimalFormatSymbols.h"
#include "../lang/StringBuffer.h"
#include "../../../strings.h"

void meth_jt_DecimalFormat_PercentField__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(38356, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_PercentField_render(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(38357, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38358, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(38359, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getPercent)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38360, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(38361, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_4));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DecimalFormat_PercentField_equals(void* teavm_this_, void* teavm_local_1) {
    return teavm_instanceof(teavm_local_1, &jt_DecimalFormat_PercentField_Cls, &supertypeof_jt_DecimalFormat_PercentField);
}
int32_t meth_jt_DecimalFormat_PercentField_hashCode(void* teavm_this_) {
    return INT32_C(1);
}
int32_t supertypeof_jt_DecimalFormat_PercentField(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1833 || tag >= 1835) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DecimalFormat_PercentField_VT jt_DecimalFormat_PercentField_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormat_PercentField), sizeof(void*)),
        .flags = 0,
        .tag = 1833,
        .modifiers = 0,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7937),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DecimalFormat_PercentField,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = (TeaVM_Class*) &jt_DecimalFormat_Cls,
        .enclosingClass = (TeaVM_Class*) &jt_DecimalFormat_Cls,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DecimalFormat_PercentField_hashCode,
    .virt_equals = &meth_jt_DecimalFormat_PercentField_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_render = &meth_jt_DecimalFormat_PercentField_render
};
void sysinitclass_jt_DecimalFormat_PercentField() {
}
