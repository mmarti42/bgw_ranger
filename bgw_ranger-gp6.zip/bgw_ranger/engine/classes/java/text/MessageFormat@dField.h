#pragma once
#include "../../../runtime.h"
#include "Format@dField.h"
#include "MessageFormat@dField.h"

extern void sysinitclass_jt_MessageFormat_Field();
typedef struct cls_jt_MessageFormat_Field {
    struct cls_jt_Format_Field parent;
} cls_jt_MessageFormat_Field;
extern void* sfld_jt_MessageFormat_Field_ARGUMENT;
extern void meth_jt_MessageFormat_Field__init_(void*, void*);
extern void meth_jt_MessageFormat_Field__clinit_();
extern void initclass_jt_MessageFormat_Field();
extern int32_t supertypeof_jt_MessageFormat_Field(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_MessageFormat_Field_VT {
    jt_Format_Field_VT parent;
} jt_MessageFormat_Field_VT;
extern jt_MessageFormat_Field_VT jt_MessageFormat_Field_Cls;
