#include "AttributedCharacterIterator.h"
#include "../../../strings.h"

int32_t supertypeof_jt_AttributedCharacterIterator(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 53 || tag >= 55) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jt_AttributedCharacterIterator_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 53,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jt_AttributedCharacterIterator,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jt_AttributedCharacterIterator() {
}
