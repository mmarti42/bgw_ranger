#include "AttributedCharacterIterator@dAttribute.h"
#include "../lang/Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"

void* sfld_jt_AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT;
void* sfld_jt_AttributedCharacterIterator_Attribute_LANGUAGE;
void* sfld_jt_AttributedCharacterIterator_Attribute_READING;
void meth_jt_AttributedCharacterIterator_Attribute__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1081, teavm_initializeClass((TeaVM_Class*) &jt_AttributedCharacterIterator_Attribute_Cls, &initclass_jt_AttributedCharacterIterator_Attribute));
    TEAVM_WITH_CALL_SITE_ID(1082, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_AttributedCharacterIterator_Attribute, fld_name) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_AttributedCharacterIterator_Attribute__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1083, meth_otr_Allocator_allocate(&jt_AttributedCharacterIterator_Attribute_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(1084, meth_jt_AttributedCharacterIterator_Attribute__init_(teavm_local_1, TEAVM_GET_STRING(89)));
    sfld_jt_AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1085, meth_otr_Allocator_allocate(&jt_AttributedCharacterIterator_Attribute_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(1086, meth_jt_AttributedCharacterIterator_Attribute__init_(teavm_local_1, TEAVM_GET_STRING(90)));
    sfld_jt_AttributedCharacterIterator_Attribute_LANGUAGE = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1087, meth_otr_Allocator_allocate(&jt_AttributedCharacterIterator_Attribute_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(1088, meth_jt_AttributedCharacterIterator_Attribute__init_(teavm_local_1, TEAVM_GET_STRING(91)));
    sfld_jt_AttributedCharacterIterator_Attribute_READING = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jt_AttributedCharacterIterator_Attribute() {
    TeaVM_Class* cls = (TeaVM_Class*) &jt_AttributedCharacterIterator_Attribute_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jt_AttributedCharacterIterator_Attribute__clinit_();
    }
}
int32_t supertypeof_jt_AttributedCharacterIterator_Attribute(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 105 || tag >= 111) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_AttributedCharacterIterator_Attribute_Cls[2];
alignas(8) jt_AttributedCharacterIterator_Attribute_VT jt_AttributedCharacterIterator_Attribute_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_AttributedCharacterIterator_Attribute), sizeof(void*)),
            .flags = 0,
            .tag = 105,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_AttributedCharacterIterator_Attribute,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jt_AttributedCharacterIterator_Attribute_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_clone = &meth_jl_Object_clone,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jt_AttributedCharacterIterator_Attribute_Cls[3] = {
(void**) &sfld_jt_AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT, (void**) &sfld_jt_AttributedCharacterIterator_Attribute_LANGUAGE, (void**) &sfld_jt_AttributedCharacterIterator_Attribute_READING
};
static int16_t teavm_classLayouts_jt_AttributedCharacterIterator_Attribute_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_AttributedCharacterIterator_Attribute, fld_name)
};
void sysinitclass_jt_AttributedCharacterIterator_Attribute() {
sfld_jt_AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT = NULL;
sfld_jt_AttributedCharacterIterator_Attribute_LANGUAGE = NULL;
sfld_jt_AttributedCharacterIterator_Attribute_READING = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jt_AttributedCharacterIterator_Attribute_Cls, 3);
}
