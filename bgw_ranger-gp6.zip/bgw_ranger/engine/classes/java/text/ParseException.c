#include "ParseException.h"
#include "../lang/Exception.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "../lang/Throwable.h"

void meth_jt_ParseException__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18473, meth_jl_Exception__init_(teavm_this_, teavm_local_1));
    TEAVM_FIELD(teavm_this_, cls_jt_ParseException, fld_errorOffset) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_ParseException(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 869 || tag >= 871) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_ParseException_VT jt_ParseException_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_ParseException), sizeof(void*)),
                .flags = 0,
                .tag = 869,
                .modifiers = 1,
                .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(2710),
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_jt_ParseException,
                .superclass = (TeaVM_Class*) &jl_Exception_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_hashCode = &meth_jl_Object_hashCode,
            .virt_equals = &meth_jl_Object_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_jl_Throwable_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
            .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
            .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
            .virt_getMessage = &meth_jl_Throwable_getMessage,
            .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
            .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
        }
    }
};
void sysinitclass_jt_ParseException() {
}
