#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dWeekdayText.h"

extern void sysinitclass_jt_DateFormatElement_WeekdayText();
typedef struct cls_jt_DateFormatElement_WeekdayText {
    struct cls_jt_DateFormatElement parent;
    TeaVM_Array* fld_weeks;
    TeaVM_Array* fld_shortWeeks;
    int8_t fld_abbreviated;
} cls_jt_DateFormatElement_WeekdayText;
extern void meth_jt_DateFormatElement_WeekdayText__init_(void*, void*, int32_t);
extern void meth_jt_DateFormatElement_WeekdayText_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_WeekdayText_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_WeekdayText_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_WeekdayText_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_WeekdayText(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_WeekdayText_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_WeekdayText_VT;
extern jt_DateFormatElement_WeekdayText_VT jt_DateFormatElement_WeekdayText_Cls;
