#include "AttributedString@dRange.h"
#include "../lang/Object.h"
#include "../../../strings.h"

int32_t supertypeof_jt_AttributedString_Range(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1369 || tag >= 1371) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_AttributedString_Range_Cls[2];
alignas(8) jt_AttributedString_Range_VT jt_AttributedString_Range_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_AttributedString_Range), sizeof(void*)),
            .flags = 0,
            .tag = 1369,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_AttributedString_Range,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jt_AttributedString_Range_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_jt_AttributedString_Range_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_AttributedString_Range, fld_value)
};
void sysinitclass_jt_AttributedString_Range() {
}
