#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dMonthText.h"

extern void sysinitclass_jt_DateFormatElement_MonthText();
typedef struct cls_jt_DateFormatElement_MonthText {
    struct cls_jt_DateFormatElement parent;
    TeaVM_Array* fld_months;
    TeaVM_Array* fld_shortMonths;
    int8_t fld_abbreviated;
} cls_jt_DateFormatElement_MonthText;
extern void meth_jt_DateFormatElement_MonthText__init_(void*, void*, int32_t);
extern void meth_jt_DateFormatElement_MonthText_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_MonthText_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_MonthText_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_MonthText_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_MonthText(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_MonthText_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_MonthText_VT;
extern jt_DateFormatElement_MonthText_VT jt_DateFormatElement_MonthText_Cls;
