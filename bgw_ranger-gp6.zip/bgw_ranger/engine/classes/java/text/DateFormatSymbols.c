#include "DateFormatSymbols.h"
#include "../lang/Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/Arrays.h"
#include "../../../arrayclass.h"
#include "../lang/String.h"
#include "../util/Locale.h"
#include "../util/Objects.h"
#include "../../org/teavm/classlib/impl/unicode/CLDRHelper.h"
#include "../../../strings.h"

void meth_jt_DateFormatSymbols__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33581, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DateFormatSymbols_clone(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33582, meth_otr_Allocator_allocate(&jt_DateFormatSymbols_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(33583, meth_jt_DateFormatSymbols__init_(teavm_local_1, teavm_local_2));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33584, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33585, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33586, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_ampms) = teavm_local_3;
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33587, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33588, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33589, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_eras) = teavm_local_3;
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33590, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33591, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33592, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_months) = teavm_local_3;
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33593, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33594, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33595, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_shortMonths) = teavm_local_3;
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33596, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33597, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33598, teavm_checkcast(teavm_local_2, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33599, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33600, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33601, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_shortWeekdays) = teavm_local_3;
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33602, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33603, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33604, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_weekdays) = teavm_local_3;
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33605, teavm_nullCheck(teavm_local_3)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33606, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls)), teavm_local_5));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_zoneStrings) = teavm_local_3;
        teavm_local_6 = INT32_C(0);
        while (1) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            if ((teavm_local_6 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33607, teavm_nullCheck(teavm_local_3))))) {
                goto teavm_label_1;
            }
            teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatSymbols, fld_zoneStrings);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33608, teavm_nullCheck(teavm_local_4));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33609, teavm_checkBounds(teavm_local_6, teavm_local_4));
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_6);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33610, teavm_nullCheck(teavm_local_4));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33611, teavm_checkUpperBound(teavm_local_6, teavm_local_4));
            teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
            teavm_local_8 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(33612, teavm_nullCheck(teavm_local_4)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33613, meth_ju_Arrays_copyOf(teavm_local_7, teavm_local_8));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33614, teavm_checkcast(teavm_local_4, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33615, teavm_nullCheck(teavm_local_3));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33616, teavm_checkUpperBound(teavm_local_6, teavm_local_3));
            teavm_gc_writeBarrier(teavm_local_3);
            TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_6) = teavm_local_4;
            teavm_local_6 = (teavm_local_6 + INT32_C(1));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_DateFormatSymbols_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
        goto teavm_label_1;
    }
    if ((!teavm_instanceof(teavm_local_1, &jt_DateFormatSymbols_Cls, &supertypeof_jt_DateFormatSymbols))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33617, teavm_checkcast(teavm_local_1, &jt_DateFormatSymbols_Cls, &supertypeof_jt_DateFormatSymbols));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33618, teavm_nullCheck(teavm_local_3));
    teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_locale);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    if ((!TEAVM_WITH_CALL_SITE_ID(33619, meth_ju_Locale_equals(TEAVM_WITH_CALL_SITE_ID(33620, teavm_nullCheck(teavm_local_4)), teavm_local_5)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_localPatternChars);
    teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_localPatternChars);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    if ((!TEAVM_WITH_CALL_SITE_ID(33621, meth_ju_Objects_equals(teavm_local_4, teavm_local_5)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_ampms);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(33622, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_eras);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(33623, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_months);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(33624, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_shortMonths);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(33625, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_shortWeekdays);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(33626, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_weekdays);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(33627, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7)))) {
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings);
    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormatSymbols, fld_zoneStrings);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33628, meth_ju_Arrays_equals(teavm_local_6, teavm_local_7));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
TeaVM_Array* meth_jt_DateFormatSymbols_getAmPmStrings(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms) == NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33629, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(33630, teavm_nullCheck(teavm_local_1))));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33631, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(33632, teavm_nullCheck(teavm_local_2))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33633, meth_otciu_CLDRHelper_resolveAmPm(teavm_local_1, teavm_local_2));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms) = teavm_local_3;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33634, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33635, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33636, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_jt_DateFormatSymbols_getEras(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras) == NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33637, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(33638, teavm_nullCheck(teavm_local_1))));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33639, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(33640, teavm_nullCheck(teavm_local_2))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33641, meth_otciu_CLDRHelper_resolveEras(teavm_local_1, teavm_local_2));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras) = teavm_local_3;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33642, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33643, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33644, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_jt_DateFormatSymbols_getMonths(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months) == NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33645, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(33646, teavm_nullCheck(teavm_local_1))));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33647, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(33648, teavm_nullCheck(teavm_local_2))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33649, meth_otciu_CLDRHelper_resolveMonths(teavm_local_1, teavm_local_2));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months) = teavm_local_3;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33650, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33651, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33652, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_jt_DateFormatSymbols_getShortMonths(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths) == NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33653, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(33654, teavm_nullCheck(teavm_local_1))));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33655, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(33656, teavm_nullCheck(teavm_local_2))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33657, meth_otciu_CLDRHelper_resolveShortMonths(teavm_local_1, teavm_local_2));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths) = teavm_local_3;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33658, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33659, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33660, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_jt_DateFormatSymbols_getShortWeekdays(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33661, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(8)));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays) = teavm_local_1;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33662, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(33663, teavm_nullCheck(teavm_local_2))));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33664, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(33665, teavm_nullCheck(teavm_local_3))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33666, meth_otciu_CLDRHelper_resolveShortWeekdays(teavm_local_2, teavm_local_3));
        teavm_local_5 = INT32_C(0);
        while (1) {
            if ((teavm_local_5 >= INT32_C(7))) {
                goto teavm_label_1;
            }
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays);
            teavm_local_6 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33667, teavm_nullCheck(teavm_local_4));
            teavm_local_7 = teavm_local_4;
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(33668, teavm_checkBounds(teavm_local_5, teavm_local_7));
            teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_7, void*, teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33669, teavm_nullCheck(teavm_local_1));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(33670, teavm_checkBounds(teavm_local_6, teavm_local_1));
            teavm_gc_writeBarrier(teavm_local_1);
            TEAVM_ARRAY_AT(teavm_local_1, void*, teavm_local_5) = teavm_local_2;
        }
    }
teavm_label_1:;
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33671, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33672, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33673, teavm_checkcast(teavm_local_2, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jt_DateFormatSymbols_getWeekdays(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33674, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(8)));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays) = teavm_local_1;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33675, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(33676, teavm_nullCheck(teavm_local_2))));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33677, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(33678, teavm_nullCheck(teavm_local_3))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33679, meth_otciu_CLDRHelper_resolveWeekdays(teavm_local_2, teavm_local_3));
        teavm_local_5 = INT32_C(0);
        while (1) {
            if ((teavm_local_5 >= INT32_C(7))) {
                goto teavm_label_1;
            }
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays);
            teavm_local_6 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33680, teavm_nullCheck(teavm_local_4));
            teavm_local_7 = teavm_local_4;
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(33681, teavm_checkBounds(teavm_local_5, teavm_local_7));
            teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_7, void*, teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33682, teavm_nullCheck(teavm_local_1));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(33683, teavm_checkBounds(teavm_local_6, teavm_local_1));
            teavm_gc_writeBarrier(teavm_local_1);
            TEAVM_ARRAY_AT(teavm_local_1, void*, teavm_local_5) = teavm_local_2;
        }
    }
teavm_label_1:;
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33684, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33685, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33686, teavm_checkcast(teavm_local_2, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_DateFormatSymbols_hashCode(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_localPatternChars);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33687, meth_jl_String_hashCode(TEAVM_WITH_CALL_SITE_ID(33688, teavm_nullCheck(teavm_local_1))));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_ampms);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33689, teavm_nullCheck(teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(33690, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33691, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33692, meth_jl_String_hashCode(teavm_local_6)));
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_eras);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33693, teavm_nullCheck(teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(33694, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33695, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33696, meth_jl_String_hashCode(teavm_local_6)));
        teavm_local_5 = (teavm_local_7 + INT32_C(1));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_months);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33697, teavm_nullCheck(teavm_local_3));
    teavm_local_7 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_4 = INT32_C(0);
    while (1) {
        if (!(teavm_local_4 < teavm_local_7)) break;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(33698, teavm_checkLowerBound(teavm_local_4));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33699, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33700, meth_jl_String_hashCode(teavm_local_6)));
        teavm_local_4 = (teavm_local_5 + INT32_C(1));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortMonths);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33701, teavm_nullCheck(teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(33702, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33703, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33704, meth_jl_String_hashCode(teavm_local_6)));
        teavm_local_5 = (teavm_local_7 + INT32_C(1));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_shortWeekdays);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33705, teavm_nullCheck(teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(33706, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33707, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33708, meth_jl_String_hashCode(teavm_local_6)));
        teavm_local_5 = (teavm_local_7 + INT32_C(1));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_weekdays);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33709, teavm_nullCheck(teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(33710, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(33711, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33712, meth_jl_String_hashCode(teavm_local_6)));
        teavm_local_5 = (teavm_local_7 + INT32_C(1));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatSymbols, fld_zoneStrings);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33713, teavm_nullCheck(teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(33714, teavm_checkLowerBound(teavm_local_5));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7);
        teavm_local_9 = INT32_C(0);
        while (1) {
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(33715, teavm_nullCheck(teavm_local_8));
            teavm_local_10 = teavm_local_8;
            if ((teavm_local_9 >= TEAVM_ARRAY_LENGTH(teavm_local_10))) {
                goto teavm_label_8;
            }
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(33716, teavm_checkLowerBound(teavm_local_9));
            if ((TEAVM_ARRAY_AT(teavm_local_10, void*, teavm_local_9) != NULL)) {
                teavm_local_1 = TEAVM_ARRAY_AT(teavm_local_10, void*, teavm_local_9);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
                teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(33717, meth_jl_String_hashCode(TEAVM_WITH_CALL_SITE_ID(33718, teavm_nullCheck(teavm_local_1)))));
            }
            teavm_local_9 = (teavm_local_9 + INT32_C(1));
        }
    teavm_label_8:;
        teavm_local_5 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jt_DateFormatSymbols(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1645 || tag >= 1647) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatSymbols_Cls[10];
alignas(8) jt_DateFormatSymbols_VT jt_DateFormatSymbols_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatSymbols), sizeof(void*)),
        .flags = 0,
        .tag = 1645,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormatSymbols,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_DateFormatSymbols_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DateFormatSymbols_hashCode,
    .virt_equals = &meth_jt_DateFormatSymbols_equals,
    .virt_clone = &meth_jt_DateFormatSymbols_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getShortWeekdays = &meth_jt_DateFormatSymbols_getShortWeekdays,
    .virt_getShortMonths = &meth_jt_DateFormatSymbols_getShortMonths,
    .virt_getMonths = &meth_jt_DateFormatSymbols_getMonths,
    .virt_getEras = &meth_jt_DateFormatSymbols_getEras,
    .virt_getWeekdays = &meth_jt_DateFormatSymbols_getWeekdays,
    .virt_getAmPmStrings = &meth_jt_DateFormatSymbols_getAmPmStrings
};
static int16_t teavm_classLayouts_jt_DateFormatSymbols_Cls[10] = {
INT16_C(9), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_locale), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_localPatternChars), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_ampms), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_eras), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_months), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_shortMonths), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_shortWeekdays), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_weekdays), (int16_t) offsetof(cls_jt_DateFormatSymbols, fld_zoneStrings)
};
void sysinitclass_jt_DateFormatSymbols() {
}
