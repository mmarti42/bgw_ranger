#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DecimalFormat@d1.h"

extern void sysinitclass_jt_DecimalFormat_1();
typedef struct cls_jt_DecimalFormat_1 {
    struct TeaVM_Object parent;
} cls_jt_DecimalFormat_1;
extern TeaVM_Array* sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
extern void meth_jt_DecimalFormat_1__clinit_();
extern void initclass_jt_DecimalFormat_1();
extern int32_t supertypeof_jt_DecimalFormat_1(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DecimalFormat_1_VT {
    jl_Object_VT parent;
} jt_DecimalFormat_1_VT;
extern jt_DecimalFormat_1_VT jt_DecimalFormat_1_Cls;
