#include "DecimalFormatSymbols.h"
#include "../lang/Object.h"
#include "../util/Locale.h"
#include "../../org/teavm/classlib/impl/unicode/CLDRHelper.h"
#include "../../../resources/org/teavm/classlib/impl/unicode/DecimalData.h"
#include "../lang/AssertionError.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"

void meth_jt_DecimalFormatSymbols__init__0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9307, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9308, meth_jt_DecimalFormatSymbols__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormatSymbols__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9309, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_locale) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(9310, meth_jt_DecimalFormatSymbols_initData(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormatSymbols_initData(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_locale);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9311, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(9312, teavm_nullCheck(teavm_local_1))));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_locale);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9313, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(9314, teavm_nullCheck(teavm_local_2))));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9315, meth_otciu_CLDRHelper_resolveDecimalData(teavm_local_1, teavm_local_2));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_zeroDigit) = INT32_C(48);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_groupingSeparator) = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(9316, TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, groupingSeparator)));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_decimalSeparator) = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(9317, TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, decimalSeparator)));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_perMill) = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(9318, TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, perMille)));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_percent) = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(9319, TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, percent)));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_digit) = INT32_C(35);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_patternSeparator) = INT32_C(59);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9320, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, naN)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_nan) = teavm_local_1;
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9321, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, infinity)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_infinity) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_minusSign) = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(9322, TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, minusSign)));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_monetaryDecimalSeparator) = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(9323, TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, decimalSeparator)));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9324, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_3, cls_otciu_DecimalData, exponentSeparator)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_exponentSeparator) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DecimalFormatSymbols_getZeroDigit(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_zeroDigit);
}
int32_t meth_jt_DecimalFormatSymbols_getGroupingSeparator(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_groupingSeparator);
}
int32_t meth_jt_DecimalFormatSymbols_getPerMill(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_perMill);
}
int32_t meth_jt_DecimalFormatSymbols_getPercent(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_percent);
}
void* meth_jt_DecimalFormatSymbols_getLocale(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_locale);
}
int32_t meth_jt_DecimalFormatSymbols_getDecimalSeparator(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_decimalSeparator);
}
void* meth_jt_DecimalFormatSymbols_getNaN(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_nan);
}
void* meth_jt_DecimalFormatSymbols_getInfinity(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_infinity);
}
int32_t meth_jt_DecimalFormatSymbols_getMinusSign(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_minusSign);
}
void* meth_jt_DecimalFormatSymbols_getExponentSeparator(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatSymbols, fld_exponentSeparator);
}
void* meth_jt_DecimalFormatSymbols_clone(void* teavm_this_) {
    void* teavm_local_1;
    void * volatile teavm_spill_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_TRY
        teavm_spill_1 = teavm_local_1;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9325, meth_jl_Object_clone(teavm_this_));
        teavm_spill_1 = teavm_local_1;
    TEAVM_CATCH
        // CATCH java.lang.CloneNotSupportedException
        case 1: {
            teavm_local_1 = teavm_spill_1;
            teavm_local_2 = teavm_catchException();
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9326, meth_otr_Allocator_allocate(&jl_AssertionError_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(9327, meth_jl_AssertionError__init_(teavm_local_3, TEAVM_GET_STRING(684), teavm_local_2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(9328, meth_otr_ExceptionHandling_throwException(teavm_local_3));
            TEAVM_UNREACHABLE
            break;
        }
    TEAVM_END_TRY
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_jt_DecimalFormatSymbols(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 369 || tag >= 371) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DecimalFormatSymbols_Cls[5];
alignas(8) jt_DecimalFormatSymbols_VT jt_DecimalFormatSymbols_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormatSymbols), sizeof(void*)),
        .flags = 0,
        .tag = 369,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DecimalFormatSymbols,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_DecimalFormatSymbols_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jt_DecimalFormatSymbols_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getPercent = &meth_jt_DecimalFormatSymbols_getPercent,
    .virt_getMinusSign = &meth_jt_DecimalFormatSymbols_getMinusSign,
    .virt_getGroupingSeparator = &meth_jt_DecimalFormatSymbols_getGroupingSeparator,
    .virt_getNaN = &meth_jt_DecimalFormatSymbols_getNaN,
    .virt_getExponentSeparator = &meth_jt_DecimalFormatSymbols_getExponentSeparator,
    .virt_getInfinity = &meth_jt_DecimalFormatSymbols_getInfinity,
    .virt_getZeroDigit = &meth_jt_DecimalFormatSymbols_getZeroDigit,
    .virt_getLocale = &meth_jt_DecimalFormatSymbols_getLocale,
    .virt_getDecimalSeparator = &meth_jt_DecimalFormatSymbols_getDecimalSeparator,
    .virt_getPerMill = &meth_jt_DecimalFormatSymbols_getPerMill
};
static int16_t teavm_classLayouts_jt_DecimalFormatSymbols_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jt_DecimalFormatSymbols, fld_locale), (int16_t) offsetof(cls_jt_DecimalFormatSymbols, fld_nan), (int16_t) offsetof(cls_jt_DecimalFormatSymbols, fld_infinity), (int16_t) offsetof(cls_jt_DecimalFormatSymbols, fld_exponentSeparator)
};
void sysinitclass_jt_DecimalFormatSymbols() {
}
