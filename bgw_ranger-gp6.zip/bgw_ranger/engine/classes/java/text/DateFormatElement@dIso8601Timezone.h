#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dIso8601Timezone.h"

extern void sysinitclass_jt_DateFormatElement_Iso8601Timezone();
typedef struct cls_jt_DateFormatElement_Iso8601Timezone {
    struct cls_jt_DateFormatElement parent;
    int32_t fld_size;
} cls_jt_DateFormatElement_Iso8601Timezone;
extern void meth_jt_DateFormatElement_Iso8601Timezone__init_(void*, int32_t);
extern void meth_jt_DateFormatElement_Iso8601Timezone_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_Iso8601Timezone_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_Iso8601Timezone_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_Iso8601Timezone_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_Iso8601Timezone(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_Iso8601Timezone_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_Iso8601Timezone_VT;
extern jt_DateFormatElement_Iso8601Timezone_VT jt_DateFormatElement_Iso8601Timezone_Cls;
