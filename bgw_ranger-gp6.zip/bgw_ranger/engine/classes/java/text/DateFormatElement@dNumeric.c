#include "DateFormatElement@dNumeric.h"
#include "DateFormatElement.h"
#include "../lang/Math.h"
#include "../util/Calendar.h"
#include "../lang/Integer.h"
#include "../lang/String.h"
#include "../lang/StringBuffer.h"
#include "ParsePosition.h"
#include "../lang/Object.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/Objects.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_Numeric__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18385, meth_jt_DateFormatElement__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_field) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_length) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_maxLength) = TEAVM_WITH_CALL_SITE_ID(18386, meth_jl_Math_max(teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Numeric_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_field);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18387, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18388, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_get_2)(teavm_local_1, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18389, TEAVM_METHOD(teavm_this_, jt_DateFormatElement_Numeric_VT, virt_processBeforeFormat)(teavm_this_, teavm_local_3));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18390, meth_jl_Integer_toString_0(teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18391, teavm_nullCheck(teavm_local_5));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(18392, meth_jl_String_length(teavm_local_5));
    while (1) {
        if (!(teavm_local_6 < TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_length))) break;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18393, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(18394, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18395, teavm_nullCheck(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(18396, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_5));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Numeric_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18397, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(18398, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18399, teavm_nullCheck(teavm_local_1));
        if ((teavm_local_6 >= TEAVM_WITH_CALL_SITE_ID(18400, meth_jl_String_length(teavm_local_1)))) {
            goto teavm_label_1;
        }
        if ((teavm_local_5 >= TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_maxLength))) {
            goto teavm_label_1;
        }
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(18401, meth_jl_String_charAt(teavm_local_1, teavm_local_6));
        if ((teavm_local_7 < INT32_C(48))) {
            goto teavm_label_1;
        }
        if ((teavm_local_7 > INT32_C(57))) {
            goto teavm_label_1;
        }
        teavm_local_4 = ((teavm_local_4 * INT32_C(10)) + (teavm_local_7 - INT32_C(48)));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
teavm_label_1:;
    if ((teavm_local_5 < TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_length))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(18402, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(18403, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3))));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(18404, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setIndex)(teavm_local_3, teavm_local_6));
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_field);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(18405, TEAVM_METHOD(teavm_this_, jt_DateFormatElement_Numeric_VT, virt_processAfterParse)(teavm_this_, teavm_local_4));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18406, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(18407, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_set_1)(teavm_local_2, teavm_local_8, teavm_local_9));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_Numeric_processBeforeFormat(void* teavm_this_, int32_t teavm_local_1) {
    return teavm_local_1;
}
int32_t meth_jt_DateFormatElement_Numeric_processAfterParse(void* teavm_this_, int32_t teavm_local_1) {
    return teavm_local_1;
}
int32_t meth_jt_DateFormatElement_Numeric_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18408, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(18409, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18410, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_Numeric_Cls, &supertypeof_jt_DateFormatElement_Numeric));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_field);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18411, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = ((!((teavm_local_2 == TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_Numeric, fld_field)) && (TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_length) == TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_Numeric, fld_length)))) ? INT32_C(0) : INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_Numeric_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18412, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(2)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_field);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18413, meth_jl_Integer_valueOf_0(teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_4;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18414, meth_jl_Integer_valueOf_0(TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Numeric, fld_length)));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(1)) = teavm_local_4;
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18415, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t supertypeof_jt_DateFormatElement_Numeric(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2266 || tag >= 2274) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_Numeric_VT jt_DateFormatElement_Numeric_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_Numeric), sizeof(void*)),
        .flags = 0,
        .tag = 2266,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(2707),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormatElement_Numeric,
        .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
        .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DateFormatElement_Numeric_hashCode,
    .virt_equals = &meth_jt_DateFormatElement_Numeric_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format = &meth_jt_DateFormatElement_Numeric_format,
    .virt_parse = &meth_jt_DateFormatElement_Numeric_parse,
    .virt_processAfterParse = &meth_jt_DateFormatElement_Numeric_processAfterParse,
    .virt_processBeforeFormat = &meth_jt_DateFormatElement_Numeric_processBeforeFormat
};
void sysinitclass_jt_DateFormatElement_Numeric() {
}
