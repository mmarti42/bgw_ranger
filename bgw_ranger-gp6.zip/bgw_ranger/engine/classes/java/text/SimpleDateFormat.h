#pragma once
#include "../../../runtime.h"
#include "DateFormat.h"
#include "SimpleDateFormat.h"

extern void sysinitclass_jt_SimpleDateFormat();
typedef struct cls_jt_SimpleDateFormat {
    struct cls_jt_DateFormat parent;
    void* fld_dateFormatSymbols;
    TeaVM_Array* fld_elements;
    void* fld_pattern;
    void* fld_locale;
} cls_jt_SimpleDateFormat;
extern void meth_jt_SimpleDateFormat__init_(void*, void*);
extern void meth_jt_SimpleDateFormat__init__0(void*, void*, void*);
extern void meth_jt_SimpleDateFormat__init__1(void*, void*, void*);
extern void* meth_jt_SimpleDateFormat_format(void*, void*, void*, void*);
extern void meth_jt_SimpleDateFormat_applyPattern(void*, void*);
extern void meth_jt_SimpleDateFormat_reparsePattern(void*);
extern void* meth_jt_SimpleDateFormat_parse(void*, void*, void*);
extern void* meth_jt_SimpleDateFormat_toPattern(void*);
extern int32_t meth_jt_SimpleDateFormat_equals(void*, void*);
extern int32_t meth_jt_SimpleDateFormat_hashCode(void*);
extern int32_t supertypeof_jt_SimpleDateFormat(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_SimpleDateFormat_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_parse_2)(void*, void*, void*); // 14
    void (*pad1)(); // 15
    void (*virt_setLenient)(void*, int32_t); // 16
    void (*pad2)(); // 17
    void (*pad3)(); // 18
    void* (*virt_getTimeZone)(void*); // 19
    void (*virt_setTimeZone)(void*, void*); // 20
    void* (*virt_parse_1)(void*, void*); // 21
    void* (*virt_format_4)(void*, void*, void*, void*); // 22
    void* (*virt_toPattern)(void*); // 23
    void (*pad4)(); // 24
    void (*pad5)(); // 25
    void (*pad6)(); // 26
    void (*pad7)(); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*pad8)(); // 29
    void (*pad9)(); // 30
    void (*pad10)(); // 31
    void (*pad11)(); // 32
    void (*pad12)(); // 33
    void (*pad13)(); // 34
    void (*pad14)(); // 35
    void (*pad15)(); // 36
    void (*pad16)(); // 37
    void (*pad17)(); // 38
    void (*pad18)(); // 39
    void (*pad19)(); // 40
    void (*pad20)(); // 41
    void (*pad21)(); // 42
    void (*pad22)(); // 43
    void (*pad23)(); // 44
    void (*pad24)(); // 45
    void (*pad25)(); // 46
    void (*pad26)(); // 47
    void (*virt_applyPattern)(void*, void*); // 48
    void (*pad27)(); // 49
} jt_SimpleDateFormat_VT;
extern jt_SimpleDateFormat_VT jt_SimpleDateFormat_Cls;
