#pragma once
#include "../../../runtime.h"
#include "DateFormatElement@dNumeric.h"
#include "DateFormatElement@dNumericWeekday.h"

extern void sysinitclass_jt_DateFormatElement_NumericWeekday();
typedef struct cls_jt_DateFormatElement_NumericWeekday {
    struct cls_jt_DateFormatElement_Numeric parent;
} cls_jt_DateFormatElement_NumericWeekday;
extern void meth_jt_DateFormatElement_NumericWeekday__init_(void*, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericWeekday_processBeforeFormat(void*, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericWeekday_processAfterParse(void*, int32_t);
extern int32_t supertypeof_jt_DateFormatElement_NumericWeekday(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_NumericWeekday_VT {
    jt_DateFormatElement_Numeric_VT parent;
} jt_DateFormatElement_NumericWeekday_VT;
extern jt_DateFormatElement_NumericWeekday_VT jt_DateFormatElement_NumericWeekday_Cls;
