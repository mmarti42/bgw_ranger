#include "DateFormatElement@dIso8601Timezone.h"
#include "DateFormatElement.h"
#include "../util/Calendar.h"
#include "../util/TimeZone.h"
#include "../lang/StringBuffer.h"
#include "ParsePosition.h"
#include "../lang/String.h"
#include "../../../strings.h"
#include "../lang/Character.h"
#include "../lang/Object.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Integer.h"
#include "../util/Objects.h"

void meth_jt_DateFormatElement_Iso8601Timezone__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18977, meth_jt_DateFormatElement__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Iso8601Timezone_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    int64_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18978, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18979, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_getTimeZone)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18980, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_getTimeInMillis)(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = (TEAVM_WITH_CALL_SITE_ID(18981, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(18982, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_TimeZone_VT, virt_getOffset)(teavm_tmp_ptr_0, teavm_local_4))) / INT32_C(60000));
    if ((!teavm_local_5)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18983, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(18984, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(90)));
    } else {
        if ((teavm_local_5 > INT32_C(0))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18985, teavm_nullCheck(teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(18986, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(43)));
        } else {
            teavm_local_5 = (-teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18987, teavm_nullCheck(teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(18988, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(45)));
        }
        teavm_local_6 = (teavm_local_5 / INT32_C(60));
        teavm_local_7 = (teavm_local_5 % INT32_C(60));
        teavm_local_8 = (teavm_local_6 / INT32_C(10));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18989, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_2)(teavm_local_2, teavm_local_8));
        teavm_local_8 = (teavm_local_6 % INT32_C(10));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(18990, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(18991, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_2)(teavm_tmp_ptr_0, teavm_local_8)));
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) >= INT32_C(3))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(18992, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(58)));
        }
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) > INT32_C(1))) {
            teavm_local_8 = (teavm_local_7 / INT32_C(10));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18993, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_2)(teavm_local_2, teavm_local_8));
            teavm_local_8 = (teavm_local_7 % INT32_C(10));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(18994, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(18995, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_2)(teavm_tmp_ptr_0, teavm_local_8)));
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Iso8601Timezone_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18996, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18997, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
    teavm_local_5 = (teavm_local_4 + INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18998, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(18999, meth_jl_String_charAt(teavm_local_1, teavm_local_4));
    if ((teavm_local_6 == INT32_C(43))) {
        teavm_local_7 = INT32_C(1);
    } else {
        if ((teavm_local_6 != INT32_C(45))) {
            if ((teavm_local_6 != INT32_C(90))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(19000, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_5));
                goto teavm_label_1;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(19001, meth_ju_TimeZone_getTimeZone(TEAVM_GET_STRING(1651)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(19002, teavm_nullCheck(teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(19003, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_setTimeZone)(teavm_local_2, teavm_local_8));
            goto teavm_label_1;
        }
        teavm_local_7 = -INT32_C(1);
    }
    teavm_local_9 = INT32_C(2);
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) > INT32_C(1))) {
        teavm_local_9 = INT32_C(4);
    }
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) >= INT32_C(3))) {
        teavm_local_9 = (teavm_local_9 + INT32_C(1));
    }
    if (((teavm_local_5 + teavm_local_9) > TEAVM_WITH_CALL_SITE_ID(19004, meth_jl_String_length(teavm_local_1)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(19005, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_5));
    } else {
        if (TEAVM_WITH_CALL_SITE_ID(19006, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(19007, meth_jl_String_charAt(teavm_local_1, teavm_local_5))))) {
            teavm_local_10 = (teavm_local_5 + INT32_C(1));
            if (TEAVM_WITH_CALL_SITE_ID(19008, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(19009, meth_jl_String_charAt(teavm_local_1, teavm_local_10))))) {
                goto teavm_label_2;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(19010, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_5));
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_11 = (TEAVM_WITH_CALL_SITE_ID(19011, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(19012, meth_jl_String_charAt(teavm_local_1, teavm_local_5)), INT32_C(10))) * INT32_C(10));
        teavm_local_5 = (teavm_local_10 + INT32_C(1));
        teavm_local_12 = (teavm_local_11 + TEAVM_WITH_CALL_SITE_ID(19013, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(19014, meth_jl_String_charAt(teavm_local_1, teavm_local_10)), INT32_C(10))));
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) >= INT32_C(3))) {
            teavm_local_10 = (teavm_local_5 + INT32_C(1));
            if ((TEAVM_WITH_CALL_SITE_ID(19015, meth_jl_String_charAt(teavm_local_1, teavm_local_5)) != INT32_C(58))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(19016, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_10));
                goto teavm_label_1;
            }
            teavm_local_5 = teavm_local_10;
        }
        teavm_local_13 = INT32_C(0);
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size) > INT32_C(1))) {
            if (TEAVM_WITH_CALL_SITE_ID(19017, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(19018, meth_jl_String_charAt(teavm_local_1, teavm_local_5))))) {
                teavm_local_10 = (teavm_local_5 + INT32_C(1));
                if (TEAVM_WITH_CALL_SITE_ID(19019, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(19020, meth_jl_String_charAt(teavm_local_1, teavm_local_10))))) {
                    goto teavm_label_3;
                }
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(19021, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_5));
            goto teavm_label_1;
        teavm_label_3:;
            teavm_local_11 = (TEAVM_WITH_CALL_SITE_ID(19022, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(19023, meth_jl_String_charAt(teavm_local_1, teavm_local_5)), INT32_C(10))) * INT32_C(10));
            teavm_local_5 = (teavm_local_10 + INT32_C(1));
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(19024, meth_jl_String_charAt(teavm_local_1, teavm_local_10));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_13 = (teavm_local_11 + TEAVM_WITH_CALL_SITE_ID(19025, meth_jl_Character_digit(teavm_local_14, INT32_C(10))));
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(19026, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setIndex)(teavm_local_3, teavm_local_5));
        teavm_local_5 = (teavm_local_7 * teavm_local_12);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(19027, meth_jt_DateFormatElement_getStaticTimeZone(teavm_local_5, teavm_local_13));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(19028, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(19029, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_setTimeZone)(teavm_local_2, teavm_local_8));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_Iso8601Timezone_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19030, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(19031, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(19032, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_Iso8601Timezone_Cls, &supertypeof_jt_DateFormatElement_Iso8601Timezone));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(19033, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = ((teavm_local_2 != TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_Iso8601Timezone, fld_size)) ? INT32_C(0) : INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_Iso8601Timezone_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19034, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(1)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Iso8601Timezone, fld_size);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(19035, meth_jl_Integer_valueOf_0(teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_4;
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19036, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t supertypeof_jt_DateFormatElement_Iso8601Timezone(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2274 || tag >= 2276) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_Iso8601Timezone_VT jt_DateFormatElement_Iso8601Timezone_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_Iso8601Timezone), sizeof(void*)),
            .flags = 0,
            .tag = 2274,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(2741),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_Iso8601Timezone,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_Iso8601Timezone_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_Iso8601Timezone_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_Iso8601Timezone_format,
        .virt_parse = &meth_jt_DateFormatElement_Iso8601Timezone_parse
    }
};
void sysinitclass_jt_DateFormatElement_Iso8601Timezone() {
}
