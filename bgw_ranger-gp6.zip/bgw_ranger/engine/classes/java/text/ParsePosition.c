#include "ParsePosition.h"
#include "../lang/Object.h"
#include "../../../strings.h"

void meth_jt_ParsePosition__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(32610, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_ParsePosition, fld_errorIndex) = -INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jt_ParsePosition, fld_currentPosition) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_ParsePosition_getErrorIndex(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_ParsePosition, fld_errorIndex);
}
int32_t meth_jt_ParsePosition_getIndex(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_ParsePosition, fld_currentPosition);
}
void meth_jt_ParsePosition_setErrorIndex(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_ParsePosition, fld_errorIndex) = teavm_local_1;
}
void meth_jt_ParsePosition_setIndex(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_ParsePosition, fld_currentPosition) = teavm_local_1;
}
int32_t supertypeof_jt_ParsePosition(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1617 || tag >= 1619) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_ParsePosition_VT jt_ParsePosition_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_ParsePosition), sizeof(void*)),
        .flags = 0,
        .tag = 1617,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_ParsePosition,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getErrorIndex = &meth_jt_ParsePosition_getErrorIndex,
    .virt_setErrorIndex = &meth_jt_ParsePosition_setErrorIndex,
    .virt_getIndex = &meth_jt_ParsePosition_getIndex,
    .virt_setIndex = &meth_jt_ParsePosition_setIndex
};
void sysinitclass_jt_ParsePosition() {
}
