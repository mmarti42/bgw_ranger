#include "Annotation.h"
#include "../lang/Object.h"
#include "../../../strings.h"

int32_t supertypeof_jt_Annotation(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1569 || tag >= 1571) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_Annotation_VT jt_Annotation_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_Annotation), sizeof(void*)),
            .flags = 0,
            .tag = 1569,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_Annotation,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_jt_Annotation() {
}
