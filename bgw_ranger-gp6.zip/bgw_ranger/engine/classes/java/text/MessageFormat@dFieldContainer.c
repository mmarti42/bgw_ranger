#include "MessageFormat@dFieldContainer.h"
#include "../lang/Object.h"
#include "../../../strings.h"

void meth_jt_MessageFormat_FieldContainer__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, void* teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34538, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat_FieldContainer, fld_start) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat_FieldContainer, fld_end) = teavm_local_2;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat_FieldContainer, fld_attribute) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat_FieldContainer, fld_value) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_MessageFormat_FieldContainer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1699 || tag >= 1701) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_MessageFormat_FieldContainer_Cls[3];
alignas(8) jt_MessageFormat_FieldContainer_VT jt_MessageFormat_FieldContainer_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_MessageFormat_FieldContainer), sizeof(void*)),
            .flags = 0,
            .tag = 1699,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_MessageFormat_FieldContainer,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jt_MessageFormat_FieldContainer_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_jt_MessageFormat_FieldContainer_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_MessageFormat_FieldContainer, fld_attribute), (int16_t) offsetof(cls_jt_MessageFormat_FieldContainer, fld_value)
};
void sysinitclass_jt_MessageFormat_FieldContainer() {
}
