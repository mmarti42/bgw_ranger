#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dBaseTimezone.h"

extern void sysinitclass_jt_DateFormatElement_BaseTimezone();
typedef struct cls_jt_DateFormatElement_BaseTimezone {
    struct cls_jt_DateFormatElement parent;
    void* fld_locale;
    void* fld_searchTrie;
} cls_jt_DateFormatElement_BaseTimezone;
extern void* sfld_jt_DateFormatElement_BaseTimezone_cache;
extern void* sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie;
extern void meth_jt_DateFormatElement_BaseTimezone__init_(void*, void*);
extern void meth_jt_DateFormatElement_BaseTimezone_parse(void*, void*, void*, void*);
extern void* meth_jt_DateFormatElement_BaseTimezone_match(void*, void*, void*, void*);
extern void meth_jt_DateFormatElement_BaseTimezone_prepareTrie(void*);
extern void meth_jt_DateFormatElement_BaseTimezone_prepareIdTrie();
extern int32_t meth_jt_DateFormatElement_BaseTimezone_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_BaseTimezone_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_BaseTimezone(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_BaseTimezone_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_format)(void*, void*, void*); // 11
    void (*virt_parse)(void*, void*, void*, void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void* (*virt_match)(void*, void*, void*, void*); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} jt_DateFormatElement_BaseTimezone_VT;
extern jt_DateFormatElement_BaseTimezone_VT jt_DateFormatElement_BaseTimezone_Cls;
