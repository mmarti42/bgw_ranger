#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DecimalFormat@dConstants.h"

extern void sysinitclass_jt_DecimalFormat_Constants();
typedef struct cls_jt_DecimalFormat_Constants {
    struct TeaVM_Object parent;
} cls_jt_DecimalFormat_Constants;
extern void* sfld_jt_DecimalFormat_Constants_doubleAnalysisResult;
extern void* sfld_jt_DecimalFormat_Constants_floatAnalysisResult;
extern void meth_jt_DecimalFormat_Constants__clinit_();
extern void initclass_jt_DecimalFormat_Constants();
extern int32_t supertypeof_jt_DecimalFormat_Constants(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DecimalFormat_Constants_VT {
    jl_Object_VT parent;
} jt_DecimalFormat_Constants_VT;
extern jt_DecimalFormat_Constants_VT jt_DecimalFormat_Constants_Cls;
