#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DateFormatElement@dTrieNodeBuilder.h"

extern void sysinitclass_jt_DateFormatElement_TrieNodeBuilder();
typedef struct cls_jt_DateFormatElement_TrieNodeBuilder {
    struct TeaVM_Object parent;
    char16_t fld_ch;
    void* fld_next;
    void* fld_tz;
    void* fld_sibling;
} cls_jt_DateFormatElement_TrieNodeBuilder;
extern void meth_jt_DateFormatElement_TrieNodeBuilder__init_(void*);
extern int32_t supertypeof_jt_DateFormatElement_TrieNodeBuilder(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_TrieNodeBuilder_VT {
    jl_Object_VT parent;
} jt_DateFormatElement_TrieNodeBuilder_VT;
extern jt_DateFormatElement_TrieNodeBuilder_VT jt_DateFormatElement_TrieNodeBuilder_Cls;
