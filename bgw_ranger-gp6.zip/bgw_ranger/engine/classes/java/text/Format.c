#include "Format.h"
#include "../lang/Object.h"
#include "../lang/StringBuffer.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "FieldPosition.h"
#include "AttributedString.h"
#include "ParsePosition.h"
#include "../lang/String.h"
#include "../lang/IllegalArgumentException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"

void meth_jt_Format__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20325, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_jt_Format_format(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20326, meth_otr_Allocator_allocate(&jl_StringBuffer_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20327, meth_jl_StringBuffer__init__0(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20328, meth_otr_Allocator_allocate(&jt_FieldPosition_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(20329, meth_jt_FieldPosition__init_(teavm_local_3, INT32_C(0)));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20330, TEAVM_METHOD(teavm_this_, jt_Format_VT, virt_format_2)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20331, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20332, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_Format_formatToCharacterIterator(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20333, meth_otr_Allocator_allocate(&jt_AttributedString_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20334, meth_jt_Format_format(teavm_this_, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(20335, meth_jt_AttributedString__init_(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20336, TEAVM_METHOD(teavm_local_2, jt_AttributedString_VT, virt_getIterator)(teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_Format_upTo(void* teavm_local_1, void* teavm_local_2, void* teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20337, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(20338, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20339, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(20340, meth_jl_String_length(teavm_local_1));
    teavm_local_7 = INT32_C(0);
    teavm_local_8 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_6)) break;
        teavm_local_9 = (teavm_local_5 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(20341, meth_jl_String_charAt(teavm_local_1, teavm_local_5));
        if ((teavm_local_10 != INT32_C(39))) {
            if (((teavm_local_10 == teavm_local_4) && (!teavm_local_8))) {
                goto teavm_label_2;
            }
            teavm_local_7 = INT32_C(0);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20342, teavm_nullCheck(teavm_local_3));
            TEAVM_WITH_CALL_SITE_ID(20343, TEAVM_METHOD(teavm_local_3, jl_StringBuffer_VT, virt_append_3)(teavm_local_3, teavm_local_10));
        } else {
            if (teavm_local_7) {
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20344, teavm_nullCheck(teavm_local_3));
                TEAVM_WITH_CALL_SITE_ID(20345, TEAVM_METHOD(teavm_local_3, jl_StringBuffer_VT, virt_append_3)(teavm_local_3, INT32_C(39)));
            }
            teavm_local_8 = (teavm_local_8 ? INT32_C(0) : INT32_C(1));
            teavm_local_7 = INT32_C(1);
        }
        teavm_local_5 = teavm_local_9;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20346, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_5));
    teavm_local_11 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20347, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_9));
    teavm_local_11 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_11;
}
int32_t meth_jt_Format_upToWithQuotes(void* teavm_local_1, void* teavm_local_2, void* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20348, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(20349, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20350, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(20351, meth_jl_String_length(teavm_local_1));
    teavm_local_8 = INT32_C(1);
    teavm_local_9 = INT32_C(0);
    while (1) {
        if ((teavm_local_6 >= teavm_local_7)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(20352, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(20353, meth_jl_IllegalArgumentException__init__0(teavm_local_10, TEAVM_GET_STRING(2805)));
            TEAVM_WITH_CALL_SITE_ID(20354, meth_otr_ExceptionHandling_throwException(teavm_local_10));
            TEAVM_UNREACHABLE
        }
        teavm_local_11 = (teavm_local_6 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(20355, meth_jl_String_charAt(teavm_local_1, teavm_local_6));
        if ((teavm_local_12 == INT32_C(39))) {
            teavm_local_9 = (teavm_local_9 ? INT32_C(0) : INT32_C(1));
        }
        if ((!teavm_local_9)) {
            if ((teavm_local_12 == teavm_local_4)) {
                teavm_local_8 = (teavm_local_8 + -INT32_C(1));
            }
            if ((!teavm_local_8)) {
                goto teavm_label_1;
            }
            if ((teavm_local_12 == teavm_local_5)) {
                teavm_local_8 = (teavm_local_8 + INT32_C(1));
            }
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20356, teavm_nullCheck(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(20357, TEAVM_METHOD(teavm_local_3, jl_StringBuffer_VT, virt_append_3)(teavm_local_3, teavm_local_12));
        teavm_local_6 = teavm_local_11;
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20358, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_11));
    TEAVM_RELEASE_STACK;
    return INT32_C(1);
}
int32_t supertypeof_jt_Format(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1215 || tag >= 1229) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_Format_VT jt_Format_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_Format), sizeof(void*)),
        .flags = 0,
        .tag = 1215,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_Format,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_formatToCharacterIterator = &meth_jt_Format_formatToCharacterIterator,
    .virt_format_3 = &meth_jt_Format_format
};
void sysinitclass_jt_Format() {
}
