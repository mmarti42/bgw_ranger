#include "SimpleDateFormat.h"
#include "DateFormat.h"
#include "../util/Locale.h"
#include "DateFormatSymbols.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/GregorianCalendar.h"
#include "../util/Calendar.h"
#include "DateFormatElement.h"
#include "SimpleDatePatternParser.h"
#include "../../../arrayclass.h"
#include "../util/List.h"
#include "ParsePosition.h"
#include "../lang/String.h"
#include "../util/Arrays.h"
#include "../../../arrays/primitives/int.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "Format.h"

void meth_jt_SimpleDateFormat__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17378, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(17379, meth_jt_SimpleDateFormat__init__0(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jt_SimpleDateFormat__init__0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17380, meth_otr_Allocator_allocate(&jt_DateFormatSymbols_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(17381, meth_jt_DateFormatSymbols__init_(teavm_local_3, teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(17382, meth_jt_SimpleDateFormat__init__1(teavm_this_, teavm_local_1, teavm_local_3));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_locale) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jt_SimpleDateFormat__init__1(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(17383, meth_jt_DateFormat__init_(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17384, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17385, TEAVM_METHOD(teavm_local_2, jt_DateFormatSymbols_VT, virt_clone)(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17386, teavm_checkcast(teavm_local_3, &jt_DateFormatSymbols_Cls, &supertypeof_jt_DateFormatSymbols));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_dateFormatSymbols) = teavm_local_3;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17387, meth_ju_Locale_getDefault());
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_locale) = teavm_local_3;
    TEAVM_WITH_CALL_SITE_ID(17388, TEAVM_METHOD(teavm_this_, jt_SimpleDateFormat_VT, virt_applyPattern)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jt_SimpleDateFormat_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17389, meth_otr_Allocator_allocate(&ju_GregorianCalendar_Cls));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_locale);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(17390, meth_ju_GregorianCalendar__init__1(teavm_local_4, teavm_local_5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(17391, meth_ju_Calendar_setTime(teavm_local_4, teavm_local_1));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(17392, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17393, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getTimeZone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(17394, TEAVM_METHOD(teavm_local_4, ju_Calendar_VT, virt_setTimeZone)(teavm_local_4, teavm_local_5));
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_elements);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(17395, teavm_nullCheck(teavm_local_6));
    teavm_local_7 = TEAVM_ARRAY_LENGTH(teavm_local_6);
    teavm_local_8 = INT32_C(0);
    while (1) {
        if (!(teavm_local_8 < teavm_local_7)) break;
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(17396, teavm_checkLowerBound(teavm_local_8));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(17397, teavm_nullCheck(teavm_local_9));
        TEAVM_WITH_CALL_SITE_ID(17398, TEAVM_METHOD(teavm_local_9, jt_DateFormatElement_VT, virt_format)(teavm_local_9, teavm_local_4, teavm_local_2));
        teavm_local_8 = (teavm_local_8 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jt_SimpleDateFormat_applyPattern(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_pattern) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(17399, meth_jt_SimpleDateFormat_reparsePattern(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jt_SimpleDateFormat_reparsePattern(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17400, meth_otr_Allocator_allocate(&jt_SimpleDatePatternParser_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_dateFormatSymbols);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_locale);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(17401, meth_jt_SimpleDatePatternParser__init_(teavm_local_1, teavm_local_2, teavm_local_3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_pattern);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(17402, TEAVM_METHOD(teavm_local_1, jt_SimpleDatePatternParser_VT, virt_parsePattern)(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17403, TEAVM_METHOD(teavm_local_1, jt_SimpleDatePatternParser_VT, virt_getElements)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17404, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DateFormatElement_Cls), INT32_C(0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17405, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17406, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_toArray_0)(teavm_tmp_ptr_0, teavm_local_4)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17407, teavm_checkcast(teavm_local_4, teavm_getArrayClass((TeaVM_Class*) &jt_DateFormatElement_Cls), &teavm_isSupertypeOfArray));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_elements) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_SimpleDateFormat_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(5));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17408, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17409, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17410, teavm_checkcast(teavm_local_3, &ju_Calendar_Cls, &supertypeof_ju_Calendar));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17411, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(17412, meth_ju_Calendar_clear(teavm_local_4));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_elements);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(17413, teavm_nullCheck(teavm_local_5));
    teavm_local_6 = TEAVM_ARRAY_LENGTH(teavm_local_5);
    teavm_local_7 = INT32_C(0);
    while (1) {
        if ((teavm_local_7 >= teavm_local_6)) {
            goto teavm_label_3;
        }
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_1);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(17414, teavm_checkLowerBound(teavm_local_7));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17415, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17416, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17417, teavm_nullCheck(teavm_local_1));
        if ((teavm_local_7 > TEAVM_WITH_CALL_SITE_ID(17418, meth_jl_String_length(teavm_local_1)))) {
            goto teavm_label_2;
        }
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(17419, teavm_nullCheck(teavm_local_9));
        TEAVM_WITH_CALL_SITE_ID(17420, TEAVM_METHOD(teavm_local_9, jt_DateFormatElement_VT, virt_parse)(teavm_local_9, teavm_local_1, teavm_local_4, teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        if ((TEAVM_WITH_CALL_SITE_ID(17421, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getErrorIndex)(teavm_local_2)) >= INT32_C(0))) {
            goto teavm_label_4;
        }
        teavm_local_7 = (teavm_local_8 + INT32_C(1));
    }
teavm_label_4:;
    teavm_local_3 = NULL;
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17422, meth_ju_Calendar_getTime(teavm_local_4));
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_WITH_CALL_SITE_ID(17423, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(17424, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getErrorIndex)(teavm_local_2))));
    teavm_local_3 = NULL;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_SimpleDateFormat_toPattern(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_pattern);
}
int32_t meth_jt_SimpleDateFormat_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_local_1 == teavm_this_)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jt_SimpleDateFormat_Cls, &supertypeof_jt_SimpleDateFormat))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17425, teavm_checkcast(teavm_local_1, &jt_SimpleDateFormat_Cls, &supertypeof_jt_SimpleDateFormat));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((!TEAVM_WITH_CALL_SITE_ID(17426, meth_jt_DateFormat_equals(teavm_this_, teavm_local_3)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_elements);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17427, teavm_nullCheck(teavm_local_3));
            teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_SimpleDateFormat, fld_elements);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if (TEAVM_WITH_CALL_SITE_ID(17428, meth_ju_Arrays_equals(teavm_local_4, teavm_local_5))) {
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_dateFormatSymbols);
                teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_SimpleDateFormat, fld_dateFormatSymbols);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
                if (TEAVM_WITH_CALL_SITE_ID(17429, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17430, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DateFormatSymbols_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_7)))) {
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_locale);
                    teavm_local_7 = TEAVM_FIELD(teavm_local_3, cls_jt_SimpleDateFormat, fld_locale);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    if (TEAVM_WITH_CALL_SITE_ID(17431, meth_ju_Locale_equals(TEAVM_WITH_CALL_SITE_ID(17432, teavm_nullCheck(teavm_local_6)), teavm_local_7))) {
                        goto teavm_label_2;
                    }
                }
            }
            teavm_local_2 = INT32_C(0);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(1);
        teavm_label_1:;
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_SimpleDateFormat_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17433, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(4)));
    teavm_local_2 = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, int32_t, INT32_C(0)) = TEAVM_WITH_CALL_SITE_ID(17434, meth_jt_DateFormat_hashCode(teavm_this_));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_dateFormatSymbols);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_2, int32_t, INT32_C(1)) = TEAVM_WITH_CALL_SITE_ID(17435, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17436, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DateFormatSymbols_VT, virt_hashCode)(teavm_tmp_ptr_0)));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_elements);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_ARRAY_AT(teavm_local_2, int32_t, INT32_C(2)) = TEAVM_WITH_CALL_SITE_ID(17437, meth_ju_Arrays_hashCode(teavm_local_4));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDateFormat, fld_locale);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_2, int32_t, INT32_C(3)) = TEAVM_WITH_CALL_SITE_ID(17438, meth_ju_Locale_hashCode(TEAVM_WITH_CALL_SITE_ID(17439, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(17440, meth_ju_Arrays_hashCode_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t supertypeof_jt_SimpleDateFormat(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1225 || tag >= 1227) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_SimpleDateFormat_Cls[5];
alignas(8) jt_SimpleDateFormat_VT jt_SimpleDateFormat_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_SimpleDateFormat), sizeof(void*)),
        .flags = 0,
        .tag = 1225,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(1590),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_SimpleDateFormat,
        .superclass = (TeaVM_Class*) &jt_DateFormat_Cls,
        .layout = teavm_classLayouts_jt_SimpleDateFormat_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_SimpleDateFormat_hashCode,
    .virt_equals = &meth_jt_SimpleDateFormat_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format_2 = &meth_jt_DateFormat_format,
    .virt_formatToCharacterIterator = &meth_jt_Format_formatToCharacterIterator,
    .virt_parse_2 = &meth_jt_SimpleDateFormat_parse,
    .virt_setLenient = &meth_jt_DateFormat_setLenient,
    .virt_getTimeZone = &meth_jt_DateFormat_getTimeZone,
    .virt_setTimeZone = &meth_jt_DateFormat_setTimeZone,
    .virt_parse_1 = &meth_jt_DateFormat_parse,
    .virt_format_4 = &meth_jt_SimpleDateFormat_format,
    .virt_toPattern = &meth_jt_SimpleDateFormat_toPattern,
    .virt_format_3 = &meth_jt_Format_format,
    .virt_applyPattern = &meth_jt_SimpleDateFormat_applyPattern
};
static int16_t teavm_classLayouts_jt_SimpleDateFormat_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jt_SimpleDateFormat, fld_dateFormatSymbols), (int16_t) offsetof(cls_jt_SimpleDateFormat, fld_elements), (int16_t) offsetof(cls_jt_SimpleDateFormat, fld_pattern), (int16_t) offsetof(cls_jt_SimpleDateFormat, fld_locale)
};
void sysinitclass_jt_SimpleDateFormat() {
}
