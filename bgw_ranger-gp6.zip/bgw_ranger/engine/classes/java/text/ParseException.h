#pragma once
#include "../../../runtime.h"
#include "../lang/Exception.h"
#include "ParseException.h"

extern void sysinitclass_jt_ParseException();
typedef struct cls_jt_ParseException {
    struct cls_jl_Exception parent;
    int32_t fld_errorOffset;
} cls_jt_ParseException;
extern void meth_jt_ParseException__init_(void*, void*, int32_t);
extern int32_t supertypeof_jt_ParseException(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_ParseException_VT {
    jl_Exception_VT parent;
} jt_ParseException_VT;
extern jt_ParseException_VT jt_ParseException_Cls;
