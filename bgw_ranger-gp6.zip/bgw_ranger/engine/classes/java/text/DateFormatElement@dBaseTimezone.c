#include "DateFormatElement@dBaseTimezone.h"
#include "DateFormatElement.h"
#include "../util/Calendar.h"
#include "ParsePosition.h"
#include "DateFormatElement@dTrieNode.h"
#include "../lang/String.h"
#include "../util/Arrays.h"
#include "../lang/Character.h"
#include "../util/HashMap.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/Map.h"
#include "DateFormatElement@dTrieBuilder.h"
#include "../util/TimeZone.h"
#include "../lang/Object.h"
#include "../util/Objects.h"
#include "../../../arrayclass.h"
#include "../../../strings.h"

void* sfld_jt_DateFormatElement_BaseTimezone_cache;
void* sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie;
void meth_jt_DateFormatElement_BaseTimezone__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(37328, meth_jt_DateFormatElement__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_locale) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_BaseTimezone_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((!TEAVM_WITH_CALL_SITE_ID(37329, meth_jt_DateFormatElement_tryParseFixedTimeZone(teavm_local_1, teavm_local_2, teavm_local_3)))) {
        TEAVM_WITH_CALL_SITE_ID(37330, meth_jt_DateFormatElement_BaseTimezone_prepareTrie(teavm_this_));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(37331, TEAVM_METHOD(teavm_this_, jt_DateFormatElement_BaseTimezone_VT, virt_match)(teavm_this_, teavm_local_4, teavm_local_1, teavm_local_3));
        if ((teavm_local_5 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37332, teavm_nullCheck(teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(37333, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_setTimeZone)(teavm_local_2, teavm_local_5));
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(37334, meth_jt_DateFormatElement_BaseTimezone_prepareIdTrie());
            teavm_local_4 = sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37335, TEAVM_METHOD(teavm_this_, jt_DateFormatElement_BaseTimezone_VT, virt_match)(teavm_this_, teavm_local_4, teavm_local_1, teavm_local_3));
            if ((teavm_local_4 == NULL)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37336, teavm_nullCheck(teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_WITH_CALL_SITE_ID(37337, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(37338, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3))));
            } else {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37339, teavm_nullCheck(teavm_local_2));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_WITH_CALL_SITE_ID(37340, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_setTimeZone)(teavm_local_2, teavm_local_4));
            }
        }
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DateFormatElement_BaseTimezone_match(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37341, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37342, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
    teavm_local_5 = NULL;
    teavm_local_6 = teavm_local_4;
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_2);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(37343, teavm_nullCheck(teavm_local_1));
        if ((TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_childNodes) == NULL)) {
            goto teavm_label_5;
        }
        teavm_local_8 = TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_childNodes);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
        if ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(37344, teavm_nullCheck(teavm_local_8))) <= INT32_C(0))) {
            goto teavm_label_3;
        }
        if ((TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_tz) != NULL)) {
            teavm_local_5 = TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_tz);
            teavm_local_6 = teavm_local_4;
        }
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37345, teavm_nullCheck(teavm_local_2));
        if ((teavm_local_4 >= TEAVM_WITH_CALL_SITE_ID(37346, meth_jl_String_length(teavm_local_2)))) {
            goto teavm_label_4;
        }
        teavm_local_8 = TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_chars);
        teavm_local_9 = (teavm_local_4 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(37347, meth_ju_Arrays_binarySearch_5(teavm_local_8, TEAVM_WITH_CALL_SITE_ID(37348, meth_jl_Character_toLowerCase(TEAVM_WITH_CALL_SITE_ID(37349, meth_jl_String_charAt(teavm_local_2, teavm_local_4))))));
        if ((teavm_local_10 < INT32_C(0))) {
            goto teavm_label_6;
        }
        teavm_local_8 = TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_childNodes);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(37350, teavm_nullCheck(teavm_local_8));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(37351, teavm_checkBounds(teavm_local_10, teavm_local_8));
        teavm_local_1 = TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_10);
        teavm_local_4 = teavm_local_9;
    }
teavm_label_6:;
    teavm_local_5 = NULL;
    goto teavm_label_1;
teavm_label_5:;
    goto teavm_label_2;
teavm_label_4:;
    goto teavm_label_2;
teavm_label_3:;
teavm_label_2:;
    if ((TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_tz) != NULL)) {
        teavm_local_5 = TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNode, fld_tz);
    } else {
        teavm_local_4 = teavm_local_6;
    }
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_WITH_CALL_SITE_ID(37352, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setIndex)(teavm_local_3, teavm_local_4));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void meth_jt_DateFormatElement_BaseTimezone_prepareTrie(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie) == NULL)) {
        if ((sfld_jt_DateFormatElement_BaseTimezone_cache == NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37353, meth_otr_Allocator_allocate(&ju_HashMap_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(37354, meth_ju_HashMap__init__0(teavm_local_1));
            sfld_jt_DateFormatElement_BaseTimezone_cache = teavm_local_1;
        }
        teavm_local_1 = sfld_jt_DateFormatElement_BaseTimezone_cache;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37355, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(37356, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_get_3)(teavm_tmp_ptr_0, teavm_local_2)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37357, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_TrieNode_Cls, &supertypeof_jt_DateFormatElement_TrieNode));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie) = teavm_local_1;
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie) == NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37358, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(37359, meth_jt_DateFormatElement_TrieBuilder__init_(teavm_local_3));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37360, meth_ju_TimeZone_getAvailableIDs());
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37361, teavm_nullCheck(teavm_local_4));
            teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
            teavm_local_6 = INT32_C(0);
            while (1) {
                if (!(teavm_local_6 < teavm_local_5)) break;
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(37362, teavm_checkLowerBound(teavm_local_6));
                teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_7);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(37363, meth_ju_TimeZone_getTimeZone(teavm_local_8));
                teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_locale);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_1);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(37364, teavm_nullCheck(teavm_local_9));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37365, meth_ju_TimeZone_getDisplayName_0(teavm_local_9, teavm_local_1));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_1);
                TEAVM_WITH_CALL_SITE_ID(37366, TEAVM_METHOD(teavm_local_3, jt_DateFormatElement_TrieBuilder_VT, virt_add_9)(teavm_local_3, teavm_local_1, teavm_local_9));
                teavm_local_6 = (teavm_local_7 + INT32_C(1));
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37367, TEAVM_METHOD(teavm_local_3, jt_DateFormatElement_TrieBuilder_VT, virt_build_0)(teavm_local_3));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie) = teavm_local_1;
            teavm_local_1 = sfld_jt_DateFormatElement_BaseTimezone_cache;
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_locale);
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(37368, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(37369, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_put)(teavm_tmp_ptr_0, teavm_local_2, teavm_local_10)));
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_BaseTimezone_prepareIdTrie() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37370, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(37371, meth_jt_DateFormatElement_TrieBuilder__init_(teavm_local_1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37372, meth_ju_TimeZone_getAvailableIDs());
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37373, teavm_nullCheck(teavm_local_2));
        teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_2);
        teavm_local_4 = INT32_C(0);
        while (1) {
            if (!(teavm_local_4 < teavm_local_3)) break;
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(37374, teavm_checkLowerBound(teavm_local_4));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(37375, meth_ju_TimeZone_getTimeZone(teavm_local_6));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(37376, teavm_nullCheck(teavm_local_7));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(37377, TEAVM_METHOD(teavm_local_7, ju_TimeZone_VT, virt_getID)(teavm_local_7));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
            TEAVM_WITH_CALL_SITE_ID(37378, TEAVM_METHOD(teavm_local_1, jt_DateFormatElement_TrieBuilder_VT, virt_add_9)(teavm_local_1, teavm_local_8, teavm_local_7));
            teavm_local_4 = (teavm_local_5 + INT32_C(1));
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie = TEAVM_WITH_CALL_SITE_ID(37379, TEAVM_METHOD(teavm_local_1, jt_DateFormatElement_TrieBuilder_VT, virt_build_0)(teavm_local_1));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_BaseTimezone_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37380, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(37381, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37382, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_BaseTimezone_Cls, &supertypeof_jt_DateFormatElement_BaseTimezone));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_locale);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37383, teavm_nullCheck(teavm_local_4));
        teavm_local_5 = TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_BaseTimezone, fld_locale);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        if (TEAVM_WITH_CALL_SITE_ID(37384, meth_ju_Objects_equals(teavm_local_3, teavm_local_5))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie);
            teavm_local_5 = TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if (TEAVM_WITH_CALL_SITE_ID(37385, meth_ju_Objects_equals(teavm_local_3, teavm_local_5))) {
                goto teavm_label_4;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_3;
    teavm_label_4:;
        teavm_local_2 = INT32_C(1);
    teavm_label_3:;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_BaseTimezone_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37386, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(2)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_locale);
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_3;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(1)) = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37387, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t supertypeof_jt_DateFormatElement_BaseTimezone(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2278 || tag >= 2284) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatElement_BaseTimezone_Cls[3];
alignas(8) jt_DateFormatElement_BaseTimezone_VT jt_DateFormatElement_BaseTimezone_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_BaseTimezone), sizeof(void*)),
        .flags = 0,
        .tag = 2278,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormatElement_BaseTimezone,
        .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
        .layout = teavm_classLayouts_jt_DateFormatElement_BaseTimezone_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DateFormatElement_BaseTimezone_hashCode,
    .virt_equals = &meth_jt_DateFormatElement_BaseTimezone_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_parse = &meth_jt_DateFormatElement_BaseTimezone_parse,
    .virt_match = &meth_jt_DateFormatElement_BaseTimezone_match
};
static void** teavm_gc_localStaticRoots_jt_DateFormatElement_BaseTimezone_Cls[2] = {
(void**) &sfld_jt_DateFormatElement_BaseTimezone_cache, (void**) &sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie
};
static int16_t teavm_classLayouts_jt_DateFormatElement_BaseTimezone_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_DateFormatElement_BaseTimezone, fld_locale), (int16_t) offsetof(cls_jt_DateFormatElement_BaseTimezone, fld_searchTrie)
};
void sysinitclass_jt_DateFormatElement_BaseTimezone() {
sfld_jt_DateFormatElement_BaseTimezone_cache = NULL;
sfld_jt_DateFormatElement_BaseTimezone_idSearchTrie = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jt_DateFormatElement_BaseTimezone_Cls, 2);
}
