#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "AttributedString@dAttributedIterator.h"

extern void sysinitclass_jt_AttributedString_AttributedIterator();
typedef struct cls_jt_AttributedString_AttributedIterator {
    struct TeaVM_Object parent;
    int32_t fld_begin;
    int32_t fld_end;
    int32_t fld_offset;
    void* fld_attrString;
    void* fld_attributesAllowed;
} cls_jt_AttributedString_AttributedIterator;
extern void meth_jt_AttributedString_AttributedIterator__init_(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getEndIndex(void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getIndex(void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_inRange(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_inRange_0(void*, void*);
extern void* meth_jt_AttributedString_AttributedIterator_getAllAttributeKeys(void*);
extern void* meth_jt_AttributedString_AttributedIterator_currentValue(void*, void*);
extern void* meth_jt_AttributedString_AttributedIterator_getAttribute(void*, void*);
extern void* meth_jt_AttributedString_AttributedIterator_getAttributes(void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getRunLimit(void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_runLimit(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getRunLimit_0(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getRunLimit_1(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getRunStart(void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_runStart(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getRunStart_0(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_getRunStart_1(void*, void*);
extern int32_t meth_jt_AttributedString_AttributedIterator_setIndex(void*, int32_t);
extern int32_t supertypeof_jt_AttributedString_AttributedIterator(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_AttributedString_AttributedIterator_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_setIndex_0)(void*, int32_t); // 11
    void* (*virt_getAttribute)(void*, void*); // 12
    void (*pad0)(); // 13
    int32_t (*virt_getEndIndex)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void* (*virt_getAttributes)(void*); // 19
    int32_t (*virt_getIndex)(void*); // 20
    void* (*virt_getAllAttributeKeys)(void*); // 21
    int32_t (*virt_getRunStart_1)(void*); // 22
    int32_t (*virt_getRunLimit)(void*, void*); // 23
    void (*pad5)(); // 24
    void (*pad6)(); // 25
    void (*pad7)(); // 26
    int32_t (*virt_getRunLimit_0)(void*, void*); // 27
    int32_t (*virt_getRunLimit_1)(void*); // 28
    void (*pad8)(); // 29
    void (*pad9)(); // 30
    void (*pad10)(); // 31
    void (*pad11)(); // 32
    void (*pad12)(); // 33
    void (*pad13)(); // 34
    void (*pad14)(); // 35
    void (*pad15)(); // 36
    int32_t (*virt_getRunStart_0)(void*, void*); // 37
    void (*pad16)(); // 38
    void (*pad17)(); // 39
    void (*pad18)(); // 40
    void (*pad19)(); // 41
    void (*pad20)(); // 42
    void (*pad21)(); // 43
    void (*pad22)(); // 44
    void (*pad23)(); // 45
    void (*pad24)(); // 46
    void (*pad25)(); // 47
    int32_t (*virt_getRunStart)(void*, void*); // 48
    void (*pad26)(); // 49
} jt_AttributedString_AttributedIterator_VT;
extern jt_AttributedString_AttributedIterator_VT jt_AttributedString_AttributedIterator_Cls;
