#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DateFormatElement@dTrieNode.h"

extern void sysinitclass_jt_DateFormatElement_TrieNode();
typedef struct cls_jt_DateFormatElement_TrieNode {
    struct TeaVM_Object parent;
    TeaVM_Array* fld_chars;
    TeaVM_Array* fld_childNodes;
    void* fld_tz;
} cls_jt_DateFormatElement_TrieNode;
extern void meth_jt_DateFormatElement_TrieNode__init_(void*);
extern int32_t supertypeof_jt_DateFormatElement_TrieNode(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_TrieNode_VT {
    jl_Object_VT parent;
} jt_DateFormatElement_TrieNode_VT;
extern jt_DateFormatElement_TrieNode_VT jt_DateFormatElement_TrieNode_Cls;
