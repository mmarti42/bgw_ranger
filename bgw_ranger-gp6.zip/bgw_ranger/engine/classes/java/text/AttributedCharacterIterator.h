#pragma once
#include "../../../runtime.h"
#include "AttributedCharacterIterator.h"

extern void sysinitclass_jt_AttributedCharacterIterator();
extern int32_t supertypeof_jt_AttributedCharacterIterator(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_AttributedCharacterIterator_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void (*pad0)(); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_setIndex_0)(void*, int32_t); // 11
    void* (*virt_getAttribute)(void*, void*); // 12
    void (*pad1)(); // 13
    int32_t (*virt_getEndIndex)(void*); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void* (*virt_getAttributes)(void*); // 19
    int32_t (*virt_getIndex)(void*); // 20
    void (*pad6)(); // 21
    int32_t (*virt_getRunStart_1)(void*); // 22
    void (*pad7)(); // 23
    void (*pad8)(); // 24
    void (*pad9)(); // 25
    void (*pad10)(); // 26
    void (*pad11)(); // 27
    int32_t (*virt_getRunLimit_1)(void*); // 28
} jt_AttributedCharacterIterator_VT;
extern TeaVM_Class jt_AttributedCharacterIterator_Cls;
