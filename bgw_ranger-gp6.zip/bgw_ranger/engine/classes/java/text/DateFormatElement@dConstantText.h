#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dConstantText.h"

extern void sysinitclass_jt_DateFormatElement_ConstantText();
typedef struct cls_jt_DateFormatElement_ConstantText {
    struct cls_jt_DateFormatElement parent;
    void* fld_textConstant;
} cls_jt_DateFormatElement_ConstantText;
extern void meth_jt_DateFormatElement_ConstantText__init_(void*, void*);
extern void meth_jt_DateFormatElement_ConstantText_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_ConstantText_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_ConstantText_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_ConstantText_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_ConstantText(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_ConstantText_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_ConstantText_VT;
extern jt_DateFormatElement_ConstantText_VT jt_DateFormatElement_ConstantText_Cls;
