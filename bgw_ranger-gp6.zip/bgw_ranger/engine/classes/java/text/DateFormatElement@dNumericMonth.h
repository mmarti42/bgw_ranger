#pragma once
#include "../../../runtime.h"
#include "DateFormatElement@dNumeric.h"
#include "DateFormatElement@dNumericMonth.h"

extern void sysinitclass_jt_DateFormatElement_NumericMonth();
typedef struct cls_jt_DateFormatElement_NumericMonth {
    struct cls_jt_DateFormatElement_Numeric parent;
} cls_jt_DateFormatElement_NumericMonth;
extern void meth_jt_DateFormatElement_NumericMonth__init_(void*, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericMonth_processBeforeFormat(void*, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericMonth_processAfterParse(void*, int32_t);
extern int32_t supertypeof_jt_DateFormatElement_NumericMonth(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_NumericMonth_VT {
    jt_DateFormatElement_Numeric_VT parent;
} jt_DateFormatElement_NumericMonth_VT;
extern jt_DateFormatElement_NumericMonth_VT jt_DateFormatElement_NumericMonth_Cls;
