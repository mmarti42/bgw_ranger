#include "DateFormatElement@dTrieBuilder@dbuild@dlambda@d_3_0.h"
#include "../lang/Object.h"
#include "DateFormatElement@dTrieNodeBuilder.h"
#include "DateFormatElement@dTrieBuilder.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(3079, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0_applyAsInt(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3080, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_TrieNodeBuilder_Cls, &supertypeof_jt_DateFormatElement_TrieNodeBuilder));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3081, meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0_applyAsInt_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0_applyAsInt_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3082, meth_jt_DateFormatElement_TrieBuilder_lambda_build_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jt_DateFormatElement_TrieBuilder_build_lambda__3_0(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 141 || tag >= 143) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_TrieBuilder_build_lambda__3_0_VT jt_DateFormatElement_TrieBuilder_build_lambda__3_0_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_TrieBuilder_build_lambda__3_0), sizeof(void*)),
        .flags = 0,
        .tag = 141,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormatElement_TrieBuilder_build_lambda__3_0,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_applyAsInt_0 = &meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0_applyAsInt_0,
    .virt_applyAsInt = &meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0_applyAsInt
};
void sysinitclass_jt_DateFormatElement_TrieBuilder_build_lambda__3_0() {
}
