#pragma once
#include "../../../runtime.h"
#include "AttributedCharacterIterator@dAttribute.h"
#include "Format@dField.h"

extern void sysinitclass_jt_Format_Field();
typedef struct cls_jt_Format_Field {
    struct cls_jt_AttributedCharacterIterator_Attribute parent;
} cls_jt_Format_Field;
extern void meth_jt_Format_Field__init_(void*, void*);
extern int32_t supertypeof_jt_Format_Field(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_Format_Field_VT {
    jt_AttributedCharacterIterator_Attribute_VT parent;
} jt_Format_Field_VT;
extern jt_Format_Field_VT jt_Format_Field_Cls;
