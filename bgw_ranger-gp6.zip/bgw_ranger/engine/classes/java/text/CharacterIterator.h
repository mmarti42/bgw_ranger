#pragma once
#include "../../../runtime.h"
#include "CharacterIterator.h"

extern void sysinitclass_jt_CharacterIterator();
extern int32_t supertypeof_jt_CharacterIterator(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_CharacterIterator_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void (*pad0)(); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
} jt_CharacterIterator_VT;
extern TeaVM_Class jt_CharacterIterator_Cls;
