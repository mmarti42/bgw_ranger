#pragma once
#include "../../../runtime.h"
#include "NumberFormat.h"
#include "DecimalFormat.h"

extern void sysinitclass_jt_DecimalFormat();
typedef struct cls_jt_DecimalFormat {
    struct cls_jt_NumberFormat parent;
    void* fld_symbols;
    TeaVM_Array* fld_positivePrefix;
    TeaVM_Array* fld_negativePrefix;
    TeaVM_Array* fld_positiveSuffix;
    TeaVM_Array* fld_negativeSuffix;
    int32_t fld_multiplier;
    int32_t fld_groupingSize;
    int8_t fld_decimalSeparatorAlwaysShown;
    int8_t fld_parseBigDecimal;
    int32_t fld_exponentDigits;
    void* fld_pattern;
} cls_jt_DecimalFormat;
extern TeaVM_Array* sfld_jt_DecimalFormat_POW10_ARRAY;
extern TeaVM_Array* sfld_jt_DecimalFormat_POW10_INT_ARRAY;
extern void meth_jt_DecimalFormat__init__0(void*);
extern void meth_jt_DecimalFormat__init__1(void*, void*);
extern void meth_jt_DecimalFormat__init_(void*, void*, void*);
extern void meth_jt_DecimalFormat_applyPattern(void*, void*);
extern void* meth_jt_DecimalFormat_toPattern(void*);
extern void meth_jt_DecimalFormat_setDecimalFormatSymbols(void*, void*);
extern void* meth_jt_DecimalFormat_fieldsToText(void*, TeaVM_Array*, void*);
extern void* meth_jt_DecimalFormat_fieldsToText_0(void*, TeaVM_Array*);
extern TeaVM_Array* meth_jt_DecimalFormat_textToFields(void*, void*);
extern void* meth_jt_DecimalFormat_getPositivePrefix(void*);
extern void meth_jt_DecimalFormat_setPositivePrefix(void*, void*);
extern void* meth_jt_DecimalFormat_getNegativePrefix(void*);
extern void meth_jt_DecimalFormat_setNegativePrefix(void*, void*);
extern void* meth_jt_DecimalFormat_getPositiveSuffix(void*);
extern void* meth_jt_DecimalFormat_getNegativeSuffix(void*);
extern void meth_jt_DecimalFormat_setNegativeSuffix(void*, void*);
extern void meth_jt_DecimalFormat_setMultiplier(void*, int32_t);
extern int32_t meth_jt_DecimalFormat_getGroupingSize(void*);
extern void meth_jt_DecimalFormat_setGroupingSize(void*, int32_t);
extern int32_t meth_jt_DecimalFormat_isDecimalSeparatorAlwaysShown(void*);
extern void meth_jt_DecimalFormat_setDecimalSeparatorAlwaysShown(void*, int32_t);
extern int32_t meth_jt_DecimalFormat_isParseBigDecimal(void*);
extern int32_t meth_jt_DecimalFormat_equals(void*, void*);
extern int32_t meth_jt_DecimalFormat_hashCode(void*);
extern void* meth_jt_DecimalFormat_parse(void*, void*, void*);
extern void* meth_jt_DecimalFormat_parseBigDecimal(void*, void*, void*);
extern void* meth_jt_DecimalFormat_parseNumber(void*, void*, void*);
extern void* meth_jt_DecimalFormat_format(void*, void*, void*, void*);
extern void* meth_jt_DecimalFormat_format_1(void*, void*, void*, void*);
extern void* meth_jt_DecimalFormat_format_0(void*, void*, void*, void*);
extern void* meth_jt_DecimalFormat_format_2(void*, int64_t, void*, void*);
extern void* meth_jt_DecimalFormat_format_3(void*, double, void*, void*);
extern void meth_jt_DecimalFormat_formatExponent_0(void*, int64_t, void*);
extern void meth_jt_DecimalFormat_formatRegular_0(void*, int64_t, void*);
extern void meth_jt_DecimalFormat_formatExponent_1(void*, int64_t, int32_t, int32_t, void*);
extern void meth_jt_DecimalFormat_formatRegular_1(void*, int64_t, int32_t, int32_t, void*);
extern void meth_jt_DecimalFormat_formatExponent(void*, void*, void*);
extern void meth_jt_DecimalFormat_appendSuffix(void*, int32_t, void*);
extern void meth_jt_DecimalFormat_formatRegular(void*, void*, void*);
extern int64_t meth_jt_DecimalFormat_applyRounding(void*, int64_t, int32_t, int32_t, int32_t);
extern void* meth_jt_DecimalFormat_applyRounding_0(void*, void*, int32_t, int32_t);
extern int32_t meth_jt_DecimalFormat_fastLn10_0(void*, int64_t);
extern int32_t meth_jt_DecimalFormat_fastLn10(void*, int32_t);
extern void* meth_jt_DecimalFormat_pow10(void*, void*, int32_t);
extern int32_t meth_jt_DecimalFormat_forDigit(void*, int32_t);
extern void meth_jt_DecimalFormat__clinit_();
extern void initclass_jt_DecimalFormat();
extern int32_t supertypeof_jt_DecimalFormat(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DecimalFormat_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*virt_setMaximumFractionDigits)(void*, int32_t); // 13
    void* (*virt_format_1)(void*, int64_t, void*, void*); // 14
    void (*pad0)(); // 15
    void (*virt_setMaximumIntegerDigits)(void*, int32_t); // 16
    void (*virt_setMinimumFractionDigits)(void*, int32_t); // 17
    void (*pad1)(); // 18
    int32_t (*virt_getMinimumIntegerDigits)(void*); // 19
    int32_t (*virt_isGroupingUsed)(void*); // 20
    void* (*virt_parse_0)(void*, void*, void*); // 21
    void* (*virt_format_0)(void*, double, void*, void*); // 22
    void* (*virt_toPattern)(void*); // 23
    int32_t (*virt_getMaximumIntegerDigits)(void*); // 24
    void (*virt_setMinimumIntegerDigits)(void*, int32_t); // 25
    void (*virt_setParseIntegerOnly)(void*, int32_t); // 26
    int32_t (*virt_getMaximumFractionDigits)(void*); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*virt_setNegativePrefix)(void*, void*); // 29
    void (*virt_setGroupingSize)(void*, int32_t); // 30
    int32_t (*virt_getMinimumFractionDigits)(void*); // 31
    int32_t (*virt_getGroupingSize)(void*); // 32
    void* (*virt_getPositiveSuffix)(void*); // 33
    void (*pad2)(); // 34
    void (*pad3)(); // 35
    void (*virt_setDecimalSeparatorAlwaysShown)(void*, int32_t); // 36
    void* (*virt_getCurrency)(void*); // 37
    void* (*virt_getRoundingMode)(void*); // 38
    void (*virt_setNegativeSuffix)(void*, void*); // 39
    void (*pad4)(); // 40
    void (*pad5)(); // 41
    void* (*virt_getNegativeSuffix)(void*); // 42
    void (*virt_setPositivePrefix)(void*, void*); // 43
    int32_t (*virt_isDecimalSeparatorAlwaysShown)(void*); // 44
    void (*virt_setDecimalFormatSymbols)(void*, void*); // 45
    void (*pad6)(); // 46
    void (*virt_setGroupingUsed)(void*, int32_t); // 47
    void (*virt_applyPattern)(void*, void*); // 48
    int32_t (*virt_isParseBigDecimal)(void*); // 49
    void* (*virt_getPositivePrefix)(void*); // 50
    void* (*virt_getNegativePrefix)(void*); // 51
    void (*virt_setMultiplier)(void*, int32_t); // 52
} jt_DecimalFormat_VT;
extern jt_DecimalFormat_VT jt_DecimalFormat_Cls;
