#include "DecimalFormat@d1.h"
#include "../lang/Object.h"
#include "../math/RoundingMode.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Enum.h"
#include "../../../strings.h"

TeaVM_Array* sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
void meth_jt_DecimalFormat_1__clinit_() {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13700, meth_jm_RoundingMode_values());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(13701, teavm_nullCheck(teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode = TEAVM_WITH_CALL_SITE_ID(13702, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_2));
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_CEILING;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13703, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13704, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13705, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13706, teavm_checkBounds(teavm_local_4, teavm_local_1))) = INT32_C(1);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_FLOOR;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13707, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13708, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13709, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13710, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(2);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_UP;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13711, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13712, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13713, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13714, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(3);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_DOWN;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13715, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13716, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13717, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13718, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(4);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_UNNECESSARY;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13719, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13720, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13721, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13722, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(5);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_HALF_DOWN;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13723, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13724, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13725, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13726, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(6);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_HALF_UP;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13727, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13728, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13729, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13730, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(7);
    teavm_local_1 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    teavm_local_3 = sfld_jm_RoundingMode_HALF_EVEN;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13731, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(13732, teavm_nullCheck(teavm_local_3))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13733, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13734, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(8);
    TEAVM_RELEASE_STACK;
}
void initclass_jt_DecimalFormat_1() {
    TeaVM_Class* cls = (TeaVM_Class*) &jt_DecimalFormat_1_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jt_DecimalFormat_1__clinit_();
    }
}
int32_t supertypeof_jt_DecimalFormat_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 621 || tag >= 623) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DecimalFormat_1_VT jt_DecimalFormat_1_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormat_1), sizeof(void*)),
            .flags = 0,
            .tag = 621,
            .modifiers = 32768,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DecimalFormat_1,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jt_DecimalFormat_1_Cls[1] = {
(void**) &sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode
};
void sysinitclass_jt_DecimalFormat_1() {
sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jt_DecimalFormat_1_Cls, 1);
}
