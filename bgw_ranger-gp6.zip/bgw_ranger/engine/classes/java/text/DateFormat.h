#pragma once
#include "../../../runtime.h"
#include "Format.h"
#include "DateFormat.h"

extern void sysinitclass_jt_DateFormat();
typedef struct cls_jt_DateFormat {
    struct cls_jt_Format parent;
    void* fld_calendar;
} cls_jt_DateFormat;
extern void meth_jt_DateFormat__init_(void*);
extern int32_t meth_jt_DateFormat_equals(void*, void*);
extern void* meth_jt_DateFormat_format(void*, void*, void*, void*);
extern void* meth_jt_DateFormat_getTimeZone(void*);
extern void meth_jt_DateFormat_setTimeZone(void*, void*);
extern void* meth_jt_DateFormat_getDateInstance(int32_t, void*);
extern void* meth_jt_DateFormat_getDateFormatString(int32_t, void*);
extern void* meth_jt_DateFormat_getDateTimeInstance(int32_t, int32_t);
extern void* meth_jt_DateFormat_getDateTimeInstance_0(int32_t, int32_t, void*);
extern void* meth_jt_DateFormat_getDateTimeFormatString(int32_t, void*);
extern void* meth_jt_DateFormat_getInstance();
extern void* meth_jt_DateFormat_getTimeInstance(int32_t, void*);
extern void* meth_jt_DateFormat_getTimeFormatString(int32_t, void*);
extern int32_t meth_jt_DateFormat_hashCode(void*);
extern void* meth_jt_DateFormat_parse(void*, void*);
extern void meth_jt_DateFormat_setLenient(void*, int32_t);
extern int32_t supertypeof_jt_DateFormat(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormat_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_parse_2)(void*, void*, void*); // 14
    void (*pad1)(); // 15
    void (*virt_setLenient)(void*, int32_t); // 16
    void (*pad2)(); // 17
    void (*pad3)(); // 18
    void* (*virt_getTimeZone)(void*); // 19
    void (*virt_setTimeZone)(void*, void*); // 20
    void* (*virt_parse_1)(void*, void*); // 21
    void* (*virt_format_4)(void*, void*, void*, void*); // 22
    void (*pad4)(); // 23
    void (*pad5)(); // 24
    void (*pad6)(); // 25
    void (*pad7)(); // 26
    void (*pad8)(); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*pad9)(); // 29
    void (*pad10)(); // 30
    void (*pad11)(); // 31
    void (*pad12)(); // 32
    void (*pad13)(); // 33
    void (*pad14)(); // 34
    void (*pad15)(); // 35
    void (*pad16)(); // 36
    void (*pad17)(); // 37
    void (*pad18)(); // 38
    void (*pad19)(); // 39
    void (*pad20)(); // 40
    void (*pad21)(); // 41
    void (*pad22)(); // 42
    void (*pad23)(); // 43
    void (*pad24)(); // 44
    void (*pad25)(); // 45
    void (*pad26)(); // 46
    void (*pad27)(); // 47
    void (*pad28)(); // 48
    void (*pad29)(); // 49
} jt_DateFormat_VT;
extern jt_DateFormat_VT jt_DateFormat_Cls;
