#pragma once
#include "../../../runtime.h"
#include "Format.h"
#include "MessageFormat.h"

extern void sysinitclass_jt_MessageFormat();
typedef struct cls_jt_MessageFormat {
    struct cls_jt_Format parent;
    void* fld_locale;
    TeaVM_Array* fld_strings;
    TeaVM_Array* fld_argumentNumbers;
    TeaVM_Array* fld_formats;
    int32_t fld_maxOffset;
    int32_t fld_maxArgumentIndex;
} cls_jt_MessageFormat;
extern void meth_jt_MessageFormat__init_(void*, void*);
extern void meth_jt_MessageFormat_applyPattern(void*, void*);
extern void* meth_jt_MessageFormat_format(void*, TeaVM_Array*, void*, void*);
extern void* meth_jt_MessageFormat_formatImpl(void*, TeaVM_Array*, void*, void*, void*);
extern void meth_jt_MessageFormat_handleArgumentField(void*, int32_t, int32_t, int32_t, void*, void*);
extern void meth_jt_MessageFormat_handleformat(void*, void*, void*, int32_t, void*);
extern void* meth_jt_MessageFormat_format_0(void*, void*, void*, void*);
extern int32_t meth_jt_MessageFormat_match(void*, void*, void*, int32_t, TeaVM_Array*);
extern void* meth_jt_MessageFormat_parseVariable(void*, void*, void*);
extern void meth_jt_MessageFormat_setLocale(void*, void*);
extern int32_t supertypeof_jt_MessageFormat(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_MessageFormat_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*virt_setLocale)(void*, void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void* (*virt_format_5)(void*, TeaVM_Array*, void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*virt_applyPattern)(void*, void*); // 48
    void (*pad32)(); // 49
} jt_MessageFormat_VT;
extern jt_MessageFormat_VT jt_MessageFormat_Cls;
