#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DecimalFormatParser.h"

extern void sysinitclass_jt_DecimalFormatParser();
typedef struct cls_jt_DecimalFormatParser {
    struct TeaVM_Object parent;
    TeaVM_Array* fld_positivePrefix;
    TeaVM_Array* fld_positiveSuffix;
    TeaVM_Array* fld_negativePrefix;
    TeaVM_Array* fld_negativeSuffix;
    int32_t fld_groupSize;
    int32_t fld_minimumIntLength;
    int32_t fld_intLength;
    int32_t fld_minimumFracLength;
    int32_t fld_fracLength;
    int32_t fld_exponentLength;
    int8_t fld_decimalSeparatorRequired;
    void* fld_string;
    int32_t fld_index;
    int32_t fld_multiplier;
} cls_jt_DecimalFormatParser;
extern void meth_jt_DecimalFormatParser__init_(void*);
extern void meth_jt_DecimalFormatParser_parse(void*, void*);
extern void meth_jt_DecimalFormatParser_apply(void*, void*);
extern TeaVM_Array* meth_jt_DecimalFormatParser_parseText(void*, int32_t, int32_t);
extern void meth_jt_DecimalFormatParser_parseNumber(void*, int32_t);
extern void meth_jt_DecimalFormatParser_parseIntegerPart(void*, int32_t);
extern void meth_jt_DecimalFormatParser_parseFractionalPart(void*, int32_t);
extern void meth_jt_DecimalFormatParser_parseExponent(void*, int32_t);
extern int32_t supertypeof_jt_DecimalFormatParser(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DecimalFormatParser_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_apply_28)(void*, void*); // 11
    TeaVM_Array* (*virt_parseText)(void*, int32_t, int32_t); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void (*virt_parse_3)(void*, void*); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} jt_DecimalFormatParser_VT;
extern jt_DecimalFormatParser_VT jt_DecimalFormatParser_Cls;
