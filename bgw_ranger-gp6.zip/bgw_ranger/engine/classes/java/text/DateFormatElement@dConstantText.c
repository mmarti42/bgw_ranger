#include "DateFormatElement@dConstantText.h"
#include "DateFormatElement.h"
#include "../lang/StringBuffer.h"
#include "ParsePosition.h"
#include "../lang/String.h"
#include "../lang/Object.h"
#include "../util/Objects.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_ConstantText__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34068, meth_jt_DateFormatElement__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_ConstantText, fld_textConstant) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_ConstantText_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_ConstantText, fld_textConstant);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34069, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(34070, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_ConstantText_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34071, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34072, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_ConstantText, fld_textConstant);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    if ((!TEAVM_WITH_CALL_SITE_ID(34073, meth_jt_DateFormatElement_matches(teavm_local_1, teavm_local_4, teavm_local_5)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(34074, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(34075, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3))));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34076, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_ConstantText, fld_textConstant);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_4 = (teavm_local_4 + TEAVM_WITH_CALL_SITE_ID(34077, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(34078, teavm_nullCheck(teavm_local_5)))));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(34079, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setIndex)(teavm_local_3, teavm_local_4));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_ConstantText_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34080, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(34081, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34082, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_ConstantText_Cls, &supertypeof_jt_DateFormatElement_ConstantText));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_ConstantText, fld_textConstant);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34083, teavm_nullCheck(teavm_local_4));
        teavm_local_5 = TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_ConstantText, fld_textConstant);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34084, meth_ju_Objects_equals(teavm_local_3, teavm_local_5));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_ConstantText_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34085, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(1)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_ConstantText, fld_textConstant);
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_3;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34086, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t supertypeof_jt_DateFormatElement_ConstantText(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2276 || tag >= 2278) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatElement_ConstantText_Cls[2];
alignas(8) jt_DateFormatElement_ConstantText_VT jt_DateFormatElement_ConstantText_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_ConstantText), sizeof(void*)),
            .flags = 0,
            .tag = 2276,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7678),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_ConstantText,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .layout = teavm_classLayouts_jt_DateFormatElement_ConstantText_Cls,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_ConstantText_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_ConstantText_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_ConstantText_format,
        .virt_parse = &meth_jt_DateFormatElement_ConstantText_parse
    }
};
static int16_t teavm_classLayouts_jt_DateFormatElement_ConstantText_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_DateFormatElement_ConstantText, fld_textConstant)
};
void sysinitclass_jt_DateFormatElement_ConstantText() {
}
