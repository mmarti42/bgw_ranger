#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DecimalFormat@dCurrencyField.h"

extern void sysinitclass_jt_DecimalFormat_CurrencyField();
typedef struct cls_jt_DecimalFormat_CurrencyField {
    struct TeaVM_Object parent;
} cls_jt_DecimalFormat_CurrencyField;
extern void meth_jt_DecimalFormat_CurrencyField__init_(void*);
extern void meth_jt_DecimalFormat_CurrencyField_render(void*, void*, void*);
extern int32_t meth_jt_DecimalFormat_CurrencyField_equals(void*, void*);
extern int32_t meth_jt_DecimalFormat_CurrencyField_hashCode(void*);
extern int32_t supertypeof_jt_DecimalFormat_CurrencyField(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DecimalFormat_CurrencyField_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*virt_render)(void*, void*, void*); // 12
    void (*pad1)(); // 13
    void (*pad2)(); // 14
    void (*pad3)(); // 15
    void (*pad4)(); // 16
    void (*pad5)(); // 17
    void (*pad6)(); // 18
    void (*pad7)(); // 19
    void (*pad8)(); // 20
    void (*pad9)(); // 21
    void (*pad10)(); // 22
    void (*pad11)(); // 23
    void (*pad12)(); // 24
    void (*pad13)(); // 25
    void (*pad14)(); // 26
    void (*pad15)(); // 27
    void (*pad16)(); // 28
    void (*pad17)(); // 29
    void (*pad18)(); // 30
    void (*pad19)(); // 31
    void (*pad20)(); // 32
    void (*pad21)(); // 33
    void (*pad22)(); // 34
    void (*pad23)(); // 35
    void (*pad24)(); // 36
    void (*pad25)(); // 37
    void (*pad26)(); // 38
    void (*pad27)(); // 39
    void (*pad28)(); // 40
    void (*pad29)(); // 41
    void (*pad30)(); // 42
    void (*pad31)(); // 43
    void (*pad32)(); // 44
    void (*pad33)(); // 45
    void (*pad34)(); // 46
    void (*pad35)(); // 47
    void (*pad36)(); // 48
    void (*pad37)(); // 49
} jt_DecimalFormat_CurrencyField_VT;
extern jt_DecimalFormat_CurrencyField_VT jt_DecimalFormat_CurrencyField_Cls;
