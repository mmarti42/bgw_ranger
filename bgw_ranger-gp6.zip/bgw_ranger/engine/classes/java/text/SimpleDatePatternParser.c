#include "SimpleDatePatternParser.h"
#include "../lang/Object.h"
#include "../util/ArrayList.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/List.h"
#include "../lang/String.h"
#include "DateFormatElement@dNumericWeekday.h"
#include "DateFormatElement@dNumeric.h"
#include "DateFormatElement@dNumericHour.h"
#include "DateFormatElement@dEraText.h"
#include "DateFormatElement@dRfc822Timezone.h"
#include "DateFormatElement@dAmPmText.h"
#include "DateFormatElement@dGeneralTimezone.h"
#include "DateFormatElement@dYear.h"
#include "DateFormatElement@dWeekdayText.h"
#include "../lang/IllegalArgumentException.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "DateFormatElement@dIso8601Timezone.h"
#include "DateFormatElement@dNumericMonth.h"
#include "DateFormatElement@dMonthText.h"
#include "DateFormatElement@dConstantText.h"

void meth_jt_SimpleDatePatternParser__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(19871, meth_jl_Object__init_(teavm_this_));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19872, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(19873, meth_ju_ArrayList__init_(teavm_local_3));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_symbols) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_locale) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_SimpleDatePatternParser_getElements(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
}
void meth_jt_SimpleDatePatternParser_parsePattern(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(19874, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19875, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_clear)(teavm_tmp_ptr_0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = INT32_C(0);
    while (1) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19876, teavm_nullCheck(teavm_local_1));
        if ((teavm_local_3 >= TEAVM_WITH_CALL_SITE_ID(19877, meth_jl_String_length(teavm_local_1)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(19878, meth_jl_String_charAt(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index)));
        switch (teavm_local_4) {
            case 39:
                goto teavm_label_25;
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 59:
            case 60:
            case 61:
            case 62:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 73:
            case 74:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 84:
            case 85:
            case 86:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 98:
            case 101:
            case 102:
            case 103:
            case 105:
            case 106:
            case 108:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 116:
            case 118:
            case 120:
                goto teavm_label_3;
            case 68:
                goto teavm_label_23;
            case 69:
            case 99:
                goto teavm_label_6;
            case 70:
                goto teavm_label_22;
            case 71:
                goto teavm_label_11;
            case 72:
                goto teavm_label_21;
            case 75:
                goto teavm_label_20;
            case 76:
            case 77:
                goto teavm_label_4;
            case 83:
                goto teavm_label_19;
            case 87:
                goto teavm_label_18;
            case 88:
                goto teavm_label_5;
            case 89:
            case 121:
                goto teavm_label_7;
            case 90:
                goto teavm_label_10;
            case 97:
                goto teavm_label_9;
            case 100:
                goto teavm_label_17;
            case 104:
                goto teavm_label_16;
            case 107:
                goto teavm_label_15;
            case 109:
                goto teavm_label_14;
            case 115:
                goto teavm_label_13;
            case 117:
                goto teavm_label_24;
            case 119:
                goto teavm_label_12;
            case 122:
                goto teavm_label_8;
            default:
                goto teavm_label_3;
        }
    teavm_label_25:;
        TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) + INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(19879, meth_jt_SimpleDatePatternParser_parseQuoted(teavm_this_));
        goto teavm_label_2;
    teavm_label_24:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19880, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19881, meth_otr_Allocator_allocate(&jt_DateFormatElement_NumericWeekday_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19882, meth_jt_DateFormatElement_NumericWeekday__init_(teavm_local_6, teavm_local_5));
        TEAVM_WITH_CALL_SITE_ID(19883, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19884, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_23:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19885, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19886, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19887, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(6), teavm_local_5, INT32_C(3)));
        TEAVM_WITH_CALL_SITE_ID(19888, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19889, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_22:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19890, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19891, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19892, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(8), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19893, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19894, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_21:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19895, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19896, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19897, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(11), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19898, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19899, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_20:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19900, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19901, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19902, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(10), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19903, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19904, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_19:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19905, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19906, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19907, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(14), teavm_local_5, INT32_C(3)));
        TEAVM_WITH_CALL_SITE_ID(19908, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19909, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_18:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19910, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19911, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19912, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(4), teavm_local_5, INT32_C(1)));
        TEAVM_WITH_CALL_SITE_ID(19913, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19914, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_17:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19915, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19916, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19917, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(5), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19918, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19919, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_16:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19920, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19921, meth_otr_Allocator_allocate(&jt_DateFormatElement_NumericHour_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19922, meth_jt_DateFormatElement_NumericHour__init_(teavm_local_6, INT32_C(10), teavm_local_5, INT32_C(12)));
        TEAVM_WITH_CALL_SITE_ID(19923, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19924, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_15:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19925, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19926, meth_otr_Allocator_allocate(&jt_DateFormatElement_NumericHour_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19927, meth_jt_DateFormatElement_NumericHour__init_(teavm_local_6, INT32_C(11), teavm_local_5, INT32_C(24)));
        TEAVM_WITH_CALL_SITE_ID(19928, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19929, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_14:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19930, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19931, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19932, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(12), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19933, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19934, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_13:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19935, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19936, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19937, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(13), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19938, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19939, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_12:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19940, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19941, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19942, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(3), teavm_local_5, INT32_C(2)));
        TEAVM_WITH_CALL_SITE_ID(19943, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19944, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_11:;
        TEAVM_WITH_CALL_SITE_ID(19945, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19946, meth_otr_Allocator_allocate(&jt_DateFormatElement_EraText_Cls));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19947, meth_jt_DateFormatElement_EraText__init_(teavm_local_6, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(19948, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19949, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_10:;
        TEAVM_WITH_CALL_SITE_ID(19950, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19951, meth_otr_Allocator_allocate(&jt_DateFormatElement_Rfc822Timezone_Cls));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_locale);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19952, meth_jt_DateFormatElement_Rfc822Timezone__init_(teavm_local_6, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(19953, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19954, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_9:;
        TEAVM_WITH_CALL_SITE_ID(19955, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19956, meth_otr_Allocator_allocate(&jt_DateFormatElement_AmPmText_Cls));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19957, meth_jt_DateFormatElement_AmPmText__init_(teavm_local_6, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(19958, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19959, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_8:;
        TEAVM_WITH_CALL_SITE_ID(19960, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19961, meth_otr_Allocator_allocate(&jt_DateFormatElement_GeneralTimezone_Cls));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_locale);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19962, meth_jt_DateFormatElement_GeneralTimezone__init_(teavm_local_6, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(19963, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19964, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_7:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19965, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        if ((teavm_local_5 == INT32_C(2))) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19966, meth_otr_Allocator_allocate(&jt_DateFormatElement_Year_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(19967, meth_jt_DateFormatElement_Year__init_(teavm_local_6, INT32_C(1)));
            TEAVM_WITH_CALL_SITE_ID(19968, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19969, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
            goto teavm_label_2;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19970, meth_otr_Allocator_allocate(&jt_DateFormatElement_Numeric_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19971, meth_jt_DateFormatElement_Numeric__init_(teavm_local_6, INT32_C(1), teavm_local_5, INT32_C(8)));
        TEAVM_WITH_CALL_SITE_ID(19972, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19973, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_6:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19974, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19975, meth_otr_Allocator_allocate(&jt_DateFormatElement_WeekdayText_Cls));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_symbols);
        teavm_local_3 = ((teavm_local_5 > INT32_C(3)) ? INT32_C(0) : INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19976, meth_jt_DateFormatElement_WeekdayText__init_(teavm_local_6, teavm_local_7, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(19977, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19978, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_5:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19979, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        if ((teavm_local_5 > INT32_C(3))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(19980, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19981, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(19982, meth_jl_StringBuilder__init_(teavm_local_6));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(19983, meth_jl_StringBuilder_append(teavm_local_6, TEAVM_GET_STRING(2787)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(19984, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(19985, teavm_nullCheck(teavm_local_7)), teavm_local_3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19986, meth_jl_StringBuilder_toString(teavm_local_6));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(19987, meth_jl_IllegalArgumentException__init__0(teavm_local_2, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(19988, meth_otr_ExceptionHandling_throwException(teavm_local_2));
            TEAVM_UNREACHABLE
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19989, meth_otr_Allocator_allocate(&jt_DateFormatElement_Iso8601Timezone_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(19990, meth_jt_DateFormatElement_Iso8601Timezone__init_(teavm_local_6, teavm_local_5));
        TEAVM_WITH_CALL_SITE_ID(19991, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19992, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_4:;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19993, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        if ((teavm_local_5 <= INT32_C(2))) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19994, meth_otr_Allocator_allocate(&jt_DateFormatElement_NumericMonth_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(19995, meth_jt_DateFormatElement_NumericMonth__init_(teavm_local_6, teavm_local_5));
            TEAVM_WITH_CALL_SITE_ID(19996, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(19997, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
            goto teavm_label_2;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19998, meth_otr_Allocator_allocate(&jt_DateFormatElement_MonthText_Cls));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_symbols);
        teavm_local_3 = ((teavm_local_5 != INT32_C(3)) ? INT32_C(0) : INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19999, meth_jt_DateFormatElement_MonthText__init_(teavm_local_6, teavm_local_7, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(20000, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20001, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        goto teavm_label_2;
    teavm_label_3:;
        if (TEAVM_WITH_CALL_SITE_ID(20002, meth_jt_SimpleDatePatternParser_isControl(teavm_this_, teavm_local_4))) {
            TEAVM_WITH_CALL_SITE_ID(20003, meth_jt_SimpleDatePatternParser_parseRepetitions(teavm_this_));
        } else {
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(20004, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            TEAVM_WITH_CALL_SITE_ID(20005, meth_jl_StringBuilder__init_(teavm_local_8));
            while (1) {
                if (!((TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) < TEAVM_WITH_CALL_SITE_ID(20006, meth_jl_String_length(teavm_local_1))) && (!TEAVM_WITH_CALL_SITE_ID(20007, meth_jt_SimpleDatePatternParser_isControl(teavm_this_, TEAVM_WITH_CALL_SITE_ID(20008, meth_jl_String_charAt(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index)))))))) break;
                teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
                TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = (teavm_local_9 + INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(20009, TEAVM_METHOD(teavm_local_8, jl_StringBuilder_VT, virt_append_28)(teavm_local_8, TEAVM_WITH_CALL_SITE_ID(20010, meth_jl_String_charAt(teavm_local_1, teavm_local_9))));
            }
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(20011, meth_otr_Allocator_allocate(&jt_DateFormatElement_ConstantText_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(20012, TEAVM_METHOD(teavm_local_8, jl_StringBuilder_VT, virt_toString)(teavm_local_8));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(20013, meth_jt_DateFormatElement_ConstantText__init_(teavm_local_6, teavm_local_7));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(20014, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20015, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
        }
    teavm_label_2:;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_SimpleDatePatternParser_isControl(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    if (((teavm_local_1 != INT32_C(39)) && (!((teavm_local_1 >= INT32_C(97)) && (teavm_local_1 <= INT32_C(122)))))) {
        if ((teavm_local_1 < INT32_C(65))) {
            goto teavm_label_2;
        }
        if ((teavm_local_1 > INT32_C(90))) {
            goto teavm_label_2;
        }
    }
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    return teavm_local_2;
}
void meth_jt_SimpleDatePatternParser_parseQuoted(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20016, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20017, meth_jl_StringBuilder__init_(teavm_local_1));
    while (1) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        if ((teavm_local_2 >= TEAVM_WITH_CALL_SITE_ID(20018, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(20019, teavm_nullCheck(teavm_local_3)))))) {
            goto teavm_label_1;
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
        TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = (teavm_local_4 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(20020, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(20021, teavm_nullCheck(teavm_local_3)), teavm_local_4));
        if ((teavm_local_5 != INT32_C(39))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(20022, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, teavm_local_5));
        } else {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            if ((teavm_local_2 >= TEAVM_WITH_CALL_SITE_ID(20023, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(20024, teavm_nullCheck(teavm_local_3)))))) {
                goto teavm_label_1;
            }
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            if ((TEAVM_WITH_CALL_SITE_ID(20025, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(20026, teavm_nullCheck(teavm_local_3)), teavm_local_2)) != INT32_C(39))) {
                goto teavm_label_1;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(20027, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(39)));
            TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) + INT32_C(1));
        }
    }
teavm_label_1:;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_elements);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(20028, meth_otr_Allocator_allocate(&jt_DateFormatElement_ConstantText_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(20029, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_toString)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(20030, meth_jt_DateFormatElement_ConstantText__init_(teavm_local_6, teavm_local_7));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20031, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20032, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_List_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_6)));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_SimpleDatePatternParser_parseRepetitions(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = INT32_C(1);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
    TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = (teavm_local_3 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20033, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(20034, teavm_nullCheck(teavm_local_2)), teavm_local_3));
    while (1) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_3 >= TEAVM_WITH_CALL_SITE_ID(20035, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(20036, teavm_nullCheck(teavm_local_2)))))) {
            goto teavm_label_1;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_pattern);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((TEAVM_WITH_CALL_SITE_ID(20037, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(20038, teavm_nullCheck(teavm_local_2)), teavm_local_5)) != teavm_local_4)) {
            goto teavm_label_1;
        }
        TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_SimpleDatePatternParser, fld_index) + INT32_C(1));
        teavm_local_1 = (teavm_local_1 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_jt_SimpleDatePatternParser(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1189 || tag >= 1191) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_SimpleDatePatternParser_Cls[5];
alignas(8) jt_SimpleDatePatternParser_VT jt_SimpleDatePatternParser_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_SimpleDatePatternParser), sizeof(void*)),
        .flags = 0,
        .tag = 1189,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_SimpleDatePatternParser,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_SimpleDatePatternParser_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getElements = &meth_jt_SimpleDatePatternParser_getElements,
    .virt_parsePattern = &meth_jt_SimpleDatePatternParser_parsePattern
};
static int16_t teavm_classLayouts_jt_SimpleDatePatternParser_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jt_SimpleDatePatternParser, fld_symbols), (int16_t) offsetof(cls_jt_SimpleDatePatternParser, fld_locale), (int16_t) offsetof(cls_jt_SimpleDatePatternParser, fld_elements), (int16_t) offsetof(cls_jt_SimpleDatePatternParser, fld_pattern)
};
void sysinitclass_jt_SimpleDatePatternParser() {
}
