#include "DecimalFormat@dConstants.h"
#include "../lang/Object.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer@dResult.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/classlib/impl/text/FloatAnalyzer@dResult.h"
#include "../../../strings.h"

void* sfld_jt_DecimalFormat_Constants_doubleAnalysisResult;
void* sfld_jt_DecimalFormat_Constants_floatAnalysisResult;
void meth_jt_DecimalFormat_Constants__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24529, meth_otr_Allocator_allocate(&otcit_DoubleAnalyzer_Result_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(24530, meth_otcit_DoubleAnalyzer_Result__init_(teavm_local_1));
    sfld_jt_DecimalFormat_Constants_doubleAnalysisResult = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24531, meth_otr_Allocator_allocate(&otcit_FloatAnalyzer_Result_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(24532, meth_otcit_FloatAnalyzer_Result__init_(teavm_local_1));
    sfld_jt_DecimalFormat_Constants_floatAnalysisResult = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jt_DecimalFormat_Constants() {
    TeaVM_Class* cls = (TeaVM_Class*) &jt_DecimalFormat_Constants_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jt_DecimalFormat_Constants__clinit_();
    }
}
int32_t supertypeof_jt_DecimalFormat_Constants(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1409 || tag >= 1411) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DecimalFormat_Constants_VT jt_DecimalFormat_Constants_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormat_Constants), sizeof(void*)),
            .flags = 0,
            .tag = 1409,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DecimalFormat_Constants,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jt_DecimalFormat_Constants_Cls[2] = {
(void**) &sfld_jt_DecimalFormat_Constants_doubleAnalysisResult, (void**) &sfld_jt_DecimalFormat_Constants_floatAnalysisResult
};
void sysinitclass_jt_DecimalFormat_Constants() {
sfld_jt_DecimalFormat_Constants_doubleAnalysisResult = NULL;
sfld_jt_DecimalFormat_Constants_floatAnalysisResult = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jt_DecimalFormat_Constants_Cls, 2);
}
