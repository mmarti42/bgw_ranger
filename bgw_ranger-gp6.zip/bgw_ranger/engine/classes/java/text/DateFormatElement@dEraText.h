#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dEraText.h"

extern void sysinitclass_jt_DateFormatElement_EraText();
typedef struct cls_jt_DateFormatElement_EraText {
    struct cls_jt_DateFormatElement parent;
    TeaVM_Array* fld_eras;
} cls_jt_DateFormatElement_EraText;
extern void meth_jt_DateFormatElement_EraText__init_(void*, void*);
extern void meth_jt_DateFormatElement_EraText_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_EraText_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_EraText_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_EraText_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_EraText(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_EraText_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_EraText_VT;
extern jt_DateFormatElement_EraText_VT jt_DateFormatElement_EraText_Cls;
