#include "ChoiceFormat.h"
#include "NumberFormat.h"
#include "../../../arrays/primitives/double.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/ArrayList.h"
#include "../lang/String.h"
#include "../lang/StringBuffer.h"
#include "../util/Locale.h"
#include "ParsePosition.h"
#include "../lang/System.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/Number.h"
#include "Format.h"
#include "../util/List.h"
#include "../../../arrayclass.h"
#include "../util/Arrays.h"
#include "../lang/Double.h"
#include "../lang/Character.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_jt_ChoiceFormat__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34589, meth_jt_NumberFormat__init_(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(34590, TEAVM_METHOD(teavm_this_, jt_ChoiceFormat_VT, virt_applyPattern)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_ChoiceFormat_applyPattern(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_local_12;
    TeaVM_Array* teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    TeaVM_Array* teavm_local_16;
    double teavm_local_17;
    double teavm_local_18;
    int32_t teavm_local_19;
    int32_t teavm_local_20;
    TEAVM_ALLOC_STACK(INT32_C(8));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(7));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34591, meth_otr_Allocator_allocateArray(&Arr_D_Cls, INT32_C(5)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34592, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(34593, meth_ju_ArrayList__init_(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34594, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34595, meth_jl_String_length(teavm_local_1));
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = INT32_C(0);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(34596, meth_otr_Allocator_allocate(&jl_StringBuffer_Cls));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(34597, meth_jl_StringBuffer__init__0(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(34598, teavm_initializeClass((TeaVM_Class*) &ju_Locale_Cls, &initclass_ju_Locale));
    teavm_local_8 = sfld_ju_Locale_US;
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_8);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(34599, meth_jt_NumberFormat_getInstance_0(teavm_local_8));
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_9);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(34600, meth_otr_Allocator_allocate(&jt_ParsePosition_Cls));
    TEAVM_GC_ROOT(INT32_C(5), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(34601, meth_jt_ParsePosition__init_(teavm_local_10, INT32_C(0)));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_GC_ROOT(INT32_C(7), teavm_local_9);
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(34602, meth_jt_ChoiceFormat_skipWhitespace(teavm_this_, teavm_local_1, teavm_local_6));
        if ((teavm_local_11 >= teavm_local_4)) {
            goto teavm_label_2;
        }
        TEAVM_WITH_CALL_SITE_ID(34603, TEAVM_METHOD(teavm_local_10, jt_ParsePosition_VT, virt_setIndex)(teavm_local_10, teavm_local_11));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(34604, teavm_nullCheck(teavm_local_9));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(34605, TEAVM_METHOD(teavm_local_9, jt_NumberFormat_VT, virt_parse_0)(teavm_local_9, teavm_local_1, teavm_local_10));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_12);
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(34606, meth_jt_ChoiceFormat_skipWhitespace(teavm_this_, teavm_local_1, TEAVM_WITH_CALL_SITE_ID(34607, TEAVM_METHOD(teavm_local_10, jt_ParsePosition_VT, virt_getIndex)(teavm_local_10))));
        if ((TEAVM_WITH_CALL_SITE_ID(34608, TEAVM_METHOD(teavm_local_10, jt_ParsePosition_VT, virt_getErrorIndex)(teavm_local_10)) != -INT32_C(1))) {
            goto teavm_label_3;
        }
        if ((teavm_local_11 >= teavm_local_4)) {
            goto teavm_label_3;
        }
        teavm_local_13 = teavm_local_2;
        teavm_local_14 = (teavm_local_11 + INT32_C(1));
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(34609, meth_jl_String_charAt(teavm_local_1, teavm_local_11));
        if ((teavm_local_5 != TEAVM_ARRAY_LENGTH(teavm_local_13))) {
            teavm_local_16 = teavm_local_2;
        } else {
            teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(34610, meth_otr_Allocator_allocateArray(&Arr_D_Cls, (teavm_local_5 * INT32_C(2))));
            TEAVM_GC_ROOT(INT32_C(6), teavm_local_16);
            TEAVM_WITH_CALL_SITE_ID(34611, meth_jl_System_fastArraycopy(teavm_local_2, INT32_C(0), teavm_local_16, INT32_C(0), teavm_local_5));
        }
        switch (teavm_local_15) {
            case 35:
            case 8804:
                goto teavm_label_7;
            case 60:
                goto teavm_label_6;
            default:
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_GC_ROOT_RELEASE(INT32_C(4));
                TEAVM_GC_ROOT_RELEASE(INT32_C(5));
                TEAVM_GC_ROOT_RELEASE(INT32_C(7));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(34612, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(34613, meth_jl_IllegalArgumentException__init_(teavm_local_8));
                TEAVM_WITH_CALL_SITE_ID(34614, meth_otr_ExceptionHandling_throwException(teavm_local_8));
                TEAVM_UNREACHABLE
        }
    teavm_label_7:;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_16);
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(34615, teavm_nullCheck(teavm_local_12));
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(34616, TEAVM_METHOD(teavm_local_12, jl_Number_VT, virt_doubleValue)(teavm_local_12));
        goto teavm_label_5;
    teavm_label_6:;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_16);
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(34617, teavm_nullCheck(teavm_local_12));
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(34618, TEAVM_METHOD(teavm_local_12, jl_Number_VT, virt_doubleValue)(teavm_local_12));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(34619, meth_jt_ChoiceFormat_nextDouble(teavm_local_18));
    teavm_label_5:;
        if ((teavm_local_5 > INT32_C(0))) {
            teavm_local_13 = teavm_local_16;
            teavm_local_19 = (teavm_local_5 - INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_13);
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            if ((teavm_local_17 <= TEAVM_ARRAY_AT(teavm_local_13, double, TEAVM_WITH_CALL_SITE_ID(34620, teavm_checkBounds(teavm_local_19, teavm_local_13))))) {
                goto teavm_label_4;
            }
        }
        teavm_local_13 = teavm_local_16;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_13);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_WITH_CALL_SITE_ID(34621, TEAVM_METHOD(teavm_local_7, jl_StringBuffer_VT, virt_setLength)(teavm_local_7, INT32_C(0)));
        TEAVM_WITH_CALL_SITE_ID(34622, TEAVM_METHOD(teavm_local_10, jt_ParsePosition_VT, virt_setIndex)(teavm_local_10, teavm_local_14));
        TEAVM_WITH_CALL_SITE_ID(34623, meth_jt_Format_upTo(teavm_local_1, teavm_local_10, teavm_local_7, INT32_C(124)));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(34624, TEAVM_METHOD(teavm_local_10, jt_ParsePosition_VT, virt_getIndex)(teavm_local_10));
        teavm_local_19 = (teavm_local_5 + INT32_C(1));
        TEAVM_ARRAY_AT(teavm_local_13, double, TEAVM_WITH_CALL_SITE_ID(34625, teavm_checkBounds(teavm_local_5, teavm_local_13))) = teavm_local_17;
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(34626, TEAVM_METHOD(teavm_local_7, jl_StringBuffer_VT, virt_toString)(teavm_local_7));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_8);
        TEAVM_WITH_CALL_SITE_ID(34627, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_8));
        teavm_local_2 = teavm_local_16;
        teavm_local_5 = teavm_local_19;
    }
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(7));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(34628, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(34629, meth_jl_IllegalArgumentException__init_(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(34630, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(7));
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(34631, meth_otr_Allocator_allocateArray(&Arr_D_Cls, INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits) = teavm_local_13;
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(34632, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats) = teavm_local_13;
    goto teavm_label_1;
teavm_label_2:;
    if ((teavm_local_5 == TEAVM_ARRAY_LENGTH(teavm_local_2))) {
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits) = teavm_local_2;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        TEAVM_GC_ROOT_RELEASE(INT32_C(7));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(34633, meth_otr_Allocator_allocateArray(&Arr_D_Cls, teavm_local_5));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits) = teavm_local_13;
        teavm_local_13 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
        TEAVM_WITH_CALL_SITE_ID(34634, meth_jl_System_fastArraycopy(teavm_local_2, INT32_C(0), teavm_local_13, INT32_C(0), teavm_local_5));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(7));
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(34635, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), TEAVM_WITH_CALL_SITE_ID(34636, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_size)(teavm_local_3))));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats) = teavm_local_13;
    teavm_local_20 = INT32_C(0);
    while (1) {
        if (!(teavm_local_20 < TEAVM_WITH_CALL_SITE_ID(34637, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_size)(teavm_local_3)))) break;
        teavm_local_13 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(34638, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_get)(teavm_local_3, teavm_local_20));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(34639, teavm_checkcast(teavm_local_8, &jl_String_Cls, &supertypeof_jl_String));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(34640, teavm_nullCheck(teavm_local_13));
        teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(34641, teavm_checkBounds(teavm_local_20, teavm_local_13));
        teavm_gc_writeBarrier(teavm_local_13);
        TEAVM_ARRAY_AT(teavm_local_13, void*, teavm_local_20) = teavm_local_8;
        teavm_local_20 = (teavm_local_20 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_ChoiceFormat_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jt_ChoiceFormat_Cls, &supertypeof_jt_ChoiceFormat))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34642, teavm_checkcast(teavm_local_1, &jt_ChoiceFormat_Cls, &supertypeof_jt_ChoiceFormat));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34643, teavm_nullCheck(teavm_local_3));
        teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_ChoiceFormat, fld_choiceLimits);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        if (TEAVM_WITH_CALL_SITE_ID(34644, meth_ju_Arrays_equals_0(teavm_local_4, teavm_local_5))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats);
            teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_ChoiceFormat, fld_choiceFormats);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if (TEAVM_WITH_CALL_SITE_ID(34645, meth_ju_Arrays_equals(teavm_local_4, teavm_local_5))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_ChoiceFormat_format(void* teavm_this_, double teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(34646, teavm_nullCheck(teavm_local_4))) - INT32_C(1));
    while (1) {
        if ((teavm_local_5 < INT32_C(0))) {
            goto teavm_label_2;
        }
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34647, teavm_nullCheck(teavm_local_4));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(34648, teavm_checkBounds(teavm_local_5, teavm_local_4));
        if ((TEAVM_ARRAY_AT(teavm_local_4, double, teavm_local_5) <= teavm_local_1)) {
            goto teavm_label_3;
        }
        teavm_local_5 = (teavm_local_5 + -INT32_C(1));
    }
teavm_label_3:;
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34649, teavm_nullCheck(teavm_local_4));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(34650, teavm_checkUpperBound(teavm_local_5, teavm_local_4));
    teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34651, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34652, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_6));
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    if (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(34653, teavm_nullCheck(teavm_local_4)))) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34654, teavm_nullCheck(teavm_local_4));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_4, void*, TEAVM_WITH_CALL_SITE_ID(34655, teavm_checkUpperBound(INT32_C(0), teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34656, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34657, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_6));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_ChoiceFormat_format_0(void* teavm_this_, int64_t teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34658, TEAVM_METHOD(teavm_this_, jt_ChoiceFormat_VT, virt_format_0)(teavm_this_, ((double) teavm_local_1), teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jt_ChoiceFormat_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    double teavm_local_4;
    int64_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = INT32_C(0);
    teavm_local_2 = INT32_C(0);
    while (1) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((teavm_local_2 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(34659, teavm_nullCheck(teavm_local_3))))) {
            goto teavm_label_1;
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceLimits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34660, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34661, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, double, teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(34662, meth_jl_Double_doubleToLongBits(teavm_local_4));
        teavm_local_6 = ((int32_t) (teavm_local_5 ^ ((int64_t) ((uint64_t) teavm_local_5 >> INT32_C(32)))));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_ChoiceFormat, fld_choiceFormats);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34663, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34664, teavm_checkUpperBound(teavm_local_2, teavm_local_3));
        teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        teavm_local_1 = (teavm_local_1 + (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(34665, meth_jl_String_hashCode(TEAVM_WITH_CALL_SITE_ID(34666, teavm_nullCheck(teavm_local_7))))));
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
double meth_jt_ChoiceFormat_nextDouble(double teavm_local_1) {
    int64_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((teavm_local_1 != INFINITY)) {
        teavm_local_2 = ((teavm_local_1 != 0.0) ? TEAVM_WITH_CALL_SITE_ID(34667, meth_jl_Double_doubleToLongBits(teavm_local_1)) : INT64_C(0));
        teavm_local_1 = teavm_reinterpretLongToDouble(((!(teavm_local_1 < 0.0)) ? (teavm_local_2 + INT64_C(1)) : (teavm_local_2 - INT64_C(1))));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_ChoiceFormat_skipWhitespace(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34668, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34669, meth_jl_String_length(teavm_local_1));
    while (1) {
        if (!((teavm_local_2 < teavm_local_3) && TEAVM_WITH_CALL_SITE_ID(34670, meth_jl_Character_isWhitespace(TEAVM_WITH_CALL_SITE_ID(34671, meth_jl_String_charAt(teavm_local_1, teavm_local_2)))))) break;
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jt_ChoiceFormat(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1219 || tag >= 1221) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_ChoiceFormat_Cls[3];
alignas(8) jt_ChoiceFormat_VT jt_ChoiceFormat_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_ChoiceFormat), sizeof(void*)),
        .flags = 0,
        .tag = 1219,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7714),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_ChoiceFormat,
        .superclass = (TeaVM_Class*) &jt_NumberFormat_Cls,
        .layout = teavm_classLayouts_jt_ChoiceFormat_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_ChoiceFormat_hashCode,
    .virt_equals = &meth_jt_ChoiceFormat_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format_2 = &meth_jt_NumberFormat_format,
    .virt_formatToCharacterIterator = &meth_jt_Format_formatToCharacterIterator,
    .virt_setMaximumFractionDigits = &meth_jt_NumberFormat_setMaximumFractionDigits,
    .virt_format_1 = &meth_jt_ChoiceFormat_format_0,
    .virt_setMaximumIntegerDigits = &meth_jt_NumberFormat_setMaximumIntegerDigits,
    .virt_setMinimumFractionDigits = &meth_jt_NumberFormat_setMinimumFractionDigits,
    .virt_getMinimumIntegerDigits = &meth_jt_NumberFormat_getMinimumIntegerDigits,
    .virt_isGroupingUsed = &meth_jt_NumberFormat_isGroupingUsed,
    .virt_format_0 = &meth_jt_ChoiceFormat_format,
    .virt_getMaximumIntegerDigits = &meth_jt_NumberFormat_getMaximumIntegerDigits,
    .virt_setMinimumIntegerDigits = &meth_jt_NumberFormat_setMinimumIntegerDigits,
    .virt_setParseIntegerOnly = &meth_jt_NumberFormat_setParseIntegerOnly,
    .virt_getMaximumFractionDigits = &meth_jt_NumberFormat_getMaximumFractionDigits,
    .virt_format_3 = &meth_jt_Format_format,
    .virt_getMinimumFractionDigits = &meth_jt_NumberFormat_getMinimumFractionDigits,
    .virt_getCurrency = &meth_jt_NumberFormat_getCurrency,
    .virt_getRoundingMode = &meth_jt_NumberFormat_getRoundingMode,
    .virt_setGroupingUsed = &meth_jt_NumberFormat_setGroupingUsed,
    .virt_applyPattern = &meth_jt_ChoiceFormat_applyPattern
};
static int16_t teavm_classLayouts_jt_ChoiceFormat_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_ChoiceFormat, fld_choiceLimits), (int16_t) offsetof(cls_jt_ChoiceFormat, fld_choiceFormats)
};
void sysinitclass_jt_ChoiceFormat() {
}
