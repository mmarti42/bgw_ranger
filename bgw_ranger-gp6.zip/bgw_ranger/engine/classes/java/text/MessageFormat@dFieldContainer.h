#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "MessageFormat@dFieldContainer.h"

extern void sysinitclass_jt_MessageFormat_FieldContainer();
typedef struct cls_jt_MessageFormat_FieldContainer {
    struct TeaVM_Object parent;
    int32_t fld_start;
    int32_t fld_end;
    void* fld_attribute;
    void* fld_value;
} cls_jt_MessageFormat_FieldContainer;
extern void meth_jt_MessageFormat_FieldContainer__init_(void*, int32_t, int32_t, void*, void*);
extern int32_t supertypeof_jt_MessageFormat_FieldContainer(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_MessageFormat_FieldContainer_VT {
    jl_Object_VT parent;
} jt_MessageFormat_FieldContainer_VT;
extern jt_MessageFormat_FieldContainer_VT jt_MessageFormat_FieldContainer_Cls;
