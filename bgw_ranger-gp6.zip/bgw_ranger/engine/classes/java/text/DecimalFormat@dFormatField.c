#include "DecimalFormat@dFormatField.h"
#include "../../../strings.h"

int32_t supertypeof_jt_DecimalFormat_FormatField(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 245 || tag >= 1835) return INT32_C(0);
    if (tag >= 247 && tag < 345) return INT32_C(0);
    if (tag >= 347 && tag < 545) return INT32_C(0);
    if (tag >= 547 && tag < 1113) return INT32_C(0);
    if (tag >= 1115 && tag < 1833) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jt_DecimalFormat_FormatField_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 245,
    .modifiers = 1536,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jt_DecimalFormat_FormatField,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jt_DecimalFormat_FormatField() {
}
