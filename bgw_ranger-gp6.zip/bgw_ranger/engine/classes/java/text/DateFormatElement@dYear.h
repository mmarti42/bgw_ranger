#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dYear.h"

extern void sysinitclass_jt_DateFormatElement_Year();
typedef struct cls_jt_DateFormatElement_Year {
    struct cls_jt_DateFormatElement parent;
    int32_t fld_field;
} cls_jt_DateFormatElement_Year;
extern void meth_jt_DateFormatElement_Year__init_(void*, int32_t);
extern void meth_jt_DateFormatElement_Year_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_Year_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_Year_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_Year_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_Year(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_Year_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_Year_VT;
extern jt_DateFormatElement_Year_VT jt_DateFormatElement_Year_Cls;
