#include "AttributedString.h"
#include "../lang/Object.h"
#include "../util/HashMap.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/NullPointerException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "AttributedString@dAttributedIterator.h"
#include "../../../strings.h"

void meth_jt_AttributedString__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9699, meth_jl_Object__init_(teavm_this_));
    if ((teavm_local_1 != NULL)) {
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_AttributedString, fld_text) = teavm_local_1;
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9700, meth_otr_Allocator_allocate(&ju_HashMap_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(9701, meth_ju_HashMap__init_(teavm_local_2, INT32_C(11)));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jt_AttributedString, fld_attributeMap) = teavm_local_2;
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9702, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(9703, meth_jl_NullPointerException__init_(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(9704, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void* meth_jt_AttributedString_getIterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9705, meth_otr_Allocator_allocate(&jt_AttributedString_AttributedIterator_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9706, meth_jt_AttributedString_AttributedIterator__init_(teavm_local_1, teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_jt_AttributedString(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 387 || tag >= 389) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_AttributedString_Cls[3];
alignas(8) jt_AttributedString_VT jt_AttributedString_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_AttributedString), sizeof(void*)),
        .flags = 0,
        .tag = 387,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_AttributedString,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_AttributedString_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getIterator = &meth_jt_AttributedString_getIterator
};
static int16_t teavm_classLayouts_jt_AttributedString_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_AttributedString, fld_text), (int16_t) offsetof(cls_jt_AttributedString, fld_attributeMap)
};
void sysinitclass_jt_AttributedString() {
}
