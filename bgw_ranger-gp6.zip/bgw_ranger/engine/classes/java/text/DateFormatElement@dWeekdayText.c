#include "DateFormatElement@dWeekdayText.h"
#include "DateFormatElement.h"
#include "DateFormatSymbols.h"
#include "../util/Calendar.h"
#include "../lang/StringBuffer.h"
#include "ParsePosition.h"
#include "../lang/Object.h"
#include "../util/Arrays.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Boolean.h"
#include "../util/Objects.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_WeekdayText__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(37388, meth_jt_DateFormatElement__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37389, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37390, TEAVM_METHOD(teavm_local_1, jt_DateFormatSymbols_VT, virt_getWeekdays)(teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_weeks) = teavm_local_3;
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37391, TEAVM_METHOD(teavm_local_1, jt_DateFormatSymbols_VT, virt_getShortWeekdays)(teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_abbreviated) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_WeekdayText_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37392, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37393, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_get_2)(teavm_local_1, INT32_C(7)));
    if ((!TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_abbreviated))) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_weeks);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37394, teavm_nullCheck(teavm_local_4));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37395, teavm_checkBounds(teavm_local_3, teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_3);
    } else {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37396, teavm_nullCheck(teavm_local_4));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37397, teavm_checkBounds(teavm_local_3, teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_3);
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37398, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(37399, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_5));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_WeekdayText_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_weeks);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(37400, meth_jt_DateFormatElement_whichMatches(teavm_local_1, teavm_local_3, teavm_local_4));
    if ((teavm_local_5 < INT32_C(0))) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(37401, meth_jt_DateFormatElement_whichMatches(teavm_local_1, teavm_local_3, teavm_local_4));
    }
    if ((teavm_local_5 < INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37402, teavm_nullCheck(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(37403, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(37404, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3))));
    } else {
        teavm_local_6 = (teavm_local_5 + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(37405, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(37406, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_set_1)(teavm_local_2, INT32_C(4), teavm_local_6));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_WeekdayText_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(37407, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(37408, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37409, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_WeekdayText_Cls, &supertypeof_jt_DateFormatElement_WeekdayText));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_abbreviated);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(37410, teavm_nullCheck(teavm_local_4));
        if ((teavm_local_2 == TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_WeekdayText, fld_abbreviated))) {
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_weeks);
            teavm_local_6 = TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_WeekdayText, fld_weeks);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            if (TEAVM_WITH_CALL_SITE_ID(37411, meth_ju_Arrays_equals(teavm_local_5, teavm_local_6))) {
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks);
                teavm_local_6 = TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                if (TEAVM_WITH_CALL_SITE_ID(37412, meth_ju_Arrays_equals(teavm_local_5, teavm_local_6))) {
                    goto teavm_label_4;
                }
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_3;
    teavm_label_4:;
        teavm_local_2 = INT32_C(1);
    teavm_label_3:;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_WeekdayText_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(37413, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(3)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_weeks);
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_3;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(1)) = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_WeekdayText, fld_abbreviated);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(37414, meth_jl_Boolean_valueOf(teavm_local_4));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(2)) = teavm_local_5;
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(37415, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t supertypeof_jt_DateFormatElement_WeekdayText(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2284 || tag >= 2286) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatElement_WeekdayText_Cls[3];
alignas(8) jt_DateFormatElement_WeekdayText_VT jt_DateFormatElement_WeekdayText_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_WeekdayText), sizeof(void*)),
            .flags = 0,
            .tag = 2284,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7885),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_WeekdayText,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .layout = teavm_classLayouts_jt_DateFormatElement_WeekdayText_Cls,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_WeekdayText_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_WeekdayText_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_WeekdayText_format,
        .virt_parse = &meth_jt_DateFormatElement_WeekdayText_parse
    }
};
static int16_t teavm_classLayouts_jt_DateFormatElement_WeekdayText_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_DateFormatElement_WeekdayText, fld_weeks), (int16_t) offsetof(cls_jt_DateFormatElement_WeekdayText, fld_shortWeeks)
};
void sysinitclass_jt_DateFormatElement_WeekdayText() {
}
