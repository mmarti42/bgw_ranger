#include "DateFormatElement.h"
#include "../lang/Object.h"
#include "../lang/String.h"
#include "../lang/Character.h"
#include "ParsePosition.h"
#include "../../../strings.h"
#include "../util/Calendar.h"
#include "../lang/Math.h"
#include "../lang/StringBuilder.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/TimeZone.h"

void meth_jt_DateFormatElement__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44801, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_matches(void* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44802, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = (TEAVM_WITH_CALL_SITE_ID(44803, meth_jl_String_length(teavm_local_3)) + teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44804, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((teavm_local_4 > TEAVM_WITH_CALL_SITE_ID(44805, meth_jl_String_length(teavm_local_1)))) {
        teavm_local_4 = INT32_C(0);
    } else {
        teavm_local_5 = INT32_C(0);
        while (1) {
            if (!(teavm_local_5 < TEAVM_WITH_CALL_SITE_ID(44806, meth_jl_String_length(teavm_local_3)))) break;
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(44807, meth_jl_Character_toLowerCase(TEAVM_WITH_CALL_SITE_ID(44808, meth_jl_String_charAt(teavm_local_3, teavm_local_5))));
            teavm_local_4 = (teavm_local_2 + INT32_C(1));
            if ((teavm_local_6 != TEAVM_WITH_CALL_SITE_ID(44809, meth_jl_Character_toLowerCase(TEAVM_WITH_CALL_SITE_ID(44810, meth_jl_String_charAt(teavm_local_1, teavm_local_2)))))) {
                goto teavm_label_2;
            }
            teavm_local_5 = (teavm_local_5 + INT32_C(1));
            teavm_local_2 = teavm_local_4;
        }
        teavm_local_4 = INT32_C(1);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_4 = INT32_C(0);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jt_DateFormatElement_whichMatches(void* teavm_local_1, void* teavm_local_2, TeaVM_Array* teavm_local_3) {
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_4 = INT32_C(0);
    while (1) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44811, teavm_nullCheck(teavm_local_3));
        teavm_local_5 = teavm_local_3;
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(teavm_local_5))) {
            goto teavm_label_3;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(44812, teavm_checkLowerBound(teavm_local_4));
        if ((TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4) != NULL)) {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44813, teavm_nullCheck(teavm_local_2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(44814, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            if (TEAVM_WITH_CALL_SITE_ID(44815, meth_jt_DateFormatElement_matches(teavm_local_1, teavm_local_6, teavm_local_7))) {
                goto teavm_label_2;
            }
        }
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_3:;
    teavm_local_4 = -INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(44816, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    teavm_local_6 = (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(44817, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(44818, teavm_nullCheck(teavm_local_7)))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44819, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_6));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jt_DateFormatElement_tryParseFixedTimeZone(void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44820, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = (TEAVM_WITH_CALL_SITE_ID(44821, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3)) + INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44822, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((teavm_local_4 < TEAVM_WITH_CALL_SITE_ID(44823, meth_jl_String_length(teavm_local_1)))) {
        teavm_local_5 = (TEAVM_WITH_CALL_SITE_ID(44824, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3)) + INT32_C(3));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(44825, meth_jl_String_substring_0(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(44826, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3)), teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        if (TEAVM_WITH_CALL_SITE_ID(44827, meth_jl_String_equals(TEAVM_WITH_CALL_SITE_ID(44828, teavm_nullCheck(teavm_local_6)), TEAVM_GET_STRING(1651)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44829, meth_jl_String_charAt(teavm_local_1, teavm_local_5));
            if ((!((teavm_local_7 != INT32_C(43)) && (teavm_local_7 != INT32_C(45))))) {
                TEAVM_WITH_CALL_SITE_ID(44830, meth_jt_DateFormatElement_parseHoursMinutes(teavm_local_1, teavm_local_2, teavm_local_3));
                teavm_local_4 = INT32_C(1);
                goto teavm_label_1;
            }
        }
    }
    if (((TEAVM_WITH_CALL_SITE_ID(44831, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3)) + INT32_C(5)) <= TEAVM_WITH_CALL_SITE_ID(44832, meth_jl_String_length(teavm_local_1)))) {
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44833, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
        teavm_local_9 = (teavm_local_8 + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44834, meth_jl_String_charAt(teavm_local_1, teavm_local_8));
        if ((!((teavm_local_7 != INT32_C(43)) && (teavm_local_7 != INT32_C(45))))) {
            teavm_local_10 = INT32_C(0);
            while (1) {
                if ((teavm_local_10 >= INT32_C(4))) {
                    goto teavm_label_2;
                }
                if ((!TEAVM_WITH_CALL_SITE_ID(44835, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(44836, meth_jl_String_charAt(teavm_local_1, (teavm_local_9 + teavm_local_10))))))) {
                    goto teavm_label_3;
                }
                teavm_local_10 = (teavm_local_10 + INT32_C(1));
            }
        teavm_label_3:;
        }
    }
    teavm_local_4 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_11 = ((teavm_local_7 != INT32_C(45)) ? INT32_C(1) : -INT32_C(1));
    teavm_local_12 = ((INT32_C(10) * TEAVM_WITH_CALL_SITE_ID(44837, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(44838, meth_jl_String_charAt(teavm_local_1, teavm_local_9)), INT32_C(10)))) + TEAVM_WITH_CALL_SITE_ID(44839, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(44840, meth_jl_String_charAt(teavm_local_1, (teavm_local_9 + INT32_C(1)))), INT32_C(10))));
    teavm_local_4 = (INT32_C(10) * TEAVM_WITH_CALL_SITE_ID(44841, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(44842, meth_jl_String_charAt(teavm_local_1, (teavm_local_9 + INT32_C(2)))), INT32_C(10))));
    teavm_local_9 = (teavm_local_9 + INT32_C(3));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(44843, meth_jl_String_charAt(teavm_local_1, teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_13 = (teavm_local_4 + TEAVM_WITH_CALL_SITE_ID(44844, meth_jl_Character_digit(teavm_local_9, INT32_C(10))));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(44845, meth_jt_DateFormatElement_getStaticTimeZone((teavm_local_11 * teavm_local_12), teavm_local_13));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44846, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(44847, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_setTimeZone)(teavm_local_2, teavm_local_6));
    teavm_local_4 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void meth_jt_DateFormatElement_parseHoursMinutes(void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_local_12;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44848, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = (TEAVM_WITH_CALL_SITE_ID(44849, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3)) + INT32_C(3));
    teavm_local_5 = (teavm_local_4 + INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44850, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_6 = ((TEAVM_WITH_CALL_SITE_ID(44851, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) != INT32_C(45)) ? INT32_C(1) : -INT32_C(1));
    if ((!((teavm_local_5 < TEAVM_WITH_CALL_SITE_ID(44852, meth_jl_String_length(teavm_local_1))) && TEAVM_WITH_CALL_SITE_ID(44853, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(44854, meth_jl_String_charAt(teavm_local_1, teavm_local_5))))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(44855, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_5));
    } else {
        teavm_local_7 = (teavm_local_5 + INT32_C(1));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44856, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(44857, meth_jl_String_charAt(teavm_local_1, teavm_local_5)), INT32_C(10)));
        if ((teavm_local_7 >= TEAVM_WITH_CALL_SITE_ID(44858, meth_jl_String_length(teavm_local_1)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(44859, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_7));
        } else {
            if ((TEAVM_WITH_CALL_SITE_ID(44860, meth_jl_String_charAt(teavm_local_1, teavm_local_7)) != INT32_C(58))) {
                if ((!TEAVM_WITH_CALL_SITE_ID(44861, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(44862, meth_jl_String_charAt(teavm_local_1, teavm_local_7)))))) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_WITH_CALL_SITE_ID(44863, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_7));
                    goto teavm_label_1;
                }
                teavm_local_8 = ((INT32_C(10) * teavm_local_8) + TEAVM_WITH_CALL_SITE_ID(44864, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(44865, meth_jl_String_charAt(teavm_local_1, teavm_local_7)), INT32_C(10))));
            }
            if ((!((teavm_local_7 < TEAVM_WITH_CALL_SITE_ID(44866, meth_jl_String_length(teavm_local_1))) && (TEAVM_WITH_CALL_SITE_ID(44867, meth_jl_String_charAt(teavm_local_1, teavm_local_7)) == INT32_C(58))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(44868, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_7));
            } else {
                teavm_local_5 = (teavm_local_7 + INT32_C(1));
                teavm_local_9 = (teavm_local_5 + INT32_C(2));
                if (((teavm_local_9 <= TEAVM_WITH_CALL_SITE_ID(44869, meth_jl_String_length(teavm_local_1))) && TEAVM_WITH_CALL_SITE_ID(44870, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(44871, meth_jl_String_charAt(teavm_local_1, teavm_local_5)))))) {
                    teavm_local_10 = (teavm_local_5 + INT32_C(1));
                    if (TEAVM_WITH_CALL_SITE_ID(44872, meth_jl_Character_isDigit(TEAVM_WITH_CALL_SITE_ID(44873, meth_jl_String_charAt(teavm_local_1, teavm_local_10))))) {
                        goto teavm_label_2;
                    }
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(44874, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, teavm_local_5));
                goto teavm_label_1;
            teavm_label_2:;
                teavm_local_10 = (TEAVM_WITH_CALL_SITE_ID(44875, meth_jl_Character_digit(TEAVM_WITH_CALL_SITE_ID(44876, meth_jl_String_charAt(teavm_local_1, teavm_local_5)), INT32_C(10))) * INT32_C(10));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(44877, meth_jl_String_charAt(teavm_local_1, teavm_local_5));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_11 = (teavm_local_10 + TEAVM_WITH_CALL_SITE_ID(44878, meth_jl_Character_digit(teavm_local_5, INT32_C(10))));
                TEAVM_WITH_CALL_SITE_ID(44879, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setIndex)(teavm_local_3, teavm_local_9));
                teavm_local_5 = (teavm_local_6 * teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(44880, meth_jt_DateFormatElement_getStaticTimeZone(teavm_local_5, teavm_local_11));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44881, teavm_nullCheck(teavm_local_2));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_WITH_CALL_SITE_ID(44882, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_setTimeZone)(teavm_local_2, teavm_local_12));
            }
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DateFormatElement_getStaticTimeZone(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = ((teavm_local_1 <= INT32_C(0)) ? INT32_C(45) : INT32_C(43));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(44883, meth_jl_Math_abs_0(teavm_local_1));
    teavm_local_5 = (teavm_local_2 / INT32_C(10));
    teavm_local_6 = (teavm_local_2 % INT32_C(10));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44884, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(44885, meth_jl_StringBuilder__init_(teavm_local_7));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44886, meth_jl_StringBuilder_append(teavm_local_7, TEAVM_GET_STRING(1651)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44887, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(44888, teavm_nullCheck(teavm_local_8)), teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44889, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(44890, teavm_nullCheck(teavm_local_8)), teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44891, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(44892, teavm_nullCheck(teavm_local_8)), INT32_C(58)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44893, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(44894, teavm_nullCheck(teavm_local_8)), teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(44895, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(44896, teavm_nullCheck(teavm_local_8)), teavm_local_6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44897, meth_jl_StringBuilder_toString(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44898, meth_ju_TimeZone_getTimeZone(teavm_local_7));
    TEAVM_RELEASE_STACK;
    return teavm_local_7;
}
int32_t supertypeof_jt_DateFormatElement(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2259 || tag >= 2289) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_VT jt_DateFormatElement_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement), sizeof(void*)),
        .flags = 0,
        .tag = 2259,
        .modifiers = 1024,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormatElement,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
void sysinitclass_jt_DateFormatElement() {
}
