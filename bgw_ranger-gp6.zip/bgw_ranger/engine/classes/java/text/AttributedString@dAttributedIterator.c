#include "AttributedString@dAttributedIterator.h"
#include "../lang/Object.h"
#include "AttributedString.h"
#include "../lang/String.h"
#include "AttributedString@dRange.h"
#include "Annotation.h"
#include "../util/List.h"
#include "../util/Iterator.h"
#include "../util/Map.h"
#include "../util/HashSet.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../util/Set.h"
#include "../util/Map@dEntry.h"
#include "../util/AbstractCollection.h"
#include "AttributedCharacterIterator@dAttribute.h"
#include "../util/ArrayList.h"
#include "../util/HashMap.h"
#include "../util/ListIterator.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"

void meth_jt_AttributedString_AttributedIterator__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(444, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin) = INT32_C(0);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(445, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jt_AttributedString, fld_text);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end) = TEAVM_WITH_CALL_SITE_ID(446, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(447, teavm_nullCheck(teavm_local_2))));
    TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) = INT32_C(0);
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_AttributedString_AttributedIterator_getEndIndex(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end);
}
int32_t meth_jt_AttributedString_AttributedIterator_getIndex(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset);
}
int32_t meth_jt_AttributedString_AttributedIterator_inRange(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(448, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = ((!teavm_instanceof(TEAVM_FIELD(teavm_local_1, cls_jt_AttributedString_Range, fld_value), &jt_Annotation_Cls, &supertypeof_jt_Annotation)) ? INT32_C(1) : ((!((TEAVM_FIELD(teavm_local_1, cls_jt_AttributedString_Range, fld_start) >= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin)) && ((TEAVM_FIELD(teavm_local_1, cls_jt_AttributedString_Range, fld_start) < TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end)) && ((TEAVM_FIELD(teavm_local_1, cls_jt_AttributedString_Range, fld_end) > TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin)) && (TEAVM_FIELD(teavm_local_1, cls_jt_AttributedString_Range, fld_end) <= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end)))))) ? INT32_C(0) : INT32_C(1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_inRange_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(449, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(450, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(451, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(452, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_4;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(453, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(454, teavm_checkcast(teavm_local_3, &jt_AttributedString_Range_Cls, &supertypeof_jt_AttributedString_Range));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(455, teavm_nullCheck(teavm_local_4));
        if (((TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_start) >= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin)) && (TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_start) < TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end)))) {
            goto teavm_label_2;
        }
        if (((TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_end) > TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin)) && (TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_end) <= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end)))) {
            goto teavm_label_3;
        }
    }
teavm_label_4:;
    teavm_local_5 = INT32_C(0);
    goto teavm_label_1;
teavm_label_3:;
    if (teavm_instanceof(TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_value), &jt_Annotation_Cls, &supertypeof_jt_Annotation)) {
        if ((TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_start) < TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin))) {
            goto teavm_label_6;
        }
        if ((TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_start) >= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end))) {
            goto teavm_label_6;
        }
    }
    teavm_local_5 = INT32_C(1);
    goto teavm_label_5;
teavm_label_6:;
    teavm_local_5 = INT32_C(0);
teavm_label_5:;
    goto teavm_label_1;
teavm_label_2:;
    if (teavm_instanceof(TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_value), &jt_Annotation_Cls, &supertypeof_jt_Annotation)) {
        if ((TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_end) <= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin))) {
            goto teavm_label_8;
        }
        if ((TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_end) > TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end))) {
            goto teavm_label_8;
        }
    }
    teavm_local_5 = INT32_C(1);
    goto teavm_label_7;
teavm_label_8:;
    teavm_local_5 = INT32_C(0);
teavm_label_7:;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jt_AttributedString_AttributedIterator_getAllAttributeKeys(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(5));
    if ((!TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(456, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_text);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if (((teavm_local_1 == TEAVM_WITH_CALL_SITE_ID(457, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(458, teavm_nullCheck(teavm_local_2))))) && (TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed) == NULL))) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(459, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(460, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(461, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_keySet)(teavm_tmp_ptr_0)));
            goto teavm_label_1;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(462, meth_otr_Allocator_allocate(&ju_HashSet_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(463, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_1 = (((TEAVM_WITH_CALL_SITE_ID(464, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(465, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_size)(teavm_tmp_ptr_0))) * INT32_C(4)) / INT32_C(3)) + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(466, meth_ju_HashSet__init_(teavm_local_3, teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(467, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(468, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(469, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_entrySet)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(470, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(471, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(472, teavm_nullCheck(teavm_local_4));
        if ((!TEAVM_WITH_CALL_SITE_ID(473, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_hasNext)(teavm_local_4)))) {
            goto teavm_label_2;
        }
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(474, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_next)(teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(475, teavm_checkcast(teavm_local_2, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
        if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed) != NULL)) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(476, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(477, TEAVM_METHOD(teavm_local_5, ju_Map_Entry_VT, virt_getKey)(teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_6);
            if ((!TEAVM_WITH_CALL_SITE_ID(478, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(479, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractCollection_VT, virt_contains)(teavm_tmp_ptr_0, teavm_local_6))))) {
                goto teavm_label_3;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(480, teavm_nullCheck(teavm_local_5));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(481, TEAVM_METHOD(teavm_local_5, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(482, teavm_checkcast(teavm_local_2, &ju_List_Cls, &supertypeof_ju_List));
        if (TEAVM_WITH_CALL_SITE_ID(483, meth_jt_AttributedString_AttributedIterator_inRange_0(teavm_this_, teavm_local_7))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(484, TEAVM_METHOD(teavm_local_5, ju_Map_Entry_VT, virt_getKey)(teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(485, TEAVM_METHOD(teavm_local_3, ju_Set_VT, virt_add_2)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(486, teavm_checkcast(teavm_local_2, &jt_AttributedCharacterIterator_Attribute_Cls, &supertypeof_jt_AttributedCharacterIterator_Attribute))));
        }
    teavm_label_3:;
    }
teavm_label_2:;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_AttributedString_AttributedIterator_currentValue(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(487, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(488, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(489, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(490, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_3;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(491, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(492, teavm_checkcast(teavm_local_3, &jt_AttributedString_Range_Cls, &supertypeof_jt_AttributedString_Range));
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(493, teavm_nullCheck(teavm_local_4));
        if (((teavm_local_5 >= TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_start)) && (TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) < TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_end)))) {
            goto teavm_label_2;
        }
    }
teavm_label_3:;
    teavm_local_3 = NULL;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = ((!TEAVM_WITH_CALL_SITE_ID(494, meth_jt_AttributedString_AttributedIterator_inRange(teavm_this_, teavm_local_4))) ? NULL : TEAVM_FIELD(teavm_local_4, cls_jt_AttributedString_Range, fld_value));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_AttributedString_AttributedIterator_getAttribute(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed) != NULL)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((!TEAVM_WITH_CALL_SITE_ID(495, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(496, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractCollection_VT, virt_contains)(teavm_tmp_ptr_0, teavm_local_1))))) {
            teavm_local_2 = NULL;
            goto teavm_label_1;
        }
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(497, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(498, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(499, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_get_3)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(500, teavm_checkcast(teavm_local_2, &ju_ArrayList_Cls, &supertypeof_ju_ArrayList));
    if ((teavm_local_3 != NULL)) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(501, meth_jt_AttributedString_AttributedIterator_currentValue(teavm_this_, teavm_local_3));
    } else {
        teavm_local_2 = NULL;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_AttributedString_AttributedIterator_getAttributes(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(502, meth_otr_Allocator_allocate(&ju_HashMap_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(503, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = (((TEAVM_WITH_CALL_SITE_ID(504, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(505, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_size)(teavm_tmp_ptr_0))) * INT32_C(4)) / INT32_C(3)) + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(506, meth_ju_HashMap__init_(teavm_local_1, teavm_local_3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(507, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(508, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(509, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_entrySet)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(510, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(511, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(512, teavm_nullCheck(teavm_local_4));
        if ((!TEAVM_WITH_CALL_SITE_ID(513, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_hasNext)(teavm_local_4)))) {
            goto teavm_label_1;
        }
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(514, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_next)(teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(515, teavm_checkcast(teavm_local_2, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
        if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed) != NULL)) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(516, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(517, TEAVM_METHOD(teavm_local_5, ju_Map_Entry_VT, virt_getKey)(teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_6);
            if ((!TEAVM_WITH_CALL_SITE_ID(518, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(519, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractCollection_VT, virt_contains)(teavm_tmp_ptr_0, teavm_local_6))))) {
                goto teavm_label_2;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(520, teavm_nullCheck(teavm_local_5));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(521, TEAVM_METHOD(teavm_local_5, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(522, meth_jt_AttributedString_AttributedIterator_currentValue(teavm_this_, TEAVM_WITH_CALL_SITE_ID(523, teavm_checkcast(teavm_local_2, &ju_List_Cls, &supertypeof_ju_List))));
        if ((teavm_local_7 != NULL)) {
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(524, TEAVM_METHOD(teavm_local_5, ju_Map_Entry_VT, virt_getKey)(teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(525, TEAVM_METHOD(teavm_local_1, ju_Map_VT, virt_put)(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(526, teavm_checkcast(teavm_local_2, &jt_AttributedCharacterIterator_Attribute_Cls, &supertypeof_jt_AttributedCharacterIterator_Attribute)), teavm_local_7));
        }
    teavm_label_2:;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_AttributedString_AttributedIterator_getRunLimit(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(527, TEAVM_METHOD(teavm_this_, jt_AttributedString_AttributedIterator_VT, virt_getAllAttributeKeys)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(528, TEAVM_METHOD(teavm_this_, jt_AttributedString_AttributedIterator_VT, virt_getRunLimit)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_runLimit(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(529, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(530, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_listIterator)(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(531, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_size)(teavm_local_1))));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(532, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(533, TEAVM_METHOD(teavm_local_3, ju_ListIterator_VT, virt_hasPrevious)(teavm_local_3)))) {
            goto teavm_label_3;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(534, TEAVM_METHOD(teavm_local_3, ju_ListIterator_VT, virt_previous)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(535, teavm_checkcast(teavm_local_4, &jt_AttributedString_Range_Cls, &supertypeof_jt_AttributedString_Range));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(536, teavm_nullCheck(teavm_local_5));
        if ((TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_end) <= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin))) {
            goto teavm_label_4;
        }
        if (((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) >= TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_start)) && (TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) < TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_end)))) {
            goto teavm_label_2;
        }
        if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) >= TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_end))) {
            goto teavm_label_5;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_start);
    }
teavm_label_5:;
    goto teavm_label_3;
teavm_label_4:;
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if (TEAVM_WITH_CALL_SITE_ID(537, meth_jt_AttributedString_AttributedIterator_inRange(teavm_this_, teavm_local_5))) {
        teavm_local_2 = TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_end);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_getRunLimit_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed) != NULL)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((!TEAVM_WITH_CALL_SITE_ID(538, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(539, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractCollection_VT, virt_contains)(teavm_tmp_ptr_0, teavm_local_1))))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end);
            goto teavm_label_1;
        }
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(540, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(541, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(542, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_get_3)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(543, teavm_checkcast(teavm_local_2, &ju_ArrayList_Cls, &supertypeof_ju_ArrayList));
    if ((teavm_local_4 != NULL)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(544, meth_jt_AttributedString_AttributedIterator_runLimit(teavm_this_, teavm_local_4));
    } else {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jt_AttributedString_AttributedIterator_getRunLimit_1(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(545, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(546, TEAVM_METHOD(teavm_local_1, ju_Set_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(547, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(548, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(549, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(550, teavm_checkcast(teavm_local_4, &jt_AttributedCharacterIterator_Attribute_Cls, &supertypeof_jt_AttributedCharacterIterator_Attribute));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(551, TEAVM_METHOD(teavm_this_, jt_AttributedString_AttributedIterator_VT, virt_getRunLimit_0)(teavm_this_, teavm_local_5));
        if ((teavm_local_6 < teavm_local_2)) {
            teavm_local_2 = teavm_local_6;
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_getRunStart(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(552, TEAVM_METHOD(teavm_this_, jt_AttributedString_AttributedIterator_VT, virt_getAllAttributeKeys)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(553, TEAVM_METHOD(teavm_this_, jt_AttributedString_AttributedIterator_VT, virt_getRunStart)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_runStart(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(554, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(555, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(556, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(557, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_3;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(558, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(559, teavm_checkcast(teavm_local_4, &jt_AttributedString_Range_Cls, &supertypeof_jt_AttributedString_Range));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(560, teavm_nullCheck(teavm_local_5));
        if ((TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_start) >= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end))) {
            goto teavm_label_4;
        }
        if (((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) >= TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_start)) && (TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) < TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_end)))) {
            goto teavm_label_2;
        }
        if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) < TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_start))) {
            goto teavm_label_5;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_end);
    }
teavm_label_5:;
    goto teavm_label_3;
teavm_label_4:;
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if (TEAVM_WITH_CALL_SITE_ID(561, meth_jt_AttributedString_AttributedIterator_inRange(teavm_this_, teavm_local_5))) {
        teavm_local_2 = TEAVM_FIELD(teavm_local_5, cls_jt_AttributedString_Range, fld_start);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_getRunStart_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed) != NULL)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((!TEAVM_WITH_CALL_SITE_ID(562, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(563, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractCollection_VT, virt_contains)(teavm_tmp_ptr_0, teavm_local_1))))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin);
            goto teavm_label_1;
        }
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(564, teavm_nullCheck(teavm_local_2)), cls_jt_AttributedString, fld_attributeMap);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(565, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(566, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_get_3)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(567, teavm_checkcast(teavm_local_2, &ju_ArrayList_Cls, &supertypeof_ju_ArrayList));
    if ((teavm_local_4 != NULL)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(568, meth_jt_AttributedString_AttributedIterator_runStart(teavm_this_, teavm_local_4));
    } else {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jt_AttributedString_AttributedIterator_getRunStart_1(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(569, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(570, TEAVM_METHOD(teavm_local_1, ju_Set_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(571, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(572, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(573, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(574, teavm_checkcast(teavm_local_4, &jt_AttributedCharacterIterator_Attribute_Cls, &supertypeof_jt_AttributedCharacterIterator_Attribute));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(575, TEAVM_METHOD(teavm_this_, jt_AttributedString_AttributedIterator_VT, virt_getRunStart_0)(teavm_this_, teavm_local_5));
        if ((teavm_local_6 > teavm_local_2)) {
            teavm_local_2 = teavm_local_6;
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_AttributedString_AttributedIterator_setIndex(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_1 >= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_begin)) && (teavm_local_1 <= TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end)))) {
        TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) = teavm_local_1;
        if ((TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset) == TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_end))) {
            teavm_local_2 = INT32_C(65535);
        } else {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_attrString);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(576, teavm_nullCheck(teavm_local_3)), cls_jt_AttributedString, fld_text);
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_AttributedString_AttributedIterator, fld_offset);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(577, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(578, teavm_nullCheck(teavm_local_3)), teavm_local_2));
        }
        TEAVM_RELEASE_STACK;
        return teavm_local_2;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(579, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(580, meth_jl_IllegalArgumentException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(581, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_jt_AttributedString_AttributedIterator(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 53 || tag >= 55) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_AttributedString_AttributedIterator_Cls[3];
alignas(8) jt_AttributedString_AttributedIterator_VT jt_AttributedString_AttributedIterator_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_AttributedString_AttributedIterator), sizeof(void*)),
        .flags = 0,
        .tag = 53,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_AttributedString_AttributedIterator,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_AttributedString_AttributedIterator_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_setIndex_0 = &meth_jt_AttributedString_AttributedIterator_setIndex,
    .virt_getAttribute = &meth_jt_AttributedString_AttributedIterator_getAttribute,
    .virt_getEndIndex = &meth_jt_AttributedString_AttributedIterator_getEndIndex,
    .virt_getAttributes = &meth_jt_AttributedString_AttributedIterator_getAttributes,
    .virt_getIndex = &meth_jt_AttributedString_AttributedIterator_getIndex,
    .virt_getAllAttributeKeys = &meth_jt_AttributedString_AttributedIterator_getAllAttributeKeys,
    .virt_getRunStart_1 = &meth_jt_AttributedString_AttributedIterator_getRunStart,
    .virt_getRunLimit = &meth_jt_AttributedString_AttributedIterator_getRunLimit_1,
    .virt_getRunLimit_0 = &meth_jt_AttributedString_AttributedIterator_getRunLimit_0,
    .virt_getRunLimit_1 = &meth_jt_AttributedString_AttributedIterator_getRunLimit,
    .virt_getRunStart_0 = &meth_jt_AttributedString_AttributedIterator_getRunStart_0,
    .virt_getRunStart = &meth_jt_AttributedString_AttributedIterator_getRunStart_1
};
static int16_t teavm_classLayouts_jt_AttributedString_AttributedIterator_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_AttributedString_AttributedIterator, fld_attrString), (int16_t) offsetof(cls_jt_AttributedString_AttributedIterator, fld_attributesAllowed)
};
void sysinitclass_jt_AttributedString_AttributedIterator() {
}
