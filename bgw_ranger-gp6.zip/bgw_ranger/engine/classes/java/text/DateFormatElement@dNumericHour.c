#include "DateFormatElement@dNumericHour.h"
#include "DateFormatElement@dNumeric.h"
#include "../lang/Object.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Integer.h"
#include "../util/Objects.h"
#include "DateFormatElement.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_NumericHour__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43547, meth_jt_DateFormatElement_Numeric__init_(teavm_this_, teavm_local_1, teavm_local_2, INT32_C(2)));
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_NumericHour, fld_limit) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_NumericHour_processBeforeFormat(void* teavm_this_, int32_t teavm_local_1) {
    if ((!teavm_local_1)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_NumericHour, fld_limit);
    }
    return teavm_local_1;
}
int32_t meth_jt_DateFormatElement_NumericHour_processAfterParse(void* teavm_this_, int32_t teavm_local_1) {
    if ((teavm_local_1 == TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_NumericHour, fld_limit))) {
        teavm_local_1 = INT32_C(0);
    }
    return teavm_local_1;
}
int32_t meth_jt_DateFormatElement_NumericHour_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43548, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(43549, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if ((!TEAVM_WITH_CALL_SITE_ID(43550, meth_jt_DateFormatElement_Numeric_equals(teavm_this_, teavm_local_1)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43551, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_NumericHour_Cls, &supertypeof_jt_DateFormatElement_NumericHour));
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_NumericHour, fld_limit);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43552, teavm_nullCheck(teavm_local_4));
            teavm_local_2 = ((teavm_local_2 != TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_NumericHour, fld_limit)) ? INT32_C(0) : INT32_C(1));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_NumericHour_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43553, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(2)));
    teavm_local_2 = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43554, meth_jl_Integer_valueOf_0(TEAVM_WITH_CALL_SITE_ID(43555, meth_jt_DateFormatElement_Numeric_hashCode(teavm_this_))));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_3;
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43556, meth_jl_Integer_valueOf_0(TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_NumericHour, fld_limit)));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(1)) = teavm_local_3;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43557, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t supertypeof_jt_DateFormatElement_NumericHour(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2271 || tag >= 2273) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_NumericHour_VT jt_DateFormatElement_NumericHour_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_NumericHour), sizeof(void*)),
            .flags = 0,
            .tag = 2271,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(8131),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_NumericHour,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Numeric_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_NumericHour_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_NumericHour_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_Numeric_format,
        .virt_parse = &meth_jt_DateFormatElement_Numeric_parse,
        .virt_processAfterParse = &meth_jt_DateFormatElement_NumericHour_processAfterParse,
        .virt_processBeforeFormat = &meth_jt_DateFormatElement_NumericHour_processBeforeFormat
    }
};
void sysinitclass_jt_DateFormatElement_NumericHour() {
}
