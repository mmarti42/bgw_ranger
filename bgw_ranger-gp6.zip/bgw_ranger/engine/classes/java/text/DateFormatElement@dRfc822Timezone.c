#include "DateFormatElement@dRfc822Timezone.h"
#include "DateFormatElement@dBaseTimezone.h"
#include "../util/Calendar.h"
#include "../util/TimeZone.h"
#include "../lang/StringBuffer.h"
#include "DateFormatElement.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_jt_DateFormatElement_Rfc822Timezone__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33741, meth_jt_DateFormatElement_BaseTimezone__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Rfc822Timezone_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    int64_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33742, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33743, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_getTimeZone)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33744, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_getTimeInMillis)(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33745, teavm_nullCheck(teavm_local_3));
    teavm_local_5 = (TEAVM_WITH_CALL_SITE_ID(33746, TEAVM_METHOD(teavm_local_3, ju_TimeZone_VT, virt_getOffset)(teavm_local_3, teavm_local_4)) / INT32_C(60000));
    if ((teavm_local_5 >= INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33747, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(33748, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(43)));
    } else {
        teavm_local_5 = (-teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33749, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(33750, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(45)));
    }
    teavm_local_6 = (teavm_local_5 / INT32_C(60));
    teavm_local_7 = (teavm_local_5 % INT32_C(60));
    teavm_local_8 = (teavm_local_6 / INT32_C(10));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(33751, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_2)(teavm_local_2, teavm_local_8));
    teavm_local_8 = (teavm_local_6 % INT32_C(10));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(33752, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33753, teavm_nullCheck(teavm_local_9))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_2)(teavm_tmp_ptr_0, teavm_local_8)));
    teavm_local_8 = (teavm_local_7 / INT32_C(10));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(33754, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33755, teavm_nullCheck(teavm_local_9))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_2)(teavm_tmp_ptr_0, teavm_local_8)));
    teavm_local_8 = (teavm_local_7 % INT32_C(10));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(33756, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33757, teavm_nullCheck(teavm_local_9))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_2)(teavm_tmp_ptr_0, teavm_local_8)));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_DateFormatElement_Rfc822Timezone(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2279 || tag >= 2281) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_Rfc822Timezone_VT jt_DateFormatElement_Rfc822Timezone_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_Rfc822Timezone), sizeof(void*)),
            .flags = 0,
            .tag = 2279,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7661),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_Rfc822Timezone,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_BaseTimezone_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_BaseTimezone_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_BaseTimezone_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_Rfc822Timezone_format,
        .virt_parse = &meth_jt_DateFormatElement_BaseTimezone_parse,
        .virt_match = &meth_jt_DateFormatElement_BaseTimezone_match
    }
};
void sysinitclass_jt_DateFormatElement_Rfc822Timezone() {
}
