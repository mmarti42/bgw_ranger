#include "MessageFormat.h"
#include "Format.h"
#include "../util/Locale.h"
#include "../lang/String.h"
#include "../lang/StringBuffer.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "ParsePosition.h"
#include "../util/ArrayList.h"
#include "../../../arrays/primitives/int.h"
#include "../../../arrayclass.h"
#include "../util/List.h"
#include "../lang/System.h"
#include "../lang/IllegalArgumentException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "FieldPosition.h"
#include "../lang/Number.h"
#include "NumberFormat.h"
#include "../util/Date.h"
#include "DateFormat.h"
#include "ChoiceFormat.h"
#include "MessageFormat@dFieldContainer.h"
#include "MessageFormat@dField.h"
#include "../lang/Integer.h"
#include "AttributedCharacterIterator.h"
#include "../util/Map.h"
#include "../util/Set.h"
#include "../util/Iterator.h"
#include "AttributedCharacterIterator@dAttribute.h"
#include "../lang/Object.h"
#include "../lang/Character.h"
#include "DecimalFormat.h"
#include "DecimalFormatSymbols.h"
#include "SimpleDateFormat.h"

void meth_jt_MessageFormat__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24251, meth_jt_Format__init_(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24252, meth_ju_Locale_getDefault());
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale) = teavm_local_2;
    TEAVM_WITH_CALL_SITE_ID(24253, TEAVM_METHOD(teavm_this_, jt_MessageFormat_VT, virt_applyPattern)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_MessageFormat_applyPattern(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    TEAVM_ALLOC_STACK(INT32_C(7));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(6));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24254, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24255, meth_jl_String_length(teavm_local_1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24256, meth_otr_Allocator_allocate(&jl_StringBuffer_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(24257, meth_jl_StringBuffer__init__0(teavm_local_3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(24258, meth_otr_Allocator_allocate(&jt_ParsePosition_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(24259, meth_jt_ParsePosition__init_(teavm_local_4, INT32_C(0)));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24260, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(24261, meth_ju_ArrayList__init_(teavm_local_5));
    teavm_local_6 = INT32_C(0);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24262, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(10)));
    teavm_local_8 = -INT32_C(1);
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_7);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24263, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
    TEAVM_GC_ROOT(INT32_C(5), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(24264, meth_ju_ArrayList__init_(teavm_local_9));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_7);
        if ((TEAVM_WITH_CALL_SITE_ID(24265, TEAVM_METHOD(teavm_local_4, jt_ParsePosition_VT, virt_getIndex)(teavm_local_4)) >= teavm_local_2)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24266, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), TEAVM_WITH_CALL_SITE_ID(24267, TEAVM_METHOD(teavm_local_5, ju_List_VT, virt_size)(teavm_local_5))));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_strings) = teavm_local_10;
            teavm_local_11 = INT32_C(0);
            while (1) {
                if (!(teavm_local_11 < TEAVM_WITH_CALL_SITE_ID(24268, TEAVM_METHOD(teavm_local_5, ju_List_VT, virt_size)(teavm_local_5)))) break;
                teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_strings);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24269, TEAVM_METHOD(teavm_local_5, ju_List_VT, virt_get)(teavm_local_5, teavm_local_11));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24270, teavm_checkcast(teavm_local_12, &jl_String_Cls, &supertypeof_jl_String));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24271, teavm_nullCheck(teavm_local_10));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(24272, teavm_checkBounds(teavm_local_11, teavm_local_10));
                teavm_gc_writeBarrier(teavm_local_10);
                TEAVM_ARRAY_AT(teavm_local_10, void*, teavm_local_11) = teavm_local_12;
                teavm_local_11 = (teavm_local_11 + INT32_C(1));
            }
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers) = teavm_local_7;
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24273, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_Format_Cls), teavm_local_6));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_formats) = teavm_local_10;
            teavm_local_11 = INT32_C(0);
            while (1) {
                if (!(teavm_local_11 < teavm_local_6)) break;
                teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_formats);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24274, TEAVM_METHOD(teavm_local_9, ju_List_VT, virt_get)(teavm_local_9, teavm_local_11));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24275, teavm_checkcast(teavm_local_12, &jt_Format_Cls, &supertypeof_jt_Format));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24276, teavm_nullCheck(teavm_local_10));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(24277, teavm_checkBounds(teavm_local_11, teavm_local_10));
                teavm_gc_writeBarrier(teavm_local_10);
                TEAVM_ARRAY_AT(teavm_local_10, void*, teavm_local_11) = teavm_local_12;
                teavm_local_11 = (teavm_local_11 + INT32_C(1));
            }
            TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_maxOffset) = (teavm_local_6 - INT32_C(1));
            TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_maxArgumentIndex) = teavm_local_8;
            TEAVM_RELEASE_STACK;
            return;
        }
        if (TEAVM_WITH_CALL_SITE_ID(24278, meth_jt_Format_upTo(teavm_local_1, teavm_local_4, teavm_local_3, INT32_C(123)))) {
            teavm_local_13 = INT32_C(0);
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(24279, TEAVM_METHOD(teavm_local_4, jt_ParsePosition_VT, virt_getIndex)(teavm_local_4));
            if ((teavm_local_14 >= teavm_local_2)) {
                goto teavm_label_3;
            }
            while (1) {
                teavm_local_15 = (teavm_local_14 + INT32_C(1));
                teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(24280, meth_jl_String_charAt(teavm_local_1, teavm_local_14));
                if ((teavm_local_16 == INT32_C(125))) {
                    goto teavm_label_6;
                }
                if ((teavm_local_16 == INT32_C(44))) {
                    goto teavm_label_7;
                }
                if ((teavm_local_16 < INT32_C(48))) {
                    goto teavm_label_1;
                }
                if ((teavm_local_16 > INT32_C(57))) {
                    goto teavm_label_1;
                }
                teavm_local_13 = ((teavm_local_13 * INT32_C(10)) + (teavm_local_16 - INT32_C(48)));
                if ((teavm_local_13 < INT32_C(0))) {
                    goto teavm_label_2;
                }
                if ((teavm_local_15 >= teavm_local_2)) {
                    goto teavm_label_2;
                }
                teavm_local_14 = teavm_local_15;
            }
        teavm_label_7:;
        teavm_label_6:;
            teavm_local_17 = (teavm_local_15 + -INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(24281, TEAVM_METHOD(teavm_local_4, jt_ParsePosition_VT, virt_setIndex)(teavm_local_4, teavm_local_17));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24282, meth_jt_MessageFormat_parseVariable(teavm_this_, teavm_local_1, teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(6), teavm_local_12);
            TEAVM_WITH_CALL_SITE_ID(24283, TEAVM_METHOD(teavm_local_9, ju_List_VT, virt_add_2)(teavm_local_9, teavm_local_12));
            TEAVM_GC_ROOT_RELEASE(INT32_C(6));
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24284, teavm_nullCheck(teavm_local_7));
            teavm_local_18 = TEAVM_ARRAY_LENGTH(teavm_local_10);
            if ((teavm_local_6 < teavm_local_18)) {
                teavm_local_7 = teavm_local_10;
            } else {
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24285, meth_otr_Allocator_allocateArray(&Arr_I_Cls, (teavm_local_18 * INT32_C(2))));
                TEAVM_GC_ROOT(INT32_C(6), teavm_local_7);
                TEAVM_WITH_CALL_SITE_ID(24286, meth_jl_System_fastArraycopy(teavm_local_10, INT32_C(0), teavm_local_7, INT32_C(0), teavm_local_18));
            }
            teavm_local_10 = teavm_local_7;
            teavm_local_19 = (teavm_local_6 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_10);
            TEAVM_ARRAY_AT(teavm_local_10, int32_t, TEAVM_WITH_CALL_SITE_ID(24287, teavm_checkBounds(teavm_local_6, teavm_local_10))) = teavm_local_13;
            if ((teavm_local_13 <= teavm_local_8)) {
                teavm_local_6 = teavm_local_19;
            } else {
                teavm_local_6 = teavm_local_19;
                teavm_local_8 = teavm_local_13;
            }
        }
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_7);
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24288, TEAVM_METHOD(teavm_local_3, jl_StringBuffer_VT, virt_toString)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(6), teavm_local_12);
        TEAVM_WITH_CALL_SITE_ID(24289, TEAVM_METHOD(teavm_local_5, ju_List_VT, virt_add_2)(teavm_local_5, teavm_local_12));
        TEAVM_GC_ROOT_RELEASE(INT32_C(6));
        TEAVM_WITH_CALL_SITE_ID(24290, TEAVM_METHOD(teavm_local_3, jl_StringBuffer_VT, virt_setLength)(teavm_local_3, INT32_C(0)));
    }
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24291, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
    TEAVM_WITH_CALL_SITE_ID(24292, meth_jl_IllegalArgumentException__init__0(teavm_local_12, TEAVM_GET_STRING(7098)));
    TEAVM_WITH_CALL_SITE_ID(24293, meth_otr_ExceptionHandling_throwException(teavm_local_12));
    TEAVM_UNREACHABLE
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24294, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
    TEAVM_WITH_CALL_SITE_ID(24295, meth_jl_IllegalArgumentException__init__0(teavm_local_12, TEAVM_GET_STRING(7098)));
    TEAVM_WITH_CALL_SITE_ID(24296, meth_otr_ExceptionHandling_throwException(teavm_local_12));
    TEAVM_UNREACHABLE
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24297, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
    TEAVM_WITH_CALL_SITE_ID(24298, meth_jl_IllegalArgumentException__init__0(teavm_local_12, TEAVM_GET_STRING(7098)));
    TEAVM_WITH_CALL_SITE_ID(24299, meth_otr_ExceptionHandling_throwException(teavm_local_12));
    TEAVM_UNREACHABLE
}
void* meth_jt_MessageFormat_format(void* teavm_this_, TeaVM_Array* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(24300, meth_jt_MessageFormat_formatImpl(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, NULL));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jt_MessageFormat_formatImpl(void* teavm_this_, TeaVM_Array* teavm_local_1, void* teavm_local_2, void* teavm_local_3, void* teavm_local_4) {
    void* teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    void* teavm_local_14;
    void* teavm_local_15;
    void* teavm_local_16;
    void* teavm_local_17;
    void* teavm_local_18;
    TEAVM_ALLOC_STACK(INT32_C(6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24301, meth_otr_Allocator_allocate(&jt_FieldPosition_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(24302, meth_jt_FieldPosition__init_(teavm_local_5, INT32_C(0)));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 <= TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_maxOffset))) break;
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_strings);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24303, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24304, teavm_checkBounds(teavm_local_6, teavm_local_7));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, void*, teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24305, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(24306, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_8));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24307, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_length)(teavm_local_2));
        if ((teavm_local_1 != NULL)) {
            teavm_local_10 = teavm_local_1;
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24308, teavm_nullCheck(teavm_local_7));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24309, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
            if ((TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6) < TEAVM_ARRAY_LENGTH(teavm_local_10))) {
                goto teavm_label_3;
            }
        }
        TEAVM_WITH_CALL_SITE_ID(24310, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(123)));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24311, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24312, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(24313, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_2)(teavm_local_2, teavm_local_11));
        TEAVM_WITH_CALL_SITE_ID(24314, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(125)));
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(24315, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_length)(teavm_local_2));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24316, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24317, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        teavm_local_12 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(24318, meth_jt_MessageFormat_handleArgumentField(teavm_this_, teavm_local_9, teavm_local_11, teavm_local_12, teavm_local_3, teavm_local_4));
        goto teavm_label_2;
    teavm_label_3:;
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24319, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24320, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        teavm_local_13 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_10, void*, TEAVM_WITH_CALL_SITE_ID(24321, teavm_checkBounds(teavm_local_13, teavm_local_10)));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_formats);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_14);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24322, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24323, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        teavm_local_15 = TEAVM_ARRAY_AT(teavm_local_7, void*, teavm_local_6);
        if ((!((teavm_local_15 != NULL) && (teavm_local_14 != NULL)))) {
            if (teavm_instanceof(teavm_local_14, &jl_Number_Cls, &supertypeof_jl_Number)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(24324, meth_jt_NumberFormat_getInstance());
            } else {
                if ((!teavm_instanceof(teavm_local_14, &ju_Date_Cls, &supertypeof_ju_Date))) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    TEAVM_WITH_CALL_SITE_ID(24325, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_21)(teavm_local_2, teavm_local_14));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(24326, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_length)(teavm_local_2));
                    teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24327, teavm_nullCheck(teavm_local_7));
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24328, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
                    teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_WITH_CALL_SITE_ID(24329, meth_jt_MessageFormat_handleArgumentField(teavm_this_, teavm_local_9, teavm_local_13, teavm_local_11, teavm_local_3, teavm_local_4));
                    goto teavm_label_2;
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(24330, meth_jt_DateFormat_getInstance());
            }
        }
        if ((!teavm_instanceof(teavm_local_15, &jt_ChoiceFormat_Cls, &supertypeof_jt_ChoiceFormat))) {
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_15);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24331, teavm_nullCheck(teavm_local_15));
            TEAVM_WITH_CALL_SITE_ID(24332, TEAVM_METHOD(teavm_local_8, jt_Format_VT, virt_format_2)(teavm_local_8, teavm_local_14, teavm_local_2, teavm_local_5));
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(24333, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_length)(teavm_local_2));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24334, teavm_nullCheck(teavm_local_7));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24335, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
            teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(24336, meth_jt_MessageFormat_handleArgumentField(teavm_this_, teavm_local_9, teavm_local_13, teavm_local_11, teavm_local_3, teavm_local_4));
            TEAVM_WITH_CALL_SITE_ID(24337, meth_jt_MessageFormat_handleformat(teavm_this_, teavm_local_8, teavm_local_14, teavm_local_9, teavm_local_4));
        } else {
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_15);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24338, teavm_nullCheck(teavm_local_15));
            teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(24339, meth_jt_Format_format(teavm_local_8, teavm_local_14));
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_16);
            teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(24340, meth_otr_Allocator_allocate(&jt_MessageFormat_Cls));
            TEAVM_GC_ROOT(INT32_C(5), teavm_local_17);
            TEAVM_WITH_CALL_SITE_ID(24341, meth_jt_MessageFormat__init_(teavm_local_17, teavm_local_16));
            teavm_local_18 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_18);
            TEAVM_WITH_CALL_SITE_ID(24342, TEAVM_METHOD(teavm_local_17, jt_MessageFormat_VT, virt_setLocale)(teavm_local_17, teavm_local_18));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(24343, meth_jt_MessageFormat_format(teavm_local_17, teavm_local_1, teavm_local_2, teavm_local_5));
            TEAVM_GC_ROOT_RELEASE(INT32_C(5));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24344, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_length)(teavm_local_2));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_argumentNumbers);
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24345, teavm_nullCheck(teavm_local_7));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24346, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
            teavm_local_13 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(24347, meth_jt_MessageFormat_handleArgumentField(teavm_this_, teavm_local_9, teavm_local_12, teavm_local_13, teavm_local_3, teavm_local_4));
            TEAVM_WITH_CALL_SITE_ID(24348, meth_jt_MessageFormat_handleformat(teavm_this_, teavm_local_8, teavm_local_14, teavm_local_9, teavm_local_4));
        }
    teavm_label_2:;
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    teavm_local_13 = (TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_maxOffset) + INT32_C(1));
    teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_strings);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
    if ((teavm_local_13 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(24349, teavm_nullCheck(teavm_local_7))))) {
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_strings);
        teavm_local_13 = (TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_maxOffset) + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24350, teavm_nullCheck(teavm_local_7));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, void*, TEAVM_WITH_CALL_SITE_ID(24351, teavm_checkBounds(teavm_local_13, teavm_local_7)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24352, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(24353, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_8));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jt_MessageFormat_handleArgumentField(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, void* teavm_local_4, void* teavm_local_5) {
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_local_5 != NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24354, meth_otr_Allocator_allocate(&jt_MessageFormat_FieldContainer_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(24355, teavm_initializeClass((TeaVM_Class*) &jt_MessageFormat_Field_Cls, &initclass_jt_MessageFormat_Field));
        teavm_local_7 = sfld_jt_MessageFormat_Field_ARGUMENT;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24356, meth_jl_Integer_valueOf_0(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        TEAVM_WITH_CALL_SITE_ID(24357, meth_jt_MessageFormat_FieldContainer__init_(teavm_local_6, teavm_local_1, teavm_local_2, teavm_local_7, teavm_local_8));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(24358, TEAVM_METHOD(teavm_local_5, ju_List_VT, virt_add_2)(teavm_local_5, teavm_local_6));
    } else if ((teavm_local_4 != NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24359, TEAVM_METHOD(teavm_local_4, jt_FieldPosition_VT, virt_getFieldAttribute)(teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(24360, teavm_initializeClass((TeaVM_Class*) &jt_MessageFormat_Field_Cls, &initclass_jt_MessageFormat_Field));
        if ((teavm_local_6 == sfld_jt_MessageFormat_Field_ARGUMENT)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if ((!TEAVM_WITH_CALL_SITE_ID(24361, TEAVM_METHOD(teavm_local_4, jt_FieldPosition_VT, virt_getEndIndex)(teavm_local_4)))) {
                TEAVM_WITH_CALL_SITE_ID(24362, TEAVM_METHOD(teavm_local_4, jt_FieldPosition_VT, virt_setBeginIndex)(teavm_local_4, teavm_local_1));
                TEAVM_WITH_CALL_SITE_ID(24363, TEAVM_METHOD(teavm_local_4, jt_FieldPosition_VT, virt_setEndIndex)(teavm_local_4, teavm_local_2));
            }
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_MessageFormat_handleformat(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(6));
    if ((teavm_local_4 != NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24364, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24365, TEAVM_METHOD(teavm_local_1, jt_Format_VT, virt_formatToCharacterIterator)(teavm_local_1, teavm_local_2));
        while (1) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24366, teavm_nullCheck(teavm_local_5));
            if ((TEAVM_WITH_CALL_SITE_ID(24367, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_getIndex)(teavm_local_5)) == TEAVM_WITH_CALL_SITE_ID(24368, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_getEndIndex)(teavm_local_5)))) {
                goto teavm_label_1;
            }
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24369, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_getRunStart_1)(teavm_local_5));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24370, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_getRunLimit_1)(teavm_local_5));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24371, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_getAttributes)(teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24372, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(24373, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_keySet)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24374, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(24375, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
            while (1) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT(INT32_C(4), teavm_local_9);
                TEAVM_GC_ROOT(INT32_C(5), teavm_local_4);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24376, teavm_nullCheck(teavm_local_9));
                if ((!TEAVM_WITH_CALL_SITE_ID(24377, TEAVM_METHOD(teavm_local_9, ju_Iterator_VT, virt_hasNext)(teavm_local_9)))) {
                    goto teavm_label_3;
                }
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24378, TEAVM_METHOD(teavm_local_9, ju_Iterator_VT, virt_next)(teavm_local_9));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24379, teavm_checkcast(teavm_local_8, &jt_AttributedCharacterIterator_Attribute_Cls, &supertypeof_jt_AttributedCharacterIterator_Attribute));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(24380, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_getAttribute)(teavm_local_5, teavm_local_10));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24381, meth_otr_Allocator_allocate(&jt_MessageFormat_FieldContainer_Cls));
                teavm_local_12 = (teavm_local_3 + teavm_local_6);
                teavm_local_13 = (teavm_local_3 + teavm_local_7);
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(24382, meth_jt_MessageFormat_FieldContainer__init_(teavm_local_8, teavm_local_12, teavm_local_13, teavm_local_10, teavm_local_11));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(24383, teavm_nullCheck(teavm_local_4));
                TEAVM_WITH_CALL_SITE_ID(24384, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_add_2)(teavm_local_4, teavm_local_8));
            }
        teavm_label_3:;
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(24385, TEAVM_METHOD(teavm_local_5, jt_AttributedCharacterIterator_VT, virt_setIndex_0)(teavm_local_5, teavm_local_7));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_MessageFormat_format_0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(24386, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), &teavm_isSupertypeOfArray));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24387, meth_jt_MessageFormat_format(teavm_this_, teavm_local_4, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t meth_jt_MessageFormat_match(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, TeaVM_Array* teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_local_11;
    void* teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24388, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24389, meth_jl_String_length(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24390, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24391, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    teavm_local_7 = -INT32_C(1);
    while (1) {
        if (!((teavm_local_6 < teavm_local_5) && TEAVM_WITH_CALL_SITE_ID(24392, meth_jl_Character_isWhitespace(TEAVM_WITH_CALL_SITE_ID(24393, meth_jl_String_charAt(teavm_local_1, teavm_local_6)))))) break;
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(24394, teavm_nullCheck(teavm_local_4));
    teavm_local_8 = teavm_local_4;
    teavm_local_9 = TEAVM_ARRAY_LENGTH(teavm_local_8);
    while (1) {
        teavm_local_10 = (teavm_local_9 + -INT32_C(1));
        if ((teavm_local_10 < INT32_C(0))) {
            goto teavm_label_3;
        }
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24395, teavm_checkBounds(teavm_local_10, teavm_local_8));
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_9);
        teavm_local_12 = TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_9);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_12);
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(24396, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(24397, teavm_nullCheck(teavm_local_12))));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        if (TEAVM_WITH_CALL_SITE_ID(24398, meth_jl_String_regionMatches(teavm_local_1, INT32_C(1), teavm_local_6, teavm_local_11, INT32_C(0), teavm_local_13))) {
            goto teavm_label_4;
        }
    }
teavm_label_4:;
    goto teavm_label_2;
teavm_label_3:;
    teavm_local_9 = teavm_local_7;
teavm_label_2:;
    if ((teavm_local_9 == -INT32_C(1))) {
        teavm_local_13 = -INT32_C(1);
    } else {
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(24399, teavm_checkBounds(teavm_local_9, teavm_local_8));
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_13);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
        teavm_local_14 = (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(24400, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(24401, teavm_nullCheck(teavm_local_11)))));
        while (1) {
            teavm_local_10 = teavm_compare_i32(teavm_local_14, teavm_local_5);
            if ((teavm_local_10 >= INT32_C(0))) {
                goto teavm_label_6;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((!TEAVM_WITH_CALL_SITE_ID(24402, meth_jl_Character_isWhitespace(TEAVM_WITH_CALL_SITE_ID(24403, meth_jl_String_charAt(teavm_local_1, teavm_local_14)))))) {
                goto teavm_label_6;
            }
            teavm_local_14 = (teavm_local_14 + INT32_C(1));
        }
    teavm_label_6:;
        if ((teavm_local_10 < INT32_C(0))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(24404, meth_jl_String_charAt(teavm_local_1, teavm_local_14));
            if ((teavm_local_15 == INT32_C(125))) {
                goto teavm_label_7;
            }
            if (((!teavm_local_3) && (teavm_local_15 == INT32_C(44)))) {
                goto teavm_label_7;
            }
        }
        teavm_local_13 = -INT32_C(1);
        goto teavm_label_5;
    teavm_label_7:;
        teavm_local_14 = (teavm_local_14 + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(24405, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_14));
    }
teavm_label_5:;
    TEAVM_RELEASE_STACK;
    return teavm_local_13;
}
void* meth_jt_MessageFormat_parseVariable(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_local_11;
    void* teavm_local_12;
    int32_t teavm_local_13;
    void* teavm_local_14;
    void* teavm_local_15;
    int32_t teavm_local_16;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24406, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24407, meth_jl_String_length(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24408, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(24409, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    if ((teavm_local_4 < teavm_local_3)) {
        teavm_local_5 = (teavm_local_4 + INT32_C(1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24410, meth_jl_String_charAt(teavm_local_1, teavm_local_4));
        teavm_local_7 = teavm_compare_i32(teavm_local_6, INT32_C(125));
        if ((teavm_local_7 && (teavm_local_6 != INT32_C(44)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24411, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            TEAVM_WITH_CALL_SITE_ID(24412, meth_jl_IllegalArgumentException__init__0(teavm_local_8, TEAVM_GET_STRING(7099)));
            TEAVM_WITH_CALL_SITE_ID(24413, meth_otr_ExceptionHandling_throwException(teavm_local_8));
            TEAVM_UNREACHABLE
        }
        TEAVM_WITH_CALL_SITE_ID(24414, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_5));
        if ((!teavm_local_7)) {
            teavm_local_8 = NULL;
        } else {
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24415, teavm_fillArray(meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), 4), TEAVM_GET_STRING(7100), TEAVM_GET_STRING(308), TEAVM_GET_STRING(7101), TEAVM_GET_STRING(7102)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(24416, meth_jt_MessageFormat_match(teavm_this_, teavm_local_1, teavm_local_2, INT32_C(0), teavm_local_9));
            if ((teavm_local_10 != -INT32_C(1))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(24417, meth_otr_Allocator_allocate(&jl_StringBuffer_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
                TEAVM_WITH_CALL_SITE_ID(24418, meth_jl_StringBuffer__init__0(teavm_local_11));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24419, meth_jl_String_charAt(teavm_local_1, (TEAVM_WITH_CALL_SITE_ID(24420, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2)) - INT32_C(1))));
                switch (teavm_local_10) {
                    case 0:
                    case 1:
                        goto teavm_label_2;
                    case 2:
                        goto teavm_label_3;
                }
                TEAVM_TRY
                    TEAVM_WITH_CALL_SITE_ID(24421, meth_jt_Format_upToWithQuotes(teavm_local_1, teavm_local_2, teavm_local_11, INT32_C(125), INT32_C(123)));
                    TEAVM_RESTORE_JUMP_BUFFER;
                    goto teavm_label_5;
                TEAVM_CATCH
                    // CATCH java.lang.IllegalArgumentException
                    case 1: {
                        goto teavm_label_6;
                        break;
                    }
                TEAVM_END_TRY
            teavm_label_6:;
            teavm_label_5:;
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24422, meth_otr_Allocator_allocate(&jt_ChoiceFormat_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24423, TEAVM_METHOD(teavm_local_11, jl_StringBuffer_VT, virt_toString)(teavm_local_11));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(24424, meth_jt_ChoiceFormat__init_(teavm_local_8, teavm_local_12));
                goto teavm_label_1;
            teavm_label_3:;
                if ((teavm_local_5 == INT32_C(125))) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24425, meth_jt_NumberFormat_getInstance());
                    goto teavm_label_1;
                }
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24426, teavm_fillArray(meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), 3), TEAVM_GET_STRING(7103), TEAVM_GET_STRING(7104), TEAVM_GET_STRING(7105)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(24427, meth_jt_MessageFormat_match(teavm_this_, teavm_local_1, teavm_local_2, INT32_C(1), teavm_local_9));
                if ((teavm_local_13 == -INT32_C(1))) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                    TEAVM_WITH_CALL_SITE_ID(24428, meth_jt_Format_upToWithQuotes(teavm_local_1, teavm_local_2, teavm_local_11, INT32_C(125), INT32_C(123)));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24429, meth_otr_Allocator_allocate(&jt_DecimalFormat_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24430, TEAVM_METHOD(teavm_local_11, jl_StringBuffer_VT, virt_toString)(teavm_local_11));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(24431, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
                    teavm_local_15 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_14);
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_15);
                    TEAVM_WITH_CALL_SITE_ID(24432, meth_jt_DecimalFormatSymbols__init_(teavm_local_14, teavm_local_15));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                    TEAVM_WITH_CALL_SITE_ID(24433, meth_jt_DecimalFormat__init_(teavm_local_8, teavm_local_12, teavm_local_14));
                    goto teavm_label_1;
                }
                switch (teavm_local_13) {
                    case 0:
                        goto teavm_label_9;
                    case 1:
                        goto teavm_label_8;
                    default:
                        goto teavm_label_7;
                }
            teavm_label_9:;
                teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24434, meth_jt_NumberFormat_getCurrencyInstance(teavm_local_8));
                goto teavm_label_1;
            teavm_label_8:;
                teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24435, meth_jt_NumberFormat_getPercentInstance(teavm_local_8));
                goto teavm_label_1;
            teavm_label_7:;
                teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24436, meth_jt_NumberFormat_getIntegerInstance(teavm_local_8));
                goto teavm_label_1;
            teavm_label_2:;
                if ((teavm_local_5 == INT32_C(125))) {
                    if ((teavm_local_10 != INT32_C(1))) {
                        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24437, meth_jt_DateFormat_getTimeInstance(INT32_C(2), teavm_local_8));
                    } else {
                        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24438, meth_jt_DateFormat_getDateInstance(INT32_C(2), teavm_local_8));
                    }
                } else {
                    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24439, teavm_fillArray(meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), 4), TEAVM_GET_STRING(7106), TEAVM_GET_STRING(7107), TEAVM_GET_STRING(7108), TEAVM_GET_STRING(7109)));
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                    teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(24440, meth_jt_MessageFormat_match(teavm_this_, teavm_local_1, teavm_local_2, INT32_C(1), teavm_local_9));
                    if ((teavm_local_16 == -INT32_C(1))) {
                        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                        TEAVM_WITH_CALL_SITE_ID(24441, meth_jt_Format_upToWithQuotes(teavm_local_1, teavm_local_2, teavm_local_11, INT32_C(125), INT32_C(123)));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24442, meth_otr_Allocator_allocate(&jt_SimpleDateFormat_Cls));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(24443, TEAVM_METHOD(teavm_local_11, jl_StringBuffer_VT, virt_toString)(teavm_local_11));
                        teavm_local_14 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_14);
                        TEAVM_WITH_CALL_SITE_ID(24444, meth_jt_SimpleDateFormat__init__0(teavm_local_8, teavm_local_12, teavm_local_14));
                    } else {
                        switch (teavm_local_16) {
                            case 0:
                                goto teavm_label_14;
                            case 1:
                                goto teavm_label_13;
                            case 2:
                                goto teavm_label_12;
                            case 3:
                                goto teavm_label_11;
                        }
                        goto teavm_label_10;
                    teavm_label_14:;
                        teavm_local_16 = INT32_C(0);
                        goto teavm_label_10;
                    teavm_label_13:;
                        teavm_local_16 = INT32_C(1);
                        goto teavm_label_10;
                    teavm_label_12:;
                        teavm_local_16 = INT32_C(2);
                        goto teavm_label_10;
                    teavm_label_11:;
                        teavm_local_16 = INT32_C(3);
                    teavm_label_10:;
                        if ((teavm_local_10 != INT32_C(1))) {
                            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24445, meth_jt_DateFormat_getTimeInstance(teavm_local_16, teavm_local_8));
                        } else {
                            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale);
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24446, meth_jt_DateFormat_getDateInstance(teavm_local_16, teavm_local_8));
                        }
                    }
                }
            } else {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24447, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(24448, meth_jl_IllegalArgumentException__init__0(teavm_local_8, TEAVM_GET_STRING(7110)));
                TEAVM_WITH_CALL_SITE_ID(24449, meth_otr_ExceptionHandling_throwException(teavm_local_8));
                TEAVM_UNREACHABLE
            }
        }
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_8;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(24450, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(24451, meth_jl_IllegalArgumentException__init__0(teavm_local_8, TEAVM_GET_STRING(7099)));
    TEAVM_WITH_CALL_SITE_ID(24452, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
void meth_jt_MessageFormat_setLocale(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_locale) = teavm_local_1;
    teavm_local_2 = INT32_C(0);
    while (1) {
        if (!(teavm_local_2 <= TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_maxOffset))) break;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_formats);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24453, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24454, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2);
        if (teavm_instanceof(teavm_local_4, &jt_DecimalFormat_Cls, &supertypeof_jt_DecimalFormat)) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_formats);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24455, meth_otr_Allocator_allocate(&jt_DecimalFormat_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24456, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(24457, teavm_nullCheck(TEAVM_WITH_CALL_SITE_ID(24458, teavm_checkcast(teavm_local_4, &jt_DecimalFormat_Cls, &supertypeof_jt_DecimalFormat))))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormat_VT, virt_toPattern)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(24459, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(24460, meth_jt_DecimalFormatSymbols__init_(teavm_local_7, teavm_local_1));
            TEAVM_WITH_CALL_SITE_ID(24461, meth_jt_DecimalFormat__init_(teavm_local_5, teavm_local_6, teavm_local_7));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24462, teavm_nullCheck(teavm_local_3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24463, teavm_checkUpperBound(teavm_local_2, teavm_local_3));
            teavm_gc_writeBarrier(teavm_local_3);
            TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_5;
        } else if (teavm_instanceof(teavm_local_4, &jt_SimpleDateFormat_Cls, &supertypeof_jt_SimpleDateFormat)) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_MessageFormat, fld_formats);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(24464, meth_otr_Allocator_allocate(&jt_SimpleDateFormat_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(24465, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(24466, teavm_nullCheck(TEAVM_WITH_CALL_SITE_ID(24467, teavm_checkcast(teavm_local_4, &jt_SimpleDateFormat_Cls, &supertypeof_jt_SimpleDateFormat))))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_SimpleDateFormat_VT, virt_toPattern)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(24468, meth_jt_SimpleDateFormat__init__0(teavm_local_5, teavm_local_6, teavm_local_1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24469, teavm_nullCheck(teavm_local_3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24470, teavm_checkUpperBound(teavm_local_2, teavm_local_3));
            teavm_gc_writeBarrier(teavm_local_3);
            TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_5;
        }
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_MessageFormat(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1222 || tag >= 1224) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_MessageFormat_Cls[5];
alignas(8) jt_MessageFormat_VT jt_MessageFormat_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_MessageFormat), sizeof(void*)),
        .flags = 0,
        .tag = 1222,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_MessageFormat,
        .superclass = (TeaVM_Class*) &jt_Format_Cls,
        .layout = teavm_classLayouts_jt_MessageFormat_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format_2 = &meth_jt_MessageFormat_format_0,
    .virt_setLocale = &meth_jt_MessageFormat_setLocale,
    .virt_format_5 = &meth_jt_MessageFormat_format,
    .virt_format_3 = &meth_jt_Format_format,
    .virt_applyPattern = &meth_jt_MessageFormat_applyPattern
};
static int16_t teavm_classLayouts_jt_MessageFormat_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jt_MessageFormat, fld_locale), (int16_t) offsetof(cls_jt_MessageFormat, fld_strings), (int16_t) offsetof(cls_jt_MessageFormat, fld_argumentNumbers), (int16_t) offsetof(cls_jt_MessageFormat, fld_formats)
};
void sysinitclass_jt_MessageFormat() {
}
