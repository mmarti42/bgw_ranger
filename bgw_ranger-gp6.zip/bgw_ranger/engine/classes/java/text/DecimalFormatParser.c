#include "DecimalFormatParser.h"
#include "../lang/Object.h"
#include "../lang/String.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "DecimalFormat.h"
#include "../../../arrayclass.h"
#include "DecimalFormat@dFormatField.h"
#include "../lang/System.h"
#include "DecimalFormat@dMinusField.h"
#include "../lang/Math.h"
#include "../util/ArrayList.h"
#include "DecimalFormat@dTextField.h"
#include "../util/List.h"
#include "DecimalFormat@dCurrencyField.h"
#include "DecimalFormat@dPercentField.h"
#include "DecimalFormat@dPerMillField.h"

void meth_jt_DecimalFormatParser__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(31174, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormatParser_parse(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_groupSize) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_minimumFracLength) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_fracLength) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_exponentLength) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_decimalSeparatorRequired) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_multiplier) = INT32_C(1);
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31175, TEAVM_METHOD(teavm_this_, jt_DecimalFormatParser_VT, virt_parseText)(teavm_this_, INT32_C(0), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positivePrefix) = teavm_local_2;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(31176, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((teavm_local_3 != TEAVM_WITH_CALL_SITE_ID(31177, meth_jl_String_length(teavm_local_1)))) {
        TEAVM_WITH_CALL_SITE_ID(31178, meth_jt_DecimalFormatParser_parseNumber(teavm_this_, INT32_C(1)));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativePrefix) = NULL;
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativeSuffix) = NULL;
        if (((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) < TEAVM_WITH_CALL_SITE_ID(31179, meth_jl_String_length(teavm_local_1))) && (TEAVM_WITH_CALL_SITE_ID(31180, meth_jl_String_charAt(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index))) != INT32_C(59)))) {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31181, TEAVM_METHOD(teavm_this_, jt_DecimalFormatParser_VT, virt_parseText)(teavm_this_, INT32_C(1), INT32_C(0)));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positiveSuffix) = teavm_local_2;
        }
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) < TEAVM_WITH_CALL_SITE_ID(31182, meth_jl_String_length(teavm_local_1)))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (teavm_local_4 + INT32_C(1));
            if ((TEAVM_WITH_CALL_SITE_ID(31183, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) != INT32_C(59))) {
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31184, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31185, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                TEAVM_WITH_CALL_SITE_ID(31186, meth_jl_StringBuilder__init_(teavm_local_6));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31187, meth_jl_StringBuilder_append(teavm_local_6, TEAVM_GET_STRING(7558)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31188, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31189, teavm_nullCheck(teavm_local_7)), teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31190, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31191, teavm_nullCheck(teavm_local_7)), TEAVM_GET_STRING(7559)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
                TEAVM_WITH_CALL_SITE_ID(31192, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31193, teavm_nullCheck(teavm_local_7)), teavm_local_1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31194, meth_jl_StringBuilder_toString(teavm_local_6));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(31195, meth_jl_IllegalArgumentException__init__0(teavm_local_5, teavm_local_6));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(31196, meth_otr_ExceptionHandling_throwException(teavm_local_5));
                TEAVM_UNREACHABLE
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31197, TEAVM_METHOD(teavm_this_, jt_DecimalFormatParser_VT, virt_parseText)(teavm_this_, INT32_C(0), INT32_C(1)));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativePrefix) = teavm_local_2;
            TEAVM_WITH_CALL_SITE_ID(31198, meth_jt_DecimalFormatParser_parseNumber(teavm_this_, INT32_C(0)));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31199, TEAVM_METHOD(teavm_this_, jt_DecimalFormatParser_VT, virt_parseText)(teavm_this_, INT32_C(1), INT32_C(1)));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativeSuffix) = teavm_local_2;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31200, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31201, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(31202, meth_jl_StringBuilder__init_(teavm_local_6));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31203, meth_jl_StringBuilder_append(teavm_local_6, TEAVM_GET_STRING(7560)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(31204, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31205, teavm_nullCheck(teavm_local_7)), teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31206, meth_jl_StringBuilder_toString(teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(31207, meth_jl_IllegalArgumentException__init__0(teavm_local_5, teavm_local_6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(31208, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void meth_jt_DecimalFormatParser_apply(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positivePrefix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(31209, teavm_nullCheck(teavm_local_1));
    teavm_gc_writeBarrier(teavm_local_1);
    TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_positivePrefix) = teavm_local_2;
    TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_positiveSuffix) = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positiveSuffix);
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativePrefix) != NULL)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativePrefix);
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_negativePrefix) = teavm_local_2;
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positivePrefix);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(31210, teavm_nullCheck(teavm_local_2))) + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31211, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), teavm_local_3));
        teavm_gc_writeBarrier(teavm_local_1);
        TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_negativePrefix) = teavm_local_2;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positivePrefix);
        teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_negativePrefix);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positivePrefix);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
        teavm_local_6 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(31212, teavm_nullCheck(teavm_local_5)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(31213, meth_jl_System_fastArraycopy(teavm_local_2, INT32_C(0), teavm_local_4, INT32_C(1), teavm_local_6));
        teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_negativePrefix);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31214, meth_otr_Allocator_allocate(&jt_DecimalFormat_MinusField_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(31215, meth_jt_DecimalFormat_MinusField__init_(teavm_local_7));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31216, teavm_nullCheck(teavm_local_2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31217, teavm_checkUpperBound(INT32_C(0), teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_3) = teavm_local_7;
    }
    teavm_local_2 = ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativeSuffix) == NULL) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_positiveSuffix) : TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_negativeSuffix));
    teavm_gc_writeBarrier(teavm_local_1);
    TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_negativeSuffix) = teavm_local_2;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_groupSize);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(31218, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setGroupingSize)(teavm_local_1, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(31219, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setGroupingUsed)(teavm_local_1, ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_groupSize) <= INT32_C(0)) ? INT32_C(0) : INT32_C(1))));
    TEAVM_WITH_CALL_SITE_ID(31220, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setMinimumIntegerDigits)(teavm_local_1, ((!TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_decimalSeparatorRequired)) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_minimumIntLength) : TEAVM_WITH_CALL_SITE_ID(31221, meth_jl_Math_max(INT32_C(1), TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_minimumIntLength))))));
    TEAVM_WITH_CALL_SITE_ID(31222, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setMaximumIntegerDigits)(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_intLength)));
    TEAVM_WITH_CALL_SITE_ID(31223, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setMinimumFractionDigits)(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_minimumFracLength)));
    TEAVM_WITH_CALL_SITE_ID(31224, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setMaximumFractionDigits)(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_fracLength)));
    TEAVM_WITH_CALL_SITE_ID(31225, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setDecimalSeparatorAlwaysShown)(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_decimalSeparatorRequired)));
    TEAVM_FIELD(teavm_local_1, cls_jt_DecimalFormat, fld_exponentDigits) = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_exponentLength);
    TEAVM_WITH_CALL_SITE_ID(31226, TEAVM_METHOD(teavm_local_1, jt_DecimalFormat_VT, virt_setMultiplier)(teavm_local_1, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_multiplier)));
    TEAVM_RELEASE_STACK;
}
TeaVM_Array* meth_jt_DecimalFormatParser_parseText(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    TeaVM_Array* teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31227, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(31228, meth_ju_ArrayList__init_(teavm_local_3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31229, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(31230, meth_jl_StringBuilder__init_(teavm_local_4));
    while (1) {
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        if ((teavm_local_5 >= TEAVM_WITH_CALL_SITE_ID(31231, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(31232, teavm_nullCheck(teavm_local_6)))))) {
            goto teavm_label_1;
        }
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31233, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(31234, teavm_nullCheck(teavm_local_6)), teavm_local_5));
        switch (teavm_local_7) {
            case 35:
            case 48:
                if ((!teavm_local_1)) {
                    goto teavm_label_1;
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31235, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
                teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31236, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                TEAVM_WITH_CALL_SITE_ID(31237, meth_jl_StringBuilder__init_(teavm_local_10));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31238, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7561)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31239, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31240, teavm_nullCheck(teavm_local_11)), teavm_local_8));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31241, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31242, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                TEAVM_WITH_CALL_SITE_ID(31243, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31244, teavm_nullCheck(teavm_local_11)), teavm_local_9));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31245, meth_jl_StringBuilder_toString(teavm_local_10));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(31246, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_9));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(31247, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                TEAVM_UNREACHABLE
            case 37:
                goto teavm_label_6;
            case 39:
                goto teavm_label_4;
            case 45:
                goto teavm_label_8;
            case 46:
            case 69:
                goto teavm_label_2;
            case 59:
                if ((!teavm_local_2)) {
                    goto teavm_label_1;
                } else {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31248, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
                    teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31249, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                    TEAVM_WITH_CALL_SITE_ID(31250, meth_jl_StringBuilder__init_(teavm_local_10));
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31251, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7561)));
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31252, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31253, teavm_nullCheck(teavm_local_11)), teavm_local_8));
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31254, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31255, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                    TEAVM_WITH_CALL_SITE_ID(31256, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31257, teavm_nullCheck(teavm_local_11)), teavm_local_9));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31258, meth_jl_StringBuilder_toString(teavm_local_10));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    TEAVM_WITH_CALL_SITE_ID(31259, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_9));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_WITH_CALL_SITE_ID(31260, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                    TEAVM_UNREACHABLE
                }
            case 164:
                goto teavm_label_7;
            case 8240:
                goto teavm_label_5;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(31261, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_28)(teavm_local_4, teavm_local_7));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
        goto teavm_label_3;
    teavm_label_8:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        if ((TEAVM_WITH_CALL_SITE_ID(31262, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_length)(teavm_local_4)) > INT32_C(0))) {
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31263, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31264, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
            TEAVM_WITH_CALL_SITE_ID(31265, meth_jt_DecimalFormat_TextField__init_(teavm_local_6, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_WITH_CALL_SITE_ID(31266, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31267, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_setLength)(teavm_local_4, INT32_C(0)));
        }
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31268, meth_otr_Allocator_allocate(&jt_DecimalFormat_MinusField_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(31269, meth_jt_DecimalFormat_MinusField__init_(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(31270, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
        goto teavm_label_3;
    teavm_label_7:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        if ((TEAVM_WITH_CALL_SITE_ID(31271, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_length)(teavm_local_4)) > INT32_C(0))) {
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31272, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31273, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
            TEAVM_WITH_CALL_SITE_ID(31274, meth_jt_DecimalFormat_TextField__init_(teavm_local_6, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_WITH_CALL_SITE_ID(31275, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31276, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_setLength)(teavm_local_4, INT32_C(0)));
        }
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31277, meth_otr_Allocator_allocate(&jt_DecimalFormat_CurrencyField_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(31278, meth_jt_DecimalFormat_CurrencyField__init_(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(31279, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
        goto teavm_label_3;
    teavm_label_6:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        if ((TEAVM_WITH_CALL_SITE_ID(31280, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_length)(teavm_local_4)) > INT32_C(0))) {
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31281, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31282, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
            TEAVM_WITH_CALL_SITE_ID(31283, meth_jt_DecimalFormat_TextField__init_(teavm_local_6, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_WITH_CALL_SITE_ID(31284, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31285, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_setLength)(teavm_local_4, INT32_C(0)));
        }
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31286, meth_otr_Allocator_allocate(&jt_DecimalFormat_PercentField_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(31287, meth_jt_DecimalFormat_PercentField__init_(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(31288, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_multiplier) = INT32_C(100);
        goto teavm_label_3;
    teavm_label_5:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        if ((TEAVM_WITH_CALL_SITE_ID(31289, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_length)(teavm_local_4)) > INT32_C(0))) {
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31290, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31291, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
            TEAVM_WITH_CALL_SITE_ID(31292, meth_jt_DecimalFormat_TextField__init_(teavm_local_6, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_WITH_CALL_SITE_ID(31293, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31294, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_setLength)(teavm_local_4, INT32_C(0)));
        }
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31295, meth_otr_Allocator_allocate(&jt_DecimalFormat_PerMillField_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(31296, meth_jt_DecimalFormat_PerMillField__init_(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(31297, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_multiplier) = INT32_C(1000);
        goto teavm_label_3;
    teavm_label_4:;
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_12 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(31298, meth_jl_String_indexOf_0(TEAVM_WITH_CALL_SITE_ID(31299, teavm_nullCheck(teavm_local_6)), INT32_C(39), teavm_local_12));
        if ((teavm_local_13 < INT32_C(0))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31300, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
            teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31301, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(31302, meth_jl_StringBuilder__init_(teavm_local_10));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31303, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7562)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31304, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31305, teavm_nullCheck(teavm_local_11)), teavm_local_8));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31306, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31307, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7563)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            TEAVM_WITH_CALL_SITE_ID(31308, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31309, teavm_nullCheck(teavm_local_11)), teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31310, meth_jl_StringBuilder_toString(teavm_local_10));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31311, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31312, meth_otr_ExceptionHandling_throwException(teavm_local_6));
            TEAVM_UNREACHABLE
        }
        if ((teavm_local_13 == TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31313, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_28)(teavm_local_4, INT32_C(39)));
        } else {
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31314, meth_jl_String_substring_0(TEAVM_WITH_CALL_SITE_ID(31315, teavm_nullCheck(teavm_local_6)), teavm_local_8, teavm_local_13));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(31316, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_0)(teavm_local_4, teavm_local_6));
        }
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (teavm_local_13 + INT32_C(1));
    teavm_label_3:;
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31317, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31318, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(31319, meth_jl_StringBuilder__init_(teavm_local_10));
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31320, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7561)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31321, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31322, teavm_nullCheck(teavm_local_11)), teavm_local_8));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31323, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31324, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(31325, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31326, teavm_nullCheck(teavm_local_11)), teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31327, meth_jl_StringBuilder_toString(teavm_local_10));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(31328, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(31329, meth_otr_ExceptionHandling_throwException(teavm_local_6));
    TEAVM_UNREACHABLE
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    if ((TEAVM_WITH_CALL_SITE_ID(31330, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_length)(teavm_local_4)) > INT32_C(0))) {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31331, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31332, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        TEAVM_WITH_CALL_SITE_ID(31333, meth_jt_DecimalFormat_TextField__init_(teavm_local_6, teavm_local_9));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(31334, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_add_2)(teavm_local_3, teavm_local_6));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(31335, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), TEAVM_WITH_CALL_SITE_ID(31336, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_size)(teavm_local_3))));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(31337, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_toArray_0)(teavm_local_3, teavm_local_14));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_14);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(31338, teavm_checkcast(teavm_local_14, teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_14;
}
void meth_jt_DecimalFormatParser_parseNumber(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(31339, meth_jt_DecimalFormatParser_parseIntegerPart(teavm_this_, teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 < TEAVM_WITH_CALL_SITE_ID(31340, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(31341, teavm_nullCheck(teavm_local_3)))))) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((TEAVM_WITH_CALL_SITE_ID(31342, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(31343, teavm_nullCheck(teavm_local_3)), teavm_local_2)) == INT32_C(46))) {
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(31344, meth_jt_DecimalFormatParser_parseFractionalPart(teavm_this_, teavm_local_1));
        }
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 < TEAVM_WITH_CALL_SITE_ID(31345, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(31346, teavm_nullCheck(teavm_local_3)))))) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((TEAVM_WITH_CALL_SITE_ID(31347, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(31348, teavm_nullCheck(teavm_local_3)), teavm_local_2)) == INT32_C(69))) {
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(31349, meth_jt_DecimalFormatParser_parseExponent(teavm_this_, teavm_local_1));
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormatParser_parseIntegerPart(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_4 = INT32_C(1);
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = INT32_C(0);
    while (1) {
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((teavm_local_7 >= TEAVM_WITH_CALL_SITE_ID(31350, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(31351, teavm_nullCheck(teavm_local_8)))))) {
            goto teavm_label_1;
        }
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        switch (TEAVM_WITH_CALL_SITE_ID(31352, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(31353, teavm_nullCheck(teavm_local_8)), teavm_local_7))) {
            case 35:
                goto teavm_label_5;
            case 44:
                goto teavm_label_4;
            case 48:
                goto teavm_label_6;
            default:
                goto teavm_label_1;
        }
    teavm_label_6:;
        teavm_local_4 = INT32_C(0);
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
        goto teavm_label_3;
    teavm_label_5:;
        if ((!teavm_local_4)) {
            goto teavm_label_2;
        }
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
        goto teavm_label_3;
    teavm_label_4:;
        if ((teavm_local_3 == TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(31354, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
            teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31355, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(31356, meth_jl_StringBuilder__init_(teavm_local_10));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31357, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7564)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31358, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31359, teavm_nullCheck(teavm_local_11)), teavm_local_7));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31360, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31361, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            TEAVM_WITH_CALL_SITE_ID(31362, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31363, teavm_nullCheck(teavm_local_11)), teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31364, meth_jl_StringBuilder_toString(teavm_local_10));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31365, meth_jl_IllegalArgumentException__init__0(teavm_local_8, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31366, meth_otr_ExceptionHandling_throwException(teavm_local_8));
            TEAVM_UNREACHABLE
        }
        if (teavm_local_1) {
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_groupSize) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) - teavm_local_3);
        }
        teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
    teavm_label_3:;
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(31367, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31368, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(31369, meth_jl_StringBuilder__init_(teavm_local_10));
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31370, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7565)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31371, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31372, teavm_nullCheck(teavm_local_11)), teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31373, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31374, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(31375, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31376, teavm_nullCheck(teavm_local_11)), teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31377, meth_jl_StringBuilder_toString(teavm_local_10));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(31378, meth_jl_IllegalArgumentException__init__0(teavm_local_8, teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(31379, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
teavm_label_1:;
    if (teavm_local_5) {
        if ((teavm_local_3 == TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(31380, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
            teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31381, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(31382, meth_jl_StringBuilder__init_(teavm_local_10));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31383, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7566)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31384, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31385, teavm_nullCheck(teavm_local_11)), teavm_local_7));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31386, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31387, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
            TEAVM_WITH_CALL_SITE_ID(31388, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31389, teavm_nullCheck(teavm_local_11)), teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31390, meth_jl_StringBuilder_toString(teavm_local_10));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31391, meth_jl_IllegalArgumentException__init__0(teavm_local_8, teavm_local_9));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31392, meth_otr_ExceptionHandling_throwException(teavm_local_8));
            TEAVM_UNREACHABLE
        }
        if ((teavm_local_1 && (teavm_local_3 > teavm_local_2))) {
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_groupSize) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) - teavm_local_3);
        }
        if (teavm_local_1) {
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_intLength) = teavm_local_5;
            TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_minimumIntLength) = teavm_local_6;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(31393, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    teavm_local_12 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(31394, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(31395, meth_jl_StringBuilder__init_(teavm_local_10));
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31396, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(7567)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31397, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31398, teavm_nullCheck(teavm_local_11)), teavm_local_12));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(31399, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31400, teavm_nullCheck(teavm_local_11)), TEAVM_GET_STRING(7559)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(31401, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31402, teavm_nullCheck(teavm_local_11)), teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31403, meth_jl_StringBuilder_toString(teavm_local_10));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(31404, meth_jl_IllegalArgumentException__init__0(teavm_local_8, teavm_local_9));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(31405, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
void meth_jt_DecimalFormatParser_parseFractionalPart(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_2 = INT32_C(0);
    teavm_local_3 = INT32_C(0);
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((teavm_local_5 >= TEAVM_WITH_CALL_SITE_ID(31406, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(31407, teavm_nullCheck(teavm_local_6)))))) {
            goto teavm_label_1;
        }
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        switch (TEAVM_WITH_CALL_SITE_ID(31408, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(31409, teavm_nullCheck(teavm_local_6)), teavm_local_5))) {
            case 35:
                goto teavm_label_5;
            case 44:
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31410, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
                teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(31411, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(31412, meth_jl_StringBuilder__init_(teavm_local_8));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31413, meth_jl_StringBuilder_append(teavm_local_8, TEAVM_GET_STRING(7568)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31414, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31415, teavm_nullCheck(teavm_local_9)), teavm_local_5));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31416, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31417, teavm_nullCheck(teavm_local_9)), TEAVM_GET_STRING(7559)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                TEAVM_WITH_CALL_SITE_ID(31418, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31419, teavm_nullCheck(teavm_local_9)), teavm_local_7));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31420, meth_jl_StringBuilder_toString(teavm_local_8));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(31421, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_7));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(31422, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                TEAVM_UNREACHABLE
            case 46:
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31423, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
                teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(31424, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(31425, meth_jl_StringBuilder__init_(teavm_local_8));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31426, meth_jl_StringBuilder_append(teavm_local_8, TEAVM_GET_STRING(7569)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31427, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31428, teavm_nullCheck(teavm_local_9)), teavm_local_5));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31429, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31430, teavm_nullCheck(teavm_local_9)), TEAVM_GET_STRING(7559)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                TEAVM_WITH_CALL_SITE_ID(31431, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31432, teavm_nullCheck(teavm_local_9)), teavm_local_7));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31433, meth_jl_StringBuilder_toString(teavm_local_8));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(31434, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_7));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(31435, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                TEAVM_UNREACHABLE
            case 48:
                goto teavm_label_4;
            default:
                goto teavm_label_2;
        }
    teavm_label_5:;
        teavm_local_3 = (teavm_local_3 + INT32_C(1));
        teavm_local_2 = INT32_C(1);
        goto teavm_label_3;
    teavm_label_4:;
        if (teavm_local_2) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31436, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(31437, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
            TEAVM_WITH_CALL_SITE_ID(31438, meth_jl_StringBuilder__init_(teavm_local_9));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31439, meth_jl_StringBuilder_append(teavm_local_9, TEAVM_GET_STRING(7570)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31440, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31441, teavm_nullCheck(teavm_local_7)), teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31442, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31443, teavm_nullCheck(teavm_local_7)), TEAVM_GET_STRING(7559)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(31444, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31445, teavm_nullCheck(teavm_local_7)), teavm_local_8));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31446, meth_jl_StringBuilder_toString(teavm_local_9));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(31447, meth_jl_IllegalArgumentException__init__0(teavm_local_6, teavm_local_7));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31448, meth_otr_ExceptionHandling_throwException(teavm_local_6));
            TEAVM_UNREACHABLE
        }
        teavm_local_3 = (teavm_local_3 + INT32_C(1));
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    teavm_label_3:;
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
    }
teavm_label_2:;
teavm_label_1:;
    if (teavm_local_1) {
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_fracLength) = teavm_local_3;
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_minimumFracLength) = teavm_local_4;
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_decimalSeparatorRequired) = (teavm_local_3 ? INT32_C(0) : INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormatParser_parseExponent(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_2 = INT32_C(0);
    while (1) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((teavm_local_3 >= TEAVM_WITH_CALL_SITE_ID(31449, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(31450, teavm_nullCheck(teavm_local_4)))))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        switch (TEAVM_WITH_CALL_SITE_ID(31451, meth_jl_String_charAt(TEAVM_WITH_CALL_SITE_ID(31452, teavm_nullCheck(teavm_local_4)), teavm_local_3))) {
            case 35:
            case 44:
            case 46:
            case 69:
                goto teavm_label_2;
            case 48:
                goto teavm_label_3;
            default:
                goto teavm_label_1;
        }
    teavm_label_3:;
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) = (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index) + INT32_C(1));
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31453, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31454, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(31455, meth_jl_StringBuilder__init_(teavm_local_6));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31456, meth_jl_StringBuilder_append(teavm_local_6, TEAVM_GET_STRING(7571)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31457, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31458, teavm_nullCheck(teavm_local_7)), teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31459, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31460, teavm_nullCheck(teavm_local_7)), TEAVM_GET_STRING(7559)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(31461, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31462, teavm_nullCheck(teavm_local_7)), teavm_local_5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31463, meth_jl_StringBuilder_toString(teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(31464, meth_jl_IllegalArgumentException__init__0(teavm_local_4, teavm_local_5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(31465, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
teavm_label_1:;
    if ((!teavm_local_2)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31466, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_index);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_string);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31467, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(31468, meth_jl_StringBuilder__init_(teavm_local_6));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31469, meth_jl_StringBuilder_append(teavm_local_6, TEAVM_GET_STRING(7572)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31470, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31471, teavm_nullCheck(teavm_local_7)), teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31472, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31473, teavm_nullCheck(teavm_local_7)), TEAVM_GET_STRING(7559)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(31474, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31475, teavm_nullCheck(teavm_local_7)), teavm_local_5));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31476, meth_jl_StringBuilder_toString(teavm_local_6));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(31477, meth_jl_IllegalArgumentException__init__0(teavm_local_4, teavm_local_5));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(31478, meth_otr_ExceptionHandling_throwException(teavm_local_4));
        TEAVM_UNREACHABLE
    }
    if (teavm_local_1) {
        TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormatParser, fld_exponentLength) = teavm_local_2;
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_DecimalFormatParser(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1591 || tag >= 1593) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DecimalFormatParser_Cls[6];
alignas(8) jt_DecimalFormatParser_VT jt_DecimalFormatParser_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormatParser), sizeof(void*)),
        .flags = 0,
        .tag = 1591,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DecimalFormatParser,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_DecimalFormatParser_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_apply_28 = &meth_jt_DecimalFormatParser_apply,
    .virt_parseText = &meth_jt_DecimalFormatParser_parseText,
    .virt_parse_3 = &meth_jt_DecimalFormatParser_parse
};
static int16_t teavm_classLayouts_jt_DecimalFormatParser_Cls[6] = {
INT16_C(5), (int16_t) offsetof(cls_jt_DecimalFormatParser, fld_positivePrefix), (int16_t) offsetof(cls_jt_DecimalFormatParser, fld_positiveSuffix), (int16_t) offsetof(cls_jt_DecimalFormatParser, fld_negativePrefix), (int16_t) offsetof(cls_jt_DecimalFormatParser, fld_negativeSuffix), (int16_t) offsetof(cls_jt_DecimalFormatParser, fld_string)
};
void sysinitclass_jt_DecimalFormatParser() {
}
