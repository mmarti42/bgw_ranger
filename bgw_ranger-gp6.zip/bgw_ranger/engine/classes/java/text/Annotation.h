#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Annotation.h"

extern void sysinitclass_jt_Annotation();
typedef struct cls_jt_Annotation {
    struct TeaVM_Object parent;
} cls_jt_Annotation;
extern int32_t supertypeof_jt_Annotation(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_Annotation_VT {
    jl_Object_VT parent;
} jt_Annotation_VT;
extern jt_Annotation_VT jt_Annotation_Cls;
