#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "FieldPosition.h"

extern void sysinitclass_jt_FieldPosition();
typedef struct cls_jt_FieldPosition {
    struct TeaVM_Object parent;
    int32_t fld_myField;
    int32_t fld_beginIndex;
    int32_t fld_endIndex;
    void* fld_myAttribute;
} cls_jt_FieldPosition;
extern void meth_jt_FieldPosition__init_(void*, int32_t);
extern int32_t meth_jt_FieldPosition_getEndIndex(void*);
extern void* meth_jt_FieldPosition_getFieldAttribute(void*);
extern void meth_jt_FieldPosition_setBeginIndex(void*, int32_t);
extern void meth_jt_FieldPosition_setEndIndex(void*, int32_t);
extern int32_t supertypeof_jt_FieldPosition(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_FieldPosition_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_getFieldAttribute)(void*); // 11
    void (*virt_setBeginIndex)(void*, int32_t); // 12
    void (*pad0)(); // 13
    int32_t (*virt_getEndIndex)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void (*pad8)(); // 22
    void (*pad9)(); // 23
    void (*pad10)(); // 24
    void (*pad11)(); // 25
    void (*pad12)(); // 26
    void (*pad13)(); // 27
    void (*virt_setEndIndex)(void*, int32_t); // 28
    void (*pad14)(); // 29
    void (*pad15)(); // 30
    void (*pad16)(); // 31
    void (*pad17)(); // 32
    void (*pad18)(); // 33
    void (*pad19)(); // 34
    void (*pad20)(); // 35
    void (*pad21)(); // 36
    void (*pad22)(); // 37
    void (*pad23)(); // 38
    void (*pad24)(); // 39
    void (*pad25)(); // 40
    void (*pad26)(); // 41
    void (*pad27)(); // 42
    void (*pad28)(); // 43
    void (*pad29)(); // 44
    void (*pad30)(); // 45
    void (*pad31)(); // 46
    void (*pad32)(); // 47
    void (*pad33)(); // 48
    void (*pad34)(); // 49
} jt_FieldPosition_VT;
extern jt_FieldPosition_VT jt_FieldPosition_Cls;
