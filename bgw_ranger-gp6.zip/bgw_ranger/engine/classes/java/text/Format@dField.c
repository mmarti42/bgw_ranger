#include "Format@dField.h"
#include "AttributedCharacterIterator@dAttribute.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_jt_Format_Field__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9707, meth_jt_AttributedCharacterIterator_Attribute__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_Format_Field(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 106 || tag >= 110) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_Format_Field_VT jt_Format_Field_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_Format_Field), sizeof(void*)),
                .flags = 0,
                .tag = 106,
                .modifiers = 1,
                .name = NULL,
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_jt_Format_Field,
                .superclass = (TeaVM_Class*) &jt_AttributedCharacterIterator_Attribute_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_clone = &meth_jl_Object_clone,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0
        }
    }
};
void sysinitclass_jt_Format_Field() {
}
