#pragma once
#include "../../../runtime.h"
#include "NumberFormat.h"
#include "ChoiceFormat.h"

extern void sysinitclass_jt_ChoiceFormat();
typedef struct cls_jt_ChoiceFormat {
    struct cls_jt_NumberFormat parent;
    TeaVM_Array* fld_choiceLimits;
    TeaVM_Array* fld_choiceFormats;
} cls_jt_ChoiceFormat;
extern void meth_jt_ChoiceFormat__init_(void*, void*);
extern void meth_jt_ChoiceFormat_applyPattern(void*, void*);
extern int32_t meth_jt_ChoiceFormat_equals(void*, void*);
extern void* meth_jt_ChoiceFormat_format(void*, double, void*, void*);
extern void* meth_jt_ChoiceFormat_format_0(void*, int64_t, void*, void*);
extern int32_t meth_jt_ChoiceFormat_hashCode(void*);
extern double meth_jt_ChoiceFormat_nextDouble(double);
extern int32_t meth_jt_ChoiceFormat_skipWhitespace(void*, void*, int32_t);
extern int32_t supertypeof_jt_ChoiceFormat(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_ChoiceFormat_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*virt_setMaximumFractionDigits)(void*, int32_t); // 13
    void* (*virt_format_1)(void*, int64_t, void*, void*); // 14
    void (*pad0)(); // 15
    void (*virt_setMaximumIntegerDigits)(void*, int32_t); // 16
    void (*virt_setMinimumFractionDigits)(void*, int32_t); // 17
    void (*pad1)(); // 18
    int32_t (*virt_getMinimumIntegerDigits)(void*); // 19
    int32_t (*virt_isGroupingUsed)(void*); // 20
    void* (*virt_parse_0)(void*, void*, void*); // 21
    void* (*virt_format_0)(void*, double, void*, void*); // 22
    void (*pad2)(); // 23
    int32_t (*virt_getMaximumIntegerDigits)(void*); // 24
    void (*virt_setMinimumIntegerDigits)(void*, int32_t); // 25
    void (*virt_setParseIntegerOnly)(void*, int32_t); // 26
    int32_t (*virt_getMaximumFractionDigits)(void*); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*pad3)(); // 29
    void (*pad4)(); // 30
    int32_t (*virt_getMinimumFractionDigits)(void*); // 31
    void (*pad5)(); // 32
    void (*pad6)(); // 33
    void (*pad7)(); // 34
    void (*pad8)(); // 35
    void (*pad9)(); // 36
    void* (*virt_getCurrency)(void*); // 37
    void* (*virt_getRoundingMode)(void*); // 38
    void (*pad10)(); // 39
    void (*pad11)(); // 40
    void (*pad12)(); // 41
    void (*pad13)(); // 42
    void (*pad14)(); // 43
    void (*pad15)(); // 44
    void (*pad16)(); // 45
    void (*pad17)(); // 46
    void (*virt_setGroupingUsed)(void*, int32_t); // 47
    void (*virt_applyPattern)(void*, void*); // 48
    void (*pad18)(); // 49
} jt_ChoiceFormat_VT;
extern jt_ChoiceFormat_VT jt_ChoiceFormat_Cls;
