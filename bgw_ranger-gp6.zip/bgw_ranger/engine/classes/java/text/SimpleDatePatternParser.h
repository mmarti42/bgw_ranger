#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "SimpleDatePatternParser.h"

extern void sysinitclass_jt_SimpleDatePatternParser();
typedef struct cls_jt_SimpleDatePatternParser {
    struct TeaVM_Object parent;
    void* fld_symbols;
    void* fld_locale;
    void* fld_elements;
    int32_t fld_index;
    void* fld_pattern;
} cls_jt_SimpleDatePatternParser;
extern void meth_jt_SimpleDatePatternParser__init_(void*, void*, void*);
extern void* meth_jt_SimpleDatePatternParser_getElements(void*);
extern void meth_jt_SimpleDatePatternParser_parsePattern(void*, void*);
extern int32_t meth_jt_SimpleDatePatternParser_isControl(void*, int32_t);
extern void meth_jt_SimpleDatePatternParser_parseQuoted(void*);
extern int32_t meth_jt_SimpleDatePatternParser_parseRepetitions(void*);
extern int32_t supertypeof_jt_SimpleDatePatternParser(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_SimpleDatePatternParser_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_getElements)(void*); // 11
    void (*virt_parsePattern)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void (*pad15)(); // 28
    void (*pad16)(); // 29
    void (*pad17)(); // 30
    void (*pad18)(); // 31
    void (*pad19)(); // 32
    void (*pad20)(); // 33
    void (*pad21)(); // 34
    void (*pad22)(); // 35
    void (*pad23)(); // 36
    void (*pad24)(); // 37
    void (*pad25)(); // 38
    void (*pad26)(); // 39
    void (*pad27)(); // 40
    void (*pad28)(); // 41
    void (*pad29)(); // 42
    void (*pad30)(); // 43
    void (*pad31)(); // 44
    void (*pad32)(); // 45
    void (*pad33)(); // 46
    void (*pad34)(); // 47
    void (*pad35)(); // 48
    void (*pad36)(); // 49
} jt_SimpleDatePatternParser_VT;
extern jt_SimpleDatePatternParser_VT jt_SimpleDatePatternParser_Cls;
