#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "AttributedString@dRange.h"

extern void sysinitclass_jt_AttributedString_Range();
typedef struct cls_jt_AttributedString_Range {
    struct TeaVM_Object parent;
    int32_t fld_start;
    int32_t fld_end;
    void* fld_value;
} cls_jt_AttributedString_Range;
extern int32_t supertypeof_jt_AttributedString_Range(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_AttributedString_Range_VT {
    jl_Object_VT parent;
} jt_AttributedString_Range_VT;
extern jt_AttributedString_Range_VT jt_AttributedString_Range_Cls;
