#include "FieldPosition.h"
#include "../lang/Object.h"
#include "../../../strings.h"

void meth_jt_FieldPosition__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(40599, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_FieldPosition, fld_myField) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_FieldPosition_getEndIndex(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_FieldPosition, fld_endIndex);
}
void* meth_jt_FieldPosition_getFieldAttribute(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_FieldPosition, fld_myAttribute);
}
void meth_jt_FieldPosition_setBeginIndex(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_FieldPosition, fld_beginIndex) = teavm_local_1;
}
void meth_jt_FieldPosition_setEndIndex(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_FieldPosition, fld_endIndex) = teavm_local_1;
}
int32_t supertypeof_jt_FieldPosition(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1897 || tag >= 1899) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_FieldPosition_Cls[2];
alignas(8) jt_FieldPosition_VT jt_FieldPosition_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_FieldPosition), sizeof(void*)),
        .flags = 0,
        .tag = 1897,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_FieldPosition,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_FieldPosition_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getFieldAttribute = &meth_jt_FieldPosition_getFieldAttribute,
    .virt_setBeginIndex = &meth_jt_FieldPosition_setBeginIndex,
    .virt_getEndIndex = &meth_jt_FieldPosition_getEndIndex,
    .virt_setEndIndex = &meth_jt_FieldPosition_setEndIndex
};
static int16_t teavm_classLayouts_jt_FieldPosition_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_FieldPosition, fld_myAttribute)
};
void sysinitclass_jt_FieldPosition() {
}
