#pragma once
#include "../../../runtime.h"
#include "Format.h"
#include "NumberFormat.h"

extern void sysinitclass_jt_NumberFormat();
typedef struct cls_jt_NumberFormat {
    struct cls_jt_Format parent;
    int8_t fld_groupingUsed;
    int8_t fld_parseIntegerOnly;
    int32_t fld_maximumIntegerDigits;
    int32_t fld_minimumIntegerDigits;
    int32_t fld_maximumFractionDigits;
    int32_t fld_minimumFractionDigits;
    void* fld_roundingMode;
    void* fld_currency;
} cls_jt_NumberFormat;
extern void meth_jt_NumberFormat__init_(void*);
extern void* meth_jt_NumberFormat_getCurrency(void*);
extern int32_t meth_jt_NumberFormat_equals(void*, void*);
extern void* meth_jt_NumberFormat_format(void*, void*, void*, void*);
extern void* meth_jt_NumberFormat_getIntegerInstance(void*);
extern void* meth_jt_NumberFormat_getInstance();
extern void* meth_jt_NumberFormat_getInstance_0(void*);
extern int32_t meth_jt_NumberFormat_getMaximumFractionDigits(void*);
extern int32_t meth_jt_NumberFormat_getMaximumIntegerDigits(void*);
extern int32_t meth_jt_NumberFormat_getMinimumFractionDigits(void*);
extern int32_t meth_jt_NumberFormat_getMinimumIntegerDigits(void*);
extern void* meth_jt_NumberFormat_getNumberInstance();
extern void* meth_jt_NumberFormat_getNumberInstance_0(void*);
extern void* meth_jt_NumberFormat_getPercentInstance(void*);
extern void* meth_jt_NumberFormat_getCurrencyInstance(void*);
extern int32_t meth_jt_NumberFormat_hashCode(void*);
extern int32_t meth_jt_NumberFormat_isGroupingUsed(void*);
extern void meth_jt_NumberFormat_setGroupingUsed(void*, int32_t);
extern void meth_jt_NumberFormat_setMaximumFractionDigits(void*, int32_t);
extern void meth_jt_NumberFormat_setMaximumIntegerDigits(void*, int32_t);
extern void meth_jt_NumberFormat_setMinimumFractionDigits(void*, int32_t);
extern void meth_jt_NumberFormat_setMinimumIntegerDigits(void*, int32_t);
extern void meth_jt_NumberFormat_setParseIntegerOnly(void*, int32_t);
extern void* meth_jt_NumberFormat_getRoundingMode(void*);
extern int32_t supertypeof_jt_NumberFormat(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_NumberFormat_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*virt_setMaximumFractionDigits)(void*, int32_t); // 13
    void* (*virt_format_1)(void*, int64_t, void*, void*); // 14
    void (*pad0)(); // 15
    void (*virt_setMaximumIntegerDigits)(void*, int32_t); // 16
    void (*virt_setMinimumFractionDigits)(void*, int32_t); // 17
    void (*pad1)(); // 18
    int32_t (*virt_getMinimumIntegerDigits)(void*); // 19
    int32_t (*virt_isGroupingUsed)(void*); // 20
    void* (*virt_parse_0)(void*, void*, void*); // 21
    void* (*virt_format_0)(void*, double, void*, void*); // 22
    void (*pad2)(); // 23
    int32_t (*virt_getMaximumIntegerDigits)(void*); // 24
    void (*virt_setMinimumIntegerDigits)(void*, int32_t); // 25
    void (*virt_setParseIntegerOnly)(void*, int32_t); // 26
    int32_t (*virt_getMaximumFractionDigits)(void*); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*pad3)(); // 29
    void (*pad4)(); // 30
    int32_t (*virt_getMinimumFractionDigits)(void*); // 31
    void (*pad5)(); // 32
    void (*pad6)(); // 33
    void (*pad7)(); // 34
    void (*pad8)(); // 35
    void (*pad9)(); // 36
    void* (*virt_getCurrency)(void*); // 37
    void* (*virt_getRoundingMode)(void*); // 38
    void (*pad10)(); // 39
    void (*pad11)(); // 40
    void (*pad12)(); // 41
    void (*pad13)(); // 42
    void (*pad14)(); // 43
    void (*pad15)(); // 44
    void (*pad16)(); // 45
    void (*pad17)(); // 46
    void (*virt_setGroupingUsed)(void*, int32_t); // 47
    void (*pad18)(); // 48
    void (*pad19)(); // 49
} jt_NumberFormat_VT;
extern jt_NumberFormat_VT jt_NumberFormat_Cls;
