#include "DateFormatElement@dAmPmText.h"
#include "DateFormatElement.h"
#include "DateFormatSymbols.h"
#include "../util/Calendar.h"
#include "../lang/StringBuffer.h"
#include "ParsePosition.h"
#include "../lang/Object.h"
#include "../util/Arrays.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_AmPmText__init_(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(10661, meth_jt_DateFormatElement__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10662, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10663, TEAVM_METHOD(teavm_local_1, jt_DateFormatSymbols_VT, virt_getAmPmStrings)(teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_AmPmText, fld_ampms) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_AmPmText_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10664, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10665, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_get_2)(teavm_local_1, INT32_C(9)));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_AmPmText, fld_ampms);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10666, teavm_nullCheck(teavm_local_4));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10667, teavm_checkBounds(teavm_local_3, teavm_local_4));
    teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10668, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(10669, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_5));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_AmPmText_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_AmPmText, fld_ampms);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(10670, meth_jt_DateFormatElement_whichMatches(teavm_local_1, teavm_local_3, teavm_local_4));
    if ((teavm_local_5 >= INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10671, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(10672, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_set_1)(teavm_local_2, INT32_C(9), teavm_local_5));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10673, teavm_nullCheck(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(10674, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(10675, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3))));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_AmPmText_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10676, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(10677, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10678, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_AmPmText_Cls, &supertypeof_jt_DateFormatElement_AmPmText));
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_AmPmText, fld_ampms);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10679, teavm_nullCheck(teavm_local_4));
        teavm_local_6 = TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_AmPmText, fld_ampms);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10680, meth_ju_Arrays_equals(teavm_local_5, teavm_local_6));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_AmPmText_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_AmPmText, fld_ampms);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10681, meth_ju_Arrays_hashCode(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jt_DateFormatElement_AmPmText(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2262 || tag >= 2264) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatElement_AmPmText_Cls[2];
alignas(8) jt_DateFormatElement_AmPmText_VT jt_DateFormatElement_AmPmText_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_AmPmText), sizeof(void*)),
            .flags = 0,
            .tag = 2262,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(761),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_AmPmText,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .layout = teavm_classLayouts_jt_DateFormatElement_AmPmText_Cls,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_AmPmText_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_AmPmText_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_AmPmText_format,
        .virt_parse = &meth_jt_DateFormatElement_AmPmText_parse
    }
};
static int16_t teavm_classLayouts_jt_DateFormatElement_AmPmText_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_DateFormatElement_AmPmText, fld_ampms)
};
void sysinitclass_jt_DateFormatElement_AmPmText() {
}
