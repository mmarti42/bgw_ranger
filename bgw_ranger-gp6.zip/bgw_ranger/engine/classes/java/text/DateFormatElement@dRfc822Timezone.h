#pragma once
#include "../../../runtime.h"
#include "DateFormatElement@dBaseTimezone.h"
#include "DateFormatElement@dRfc822Timezone.h"

extern void sysinitclass_jt_DateFormatElement_Rfc822Timezone();
typedef struct cls_jt_DateFormatElement_Rfc822Timezone {
    struct cls_jt_DateFormatElement_BaseTimezone parent;
} cls_jt_DateFormatElement_Rfc822Timezone;
extern void meth_jt_DateFormatElement_Rfc822Timezone__init_(void*, void*);
extern void meth_jt_DateFormatElement_Rfc822Timezone_format(void*, void*, void*);
extern int32_t supertypeof_jt_DateFormatElement_Rfc822Timezone(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_Rfc822Timezone_VT {
    jt_DateFormatElement_BaseTimezone_VT parent;
} jt_DateFormatElement_Rfc822Timezone_VT;
extern jt_DateFormatElement_Rfc822Timezone_VT jt_DateFormatElement_Rfc822Timezone_Cls;
