#include "DateFormat.h"
#include "Format.h"
#include "../util/Calendar.h"
#include "../util/Date.h"
#include "../lang/Number.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "SimpleDateFormat.h"
#include "../util/Locale.h"
#include "../../org/teavm/classlib/impl/unicode/CLDRHelper.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../../../resources/org/teavm/classlib/impl/unicode/DateFormatCollection.h"
#include "../lang/Math.h"
#include "../lang/String.h"
#include "ParsePosition.h"
#include "ParseException.h"
#include "../lang/Object.h"

void meth_jt_DateFormat__init_(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30995, meth_jt_Format__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30996, meth_ju_Calendar_getInstance());
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormat_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jt_DateFormat_Cls, &supertypeof_jt_DateFormat))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30997, teavm_checkcast(teavm_local_1, &jt_DateFormat_Cls, &supertypeof_jt_DateFormat));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30998, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(30999, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getFirstDayOfWeek)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31000, teavm_nullCheck(teavm_local_3));
        teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormat, fld_calendar);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        if ((teavm_local_2 == TEAVM_WITH_CALL_SITE_ID(31001, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31002, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getFirstDayOfWeek)(teavm_tmp_ptr_0))))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31003, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31004, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getMinimalDaysInFirstWeek)(teavm_tmp_ptr_0)));
            teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormat, fld_calendar);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            if ((teavm_local_2 == TEAVM_WITH_CALL_SITE_ID(31005, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31006, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getMinimalDaysInFirstWeek)(teavm_tmp_ptr_0))))) {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31007, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31008, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_isLenient)(teavm_tmp_ptr_0)));
                teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jt_DateFormat, fld_calendar);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                if ((teavm_local_2 == TEAVM_WITH_CALL_SITE_ID(31009, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31010, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_isLenient)(teavm_tmp_ptr_0))))) {
                    goto teavm_label_2;
                }
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DateFormat_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    int64_t teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (teavm_instanceof(teavm_local_1, &ju_Date_Cls, &supertypeof_ju_Date)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31011, teavm_checkcast(teavm_local_1, &ju_Date_Cls, &supertypeof_ju_Date));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31012, TEAVM_METHOD(teavm_this_, jt_DateFormat_VT, virt_format_4)(teavm_this_, teavm_local_4, teavm_local_2, teavm_local_3));
    } else if (teavm_instanceof(teavm_local_1, &jl_Number_Cls, &supertypeof_jl_Number)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31013, meth_otr_Allocator_allocate(&ju_Date_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31014, teavm_checkcast(teavm_local_1, &jl_Number_Cls, &supertypeof_jl_Number));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31015, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31016, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Number_VT, virt_longValue)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(31017, meth_ju_Date__init_(teavm_local_4, teavm_local_6));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31018, TEAVM_METHOD(teavm_this_, jt_DateFormat_VT, virt_format_4)(teavm_this_, teavm_local_4, teavm_local_2, teavm_local_3));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31019, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(31020, meth_jl_IllegalArgumentException__init_(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(31021, meth_otr_ExceptionHandling_throwException(teavm_local_4));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jt_DateFormat_getTimeZone(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(31022, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31023, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getTimeZone)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jt_DateFormat_setTimeZone(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(31024, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31025, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_setTimeZone)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DateFormat_getDateInstance(int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31026, meth_otr_Allocator_allocate(&jt_SimpleDateFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31027, meth_jt_DateFormat_getDateFormatString(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(31028, meth_jt_SimpleDateFormat__init__0(teavm_local_3, teavm_local_4, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_DateFormat_getDateFormatString(int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31029, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31030, meth_ju_Locale_getLanguage(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31031, meth_ju_Locale_getCountry(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31032, meth_otciu_CLDRHelper_resolveDateFormats(teavm_local_3, teavm_local_4));
    switch (teavm_local_1) {
        case 0:
            goto teavm_label_5;
        case 1:
            goto teavm_label_4;
        case 2:
            goto teavm_label_3;
        case 3:
            goto teavm_label_2;
        default:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31033, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31034, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(31035, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31036, meth_jl_StringBuilder_append(teavm_local_4, TEAVM_GET_STRING(7553)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(31037, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31038, teavm_nullCheck(teavm_local_6)), teavm_local_1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31039, meth_jl_StringBuilder_toString(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(31040, meth_jl_IllegalArgumentException__init__0(teavm_local_3, teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31041, meth_otr_ExceptionHandling_throwException(teavm_local_3));
            TEAVM_UNREACHABLE
    }
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31042, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, fullFormat)));
    goto teavm_label_1;
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31043, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, longFormat)));
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31044, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, mediumFormat)));
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31045, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, shortFormat)));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_DateFormat_getDateTimeInstance(int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31046, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31047, meth_jt_DateFormat_getDateTimeInstance_0(teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_DateFormat_getDateTimeInstance_0(int32_t teavm_local_1, int32_t teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31048, meth_jt_DateFormat_getDateTimeFormatString(TEAVM_WITH_CALL_SITE_ID(31049, meth_jl_Math_max(teavm_local_1, teavm_local_2)), teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31050, meth_jt_DateFormat_getTimeFormatString(teavm_local_1, teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31051, teavm_nullCheck(teavm_local_4));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31052, meth_jl_String_replace_0(teavm_local_4, TEAVM_GET_STRING(7554), teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31053, meth_jt_DateFormat_getDateFormatString(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31054, meth_jl_String_replace_0(TEAVM_WITH_CALL_SITE_ID(31055, teavm_nullCheck(teavm_local_6)), TEAVM_GET_STRING(7555), teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31056, meth_otr_Allocator_allocate(&jt_SimpleDateFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(31057, meth_jt_SimpleDateFormat__init__0(teavm_local_5, teavm_local_6, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jt_DateFormat_getDateTimeFormatString(int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31058, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31059, meth_ju_Locale_getLanguage(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31060, meth_ju_Locale_getCountry(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31061, meth_otciu_CLDRHelper_resolveDateTimeFormats(teavm_local_3, teavm_local_4));
    switch (teavm_local_1) {
        case 0:
            goto teavm_label_5;
        case 1:
            goto teavm_label_4;
        case 2:
            goto teavm_label_3;
        case 3:
            goto teavm_label_2;
        default:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31062, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31063, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(31064, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31065, meth_jl_StringBuilder_append(teavm_local_4, TEAVM_GET_STRING(7553)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(31066, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31067, teavm_nullCheck(teavm_local_6)), teavm_local_1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31068, meth_jl_StringBuilder_toString(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(31069, meth_jl_IllegalArgumentException__init__0(teavm_local_3, teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31070, meth_otr_ExceptionHandling_throwException(teavm_local_3));
            TEAVM_UNREACHABLE
    }
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31071, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, fullFormat)));
    goto teavm_label_1;
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31072, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, longFormat)));
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31073, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, mediumFormat)));
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31074, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, shortFormat)));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_DateFormat_getInstance() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(31075, meth_jt_DateFormat_getDateTimeInstance(INT32_C(3), INT32_C(3)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jt_DateFormat_getTimeInstance(int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31076, meth_otr_Allocator_allocate(&jt_SimpleDateFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31077, meth_jt_DateFormat_getTimeFormatString(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(31078, meth_jt_SimpleDateFormat__init__0(teavm_local_3, teavm_local_4, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_DateFormat_getTimeFormatString(int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31079, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31080, meth_ju_Locale_getLanguage(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31081, meth_ju_Locale_getCountry(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31082, meth_otciu_CLDRHelper_resolveTimeFormats(teavm_local_3, teavm_local_4));
    switch (teavm_local_1) {
        case 0:
            goto teavm_label_5;
        case 1:
            goto teavm_label_4;
        case 2:
            goto teavm_label_3;
        case 3:
            goto teavm_label_2;
        default:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31083, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31084, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(31085, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31086, meth_jl_StringBuilder_append(teavm_local_4, TEAVM_GET_STRING(7553)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(31087, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(31088, teavm_nullCheck(teavm_local_6)), teavm_local_1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31089, meth_jl_StringBuilder_toString(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(31090, meth_jl_IllegalArgumentException__init__0(teavm_local_3, teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(31091, meth_otr_ExceptionHandling_throwException(teavm_local_3));
            TEAVM_UNREACHABLE
    }
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31092, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, fullFormat)));
    goto teavm_label_1;
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31093, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, longFormat)));
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31094, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, mediumFormat)));
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31095, teavm_dereferenceNullable(TEAVM_FIELD(teavm_local_5, cls_otciu_DateFormatCollection, shortFormat)));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jt_DateFormat_hashCode(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31096, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31097, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getFirstDayOfWeek)(teavm_tmp_ptr_0)));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(31098, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31099, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getMinimalDaysInFirstWeek)(teavm_tmp_ptr_0))));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = (teavm_local_2 + ((!TEAVM_WITH_CALL_SITE_ID(31100, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31101, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_isLenient)(teavm_tmp_ptr_0)))) ? INT32_C(1237) : INT32_C(1231)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DateFormat_parse(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(31102, meth_otr_Allocator_allocate(&jt_ParsePosition_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(31103, meth_jt_ParsePosition__init_(teavm_local_2, INT32_C(0)));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(31104, TEAVM_METHOD(teavm_this_, jt_DateFormat_VT, virt_parse_2)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    if ((TEAVM_WITH_CALL_SITE_ID(31105, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getErrorIndex)(teavm_local_2)) > INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(31106, meth_otr_Allocator_allocate(&jt_ParseException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31107, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        TEAVM_WITH_CALL_SITE_ID(31108, meth_jl_StringBuilder__init_(teavm_local_5));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(31109, meth_jl_StringBuilder_append(teavm_local_5, TEAVM_GET_STRING(7556)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(31110, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(31111, teavm_nullCheck(teavm_local_6)), teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(31112, meth_jl_StringBuilder_toString(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(31113, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getErrorIndex)(teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(31114, meth_jt_ParseException__init_(teavm_local_4, teavm_local_5, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(31115, meth_otr_ExceptionHandling_throwException(teavm_local_4));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jt_DateFormat_setLenient(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormat, fld_calendar);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(31116, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(31117, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_setLenient)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_DateFormat(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1224 || tag >= 1228) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormat_Cls[2];
alignas(8) jt_DateFormat_VT jt_DateFormat_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormat), sizeof(void*)),
        .flags = 0,
        .tag = 1224,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormat,
        .superclass = (TeaVM_Class*) &jt_Format_Cls,
        .layout = teavm_classLayouts_jt_DateFormat_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DateFormat_hashCode,
    .virt_equals = &meth_jt_DateFormat_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format_2 = &meth_jt_DateFormat_format,
    .virt_formatToCharacterIterator = &meth_jt_Format_formatToCharacterIterator,
    .virt_setLenient = &meth_jt_DateFormat_setLenient,
    .virt_getTimeZone = &meth_jt_DateFormat_getTimeZone,
    .virt_setTimeZone = &meth_jt_DateFormat_setTimeZone,
    .virt_parse_1 = &meth_jt_DateFormat_parse,
    .virt_format_3 = &meth_jt_Format_format
};
static int16_t teavm_classLayouts_jt_DateFormat_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_DateFormat, fld_calendar)
};
void sysinitclass_jt_DateFormat() {
}
