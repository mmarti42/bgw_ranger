#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DecimalFormatSymbols.h"

extern void sysinitclass_jt_DecimalFormatSymbols();
typedef struct cls_jt_DecimalFormatSymbols {
    struct TeaVM_Object parent;
    void* fld_locale;
    char16_t fld_zeroDigit;
    char16_t fld_groupingSeparator;
    char16_t fld_decimalSeparator;
    char16_t fld_perMill;
    char16_t fld_percent;
    char16_t fld_digit;
    char16_t fld_patternSeparator;
    void* fld_nan;
    void* fld_infinity;
    char16_t fld_minusSign;
    char16_t fld_monetaryDecimalSeparator;
    void* fld_exponentSeparator;
} cls_jt_DecimalFormatSymbols;
extern void meth_jt_DecimalFormatSymbols__init__0(void*);
extern void meth_jt_DecimalFormatSymbols__init_(void*, void*);
extern void meth_jt_DecimalFormatSymbols_initData(void*);
extern int32_t meth_jt_DecimalFormatSymbols_getZeroDigit(void*);
extern int32_t meth_jt_DecimalFormatSymbols_getGroupingSeparator(void*);
extern int32_t meth_jt_DecimalFormatSymbols_getPerMill(void*);
extern int32_t meth_jt_DecimalFormatSymbols_getPercent(void*);
extern void* meth_jt_DecimalFormatSymbols_getLocale(void*);
extern int32_t meth_jt_DecimalFormatSymbols_getDecimalSeparator(void*);
extern void* meth_jt_DecimalFormatSymbols_getNaN(void*);
extern void* meth_jt_DecimalFormatSymbols_getInfinity(void*);
extern int32_t meth_jt_DecimalFormatSymbols_getMinusSign(void*);
extern void* meth_jt_DecimalFormatSymbols_getExponentSeparator(void*);
extern void* meth_jt_DecimalFormatSymbols_clone(void*);
extern int32_t supertypeof_jt_DecimalFormatSymbols(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DecimalFormatSymbols_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_getPercent)(void*); // 11
    int32_t (*virt_getMinusSign)(void*); // 12
    void (*pad0)(); // 13
    int32_t (*virt_getGroupingSeparator)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_getNaN)(void*); // 21
    void* (*virt_getExponentSeparator)(void*); // 22
    void* (*virt_getInfinity)(void*); // 23
    void (*pad7)(); // 24
    void (*pad8)(); // 25
    void (*pad9)(); // 26
    int32_t (*virt_getZeroDigit)(void*); // 27
    void* (*virt_getLocale)(void*); // 28
    void (*pad10)(); // 29
    void (*pad11)(); // 30
    void (*pad12)(); // 31
    void (*pad13)(); // 32
    void (*pad14)(); // 33
    void (*pad15)(); // 34
    void (*pad16)(); // 35
    void (*pad17)(); // 36
    int32_t (*virt_getDecimalSeparator)(void*); // 37
    void (*pad18)(); // 38
    void (*pad19)(); // 39
    void (*pad20)(); // 40
    void (*pad21)(); // 41
    void (*pad22)(); // 42
    void (*pad23)(); // 43
    void (*pad24)(); // 44
    void (*pad25)(); // 45
    void (*pad26)(); // 46
    void (*pad27)(); // 47
    int32_t (*virt_getPerMill)(void*); // 48
    void (*pad28)(); // 49
} jt_DecimalFormatSymbols_VT;
extern jt_DecimalFormatSymbols_VT jt_DecimalFormatSymbols_Cls;
