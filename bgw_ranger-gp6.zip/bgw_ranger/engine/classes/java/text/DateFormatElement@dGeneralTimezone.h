#pragma once
#include "../../../runtime.h"
#include "DateFormatElement@dBaseTimezone.h"
#include "DateFormatElement@dGeneralTimezone.h"

extern void sysinitclass_jt_DateFormatElement_GeneralTimezone();
typedef struct cls_jt_DateFormatElement_GeneralTimezone {
    struct cls_jt_DateFormatElement_BaseTimezone parent;
} cls_jt_DateFormatElement_GeneralTimezone;
extern void meth_jt_DateFormatElement_GeneralTimezone__init_(void*, void*);
extern void meth_jt_DateFormatElement_GeneralTimezone_format(void*, void*, void*);
extern int32_t supertypeof_jt_DateFormatElement_GeneralTimezone(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_GeneralTimezone_VT {
    jt_DateFormatElement_BaseTimezone_VT parent;
} jt_DateFormatElement_GeneralTimezone_VT;
extern jt_DateFormatElement_GeneralTimezone_VT jt_DateFormatElement_GeneralTimezone_Cls;
