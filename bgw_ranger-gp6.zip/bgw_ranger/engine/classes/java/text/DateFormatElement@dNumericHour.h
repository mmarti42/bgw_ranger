#pragma once
#include "../../../runtime.h"
#include "DateFormatElement@dNumeric.h"
#include "DateFormatElement@dNumericHour.h"

extern void sysinitclass_jt_DateFormatElement_NumericHour();
typedef struct cls_jt_DateFormatElement_NumericHour {
    struct cls_jt_DateFormatElement_Numeric parent;
    int32_t fld_limit;
} cls_jt_DateFormatElement_NumericHour;
extern void meth_jt_DateFormatElement_NumericHour__init_(void*, int32_t, int32_t, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericHour_processBeforeFormat(void*, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericHour_processAfterParse(void*, int32_t);
extern int32_t meth_jt_DateFormatElement_NumericHour_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_NumericHour_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_NumericHour(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_NumericHour_VT {
    jt_DateFormatElement_Numeric_VT parent;
} jt_DateFormatElement_NumericHour_VT;
extern jt_DateFormatElement_NumericHour_VT jt_DateFormatElement_NumericHour_Cls;
