#include "DecimalFormat.h"
#include "NumberFormat.h"
#include "../util/Locale.h"
#include "../../org/teavm/classlib/impl/unicode/CLDRHelper.h"
#include "DecimalFormatSymbols.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrayclass.h"
#include "DecimalFormat@dFormatField.h"
#include "DecimalFormat@dTextField.h"
#include "../../../strings.h"
#include "DecimalFormatParser.h"
#include "../lang/StringBuffer.h"
#include "../util/Arrays.h"
#include "../math/BigInteger.h"
#include "ParsePosition.h"
#include "../lang/String.h"
#include "../math/BigDecimal.h"
#include "../lang/Double.h"
#include "../lang/Long.h"
#include "../../org/teavm/classlib/impl/text/DoubleSynthesizer.h"
#include "DecimalFormat@dConstants.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer@dResult.h"
#include "../lang/Math.h"
#include "DecimalFormat@d1.h"
#include "../lang/Enum.h"
#include "../lang/ArithmeticException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../arrays/primitives/long.h"
#include "../../../arrays/primitives/int.h"
#include "../lang/Object.h"
#include "Format.h"

TeaVM_Array* sfld_jt_DecimalFormat_POW10_ARRAY;
TeaVM_Array* sfld_jt_DecimalFormat_POW10_INT_ARRAY;
void meth_jt_DecimalFormat__init__0(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(25721, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_Cls, &initclass_jt_DecimalFormat));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25722, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25723, meth_ju_Locale_getLanguage(TEAVM_WITH_CALL_SITE_ID(25724, teavm_nullCheck(teavm_local_1))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25725, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25726, meth_ju_Locale_getCountry(TEAVM_WITH_CALL_SITE_ID(25727, teavm_nullCheck(teavm_local_1))));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25728, meth_otciu_CLDRHelper_resolveNumberFormat(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(25729, meth_jt_DecimalFormat__init__1(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat__init__1(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(25730, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_Cls, &initclass_jt_DecimalFormat));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25731, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(25732, meth_jt_DecimalFormatSymbols__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(25733, meth_jt_DecimalFormat__init_(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(25734, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_Cls, &initclass_jt_DecimalFormat));
    TEAVM_WITH_CALL_SITE_ID(25735, meth_jt_NumberFormat__init_(teavm_this_));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25736, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix) = teavm_local_3;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25737, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), INT32_C(1)));
    teavm_local_3 = teavm_local_4;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25738, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(25739, meth_jt_DecimalFormat_TextField__init_(teavm_local_5, TEAVM_GET_STRING(31)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(0)) = teavm_local_5;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) = teavm_local_4;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25740, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix) = teavm_local_3;
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25741, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) = INT32_C(1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25742, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25743, TEAVM_METHOD(teavm_local_2, jt_DecimalFormatSymbols_VT, virt_clone)(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25744, teavm_checkcast(teavm_local_5, &jt_DecimalFormatSymbols_Cls, &supertypeof_jt_DecimalFormatSymbols));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols) = teavm_local_5;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(25745, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_applyPattern)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_applyPattern(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25746, meth_otr_Allocator_allocate(&jt_DecimalFormatParser_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(25747, meth_jt_DecimalFormatParser__init_(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(25748, TEAVM_METHOD(teavm_local_2, jt_DecimalFormatParser_VT, virt_parse_3)(teavm_local_2, teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(25749, TEAVM_METHOD(teavm_local_2, jt_DecimalFormatParser_VT, virt_apply_28)(teavm_local_2, teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_pattern) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DecimalFormat_toPattern(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_pattern);
}
void meth_jt_DecimalFormat_setDecimalFormatSymbols(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25750, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25751, TEAVM_METHOD(teavm_local_1, jt_DecimalFormatSymbols_VT, virt_clone)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25752, teavm_checkcast(teavm_local_2, &jt_DecimalFormatSymbols_Cls, &supertypeof_jt_DecimalFormatSymbols));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DecimalFormat_fieldsToText(void* teavm_this_, TeaVM_Array* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25753, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = teavm_local_1;
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25754, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(25755, teavm_nullCheck(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(25756, TEAVM_METHOD(teavm_local_6, jt_DecimalFormat_FormatField_VT, virt_render)(teavm_local_6, teavm_this_, teavm_local_2));
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_fieldsToText_0(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = NULL;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25757, meth_otr_Allocator_allocate(&jl_StringBuffer_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(25758, meth_jl_StringBuffer__init__0(teavm_local_2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25759, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_1, teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25760, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25761, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_toString)(teavm_tmp_ptr_0)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
TeaVM_Array* meth_jt_DecimalFormat_textToFields(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25762, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), INT32_C(1)));
    teavm_local_3 = teavm_local_2;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25763, meth_otr_Allocator_allocate(&jt_DecimalFormat_TextField_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(25764, meth_jt_DecimalFormat_TextField__init_(teavm_local_4, teavm_local_1));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(0)) = teavm_local_4;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_getPositivePrefix(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25765, meth_jt_DecimalFormat_fieldsToText_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jt_DecimalFormat_setPositivePrefix(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25766, meth_jt_DecimalFormat_textToFields(teavm_this_, teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DecimalFormat_getNegativePrefix(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25767, meth_jt_DecimalFormat_fieldsToText_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jt_DecimalFormat_setNegativePrefix(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25768, meth_jt_DecimalFormat_textToFields(teavm_this_, teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DecimalFormat_getPositiveSuffix(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25769, meth_jt_DecimalFormat_fieldsToText_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_getNegativeSuffix(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25770, meth_jt_DecimalFormat_fieldsToText_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jt_DecimalFormat_setNegativeSuffix(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25771, meth_jt_DecimalFormat_textToFields(teavm_this_, teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_setMultiplier(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) = teavm_local_1;
}
int32_t meth_jt_DecimalFormat_getGroupingSize(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize);
}
void meth_jt_DecimalFormat_setGroupingSize(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) = teavm_local_1;
}
int32_t meth_jt_DecimalFormat_isDecimalSeparatorAlwaysShown(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_decimalSeparatorAlwaysShown);
}
void meth_jt_DecimalFormat_setDecimalSeparatorAlwaysShown(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_decimalSeparatorAlwaysShown) = teavm_local_1;
}
int32_t meth_jt_DecimalFormat_isParseBigDecimal(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_parseBigDecimal);
}
int32_t meth_jt_DecimalFormat_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_local_1 == teavm_this_)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jt_DecimalFormat_Cls, &supertypeof_jt_DecimalFormat))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25772, teavm_checkcast(teavm_local_1, &jt_DecimalFormat_Cls, &supertypeof_jt_DecimalFormat));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((!TEAVM_WITH_CALL_SITE_ID(25773, meth_jt_NumberFormat_equals(teavm_this_, teavm_local_1)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25774, teavm_nullCheck(teavm_local_3));
            teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_positivePrefix);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if ((!TEAVM_WITH_CALL_SITE_ID(25775, meth_ju_Arrays_equals(teavm_local_4, teavm_local_5)))) {
                goto teavm_label_3;
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix);
            teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_positiveSuffix);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if ((!TEAVM_WITH_CALL_SITE_ID(25776, meth_ju_Arrays_equals(teavm_local_4, teavm_local_5)))) {
                goto teavm_label_3;
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix);
            teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_negativePrefix);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if ((!TEAVM_WITH_CALL_SITE_ID(25777, meth_ju_Arrays_equals(teavm_local_4, teavm_local_5)))) {
                goto teavm_label_3;
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix);
            teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_negativeSuffix);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if ((!TEAVM_WITH_CALL_SITE_ID(25778, meth_ju_Arrays_equals(teavm_local_4, teavm_local_5)))) {
                goto teavm_label_3;
            }
            if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_multiplier))) {
                goto teavm_label_3;
            }
            if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) != TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_groupingSize))) {
                goto teavm_label_3;
            }
            if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_decimalSeparatorAlwaysShown) != TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_decimalSeparatorAlwaysShown))) {
                goto teavm_label_3;
            }
            if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_parseBigDecimal) != TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_parseBigDecimal))) {
                goto teavm_label_3;
            }
            if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits) == TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat, fld_exponentDigits))) {
                goto teavm_label_2;
            }
        teavm_label_3:;
            teavm_local_2 = INT32_C(0);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(1);
        teavm_label_1:;
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DecimalFormat_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25779, meth_jt_NumberFormat_hashCode(teavm_this_));
    teavm_local_2 = (teavm_local_1 * INT32_C(31));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(25780, meth_ju_Arrays_hashCode(teavm_local_3)));
    teavm_local_2 = (teavm_local_2 * INT32_C(31));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(25781, meth_ju_Arrays_hashCode(teavm_local_3)));
    teavm_local_2 = (teavm_local_2 * INT32_C(31));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(25782, meth_ju_Arrays_hashCode(teavm_local_3)));
    teavm_local_2 = (teavm_local_2 * INT32_C(31));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(25783, meth_ju_Arrays_hashCode(teavm_local_3)));
    teavm_local_2 = ((teavm_local_2 * INT32_C(31)) + TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier));
    teavm_local_2 = ((teavm_local_2 * INT32_C(31)) + TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize));
    teavm_local_2 = ((teavm_local_2 * INT32_C(31)) + ((!TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_decimalSeparatorAlwaysShown)) ? INT32_C(0) : INT32_C(1)));
    teavm_local_2 = ((teavm_local_2 * INT32_C(31)) + ((!TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_parseBigDecimal)) ? INT32_C(0) : INT32_C(1)));
    teavm_local_2 = ((teavm_local_2 * INT32_C(31)) + TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = ((!TEAVM_WITH_CALL_SITE_ID(25784, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isParseBigDecimal)(teavm_this_))) ? TEAVM_WITH_CALL_SITE_ID(25785, meth_jt_DecimalFormat_parseNumber(teavm_this_, teavm_local_1, teavm_local_2)) : TEAVM_WITH_CALL_SITE_ID(25786, meth_jt_DecimalFormat_parseBigDecimal(teavm_this_, teavm_local_1, teavm_local_2)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_DecimalFormat_parseBigDecimal(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    void* teavm_local_13;
    void* teavm_local_14;
    int32_t teavm_local_15;
    void* teavm_local_16;
    void* teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    void* teavm_local_20;
    int64_t teavm_local_21;
    int32_t teavm_local_22;
    int32_t teavm_local_23;
    int32_t teavm_local_24;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_WITH_CALL_SITE_ID(25787, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_3 = sfld_jm_BigInteger_ZERO;
    teavm_local_4 = INT32_C(0);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25788, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25789, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    teavm_local_6 = INT32_C(0);
    teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25790, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25791, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getExponentSeparator)(teavm_tmp_ptr_0)));
    teavm_local_9 = INT32_C(0);
    teavm_local_10 = INT32_C(0);
    teavm_local_11 = INT32_C(0);
    teavm_local_12 = INT32_C(1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(25792, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getNegativePrefix)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_13);
    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(25793, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getPositivePrefix)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(5), teavm_local_14);
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(25794, teavm_nullCheck(teavm_local_13));
    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(25795, meth_jl_String_length(teavm_local_13));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25796, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if (TEAVM_WITH_CALL_SITE_ID(25797, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_5, teavm_local_13, INT32_C(0), teavm_local_15))) {
        teavm_local_12 = INT32_C(0);
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        teavm_local_15 = (teavm_local_5 + TEAVM_WITH_CALL_SITE_ID(25798, meth_jl_String_length(teavm_local_13)));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(25799, teavm_nullCheck(teavm_local_14));
        if ((!TEAVM_WITH_CALL_SITE_ID(25800, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_5, teavm_local_14, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25801, meth_jl_String_length(teavm_local_14)))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(5));
            TEAVM_WITH_CALL_SITE_ID(25802, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_5));
            teavm_local_16 = NULL;
            goto teavm_label_1;
        }
        teavm_local_15 = (teavm_local_5 + TEAVM_WITH_CALL_SITE_ID(25803, meth_jl_String_length(teavm_local_14)));
    }
    if ((!teavm_local_12)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(25804, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getNegativeSuffix)(teavm_this_));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(25805, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getPositiveSuffix)(teavm_this_));
    }
    if ((teavm_local_17 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(25806, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getPositiveSuffix)(teavm_this_));
    }
    while (1) {
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_17);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(5));
        if ((teavm_local_15 >= TEAVM_WITH_CALL_SITE_ID(25807, meth_jl_String_length(teavm_local_1)))) {
            goto teavm_label_6;
        }
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(25808, meth_jl_String_charAt(teavm_local_1, teavm_local_15));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(5), teavm_local_7);
        teavm_local_19 = (teavm_local_18 - TEAVM_WITH_CALL_SITE_ID(25809, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25810, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getZeroDigit)(teavm_tmp_ptr_0))));
        if (((teavm_local_19 >= INT32_C(0)) && (teavm_local_19 <= INT32_C(9)))) {
            if (teavm_local_11) {
                teavm_local_10 = (teavm_local_10 + INT32_C(1));
            } else {
                teavm_local_9 = (teavm_local_9 + INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(5));
                teavm_local_6 = ((!(TEAVM_WITH_CALL_SITE_ID(25811, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(1)))) ? INT32_C(0) : INT32_C(1));
            }
            teavm_local_20 = sfld_jm_BigInteger_TEN;
            TEAVM_GC_ROOT(INT32_C(5), teavm_local_20);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(25812, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25813, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_20)));
            teavm_local_21 = ((int64_t) teavm_local_19);
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_7);
            TEAVM_GC_ROOT_RELEASE(INT32_C(5));
            teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(25814, meth_jm_BigInteger_valueOf(teavm_local_21));
            TEAVM_GC_ROOT(INT32_C(5), teavm_local_20);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25815, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25816, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_20)));
            teavm_local_15 = (teavm_local_15 + INT32_C(1));
        } else {
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(5), teavm_local_7);
            if ((teavm_local_18 == TEAVM_WITH_CALL_SITE_ID(25817, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25818, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0))))) {
                if (teavm_local_11) {
                    goto teavm_label_4;
                }
                if ((teavm_local_9 < INT32_C(1))) {
                    goto teavm_label_7;
                }
                teavm_local_11 = INT32_C(1);
                teavm_local_6 = INT32_C(0);
                teavm_local_15 = (teavm_local_15 + INT32_C(1));
            } else {
                teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
                TEAVM_GC_ROOT(INT32_C(5), teavm_local_7);
                if ((teavm_local_18 != TEAVM_WITH_CALL_SITE_ID(25819, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25820, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0))))) {
                    goto teavm_label_3;
                }
                if ((!teavm_local_6)) {
                    goto teavm_label_5;
                }
                teavm_local_6 = INT32_C(0);
                teavm_local_15 = (teavm_local_15 + INT32_C(1));
            }
        }
    }
teavm_label_7:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_WITH_CALL_SITE_ID(25821, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_15));
    teavm_local_16 = NULL;
    goto teavm_label_1;
teavm_label_6:;
    goto teavm_label_2;
teavm_label_5:;
    goto teavm_label_2;
teavm_label_4:;
    goto teavm_label_2;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25822, teavm_nullCheck(teavm_local_8));
    if ((TEAVM_WITH_CALL_SITE_ID(25823, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_15, teavm_local_8, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25824, meth_jl_String_length(teavm_local_8)))) && TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits))) {
        teavm_local_15 = (teavm_local_15 + TEAVM_WITH_CALL_SITE_ID(25825, meth_jl_String_length(teavm_local_8)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((teavm_local_15 == TEAVM_WITH_CALL_SITE_ID(25826, meth_jl_String_length(teavm_local_1)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(25827, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_15));
            teavm_local_16 = NULL;
            goto teavm_label_1;
        }
        teavm_local_22 = INT32_C(1);
        teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(25828, meth_jl_String_charAt(teavm_local_1, teavm_local_15));
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
        if ((teavm_local_23 == TEAVM_WITH_CALL_SITE_ID(25829, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25830, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getMinusSign)(teavm_tmp_ptr_0))))) {
            teavm_local_22 = INT32_C(0);
            teavm_local_15 = (teavm_local_15 + INT32_C(1));
        }
        teavm_local_24 = INT32_C(0);
        while (1) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            if ((teavm_local_15 >= TEAVM_WITH_CALL_SITE_ID(25831, meth_jl_String_length(teavm_local_1)))) {
                goto teavm_label_8;
            }
            teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(25832, meth_jl_String_charAt(teavm_local_1, teavm_local_15));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            teavm_local_23 = (teavm_local_23 - TEAVM_WITH_CALL_SITE_ID(25833, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25834, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getZeroDigit)(teavm_tmp_ptr_0))));
            if ((teavm_local_23 < INT32_C(0))) {
                goto teavm_label_8;
            }
            if ((teavm_local_23 > INT32_C(9))) {
                goto teavm_label_9;
            }
            teavm_local_4 = ((teavm_local_4 * INT32_C(10)) + teavm_local_23);
            teavm_local_24 = (teavm_local_24 + INT32_C(1));
            teavm_local_15 = (teavm_local_15 + INT32_C(1));
        }
    teavm_label_9:;
    teavm_label_8:;
        if ((!teavm_local_24)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(25835, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_15));
            teavm_local_16 = NULL;
            goto teavm_label_1;
        }
        if ((!teavm_local_22)) {
            teavm_local_4 = (-teavm_local_4);
        }
    }
teavm_label_2:;
    if (((!teavm_local_10) && teavm_local_11)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((!TEAVM_WITH_CALL_SITE_ID(25836, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isDecimalSeparatorAlwaysShown)(teavm_this_)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(25837, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_15));
            teavm_local_16 = NULL;
            goto teavm_label_1;
        }
    }
    if ((teavm_local_17 != NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((!TEAVM_WITH_CALL_SITE_ID(25838, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_15, teavm_local_17, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25839, meth_jl_String_length(teavm_local_17)))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(25840, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_15));
            teavm_local_16 = NULL;
            goto teavm_label_1;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(25841, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_15));
    teavm_local_23 = (teavm_local_4 - teavm_local_10);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(25842, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
    teavm_local_23 = (-teavm_local_23);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_16);
    TEAVM_WITH_CALL_SITE_ID(25843, meth_jm_BigDecimal__init_(teavm_local_16, teavm_local_3, teavm_local_23));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != INT32_C(1))) {
        teavm_local_21 = ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(25844, meth_jm_BigDecimal_valueOf(teavm_local_21));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(25845, TEAVM_METHOD(teavm_local_16, jm_BigDecimal_VT, virt_divide_0)(teavm_local_16, teavm_local_7));
    }
    if ((!teavm_local_12)) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_16);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(25846, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25847, teavm_nullCheck(teavm_local_16))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigDecimal_VT, virt_negate_0)(teavm_tmp_ptr_0)));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_16;
}
void* meth_jt_DecimalFormat_parseNumber(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int64_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    void* teavm_local_14;
    void* teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    void* teavm_local_18;
    void* teavm_local_19;
    int32_t teavm_local_20;
    int32_t teavm_local_21;
    double teavm_local_22;
    int32_t teavm_local_23;
    int32_t teavm_local_24;
    int64_t teavm_local_25;
    int64_t teavm_local_26;
    int32_t teavm_local_27;
    int32_t teavm_local_28;
    int32_t teavm_local_29;
    TeaVM_Array* teavm_local_30;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(6));
    teavm_local_3 = INT64_C(0);
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(25848, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(25849, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_getIndex)(teavm_local_2));
    teavm_local_7 = INT32_C(0);
    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(25850, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25851, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getExponentSeparator)(teavm_tmp_ptr_0)));
    teavm_local_10 = INT32_C(0);
    teavm_local_11 = INT32_C(0);
    teavm_local_12 = INT32_C(0);
    teavm_local_13 = INT32_C(1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(25852, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getNegativePrefix)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(25853, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getPositivePrefix)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_15);
    teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(25854, teavm_nullCheck(teavm_local_14));
    teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(25855, meth_jl_String_length(teavm_local_14));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25856, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if (TEAVM_WITH_CALL_SITE_ID(25857, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_6, teavm_local_14, INT32_C(0), teavm_local_16))) {
        teavm_local_13 = INT32_C(0);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_17 = (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(25858, meth_jl_String_length(teavm_local_14)));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(25859, teavm_nullCheck(teavm_local_15));
        if ((!TEAVM_WITH_CALL_SITE_ID(25860, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_6, teavm_local_15, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25861, meth_jl_String_length(teavm_local_15)))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            TEAVM_WITH_CALL_SITE_ID(25862, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_6));
            teavm_local_8 = NULL;
            goto teavm_label_1;
        }
        teavm_local_17 = (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(25863, meth_jl_String_length(teavm_local_15)));
    }
    if ((!teavm_local_13)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(25864, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getNegativeSuffix)(teavm_this_));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(25865, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getPositiveSuffix)(teavm_this_));
    }
    if ((teavm_local_18 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(25866, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getPositiveSuffix)(teavm_this_));
    }
    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_18);
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_8);
    teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(25867, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25868, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getInfinity)(teavm_tmp_ptr_0)));
    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_19);
    TEAVM_GC_ROOT(INT32_C(5), teavm_local_8);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25869, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25870, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getInfinity)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(5), teavm_local_8);
    teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(25871, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(25872, teavm_nullCheck(teavm_local_8))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    if (TEAVM_WITH_CALL_SITE_ID(25873, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_17, teavm_local_19, INT32_C(0), teavm_local_20))) {
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25874, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25875, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getInfinity)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        teavm_local_21 = (teavm_local_17 + TEAVM_WITH_CALL_SITE_ID(25876, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(25877, teavm_nullCheck(teavm_local_8)))));
        if ((teavm_local_18 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((!TEAVM_WITH_CALL_SITE_ID(25878, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_21, teavm_local_18, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25879, meth_jl_String_length(teavm_local_18)))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_WITH_CALL_SITE_ID(25880, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_21));
                teavm_local_8 = NULL;
                goto teavm_label_1;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(25881, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_21));
        teavm_local_22 = ((!teavm_local_13) ? -INFINITY : INFINITY);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25882, meth_jl_Double_valueOf_0(teavm_local_22));
    } else {
        while (1) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            if ((teavm_local_17 >= TEAVM_WITH_CALL_SITE_ID(25883, meth_jl_String_length(teavm_local_1)))) {
                goto teavm_label_6;
            }
            teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(25884, meth_jl_String_charAt(teavm_local_1, teavm_local_17));
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(4), teavm_local_8);
            teavm_local_24 = (teavm_local_23 - TEAVM_WITH_CALL_SITE_ID(25885, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25886, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getZeroDigit)(teavm_tmp_ptr_0))));
            if (((teavm_local_24 >= INT32_C(0)) && (teavm_local_24 <= INT32_C(9)))) {
                if (teavm_local_12) {
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                } else {
                    teavm_local_10 = (teavm_local_10 + INT32_C(1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
                    teavm_local_7 = ((!(TEAVM_WITH_CALL_SITE_ID(25887, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && (TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(1)))) ? INT32_C(0) : INT32_C(1));
                }
                if ((teavm_local_3 <= INT64_C(922337203685477580))) {
                    teavm_local_25 = (teavm_local_3 * INT64_C(10));
                    teavm_local_26 = ((int64_t) teavm_local_24);
                    if ((teavm_local_25 <= (INT64_C(9223372036854775807) - teavm_local_26))) {
                        teavm_local_3 = (teavm_local_25 + teavm_local_26);
                    } else {
                        teavm_local_4 = (teavm_local_4 + INT32_C(1));
                    }
                } else {
                    if (((!teavm_local_4) && (teavm_local_24 > INT32_C(5)))) {
                        teavm_local_3 = (teavm_local_3 + INT64_C(1));
                    }
                    teavm_local_4 = (teavm_local_4 + INT32_C(1));
                }
                teavm_local_17 = (teavm_local_17 + INT32_C(1));
            } else {
                teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
                TEAVM_GC_ROOT(INT32_C(4), teavm_local_8);
                if ((teavm_local_23 == TEAVM_WITH_CALL_SITE_ID(25888, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25889, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0))))) {
                    if (teavm_local_12) {
                        goto teavm_label_4;
                    }
                    if ((teavm_local_10 < INT32_C(1))) {
                        goto teavm_label_7;
                    }
                    teavm_local_12 = INT32_C(1);
                    teavm_local_7 = INT32_C(0);
                    teavm_local_17 = (teavm_local_17 + INT32_C(1));
                } else {
                    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
                    TEAVM_GC_ROOT(INT32_C(4), teavm_local_8);
                    if ((teavm_local_23 != TEAVM_WITH_CALL_SITE_ID(25890, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25891, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0))))) {
                        goto teavm_label_3;
                    }
                    if ((!teavm_local_7)) {
                        goto teavm_label_5;
                    }
                    teavm_local_7 = INT32_C(0);
                    teavm_local_17 = (teavm_local_17 + INT32_C(1));
                }
            }
        }
    teavm_label_7:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        TEAVM_WITH_CALL_SITE_ID(25892, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_17));
        teavm_local_8 = NULL;
        goto teavm_label_1;
    teavm_label_6:;
        goto teavm_label_2;
    teavm_label_5:;
        goto teavm_label_2;
    teavm_label_4:;
        goto teavm_label_2;
    teavm_label_3:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(25893, teavm_nullCheck(teavm_local_9));
        if ((TEAVM_WITH_CALL_SITE_ID(25894, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_17, teavm_local_9, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25895, meth_jl_String_length(teavm_local_9)))) && TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits))) {
            teavm_local_17 = (teavm_local_17 + TEAVM_WITH_CALL_SITE_ID(25896, meth_jl_String_length(teavm_local_9)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((teavm_local_17 == TEAVM_WITH_CALL_SITE_ID(25897, meth_jl_String_length(teavm_local_1)))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_WITH_CALL_SITE_ID(25898, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_17));
                teavm_local_8 = NULL;
                goto teavm_label_1;
            }
            teavm_local_27 = INT32_C(1);
            teavm_local_21 = TEAVM_WITH_CALL_SITE_ID(25899, meth_jl_String_charAt(teavm_local_1, teavm_local_17));
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
            if ((teavm_local_21 == TEAVM_WITH_CALL_SITE_ID(25900, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25901, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getMinusSign)(teavm_tmp_ptr_0))))) {
                teavm_local_27 = INT32_C(0);
                teavm_local_17 = (teavm_local_17 + INT32_C(1));
            }
            teavm_local_28 = INT32_C(0);
            while (1) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                if ((teavm_local_17 >= TEAVM_WITH_CALL_SITE_ID(25902, meth_jl_String_length(teavm_local_1)))) {
                    goto teavm_label_8;
                }
                teavm_local_21 = TEAVM_WITH_CALL_SITE_ID(25903, meth_jl_String_charAt(teavm_local_1, teavm_local_17));
                teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
                teavm_local_21 = (teavm_local_21 - TEAVM_WITH_CALL_SITE_ID(25904, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25905, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getZeroDigit)(teavm_tmp_ptr_0))));
                if ((teavm_local_21 < INT32_C(0))) {
                    goto teavm_label_8;
                }
                if ((teavm_local_21 > INT32_C(9))) {
                    goto teavm_label_9;
                }
                teavm_local_5 = ((teavm_local_5 * INT32_C(10)) + teavm_local_21);
                teavm_local_28 = (teavm_local_28 + INT32_C(1));
                teavm_local_17 = (teavm_local_17 + INT32_C(1));
            }
        teavm_label_9:;
        teavm_label_8:;
            if ((!teavm_local_28)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_WITH_CALL_SITE_ID(25906, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_17));
                teavm_local_8 = NULL;
                goto teavm_label_1;
            }
            if ((!teavm_local_27)) {
                teavm_local_5 = (-teavm_local_5);
            }
        }
    teavm_label_2:;
        if (((!teavm_local_11) && teavm_local_12)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((!TEAVM_WITH_CALL_SITE_ID(25907, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isDecimalSeparatorAlwaysShown)(teavm_this_)))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_WITH_CALL_SITE_ID(25908, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_17));
                teavm_local_8 = NULL;
                goto teavm_label_1;
            }
        }
        if ((teavm_local_18 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((!TEAVM_WITH_CALL_SITE_ID(25909, meth_jl_String_regionMatches_0(teavm_local_1, teavm_local_17, teavm_local_18, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(25910, meth_jl_String_length(teavm_local_18)))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_WITH_CALL_SITE_ID(25911, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_2, teavm_local_17));
                teavm_local_8 = NULL;
                goto teavm_label_1;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(25912, TEAVM_METHOD(teavm_local_2, jt_ParsePosition_VT, virt_setIndex)(teavm_local_2, teavm_local_17));
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != INT32_C(1))) {
            teavm_local_21 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_29 = TEAVM_WITH_CALL_SITE_ID(25913, meth_jt_DecimalFormat_fastLn10(teavm_this_, teavm_local_21));
            teavm_local_30 = sfld_jt_DecimalFormat_POW10_INT_ARRAY;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
            teavm_local_30 = TEAVM_WITH_CALL_SITE_ID(25914, teavm_nullCheck(teavm_local_30));
            teavm_local_29 = TEAVM_WITH_CALL_SITE_ID(25915, teavm_checkBounds(teavm_local_29, teavm_local_30));
            if ((TEAVM_ARRAY_AT(teavm_local_30, int32_t, teavm_local_29) == TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier))) {
                teavm_local_5 = (teavm_local_5 - teavm_local_29);
            } else {
                teavm_local_3 = (teavm_local_3 / ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier)));
            }
        }
        teavm_local_21 = (teavm_local_5 + (teavm_local_4 - teavm_local_11));
        if ((teavm_local_21 > INT32_C(0))) {
            teavm_local_30 = sfld_jt_DecimalFormat_POW10_ARRAY;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if ((teavm_local_21 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(25916, teavm_nullCheck(teavm_local_30))))) {
                teavm_local_30 = sfld_jt_DecimalFormat_POW10_ARRAY;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
                teavm_local_30 = TEAVM_WITH_CALL_SITE_ID(25917, teavm_nullCheck(teavm_local_30));
                teavm_local_21 = TEAVM_WITH_CALL_SITE_ID(25918, teavm_checkBounds(teavm_local_21, teavm_local_30));
                if ((teavm_local_3 >= (INT64_C(9223372036854775807) / TEAVM_ARRAY_AT(teavm_local_30, int64_t, teavm_local_21)))) {
                    goto teavm_label_10;
                }
                teavm_local_30 = sfld_jt_DecimalFormat_POW10_ARRAY;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
                teavm_local_30 = TEAVM_WITH_CALL_SITE_ID(25919, teavm_nullCheck(teavm_local_30));
                teavm_local_3 = (teavm_local_3 * TEAVM_ARRAY_AT(teavm_local_30, int64_t, TEAVM_WITH_CALL_SITE_ID(25920, teavm_checkUpperBound(teavm_local_21, teavm_local_30))));
                teavm_local_21 = INT32_C(0);
                goto teavm_label_10;
            }
        }
        if ((teavm_local_21 < INT32_C(0))) {
            teavm_local_17 = (-teavm_local_21);
            teavm_local_30 = sfld_jt_DecimalFormat_POW10_ARRAY;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if ((teavm_local_17 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(25921, teavm_nullCheck(teavm_local_30))))) {
                teavm_local_30 = sfld_jt_DecimalFormat_POW10_ARRAY;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
                teavm_local_30 = TEAVM_WITH_CALL_SITE_ID(25922, teavm_nullCheck(teavm_local_30));
                teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(25923, teavm_checkBounds(teavm_local_17, teavm_local_30));
                if (((teavm_local_3 % TEAVM_ARRAY_AT(teavm_local_30, int64_t, teavm_local_16)) == INT64_C(0))) {
                    teavm_local_30 = sfld_jt_DecimalFormat_POW10_ARRAY;
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_30);
                    teavm_local_30 = TEAVM_WITH_CALL_SITE_ID(25924, teavm_nullCheck(teavm_local_30));
                    teavm_local_3 = (teavm_local_3 / TEAVM_ARRAY_AT(teavm_local_30, int64_t, TEAVM_WITH_CALL_SITE_ID(25925, teavm_checkUpperBound(teavm_local_16, teavm_local_30))));
                    teavm_local_21 = INT32_C(0);
                }
            }
        }
    teavm_label_10:;
        teavm_local_17 = teavm_compare_i64(teavm_local_3, INT64_C(0));
        if (((!teavm_local_17) && (!teavm_local_13))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25926, meth_jl_Double_valueOf_0(-0.0));
        } else if ((!teavm_local_21)) {
            if ((!teavm_local_13)) {
                teavm_local_3 = (-teavm_local_3);
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25927, meth_jl_Long_valueOf(teavm_local_3));
        } else {
            teavm_local_21 = (teavm_local_21 + INT32_C(18));
            if (teavm_local_17) {
                while (1) {
                    if (!((teavm_local_3 / INT64_C(1000000000000000000)) == INT64_C(0))) break;
                    teavm_local_3 = (teavm_local_3 * INT64_C(10));
                    teavm_local_21 = (teavm_local_21 + -INT32_C(1));
                }
            }
            teavm_local_17 = (teavm_local_13 ? INT32_C(0) : INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25928, meth_jl_Double_valueOf_0(TEAVM_WITH_CALL_SITE_ID(25929, meth_otcit_DoubleSynthesizer_synthesizeDouble(teavm_local_3, teavm_local_21, teavm_local_17))));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_8;
}
void* meth_jt_DecimalFormat_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (teavm_instanceof(teavm_local_1, &jm_BigDecimal_Cls, &supertypeof_jm_BigDecimal)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25930, teavm_checkcast(teavm_local_1, &jm_BigDecimal_Cls, &supertypeof_jm_BigDecimal));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25931, meth_jt_DecimalFormat_format_0(teavm_this_, teavm_local_4, teavm_local_2, teavm_local_3));
    } else if ((!teavm_instanceof(teavm_local_1, &jm_BigInteger_Cls, &supertypeof_jm_BigInteger))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25932, meth_jt_NumberFormat_format(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25933, teavm_checkcast(teavm_local_1, &jm_BigInteger_Cls, &supertypeof_jm_BigInteger));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25934, meth_jt_DecimalFormat_format_1(teavm_this_, teavm_local_4, teavm_local_2, teavm_local_3));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jt_DecimalFormat_format_1(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25935, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(25936, meth_jm_BigDecimal__init__0(teavm_local_4, teavm_local_1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25937, meth_jt_DecimalFormat_format_0(teavm_this_, teavm_local_4, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jt_DecimalFormat_format_0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits) <= INT32_C(0))) {
        TEAVM_WITH_CALL_SITE_ID(25938, meth_jt_DecimalFormat_formatRegular(teavm_this_, teavm_local_1, teavm_local_2));
    } else {
        TEAVM_WITH_CALL_SITE_ID(25939, meth_jt_DecimalFormat_formatExponent(teavm_this_, teavm_local_1, teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_format_2(void* teavm_this_, int64_t teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits) <= INT32_C(0))) {
        TEAVM_WITH_CALL_SITE_ID(25940, meth_jt_DecimalFormat_formatRegular_0(teavm_this_, teavm_local_1, teavm_local_2));
    } else {
        TEAVM_WITH_CALL_SITE_ID(25941, meth_jt_DecimalFormat_formatExponent_0(teavm_this_, teavm_local_1, teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_format_3(void* teavm_this_, double teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    int64_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (isnan(teavm_local_1)) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25942, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_4, teavm_local_2));
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(25943, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25944, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getNaN)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(25945, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25946, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_22)(teavm_tmp_ptr_0, teavm_local_6)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(25947, meth_jt_DecimalFormat_appendSuffix(teavm_this_, INT32_C(1), teavm_local_2));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((!TEAVM_WITH_CALL_SITE_ID(25948, meth_jl_Double_isInfinite(teavm_local_1)))) {
            TEAVM_WITH_CALL_SITE_ID(25949, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_Constants_Cls, &initclass_jt_DecimalFormat_Constants));
            teavm_local_7 = sfld_jt_DecimalFormat_Constants_doubleAnalysisResult;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(25950, meth_otcit_DoubleAnalyzer_analyze(teavm_local_1, teavm_local_7));
            if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits) <= INT32_C(0))) {
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(25951, teavm_nullCheck(teavm_local_7));
                teavm_local_8 = TEAVM_FIELD(teavm_local_7, cls_otcit_DoubleAnalyzer_Result, fld_mantissa);
                teavm_local_9 = TEAVM_FIELD(teavm_local_7, cls_otcit_DoubleAnalyzer_Result, fld_exponent);
                teavm_local_10 = (TEAVM_FIELD(teavm_local_7, cls_otcit_DoubleAnalyzer_Result, fld_sign) ? INT32_C(0) : INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(25952, meth_jt_DecimalFormat_formatRegular_1(teavm_this_, teavm_local_8, teavm_local_9, teavm_local_10, teavm_local_2));
            } else {
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(25953, teavm_nullCheck(teavm_local_7));
                teavm_local_8 = TEAVM_FIELD(teavm_local_7, cls_otcit_DoubleAnalyzer_Result, fld_mantissa);
                teavm_local_11 = TEAVM_FIELD(teavm_local_7, cls_otcit_DoubleAnalyzer_Result, fld_exponent);
                teavm_local_9 = (TEAVM_FIELD(teavm_local_7, cls_otcit_DoubleAnalyzer_Result, fld_sign) ? INT32_C(0) : INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(25954, meth_jt_DecimalFormat_formatExponent_1(teavm_this_, teavm_local_8, teavm_local_11, teavm_local_9, teavm_local_2));
            }
        } else {
            teavm_local_11 = teavm_compare_double_less(teavm_local_1, 0.0);
            teavm_local_4 = ((teavm_local_11 <= INT32_C(0)) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) : TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25955, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_4, teavm_local_2));
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(25956, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25957, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getInfinity)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(25958, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25959, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuffer_VT, virt_append_22)(teavm_tmp_ptr_0, teavm_local_6)));
            teavm_local_9 = ((teavm_local_11 <= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(25960, meth_jt_DecimalFormat_appendSuffix(teavm_this_, teavm_local_9, teavm_local_2));
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jt_DecimalFormat_formatExponent_0(void* teavm_this_, int64_t teavm_local_1, void* teavm_local_2) {
    int64_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25961, meth_jl_Math_abs(teavm_local_1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25962, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(25963, meth_jt_DecimalFormat_formatExponent_1(teavm_this_, teavm_local_3, teavm_local_4, ((teavm_local_1 < INT64_C(0)) ? INT32_C(0) : INT32_C(1)), teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_formatRegular_0(void* teavm_this_, int64_t teavm_local_1, void* teavm_local_2) {
    int64_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(25964, meth_jl_Math_abs(teavm_local_1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25965, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(25966, meth_jt_DecimalFormat_formatRegular_1(teavm_this_, teavm_local_3, teavm_local_4, ((teavm_local_1 < INT64_C(0)) ? INT32_C(0) : INT32_C(1)), teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_formatExponent_1(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    int64_t teavm_local_20;
    int32_t teavm_local_21;
    int32_t teavm_local_22;
    int32_t teavm_local_23;
    int32_t teavm_local_24;
    int32_t teavm_local_25;
    int32_t teavm_local_26;
    int32_t teavm_local_27;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25967, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_1));
    teavm_local_6 = (teavm_local_5 + INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != INT32_C(1))) {
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(25968, meth_jt_DecimalFormat_fastLn10(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier)));
        teavm_local_8 = sfld_jt_DecimalFormat_POW10_INT_ARRAY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25969, teavm_nullCheck(teavm_local_8));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(25970, teavm_checkBounds(teavm_local_7, teavm_local_8));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7);
        if ((teavm_local_9 == TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier))) {
            teavm_local_2 = (teavm_local_2 + teavm_local_7);
        } else {
            if ((teavm_local_1 >= (INT64_C(9223372036854775807) / ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(25971, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(25972, meth_jm_BigInteger_valueOf(teavm_local_1));
                teavm_local_12 = (teavm_local_5 - teavm_local_2);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
                TEAVM_WITH_CALL_SITE_ID(25973, meth_jm_BigDecimal__init_(teavm_local_10, teavm_local_11, teavm_local_12));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(25974, meth_jt_DecimalFormat_formatExponent(teavm_this_, teavm_local_10, teavm_local_4));
                goto teavm_label_1;
            }
            teavm_local_1 = (teavm_local_1 * ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(25975, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_1));
            teavm_local_6 = (teavm_local_5 + INT32_C(1));
        }
    }
    teavm_local_13 = (TEAVM_WITH_CALL_SITE_ID(25976, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) + TEAVM_WITH_CALL_SITE_ID(25977, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)));
    teavm_local_14 = ((TEAVM_WITH_CALL_SITE_ID(25978, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumIntegerDigits)(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(25979, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_))) + INT32_C(1));
    if ((teavm_local_14 > INT32_C(1))) {
        teavm_local_15 = (teavm_local_2 - ((teavm_local_2 / teavm_local_14) * teavm_local_14));
        teavm_local_12 = (teavm_local_2 - teavm_local_15);
        teavm_local_16 = (teavm_local_5 - teavm_local_15);
    } else {
        teavm_local_12 = (teavm_local_2 - (TEAVM_WITH_CALL_SITE_ID(25980, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) - INT32_C(1)));
        teavm_local_16 = (teavm_local_5 - (TEAVM_WITH_CALL_SITE_ID(25981, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) - INT32_C(1)));
    }
    if ((teavm_local_13 < INT32_C(0))) {
        teavm_local_1 = INT64_C(0);
    } else if ((teavm_local_13 < teavm_local_6)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(25982, meth_jt_DecimalFormat_applyRounding(teavm_this_, teavm_local_1, teavm_local_6, teavm_local_13, teavm_local_3));
        teavm_local_17 = (TEAVM_WITH_CALL_SITE_ID(25983, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_1)) + INT32_C(1));
        if ((teavm_local_17 > teavm_local_6)) {
            teavm_local_12 = (teavm_local_12 + INT32_C(1));
            teavm_local_16 = (teavm_local_16 + INT32_C(1));
            teavm_local_6 = teavm_local_17;
        }
    }
    teavm_local_8 = ((!teavm_local_3) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) : TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(25984, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_8, teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(25985, meth_jl_Math_max(teavm_local_16, INT32_C(0)));
    teavm_local_19 = (teavm_local_6 - INT32_C(1));
    while (1) {
        if (!(teavm_local_19 >= teavm_local_18)) break;
        teavm_local_8 = sfld_jt_DecimalFormat_POW10_ARRAY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(25986, teavm_nullCheck(teavm_local_8));
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(25987, teavm_checkBounds(teavm_local_19, teavm_local_8));
        teavm_local_20 = TEAVM_ARRAY_AT(teavm_local_8, int64_t, teavm_local_19);
        teavm_local_21 = ((int32_t) (teavm_local_1 / teavm_local_20));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_21 = TEAVM_WITH_CALL_SITE_ID(25988, meth_jt_DecimalFormat_forDigit(teavm_this_, teavm_local_21));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25989, teavm_nullCheck(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(25990, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_21));
        teavm_local_1 = (teavm_local_1 % teavm_local_20);
        teavm_local_19 = (teavm_local_19 + -INT32_C(1));
    }
    teavm_local_19 = (teavm_local_18 - INT32_C(1));
    while (1) {
        if (!(teavm_local_19 >= teavm_local_16)) break;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25991, teavm_nullCheck(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(25992, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
        teavm_local_19 = (teavm_local_19 + -INT32_C(1));
    }
    teavm_local_21 = (teavm_local_13 - (teavm_local_6 - teavm_local_16));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_22 = (teavm_local_21 - (TEAVM_WITH_CALL_SITE_ID(25993, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(25994, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_))));
    if ((teavm_local_22 <= INT32_C(0))) {
        if ((teavm_local_1 == INT64_C(0))) {
            goto teavm_label_4;
        }
        if ((teavm_local_21 <= INT32_C(0))) {
            goto teavm_label_4;
        }
    }
    teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(25995, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(25996, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(25997, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(25998, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_23));
    teavm_local_24 = TEAVM_WITH_CALL_SITE_ID(25999, meth_jl_Math_max(INT32_C(0), (teavm_local_16 - teavm_local_21)));
    teavm_local_25 = INT32_C(0);
    teavm_local_19 = (teavm_local_16 - INT32_C(1));
    while (1) {
        if (!(teavm_local_19 >= teavm_local_24)) break;
        teavm_local_8 = sfld_jt_DecimalFormat_POW10_ARRAY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26000, teavm_nullCheck(teavm_local_8));
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26001, teavm_checkBounds(teavm_local_19, teavm_local_8));
        teavm_local_20 = TEAVM_ARRAY_AT(teavm_local_8, int64_t, teavm_local_19);
        teavm_local_16 = ((int32_t) (teavm_local_1 / teavm_local_20));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(26002, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, TEAVM_WITH_CALL_SITE_ID(26003, meth_jt_DecimalFormat_forDigit(teavm_this_, teavm_local_16))));
        teavm_local_1 = (teavm_local_1 % teavm_local_20);
        teavm_local_25 = (teavm_local_25 + INT32_C(1));
        if ((teavm_local_1 == INT64_C(0))) {
            goto teavm_label_6;
        }
        teavm_local_19 = (teavm_local_19 + -INT32_C(1));
    }
    goto teavm_label_5;
teavm_label_6:;
teavm_label_5:;
    while (1) {
        teavm_local_16 = (teavm_local_25 + INT32_C(1));
        if ((teavm_local_25 >= teavm_local_22)) {
            goto teavm_label_8;
        }
        TEAVM_WITH_CALL_SITE_ID(26004, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
        teavm_local_25 = teavm_local_16;
    }
teavm_label_8:;
teavm_label_4:;
    teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26005, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26006, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getExponentSeparator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26007, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(26008, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_22)(teavm_local_4, teavm_local_10));
    if ((teavm_local_12 < INT32_C(0))) {
        teavm_local_12 = (-teavm_local_12);
        teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(26009, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26010, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getMinusSign)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(26011, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_16));
    }
    teavm_local_16 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_26 = TEAVM_WITH_CALL_SITE_ID(26012, meth_jl_Math_max(teavm_local_16, (TEAVM_WITH_CALL_SITE_ID(26013, meth_jt_DecimalFormat_fastLn10(teavm_this_, teavm_local_12)) + INT32_C(1))));
    teavm_local_19 = (teavm_local_26 - INT32_C(1));
    while (1) {
        if (!(teavm_local_19 >= INT32_C(0))) break;
        teavm_local_8 = sfld_jt_DecimalFormat_POW10_INT_ARRAY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26014, teavm_nullCheck(teavm_local_8));
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26015, teavm_checkBounds(teavm_local_19, teavm_local_8));
        teavm_local_27 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_19);
        teavm_local_16 = (teavm_local_12 / teavm_local_27);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(26016, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, TEAVM_WITH_CALL_SITE_ID(26017, meth_jt_DecimalFormat_forDigit(teavm_this_, teavm_local_16))));
        teavm_local_12 = (teavm_local_12 % teavm_local_27);
        teavm_local_19 = (teavm_local_19 + -INT32_C(1));
    }
    TEAVM_WITH_CALL_SITE_ID(26018, meth_jt_DecimalFormat_appendSuffix(teavm_this_, teavm_local_3, teavm_local_4));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_formatRegular_1(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    int32_t teavm_local_20;
    int64_t teavm_local_21;
    int32_t teavm_local_22;
    int32_t teavm_local_23;
    int32_t teavm_local_24;
    int32_t teavm_local_25;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = (TEAVM_WITH_CALL_SITE_ID(26019, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_1)) + INT32_C(1));
    teavm_local_6 = (teavm_local_2 + INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != INT32_C(1))) {
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26020, meth_jt_DecimalFormat_fastLn10(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier)));
        teavm_local_8 = sfld_jt_DecimalFormat_POW10_INT_ARRAY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26021, teavm_nullCheck(teavm_local_8));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26022, teavm_checkBounds(teavm_local_7, teavm_local_8));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7);
        if ((teavm_local_9 == TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier))) {
            teavm_local_6 = (teavm_local_6 + teavm_local_7);
        } else {
            if ((teavm_local_1 >= (INT64_C(9223372036854775807) / ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26023, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(26024, meth_jm_BigInteger_valueOf(teavm_local_1));
                teavm_local_12 = (teavm_local_5 - teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
                TEAVM_WITH_CALL_SITE_ID(26025, meth_jm_BigDecimal__init_(teavm_local_10, teavm_local_11, teavm_local_12));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(26026, meth_jt_DecimalFormat_formatRegular(teavm_this_, teavm_local_10, teavm_local_4));
                goto teavm_label_1;
            }
            teavm_local_1 = (teavm_local_1 * ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = (TEAVM_WITH_CALL_SITE_ID(26027, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_1)) + INT32_C(1));
        }
    }
    teavm_local_13 = (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(26028, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)));
    if ((teavm_local_13 < INT32_C(0))) {
        teavm_local_1 = INT64_C(0);
    } else if ((teavm_local_13 < teavm_local_5)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26029, meth_jt_DecimalFormat_applyRounding(teavm_this_, teavm_local_1, teavm_local_5, teavm_local_13, teavm_local_3));
        teavm_local_14 = (TEAVM_WITH_CALL_SITE_ID(26030, meth_jt_DecimalFormat_fastLn10_0(teavm_this_, teavm_local_1)) + INT32_C(1));
        if ((teavm_local_14 > teavm_local_5)) {
            teavm_local_6 = (teavm_local_6 + INT32_C(1));
            teavm_local_5 = teavm_local_14;
        }
    }
    teavm_local_8 = ((!teavm_local_3) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) : TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(26031, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_8, teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26032, meth_jl_Math_max(INT32_C(0), teavm_local_6));
    teavm_local_16 = (TEAVM_WITH_CALL_SITE_ID(26033, meth_jl_Math_max(teavm_local_15, TEAVM_WITH_CALL_SITE_ID(26034, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)))) - INT32_C(1));
    teavm_local_17 = (TEAVM_WITH_CALL_SITE_ID(26035, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) - INT32_C(1));
    while (1) {
        if (!(teavm_local_17 >= teavm_local_15)) break;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26036, teavm_nullCheck(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(26037, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
        if ((TEAVM_WITH_CALL_SITE_ID(26038, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(0)) && ((!(teavm_local_16 % TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize))) && (teavm_local_16 > INT32_C(0)))))) {
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(26039, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26040, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(26041, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_12));
        }
        teavm_local_16 = (teavm_local_16 + -INT32_C(1));
        teavm_local_17 = (teavm_local_17 + -INT32_C(1));
    }
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26042, meth_jl_Math_min(teavm_local_5, teavm_local_15));
    teavm_local_19 = (teavm_local_5 - INT32_C(1));
    teavm_local_17 = INT32_C(0);
    while (1) {
        if (!(teavm_local_17 < teavm_local_18)) break;
        teavm_local_8 = sfld_jt_DecimalFormat_POW10_ARRAY;
        teavm_local_20 = (teavm_local_19 + -INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26043, teavm_nullCheck(teavm_local_8));
        teavm_local_21 = TEAVM_ARRAY_AT(teavm_local_8, int64_t, TEAVM_WITH_CALL_SITE_ID(26044, teavm_checkBounds(teavm_local_19, teavm_local_8)));
        teavm_local_22 = ((int32_t) (teavm_local_1 / teavm_local_21));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(26045, meth_jt_DecimalFormat_forDigit(teavm_this_, TEAVM_WITH_CALL_SITE_ID(26046, meth_jl_Math_abs_0(teavm_local_22))));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26047, teavm_nullCheck(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(26048, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_12));
        teavm_local_1 = (teavm_local_1 % teavm_local_21);
        if ((TEAVM_WITH_CALL_SITE_ID(26049, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(0)) && ((!(teavm_local_16 % TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize))) && (teavm_local_16 > INT32_C(0)))))) {
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_22 = TEAVM_WITH_CALL_SITE_ID(26050, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26051, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(26052, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_22));
        }
        teavm_local_16 = (teavm_local_16 + -INT32_C(1));
        teavm_local_17 = (teavm_local_17 + INT32_C(1));
        teavm_local_19 = teavm_local_20;
    }
    teavm_local_12 = (teavm_local_15 - teavm_local_18);
    teavm_local_17 = INT32_C(0);
    while (1) {
        if (!(teavm_local_17 < teavm_local_12)) break;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26053, teavm_nullCheck(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(26054, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
        if ((TEAVM_WITH_CALL_SITE_ID(26055, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(0)) && ((!(teavm_local_16 % TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize))) && (teavm_local_16 > INT32_C(0)))))) {
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_22 = TEAVM_WITH_CALL_SITE_ID(26056, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26057, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(26058, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_22));
        }
        teavm_local_16 = (teavm_local_16 + -INT32_C(1));
        teavm_local_17 = (teavm_local_17 + INT32_C(1));
    }
    if ((teavm_local_1 == INT64_C(0))) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        if (TEAVM_WITH_CALL_SITE_ID(26059, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_))) {
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(26060, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26061, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26062, teavm_nullCheck(teavm_local_4));
            TEAVM_WITH_CALL_SITE_ID(26063, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_12));
            teavm_local_17 = INT32_C(0);
            while (1) {
                if (!(teavm_local_17 < TEAVM_WITH_CALL_SITE_ID(26064, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_)))) break;
                TEAVM_WITH_CALL_SITE_ID(26065, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
                teavm_local_17 = (teavm_local_17 + INT32_C(1));
            }
        } else if (TEAVM_WITH_CALL_SITE_ID(26066, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isDecimalSeparatorAlwaysShown)(teavm_this_))) {
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(26067, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26068, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26069, teavm_nullCheck(teavm_local_4));
            TEAVM_WITH_CALL_SITE_ID(26070, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_12));
        }
    } else {
        teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(26071, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26072, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26073, teavm_nullCheck(teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(26074, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, teavm_local_12));
        teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(26075, meth_jl_Math_min(TEAVM_WITH_CALL_SITE_ID(26076, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)), TEAVM_WITH_CALL_SITE_ID(26077, meth_jl_Math_max(INT32_C(0), (-teavm_local_6)))));
        teavm_local_17 = INT32_C(0);
        teavm_local_24 = INT32_C(0);
        while (1) {
            if (!(teavm_local_24 < teavm_local_23)) break;
            teavm_local_17 = (teavm_local_17 + INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(26078, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
            teavm_local_24 = (teavm_local_24 + INT32_C(1));
        }
        teavm_local_25 = TEAVM_WITH_CALL_SITE_ID(26079, meth_jl_Math_min((TEAVM_WITH_CALL_SITE_ID(26080, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)) - teavm_local_17), teavm_local_19));
        teavm_local_24 = INT32_C(0);
        while (1) {
            if ((teavm_local_24 >= teavm_local_25)) {
                goto teavm_label_7;
            }
            if ((teavm_local_1 == INT64_C(0))) {
                goto teavm_label_8;
            }
            teavm_local_17 = (teavm_local_17 + INT32_C(1));
            teavm_local_8 = sfld_jt_DecimalFormat_POW10_ARRAY;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26081, teavm_nullCheck(teavm_local_8));
            teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(26082, teavm_checkBounds(teavm_local_19, teavm_local_8));
            teavm_local_21 = TEAVM_ARRAY_AT(teavm_local_8, int64_t, teavm_local_20);
            teavm_local_12 = ((int32_t) (teavm_local_1 / teavm_local_21));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(26083, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, TEAVM_WITH_CALL_SITE_ID(26084, meth_jt_DecimalFormat_forDigit(teavm_this_, TEAVM_WITH_CALL_SITE_ID(26085, meth_jl_Math_abs_0(teavm_local_12))))));
            teavm_local_1 = (teavm_local_1 % teavm_local_21);
            teavm_local_19 = (teavm_local_20 + -INT32_C(1));
            teavm_local_24 = (teavm_local_24 + INT32_C(1));
        }
    teavm_label_8:;
    teavm_label_7:;
        while (1) {
            if (!(teavm_local_17 < TEAVM_WITH_CALL_SITE_ID(26086, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_)))) break;
            TEAVM_WITH_CALL_SITE_ID(26087, TEAVM_METHOD(teavm_local_4, jl_StringBuffer_VT, virt_append_3)(teavm_local_4, INT32_C(48)));
            teavm_local_17 = (teavm_local_17 + INT32_C(1));
        }
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(26088, meth_jt_DecimalFormat_appendSuffix(teavm_this_, teavm_local_3, teavm_local_4));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_formatExponent(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int64_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    TeaVM_Array* teavm_local_16;
    int32_t teavm_local_17;
    void* teavm_local_18;
    TeaVM_Array* teavm_local_19;
    int32_t teavm_local_20;
    int32_t teavm_local_21;
    int32_t teavm_local_22;
    int32_t teavm_local_23;
    int32_t teavm_local_24;
    int32_t teavm_local_25;
    int32_t teavm_local_26;
    int32_t teavm_local_27;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != INT32_C(1))) {
        teavm_local_3 = ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26089, meth_jm_BigDecimal_valueOf(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26090, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26091, TEAVM_METHOD(teavm_local_1, jm_BigDecimal_VT, virt_multiply_0)(teavm_local_1, teavm_local_4));
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(26092, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    teavm_local_4 = sfld_jm_BigDecimal_ZERO;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26093, teavm_nullCheck(teavm_local_1));
    teavm_local_6 = ((TEAVM_WITH_CALL_SITE_ID(26094, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_compareTo_8)(teavm_local_5, teavm_local_4)) < INT32_C(0)) ? INT32_C(0) : INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26095, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_precision)(teavm_local_5));
    teavm_local_8 = (teavm_local_7 - INT32_C(1));
    teavm_local_9 = (teavm_local_8 - TEAVM_WITH_CALL_SITE_ID(26096, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_scale)(teavm_local_5)));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26097, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_unscaledValue)(teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    teavm_local_11 = (TEAVM_WITH_CALL_SITE_ID(26098, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) + TEAVM_WITH_CALL_SITE_ID(26099, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)));
    teavm_local_12 = ((TEAVM_WITH_CALL_SITE_ID(26100, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumIntegerDigits)(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(26101, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_))) + INT32_C(1));
    if ((teavm_local_12 > INT32_C(1))) {
        teavm_local_13 = (teavm_local_9 - ((teavm_local_9 / teavm_local_12) * teavm_local_12));
        teavm_local_14 = (teavm_local_9 - teavm_local_13);
        teavm_local_15 = (teavm_local_8 - teavm_local_13);
    } else {
        teavm_local_14 = (teavm_local_9 - (TEAVM_WITH_CALL_SITE_ID(26102, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) - INT32_C(1)));
        teavm_local_15 = (teavm_local_8 - (TEAVM_WITH_CALL_SITE_ID(26103, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) - INT32_C(1)));
    }
    if ((teavm_local_11 < INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(26104, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
        teavm_local_10 = sfld_jm_BigInteger_ZERO;
    } else if ((teavm_local_11 < teavm_local_7)) {
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26105, meth_jt_DecimalFormat_applyRounding_0(teavm_this_, teavm_local_10, teavm_local_7, teavm_local_11));
    }
    teavm_local_16 = ((!teavm_local_6) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) : TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_16);
    TEAVM_WITH_CALL_SITE_ID(26106, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_16, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(26107, meth_jl_Math_max(teavm_local_15, INT32_C(0)));
    TEAVM_WITH_CALL_SITE_ID(26108, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_4 = sfld_jm_BigInteger_ONE;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26109, meth_jt_DecimalFormat_pow10(teavm_this_, teavm_local_4, teavm_local_8));
    while (1) {
        if (!(teavm_local_8 >= teavm_local_17)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26110, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26111, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divideAndRemainder)(teavm_tmp_ptr_0, teavm_local_18)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_19);
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26112, teavm_nullCheck(teavm_local_19));
        teavm_local_16 = teavm_local_19;
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_16, void*, TEAVM_WITH_CALL_SITE_ID(26113, teavm_checkUpperBound(INT32_C(0), teavm_local_16)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
        teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(26114, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26115, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_intValue)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(26116, meth_jt_DecimalFormat_forDigit(teavm_this_, TEAVM_WITH_CALL_SITE_ID(26117, meth_jl_Math_abs_0(teavm_local_20))));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26118, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(26119, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_20));
        teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_16, void*, TEAVM_WITH_CALL_SITE_ID(26120, teavm_checkUpperBound(INT32_C(1), teavm_local_16)));
        teavm_local_4 = sfld_jm_BigInteger_TEN;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26121, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26122, teavm_nullCheck(teavm_local_18))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_4)));
        teavm_local_8 = (teavm_local_8 + -INT32_C(1));
    }
    teavm_local_8 = (teavm_local_17 - INT32_C(1));
    while (1) {
        if (!(teavm_local_8 >= teavm_local_15)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26123, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(26124, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
        teavm_local_8 = (teavm_local_8 + -INT32_C(1));
    }
    teavm_local_21 = (teavm_local_11 - (teavm_local_7 - teavm_local_15));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
    teavm_local_22 = (teavm_local_21 - (TEAVM_WITH_CALL_SITE_ID(26125, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(26126, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_))));
    if ((teavm_local_22 <= INT32_C(0))) {
        teavm_local_4 = sfld_jm_BigInteger_ZERO;
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26127, teavm_nullCheck(teavm_local_10));
        if (TEAVM_WITH_CALL_SITE_ID(26128, TEAVM_METHOD(teavm_local_10, jm_BigInteger_VT, virt_equals)(teavm_local_10, teavm_local_4))) {
            goto teavm_label_3;
        }
        if ((teavm_local_21 <= INT32_C(0))) {
            goto teavm_label_3;
        }
    }
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
    teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(26129, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26130, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26131, teavm_nullCheck(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(26132, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_23));
    teavm_local_24 = TEAVM_WITH_CALL_SITE_ID(26133, meth_jl_Math_max(INT32_C(0), (teavm_local_15 - teavm_local_21)));
    teavm_local_25 = INT32_C(0);
    teavm_local_8 = (teavm_local_15 - INT32_C(1));
    while (1) {
        if (!(teavm_local_8 >= teavm_local_24)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26134, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26135, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divideAndRemainder)(teavm_tmp_ptr_0, teavm_local_18)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_19);
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26136, teavm_nullCheck(teavm_local_19));
        teavm_local_16 = teavm_local_19;
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_16, void*, TEAVM_WITH_CALL_SITE_ID(26137, teavm_checkUpperBound(INT32_C(0), teavm_local_16)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26138, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26139, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_intValue)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(26140, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(26141, meth_jt_DecimalFormat_forDigit(teavm_this_, TEAVM_WITH_CALL_SITE_ID(26142, meth_jl_Math_abs_0(teavm_local_15))))));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_16, void*, TEAVM_WITH_CALL_SITE_ID(26143, teavm_checkUpperBound(INT32_C(1), teavm_local_16)));
        teavm_local_25 = (teavm_local_25 + INT32_C(1));
        teavm_local_5 = sfld_jm_BigInteger_ZERO;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26144, teavm_nullCheck(teavm_local_4));
        if (TEAVM_WITH_CALL_SITE_ID(26145, TEAVM_METHOD(teavm_local_10, jm_BigInteger_VT, virt_equals)(teavm_local_10, teavm_local_5))) {
            goto teavm_label_5;
        }
        teavm_local_4 = sfld_jm_BigInteger_TEN;
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26146, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26147, teavm_nullCheck(teavm_local_18))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_4)));
        teavm_local_8 = (teavm_local_8 + -INT32_C(1));
    }
    goto teavm_label_4;
teavm_label_5:;
teavm_label_4:;
    while (1) {
        teavm_local_20 = (teavm_local_25 + INT32_C(1));
        if ((teavm_local_25 >= teavm_local_22)) {
            goto teavm_label_7;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(26148, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
        teavm_local_25 = teavm_local_20;
    }
teavm_label_7:;
teavm_label_3:;
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26149, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26150, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getExponentSeparator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26151, teavm_nullCheck(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(26152, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_4));
    if ((teavm_local_14 < INT32_C(0))) {
        teavm_local_14 = (-teavm_local_14);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26153, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26154, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getMinusSign)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(26155, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_15));
    }
    teavm_local_15 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_exponentDigits);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_26 = TEAVM_WITH_CALL_SITE_ID(26156, meth_jl_Math_max(teavm_local_15, (TEAVM_WITH_CALL_SITE_ID(26157, meth_jt_DecimalFormat_fastLn10(teavm_this_, teavm_local_14)) + INT32_C(1))));
    teavm_local_8 = (teavm_local_26 - INT32_C(1));
    while (1) {
        if (!(teavm_local_8 >= INT32_C(0))) break;
        teavm_local_16 = sfld_jt_DecimalFormat_POW10_INT_ARRAY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_16);
        teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(26158, teavm_nullCheck(teavm_local_16));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26159, teavm_checkBounds(teavm_local_8, teavm_local_16));
        teavm_local_27 = TEAVM_ARRAY_AT(teavm_local_16, int32_t, teavm_local_8);
        teavm_local_15 = (teavm_local_14 / teavm_local_27);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(26160, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(26161, meth_jt_DecimalFormat_forDigit(teavm_this_, teavm_local_15))));
        teavm_local_14 = (teavm_local_14 % teavm_local_27);
        teavm_local_8 = (teavm_local_8 + -INT32_C(1));
    }
    TEAVM_WITH_CALL_SITE_ID(26162, meth_jt_DecimalFormat_appendSuffix(teavm_this_, teavm_local_6, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_appendSuffix(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!teavm_local_1)) {
        if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix) != NULL)) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativeSuffix);
        } else if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix) != NULL)) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix);
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26163, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DecimalFormat_FormatField_Cls), INT32_C(0)));
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(26164, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_3, teavm_local_2));
    } else if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix) != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positiveSuffix);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(26165, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_3, teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_formatRegular(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int64_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    TeaVM_Array* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    void* teavm_local_18;
    TeaVM_Array* teavm_local_19;
    int32_t teavm_local_20;
    int32_t teavm_local_21;
    int32_t teavm_local_22;
    int32_t teavm_local_23;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier) != INT32_C(1))) {
        teavm_local_3 = ((int64_t) TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_multiplier));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26166, meth_jm_BigDecimal_valueOf(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26167, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26168, TEAVM_METHOD(teavm_local_1, jm_BigDecimal_VT, virt_multiply_0)(teavm_local_1, teavm_local_4));
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26169, teavm_nullCheck(teavm_local_1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26170, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_unscaledValue)(teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(26171, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_4 = sfld_jm_BigInteger_ZERO;
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26172, teavm_nullCheck(teavm_local_6));
    teavm_local_7 = ((TEAVM_WITH_CALL_SITE_ID(26173, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_compareTo_3)(teavm_local_6, teavm_local_4)) < INT32_C(0)) ? INT32_C(0) : INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26174, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_precision)(teavm_local_5));
    teavm_local_9 = (TEAVM_WITH_CALL_SITE_ID(26175, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_precision)(teavm_local_5)) - TEAVM_WITH_CALL_SITE_ID(26176, TEAVM_METHOD(teavm_local_5, jm_BigDecimal_VT, virt_scale)(teavm_local_5)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_10 = (teavm_local_9 + TEAVM_WITH_CALL_SITE_ID(26177, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)));
    if ((teavm_local_10 < INT32_C(0))) {
        teavm_local_6 = sfld_jm_BigInteger_ZERO;
    } else if ((teavm_local_10 < teavm_local_8)) {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26178, meth_jt_DecimalFormat_applyRounding_0(teavm_this_, teavm_local_6, teavm_local_8, teavm_local_10));
    }
    teavm_local_11 = ((!teavm_local_7) ? TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_negativePrefix) : TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_positivePrefix));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(26179, meth_jt_DecimalFormat_fieldsToText(teavm_this_, teavm_local_11, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(26180, meth_jl_Math_max(INT32_C(0), teavm_local_9));
    teavm_local_13 = (TEAVM_WITH_CALL_SITE_ID(26181, meth_jl_Math_max(teavm_local_12, TEAVM_WITH_CALL_SITE_ID(26182, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)))) - INT32_C(1));
    teavm_local_14 = (TEAVM_WITH_CALL_SITE_ID(26183, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumIntegerDigits)(teavm_this_)) - INT32_C(1));
    while (1) {
        if (!(teavm_local_14 >= teavm_local_12)) break;
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26184, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(26185, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
        if ((TEAVM_WITH_CALL_SITE_ID(26186, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(0)) && ((!(teavm_local_13 % TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize))) && (teavm_local_13 > INT32_C(0)))))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26187, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26188, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(26189, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_15));
        }
        teavm_local_13 = (teavm_local_13 + -INT32_C(1));
        teavm_local_14 = (teavm_local_14 + -INT32_C(1));
    }
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
    teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(26190, meth_jl_Math_min(teavm_local_8, teavm_local_12));
    teavm_local_4 = sfld_jm_BigInteger_ONE;
    teavm_local_17 = (teavm_local_8 - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26191, meth_jt_DecimalFormat_pow10(teavm_this_, teavm_local_4, teavm_local_17));
    teavm_local_14 = INT32_C(0);
    while (1) {
        if (!(teavm_local_14 < teavm_local_16)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26192, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26193, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divideAndRemainder)(teavm_tmp_ptr_0, teavm_local_18)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_19);
        teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26194, teavm_nullCheck(teavm_local_19));
        teavm_local_11 = teavm_local_19;
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_11, void*, TEAVM_WITH_CALL_SITE_ID(26195, teavm_checkUpperBound(INT32_C(0), teavm_local_11)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26196, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26197, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_intValue)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(26198, meth_jt_DecimalFormat_forDigit(teavm_this_, TEAVM_WITH_CALL_SITE_ID(26199, meth_jl_Math_abs_0(teavm_local_15))));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26200, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(26201, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_17));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_11, void*, TEAVM_WITH_CALL_SITE_ID(26202, teavm_checkUpperBound(INT32_C(1), teavm_local_11)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        if ((TEAVM_WITH_CALL_SITE_ID(26203, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(0)) && ((!(teavm_local_13 % TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize))) && (teavm_local_13 > INT32_C(0)))))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
            teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26204, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26205, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_WITH_CALL_SITE_ID(26206, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_15));
        }
        teavm_local_13 = (teavm_local_13 + -INT32_C(1));
        teavm_local_8 = (teavm_local_8 + -INT32_C(1));
        teavm_local_4 = sfld_jm_BigInteger_TEN;
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26207, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26208, teavm_nullCheck(teavm_local_18))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_4)));
        teavm_local_14 = (teavm_local_14 + INT32_C(1));
    }
    teavm_local_15 = (teavm_local_12 - teavm_local_16);
    teavm_local_14 = INT32_C(0);
    while (1) {
        if (!(teavm_local_14 < teavm_local_15)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26209, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(26210, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
        if ((TEAVM_WITH_CALL_SITE_ID(26211, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isGroupingUsed)(teavm_this_)) && ((TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize) > INT32_C(0)) && ((!(teavm_local_13 % TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_groupingSize))) && (teavm_local_13 > INT32_C(0)))))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_20 = TEAVM_WITH_CALL_SITE_ID(26212, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26213, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getGroupingSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(26214, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_20));
        }
        teavm_local_13 = (teavm_local_13 + -INT32_C(1));
        teavm_local_14 = (teavm_local_14 + INT32_C(1));
    }
    teavm_local_5 = sfld_jm_BigInteger_ZERO;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26215, teavm_nullCheck(teavm_local_6));
    if (TEAVM_WITH_CALL_SITE_ID(26216, TEAVM_METHOD(teavm_local_4, jm_BigInteger_VT, virt_equals)(teavm_local_4, teavm_local_5))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        if (TEAVM_WITH_CALL_SITE_ID(26217, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(26218, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26219, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26220, teavm_nullCheck(teavm_local_2));
            TEAVM_WITH_CALL_SITE_ID(26221, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_17));
            teavm_local_14 = INT32_C(0);
            while (1) {
                if (!(teavm_local_14 < TEAVM_WITH_CALL_SITE_ID(26222, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_)))) break;
                TEAVM_WITH_CALL_SITE_ID(26223, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
                teavm_local_14 = (teavm_local_14 + INT32_C(1));
            }
        } else if (TEAVM_WITH_CALL_SITE_ID(26224, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_isDecimalSeparatorAlwaysShown)(teavm_this_))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(26225, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26226, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26227, teavm_nullCheck(teavm_local_2));
            TEAVM_WITH_CALL_SITE_ID(26228, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_17));
        }
    } else {
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(26229, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26230, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getDecimalSeparator)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26231, teavm_nullCheck(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(26232, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_17));
        teavm_local_21 = TEAVM_WITH_CALL_SITE_ID(26233, meth_jl_Math_min(TEAVM_WITH_CALL_SITE_ID(26234, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)), TEAVM_WITH_CALL_SITE_ID(26235, meth_jl_Math_max(INT32_C(0), (-teavm_local_9)))));
        teavm_local_14 = INT32_C(0);
        teavm_local_22 = INT32_C(0);
        while (1) {
            if (!(teavm_local_22 < teavm_local_21)) break;
            teavm_local_14 = (teavm_local_14 + INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(26236, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
            teavm_local_22 = (teavm_local_22 + INT32_C(1));
        }
        teavm_local_23 = TEAVM_WITH_CALL_SITE_ID(26237, meth_jl_Math_min((TEAVM_WITH_CALL_SITE_ID(26238, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMaximumFractionDigits)(teavm_this_)) - teavm_local_14), teavm_local_8));
        teavm_local_22 = INT32_C(0);
        while (1) {
            if ((teavm_local_22 >= teavm_local_23)) {
                goto teavm_label_6;
            }
            teavm_local_5 = sfld_jm_BigInteger_ZERO;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_18);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26239, teavm_nullCheck(teavm_local_4));
            if (TEAVM_WITH_CALL_SITE_ID(26240, TEAVM_METHOD(teavm_local_4, jm_BigInteger_VT, virt_equals)(teavm_local_4, teavm_local_5))) {
                goto teavm_label_7;
            }
            teavm_local_14 = (teavm_local_14 + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26241, TEAVM_METHOD(teavm_local_4, jm_BigInteger_VT, virt_divideAndRemainder)(teavm_local_4, teavm_local_18));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_19);
            teavm_local_19 = TEAVM_WITH_CALL_SITE_ID(26242, teavm_nullCheck(teavm_local_19));
            teavm_local_11 = teavm_local_19;
            teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_11, void*, TEAVM_WITH_CALL_SITE_ID(26243, teavm_checkUpperBound(INT32_C(0), teavm_local_11)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(26244, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26245, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_intValue)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(26246, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(26247, meth_jt_DecimalFormat_forDigit(teavm_this_, TEAVM_WITH_CALL_SITE_ID(26248, meth_jl_Math_abs_0(teavm_local_15))))));
            teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_11, void*, TEAVM_WITH_CALL_SITE_ID(26249, teavm_checkUpperBound(INT32_C(1), teavm_local_11)));
            teavm_local_5 = sfld_jm_BigInteger_TEN;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(26250, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26251, teavm_nullCheck(teavm_local_18))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_5)));
            teavm_local_22 = (teavm_local_22 + INT32_C(1));
        }
    teavm_label_7:;
    teavm_label_6:;
        while (1) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if ((teavm_local_14 >= TEAVM_WITH_CALL_SITE_ID(26252, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getMinimumFractionDigits)(teavm_this_)))) {
                goto teavm_label_8;
            }
            TEAVM_WITH_CALL_SITE_ID(26253, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, INT32_C(48)));
            teavm_local_14 = (teavm_local_14 + INT32_C(1));
        }
    teavm_label_8:;
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(26254, meth_jt_DecimalFormat_appendSuffix(teavm_this_, teavm_local_7, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
int64_t meth_jt_DecimalFormat_applyRounding(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int64_t teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    int64_t teavm_local_10;
    int64_t teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(26255, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_Cls, &initclass_jt_DecimalFormat));
    teavm_local_5 = sfld_jt_DecimalFormat_POW10_ARRAY;
    teavm_local_6 = (teavm_local_2 - teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26256, teavm_nullCheck(teavm_local_5));
    teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_5, int64_t, TEAVM_WITH_CALL_SITE_ID(26257, teavm_checkBounds(teavm_local_6, teavm_local_5)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(26258, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_1_Cls, &initclass_jt_DecimalFormat_1));
    teavm_local_5 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26259, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getRoundingMode)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26260, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(26261, teavm_nullCheck(teavm_local_8))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26262, teavm_nullCheck(teavm_local_5));
    switch (TEAVM_ARRAY_AT(teavm_local_5, int32_t, TEAVM_WITH_CALL_SITE_ID(26263, teavm_checkBounds(teavm_local_9, teavm_local_5)))) {
        case 1:
            goto teavm_label_6;
        case 2:
            goto teavm_label_5;
        case 3:
            goto teavm_label_7;
        case 4:
            goto teavm_label_8;
        case 5:
            goto teavm_label_4;
        case 6:
            teavm_local_10 = (teavm_local_1 % teavm_local_7);
            teavm_local_11 = (teavm_local_7 / INT64_C(2));
            if ((teavm_local_10 == teavm_local_11)) {
                teavm_local_1 = ((teavm_local_1 / teavm_local_7) * teavm_local_7);
                goto teavm_label_1;
            }
            teavm_local_1 = (((teavm_local_1 + teavm_local_11) / teavm_local_7) * teavm_local_7);
            goto teavm_label_1;
        case 7:
            goto teavm_label_3;
        case 8:
            goto teavm_label_2;
    }
    goto teavm_label_1;
teavm_label_8:;
    teavm_local_1 = ((teavm_local_1 / teavm_local_7) * teavm_local_7);
    goto teavm_label_1;
teavm_label_7:;
    teavm_local_1 = (((teavm_local_1 / teavm_local_7) * teavm_local_7) + teavm_local_7);
    goto teavm_label_1;
teavm_label_6:;
    teavm_local_1 = ((teavm_local_1 / teavm_local_7) * teavm_local_7);
    if ((!teavm_local_4)) {
        goto teavm_label_1;
    }
    teavm_local_1 = (teavm_local_1 + teavm_local_7);
    goto teavm_label_1;
teavm_label_5:;
    teavm_local_1 = ((teavm_local_1 / teavm_local_7) * teavm_local_7);
    if (teavm_local_4) {
        goto teavm_label_1;
    }
    teavm_local_1 = (teavm_local_1 + teavm_local_7);
    goto teavm_label_1;
teavm_label_4:;
    if (((teavm_local_1 % teavm_local_7) == INT64_C(0))) {
        goto teavm_label_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26264, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(26265, meth_jl_ArithmeticException__init_(teavm_local_8, TEAVM_GET_STRING(7277)));
    TEAVM_WITH_CALL_SITE_ID(26266, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
teavm_label_3:;
    teavm_local_11 = (teavm_local_1 % teavm_local_7);
    teavm_local_10 = (teavm_local_7 / INT64_C(2));
    if ((teavm_local_11 != teavm_local_10)) {
        teavm_local_1 = (((teavm_local_1 + teavm_local_10) / teavm_local_7) * teavm_local_7);
        goto teavm_label_1;
    }
    teavm_local_1 = (((teavm_local_1 / teavm_local_7) * teavm_local_7) + teavm_local_7);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_11 = (teavm_local_1 % teavm_local_7);
    teavm_local_10 = (teavm_local_7 / INT64_C(2));
    if ((teavm_local_11 != teavm_local_10)) {
        teavm_local_1 = (((teavm_local_1 + teavm_local_10) / teavm_local_7) * teavm_local_7);
    } else {
        teavm_local_1 = ((teavm_local_1 / teavm_local_7) * teavm_local_7);
        if ((((teavm_local_1 / teavm_local_7) % INT64_C(2)) != INT64_C(0))) {
            teavm_local_1 = (teavm_local_1 + teavm_local_7);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jt_DecimalFormat_applyRounding_0(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TeaVM_Array* teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_WITH_CALL_SITE_ID(26267, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_4 = sfld_jm_BigInteger_ONE;
    teavm_local_5 = (teavm_local_2 - teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26268, meth_jt_DecimalFormat_pow10(teavm_this_, teavm_local_4, teavm_local_5));
    teavm_local_4 = sfld_jm_BigInteger_ZERO;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26269, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((TEAVM_WITH_CALL_SITE_ID(26270, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_compareTo_3)(teavm_local_1, teavm_local_4)) >= INT32_C(0))) {
        teavm_local_7 = teavm_local_6;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26271, teavm_nullCheck(teavm_local_6));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26272, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_negate)(teavm_local_6));
    }
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT(INT32_C(4), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(26273, teavm_initializeClass((TeaVM_Class*) &jt_DecimalFormat_1_Cls, &initclass_jt_DecimalFormat_1));
    teavm_local_8 = sfld_jt_DecimalFormat_1__SwitchMap_java_math_RoundingMode;
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26274, TEAVM_METHOD(teavm_this_, jt_DecimalFormat_VT, virt_getRoundingMode)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26275, meth_jl_Enum_ordinal(TEAVM_WITH_CALL_SITE_ID(26276, teavm_nullCheck(teavm_local_4))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26277, teavm_nullCheck(teavm_local_8));
    switch (TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(26278, teavm_checkBounds(teavm_local_5, teavm_local_8)))) {
        case 1:
            goto teavm_label_6;
        case 2:
            goto teavm_label_5;
        case 3:
            goto teavm_label_7;
        case 4:
            goto teavm_label_8;
        case 5:
            goto teavm_label_4;
        case 6:
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26279, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_remainder)(teavm_local_1, teavm_local_6));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26280, meth_jm_BigInteger_valueOf(INT64_C(2)));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26281, teavm_nullCheck(teavm_local_7));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26282, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_divide)(teavm_local_7, teavm_local_9));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
            if (TEAVM_WITH_CALL_SITE_ID(26283, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26284, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_9)))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26285, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26286, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26287, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
                goto teavm_label_1;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26288, meth_jm_BigInteger_valueOf(INT64_C(2)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26289, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_divide)(teavm_local_7, teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26290, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_add_6)(teavm_local_1, teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26291, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26292, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_6)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26293, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26294, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
            goto teavm_label_1;
        case 7:
            goto teavm_label_3;
        case 8:
            goto teavm_label_2;
    }
    goto teavm_label_1;
teavm_label_8:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26295, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26296, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26297, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
    goto teavm_label_1;
teavm_label_7:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26298, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26299, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26300, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26301, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26302, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_7)));
    goto teavm_label_1;
teavm_label_6:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26303, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26304, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26305, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
    teavm_local_9 = sfld_jm_BigInteger_ZERO;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26306, teavm_nullCheck(teavm_local_4));
    if ((TEAVM_WITH_CALL_SITE_ID(26307, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_compareTo_3)(teavm_local_1, teavm_local_9)) < INT32_C(0))) {
        goto teavm_label_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26308, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_add_6)(teavm_local_1, teavm_local_6));
    goto teavm_label_1;
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26309, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26310, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26311, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
    teavm_local_9 = sfld_jm_BigInteger_ZERO;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26312, teavm_nullCheck(teavm_local_4));
    if ((TEAVM_WITH_CALL_SITE_ID(26313, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_compareTo_3)(teavm_local_1, teavm_local_9)) > INT32_C(0))) {
        goto teavm_label_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26314, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_subtract)(teavm_local_1, teavm_local_6));
    goto teavm_label_1;
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26315, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_remainder)(teavm_local_1, teavm_local_6));
    teavm_local_9 = sfld_jm_BigInteger_ZERO;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    if ((!TEAVM_WITH_CALL_SITE_ID(26316, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26317, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_9))))) {
        goto teavm_label_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26318, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(26319, meth_jl_ArithmeticException__init_(teavm_local_4, TEAVM_GET_STRING(7277)));
    TEAVM_WITH_CALL_SITE_ID(26320, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26321, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_remainder)(teavm_local_1, teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26322, meth_jm_BigInteger_valueOf(INT64_C(2)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26323, teavm_nullCheck(teavm_local_7));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26324, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_divide)(teavm_local_7, teavm_local_9));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
    if (TEAVM_WITH_CALL_SITE_ID(26325, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26326, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_9)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26327, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26328, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26329, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26330, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26331, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_7)));
        goto teavm_label_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26332, meth_jm_BigInteger_valueOf(INT64_C(2)));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26333, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_divide)(teavm_local_7, teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26334, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_add_6)(teavm_local_1, teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26335, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26336, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_6)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26337, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26338, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26339, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_remainder)(teavm_local_1, teavm_local_6));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26340, meth_jm_BigInteger_valueOf(INT64_C(2)));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26341, teavm_nullCheck(teavm_local_7));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26342, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_divide)(teavm_local_7, teavm_local_9));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
    if ((!TEAVM_WITH_CALL_SITE_ID(26343, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26344, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_9))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26345, meth_jm_BigInteger_valueOf(INT64_C(2)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26346, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_divide)(teavm_local_7, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26347, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_add_6)(teavm_local_1, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26348, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26349, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_6)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26350, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26351, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26352, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26353, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26354, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26355, teavm_nullCheck(teavm_local_4));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26356, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_divide)(teavm_local_1, teavm_local_6));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26357, meth_jm_BigInteger_valueOf(INT64_C(2)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26358, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26359, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_remainder)(teavm_tmp_ptr_0, teavm_local_9)));
        teavm_local_9 = sfld_jm_BigInteger_ZERO;
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
        if ((!TEAVM_WITH_CALL_SITE_ID(26360, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26361, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_9))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26362, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_add_6)(teavm_local_1, teavm_local_7));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_DecimalFormat_fastLn10_0(void* teavm_this_, int64_t teavm_local_1) {
    int32_t teavm_local_2;
    if ((teavm_local_1 != (int64_t) INT64_C(0x8000000000000000))) {
        teavm_local_2 = INT32_C(0);
        if ((teavm_local_1 >= INT64_C(10000000000000000))) {
            teavm_local_2 = INT32_C(16);
            teavm_local_1 = (teavm_local_1 / INT64_C(10000000000000000));
        }
        if ((teavm_local_1 >= INT64_C(100000000))) {
            teavm_local_2 = (teavm_local_2 + INT32_C(8));
            teavm_local_1 = (teavm_local_1 / INT64_C(100000000));
        }
        if ((teavm_local_1 >= INT64_C(10000))) {
            teavm_local_2 = (teavm_local_2 + INT32_C(4));
            teavm_local_1 = (teavm_local_1 / INT64_C(10000));
        }
        if ((teavm_local_1 >= INT64_C(100))) {
            teavm_local_2 = (teavm_local_2 + INT32_C(2));
            teavm_local_1 = (teavm_local_1 / INT64_C(100));
        }
        if ((teavm_local_1 >= INT64_C(10))) {
            teavm_local_2 = (teavm_local_2 + INT32_C(1));
        }
        return teavm_local_2;
    }
    return INT32_C(18);
}
int32_t meth_jt_DecimalFormat_fastLn10(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    teavm_local_2 = INT32_C(0);
    if ((teavm_local_1 >= INT32_C(100000000))) {
        teavm_local_2 = INT32_C(8);
        teavm_local_1 = (teavm_local_1 / INT32_C(100000000));
    }
    if ((teavm_local_1 >= INT32_C(10000))) {
        teavm_local_2 = (teavm_local_2 + INT32_C(4));
        teavm_local_1 = (teavm_local_1 / INT32_C(10000));
    }
    if ((teavm_local_1 >= INT32_C(100))) {
        teavm_local_2 = (teavm_local_2 + INT32_C(2));
        teavm_local_1 = (teavm_local_1 / INT32_C(100));
    }
    if ((teavm_local_1 >= INT32_C(10))) {
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
    return teavm_local_2;
}
void* meth_jt_DecimalFormat_pow10(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(26363, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_3 = sfld_jm_BigInteger_TEN;
    while (1) {
        if (!teavm_local_2) break;
        if ((teavm_local_2 & INT32_C(1))) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26364, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26365, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_3)));
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26366, teavm_nullCheck(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26367, TEAVM_METHOD(teavm_local_3, jm_BigInteger_VT, virt_multiply)(teavm_local_3, teavm_local_3));
        teavm_local_2 = ((int32_t) ((uint32_t) teavm_local_2 >> INT32_C(1)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_DecimalFormat_forDigit(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat, fld_symbols);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_TO_CHAR((TEAVM_WITH_CALL_SITE_ID(26368, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(26369, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jt_DecimalFormatSymbols_VT, virt_getZeroDigit)(teavm_tmp_ptr_0))) + teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jt_DecimalFormat__clinit_() {
    TEAVM_ALLOC_STACK(INT32_C(0));
    sfld_jt_DecimalFormat_POW10_ARRAY = TEAVM_WITH_CALL_SITE_ID(26370, teavm_fillLongArray(meth_otr_Allocator_allocateArray(&Arr_J_Cls, 19), INT64_C(1), INT64_C(10), INT64_C(100), INT64_C(1000), INT64_C(10000), INT64_C(100000), INT64_C(1000000), INT64_C(10000000), INT64_C(100000000), INT64_C(1000000000), INT64_C(10000000000), INT64_C(100000000000), INT64_C(1000000000000), INT64_C(10000000000000), INT64_C(100000000000000), INT64_C(1000000000000000), INT64_C(10000000000000000), INT64_C(100000000000000000), INT64_C(1000000000000000000)));
    sfld_jt_DecimalFormat_POW10_INT_ARRAY = TEAVM_WITH_CALL_SITE_ID(26371, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 10), INT32_C(1), INT32_C(10), INT32_C(100), INT32_C(1000), INT32_C(10000), INT32_C(100000), INT32_C(1000000), INT32_C(10000000), INT32_C(100000000), INT32_C(1000000000)));
    TEAVM_RELEASE_STACK;
}
void initclass_jt_DecimalFormat() {
    TeaVM_Class* cls = (TeaVM_Class*) &jt_DecimalFormat_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jt_DecimalFormat__clinit_();
    }
}
int32_t supertypeof_jt_DecimalFormat(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1217 || tag >= 1219) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DecimalFormat_Cls[7];
alignas(8) jt_DecimalFormat_VT jt_DecimalFormat_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormat), sizeof(void*)),
        .flags = 0,
        .tag = 1217,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7278),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DecimalFormat,
        .superclass = (TeaVM_Class*) &jt_NumberFormat_Cls,
        .layout = teavm_classLayouts_jt_DecimalFormat_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DecimalFormat_hashCode,
    .virt_equals = &meth_jt_DecimalFormat_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format_2 = &meth_jt_DecimalFormat_format,
    .virt_formatToCharacterIterator = &meth_jt_Format_formatToCharacterIterator,
    .virt_setMaximumFractionDigits = &meth_jt_NumberFormat_setMaximumFractionDigits,
    .virt_format_1 = &meth_jt_DecimalFormat_format_2,
    .virt_setMaximumIntegerDigits = &meth_jt_NumberFormat_setMaximumIntegerDigits,
    .virt_setMinimumFractionDigits = &meth_jt_NumberFormat_setMinimumFractionDigits,
    .virt_getMinimumIntegerDigits = &meth_jt_NumberFormat_getMinimumIntegerDigits,
    .virt_isGroupingUsed = &meth_jt_NumberFormat_isGroupingUsed,
    .virt_parse_0 = &meth_jt_DecimalFormat_parse,
    .virt_format_0 = &meth_jt_DecimalFormat_format_3,
    .virt_toPattern = &meth_jt_DecimalFormat_toPattern,
    .virt_getMaximumIntegerDigits = &meth_jt_NumberFormat_getMaximumIntegerDigits,
    .virt_setMinimumIntegerDigits = &meth_jt_NumberFormat_setMinimumIntegerDigits,
    .virt_setParseIntegerOnly = &meth_jt_NumberFormat_setParseIntegerOnly,
    .virt_getMaximumFractionDigits = &meth_jt_NumberFormat_getMaximumFractionDigits,
    .virt_format_3 = &meth_jt_Format_format,
    .virt_setNegativePrefix = &meth_jt_DecimalFormat_setNegativePrefix,
    .virt_setGroupingSize = &meth_jt_DecimalFormat_setGroupingSize,
    .virt_getMinimumFractionDigits = &meth_jt_NumberFormat_getMinimumFractionDigits,
    .virt_getGroupingSize = &meth_jt_DecimalFormat_getGroupingSize,
    .virt_getPositiveSuffix = &meth_jt_DecimalFormat_getPositiveSuffix,
    .virt_setDecimalSeparatorAlwaysShown = &meth_jt_DecimalFormat_setDecimalSeparatorAlwaysShown,
    .virt_getCurrency = &meth_jt_NumberFormat_getCurrency,
    .virt_getRoundingMode = &meth_jt_NumberFormat_getRoundingMode,
    .virt_setNegativeSuffix = &meth_jt_DecimalFormat_setNegativeSuffix,
    .virt_getNegativeSuffix = &meth_jt_DecimalFormat_getNegativeSuffix,
    .virt_setPositivePrefix = &meth_jt_DecimalFormat_setPositivePrefix,
    .virt_isDecimalSeparatorAlwaysShown = &meth_jt_DecimalFormat_isDecimalSeparatorAlwaysShown,
    .virt_setDecimalFormatSymbols = &meth_jt_DecimalFormat_setDecimalFormatSymbols,
    .virt_setGroupingUsed = &meth_jt_NumberFormat_setGroupingUsed,
    .virt_applyPattern = &meth_jt_DecimalFormat_applyPattern,
    .virt_isParseBigDecimal = &meth_jt_DecimalFormat_isParseBigDecimal,
    .virt_getPositivePrefix = &meth_jt_DecimalFormat_getPositivePrefix,
    .virt_getNegativePrefix = &meth_jt_DecimalFormat_getNegativePrefix,
    .virt_setMultiplier = &meth_jt_DecimalFormat_setMultiplier
};
static void** teavm_gc_localStaticRoots_jt_DecimalFormat_Cls[2] = {
(void**) &sfld_jt_DecimalFormat_POW10_ARRAY, (void**) &sfld_jt_DecimalFormat_POW10_INT_ARRAY
};
static int16_t teavm_classLayouts_jt_DecimalFormat_Cls[7] = {
INT16_C(6), (int16_t) offsetof(cls_jt_DecimalFormat, fld_symbols), (int16_t) offsetof(cls_jt_DecimalFormat, fld_positivePrefix), (int16_t) offsetof(cls_jt_DecimalFormat, fld_negativePrefix), (int16_t) offsetof(cls_jt_DecimalFormat, fld_positiveSuffix), (int16_t) offsetof(cls_jt_DecimalFormat, fld_negativeSuffix), (int16_t) offsetof(cls_jt_DecimalFormat, fld_pattern)
};
void sysinitclass_jt_DecimalFormat() {
sfld_jt_DecimalFormat_POW10_ARRAY = NULL;
sfld_jt_DecimalFormat_POW10_INT_ARRAY = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jt_DecimalFormat_Cls, 2);
}
