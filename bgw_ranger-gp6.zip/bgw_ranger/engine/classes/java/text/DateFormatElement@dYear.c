#include "DateFormatElement@dYear.h"
#include "DateFormatElement.h"
#include "../util/Calendar.h"
#include "../lang/StringBuffer.h"
#include "ParsePosition.h"
#include "../lang/String.h"
#include "../util/GregorianCalendar.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Object.h"
#include "../../../arrayclass.h"
#include "../lang/Integer.h"
#include "../util/Objects.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_Year__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(339, meth_jt_DateFormatElement__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Year, fld_field) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Year_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Year, fld_field);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(340, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(341, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_get_2)(teavm_local_1, teavm_local_3));
    if ((teavm_local_4 < INT32_C(10))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(342, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(343, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_2)(teavm_local_2, teavm_local_4));
    } else {
        teavm_local_3 = TEAVM_TO_CHAR((((teavm_local_4 % INT32_C(100)) / INT32_C(10)) + INT32_C(48)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(344, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(345, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(346, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_3)(teavm_local_2, TEAVM_TO_CHAR(((teavm_local_4 % INT32_C(10)) + INT32_C(48)))));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_Year_parse(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(347, teavm_nullCheck(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(348, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getIndex)(teavm_local_3));
    teavm_local_5 = (teavm_local_4 + INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(349, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(350, meth_jl_String_charAt(teavm_local_1, teavm_local_4));
    if ((!((teavm_local_6 >= INT32_C(48)) && (teavm_local_6 <= INT32_C(57))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(351, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setErrorIndex)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(352, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_getErrorIndex)(teavm_local_3))));
    } else {
        teavm_local_7 = (teavm_local_6 - INT32_C(48));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(353, meth_jl_String_charAt(teavm_local_1, teavm_local_5));
        if (((teavm_local_8 >= INT32_C(48)) && (teavm_local_8 <= INT32_C(57)))) {
            teavm_local_7 = ((teavm_local_7 * INT32_C(10)) + (teavm_local_8 - INT32_C(48)));
            teavm_local_5 = (teavm_local_5 + INT32_C(1));
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(354, TEAVM_METHOD(teavm_local_3, jt_ParsePosition_VT, virt_setIndex)(teavm_local_3, teavm_local_5));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(355, meth_otr_Allocator_allocate(&ju_GregorianCalendar_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
        TEAVM_WITH_CALL_SITE_ID(356, meth_ju_GregorianCalendar__init_(teavm_local_9));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(357, TEAVM_METHOD(teavm_local_9, ju_Calendar_VT, virt_get_2)(teavm_local_9, INT32_C(1)));
        teavm_local_11 = (teavm_local_10 % INT32_C(100));
        teavm_local_12 = (teavm_local_10 / INT32_C(100));
        if ((teavm_local_11 <= INT32_C(80))) {
            if ((teavm_local_7 > (teavm_local_11 + INT32_C(20)))) {
                teavm_local_12 = (teavm_local_12 + -INT32_C(1));
            }
        } else if ((teavm_local_7 < (teavm_local_11 - INT32_C(80)))) {
            teavm_local_12 = (teavm_local_12 + INT32_C(1));
        }
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Year, fld_field);
        teavm_local_5 = (teavm_local_7 + (teavm_local_12 * INT32_C(100)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(358, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(359, TEAVM_METHOD(teavm_local_2, ju_Calendar_VT, virt_set_1)(teavm_local_2, teavm_local_8, teavm_local_5));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_Year_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((teavm_local_1 != NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(360, meth_jl_Object_getClass(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(361, meth_jl_Object_getClass(teavm_local_1)))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(362, teavm_checkcast(teavm_local_1, &jt_DateFormatElement_Year_Cls, &supertypeof_jt_DateFormatElement_Year));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Year, fld_field);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(363, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = ((teavm_local_2 != TEAVM_FIELD(teavm_local_4, cls_jt_DateFormatElement_Year, fld_field)) ? INT32_C(0) : INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_Year_hashCode(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(364, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(1)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_Year, fld_field);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(365, meth_jl_Integer_valueOf_0(teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_4;
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(366, meth_ju_Objects_hash(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t supertypeof_jt_DateFormatElement_Year(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2260 || tag >= 2262) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_Year_VT jt_DateFormatElement_Year_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_Year), sizeof(void*)),
            .flags = 0,
            .tag = 2260,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(35),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_Year,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_Year_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_Year_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_Year_format,
        .virt_parse = &meth_jt_DateFormatElement_Year_parse
    }
};
void sysinitclass_jt_DateFormatElement_Year() {
}
