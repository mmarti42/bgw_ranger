#pragma once
#include "../../../runtime.h"
#include "DateFormatElement.h"
#include "DateFormatElement@dAmPmText.h"

extern void sysinitclass_jt_DateFormatElement_AmPmText();
typedef struct cls_jt_DateFormatElement_AmPmText {
    struct cls_jt_DateFormatElement parent;
    TeaVM_Array* fld_ampms;
} cls_jt_DateFormatElement_AmPmText;
extern void meth_jt_DateFormatElement_AmPmText__init_(void*, void*);
extern void meth_jt_DateFormatElement_AmPmText_format(void*, void*, void*);
extern void meth_jt_DateFormatElement_AmPmText_parse(void*, void*, void*, void*);
extern int32_t meth_jt_DateFormatElement_AmPmText_equals(void*, void*);
extern int32_t meth_jt_DateFormatElement_AmPmText_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatElement_AmPmText(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatElement_AmPmText_VT {
    jt_DateFormatElement_VT parent;
} jt_DateFormatElement_AmPmText_VT;
extern jt_DateFormatElement_AmPmText_VT jt_DateFormatElement_AmPmText_Cls;
