#include "DateFormatElement@dTrieBuilder.h"
#include "../lang/Object.h"
#include "DateFormatElement@dTrieNodeBuilder.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/String.h"
#include "../lang/Character.h"
#include "DateFormatElement@dTrieNode.h"
#include "../util/ArrayList.h"
#include "../util/List.h"
#include "DateFormatElement@dTrieBuilder@dbuild@dlambda@d_3_0.h"
#include "../util/Comparator.h"
#include "../../../arrays/primitives/char.h"
#include "../../../arrayclass.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_TrieBuilder__init_(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(19530, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19531, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieNodeBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(19532, meth_jt_DateFormatElement_TrieNodeBuilder__init_(teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_TrieBuilder, fld_root) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DateFormatElement_TrieBuilder_add(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_TrieBuilder, fld_root);
    teavm_local_4 = INT32_C(0);
    while (1) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19533, teavm_nullCheck(teavm_local_1));
        if ((teavm_local_4 >= TEAVM_WITH_CALL_SITE_ID(19534, meth_jl_String_length(teavm_local_1)))) {
            goto teavm_label_1;
        }
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19535, meth_jl_Character_toLowerCase(TEAVM_WITH_CALL_SITE_ID(19536, meth_jl_String_charAt(teavm_local_1, teavm_local_4))));
        while (1) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19537, teavm_nullCheck(teavm_local_3));
            if ((TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_ch) == teavm_local_5)) {
                goto teavm_label_2;
            }
            if ((!TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_ch))) {
                goto teavm_label_3;
            }
            teavm_local_3 = TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_sibling);
        }
    teavm_label_3:;
        TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_ch) = teavm_local_5;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(19538, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieNodeBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(19539, meth_jt_DateFormatElement_TrieNodeBuilder__init_(teavm_local_7));
        teavm_gc_writeBarrier(teavm_local_6);
        TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_sibling) = teavm_local_7;
    teavm_label_2:;
        if ((TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_next) == NULL)) {
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(19540, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieNodeBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(19541, meth_jt_DateFormatElement_TrieNodeBuilder__init_(teavm_local_7));
            teavm_gc_writeBarrier(teavm_local_6);
            TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_next) = teavm_local_7;
        }
        teavm_local_3 = TEAVM_FIELD(teavm_local_6, cls_jt_DateFormatElement_TrieNodeBuilder, fld_next);
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(19542, teavm_nullCheck(teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_7);
    TEAVM_FIELD(teavm_local_7, cls_jt_DateFormatElement_TrieNodeBuilder, fld_tz) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_DateFormatElement_TrieBuilder_build(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DateFormatElement_TrieBuilder, fld_root);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19543, TEAVM_METHOD(teavm_this_, jt_DateFormatElement_TrieBuilder_VT, virt_build)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jt_DateFormatElement_TrieBuilder_build_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(19544, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieNode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(19545, meth_jt_DateFormatElement_TrieNode__init_(teavm_local_2));
    if ((teavm_local_1 != NULL)) {
        teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatElement_TrieNodeBuilder, fld_tz);
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_FIELD(teavm_local_2, cls_jt_DateFormatElement_TrieNode, fld_tz) = teavm_local_3;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(19546, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(19547, meth_ju_ArrayList__init_(teavm_local_4));
        while (1) {
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19548, teavm_nullCheck(teavm_local_1));
            if ((!TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatElement_TrieNodeBuilder, fld_ch))) {
                goto teavm_label_1;
            }
            TEAVM_WITH_CALL_SITE_ID(19549, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_add_2)(teavm_local_4, teavm_local_1));
            teavm_local_1 = TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatElement_TrieNodeBuilder, fld_sibling);
        }
    teavm_label_1:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19550, meth_otr_Allocator_allocate(&jt_DateFormatElement_TrieBuilder_build_lambda__3_0_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(19551, meth_jt_DateFormatElement_TrieBuilder_build_lambda__3_0__init_(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19552, meth_ju_Comparator_comparingInt(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(19553, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_sort)(teavm_local_4, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19554, meth_otr_Allocator_allocateArray(&Arr_C_Cls, TEAVM_WITH_CALL_SITE_ID(19555, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_size)(teavm_local_4))));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_FIELD(teavm_local_2, cls_jt_DateFormatElement_TrieNode, fld_chars) = teavm_local_5;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19556, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jt_DateFormatElement_TrieNode_Cls), TEAVM_WITH_CALL_SITE_ID(19557, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_size)(teavm_local_4))));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_FIELD(teavm_local_2, cls_jt_DateFormatElement_TrieNode, fld_childNodes) = teavm_local_5;
        teavm_local_6 = INT32_C(0);
        while (1) {
            teavm_local_5 = TEAVM_FIELD(teavm_local_2, cls_jt_DateFormatElement_TrieNode, fld_chars);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if ((teavm_local_6 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(19558, teavm_nullCheck(teavm_local_5))))) {
                goto teavm_label_2;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_local_2, cls_jt_DateFormatElement_TrieNode, fld_chars);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19559, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_get)(teavm_local_4, teavm_local_6));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
            teavm_local_7 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(19560, teavm_nullCheck(TEAVM_WITH_CALL_SITE_ID(19561, teavm_checkcast(teavm_local_3, &jt_DateFormatElement_TrieNodeBuilder_Cls, &supertypeof_jt_DateFormatElement_TrieNodeBuilder)))), cls_jt_DateFormatElement_TrieNodeBuilder, fld_ch);
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19562, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19563, teavm_checkBounds(teavm_local_6, teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_6) = teavm_local_7;
            teavm_local_5 = TEAVM_FIELD(teavm_local_2, cls_jt_DateFormatElement_TrieNode, fld_childNodes);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19564, TEAVM_METHOD(teavm_local_4, ju_List_VT, virt_get)(teavm_local_4, teavm_local_6));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
            teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(19565, teavm_nullCheck(TEAVM_WITH_CALL_SITE_ID(19566, teavm_checkcast(teavm_local_3, &jt_DateFormatElement_TrieNodeBuilder_Cls, &supertypeof_jt_DateFormatElement_TrieNodeBuilder)))), cls_jt_DateFormatElement_TrieNodeBuilder, fld_next);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(19567, TEAVM_METHOD(teavm_this_, jt_DateFormatElement_TrieBuilder_VT, virt_build)(teavm_this_, teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(19568, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(19569, teavm_checkUpperBound(teavm_local_6, teavm_local_5));
            teavm_gc_writeBarrier(teavm_local_5);
            TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_6) = teavm_local_3;
            teavm_local_6 = (teavm_local_6 + INT32_C(1));
        }
    teavm_label_2:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DateFormatElement_TrieBuilder_lambda_build_0(void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19570, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jt_DateFormatElement_TrieNodeBuilder, fld_ch);
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jt_DateFormatElement_TrieBuilder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1169 || tag >= 1171) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatElement_TrieBuilder_Cls[2];
alignas(8) jt_DateFormatElement_TrieBuilder_VT jt_DateFormatElement_TrieBuilder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_TrieBuilder), sizeof(void*)),
        .flags = 0,
        .tag = 1169,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DateFormatElement_TrieBuilder,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_DateFormatElement_TrieBuilder_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_build = &meth_jt_DateFormatElement_TrieBuilder_build_0,
    .virt_build_0 = &meth_jt_DateFormatElement_TrieBuilder_build,
    .virt_add_9 = &meth_jt_DateFormatElement_TrieBuilder_add
};
static int16_t teavm_classLayouts_jt_DateFormatElement_TrieBuilder_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_DateFormatElement_TrieBuilder, fld_root)
};
void sysinitclass_jt_DateFormatElement_TrieBuilder() {
}
