#include "DateFormatElement@dNumericMonth.h"
#include "DateFormatElement@dNumeric.h"
#include "DateFormatElement.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_jt_DateFormatElement_NumericMonth__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(12442, meth_jt_DateFormatElement_Numeric__init_(teavm_this_, INT32_C(2), teavm_local_1, INT32_C(2)));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DateFormatElement_NumericMonth_processBeforeFormat(void* teavm_this_, int32_t teavm_local_1) {
    return (teavm_local_1 + INT32_C(1));
}
int32_t meth_jt_DateFormatElement_NumericMonth_processAfterParse(void* teavm_this_, int32_t teavm_local_1) {
    return (teavm_local_1 - INT32_C(1));
}
int32_t supertypeof_jt_DateFormatElement_NumericMonth(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2267 || tag >= 2269) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jt_DateFormatElement_NumericMonth_VT jt_DateFormatElement_NumericMonth_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_NumericMonth), sizeof(void*)),
            .flags = 0,
            .tag = 2267,
            .modifiers = 1,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(814),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_NumericMonth,
            .superclass = (TeaVM_Class*) &jt_DateFormatElement_Numeric_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jt_DateFormatElement_Numeric_hashCode,
        .virt_equals = &meth_jt_DateFormatElement_Numeric_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_format = &meth_jt_DateFormatElement_Numeric_format,
        .virt_parse = &meth_jt_DateFormatElement_Numeric_parse,
        .virt_processAfterParse = &meth_jt_DateFormatElement_NumericMonth_processAfterParse,
        .virt_processBeforeFormat = &meth_jt_DateFormatElement_NumericMonth_processBeforeFormat
    }
};
void sysinitclass_jt_DateFormatElement_NumericMonth() {
}
