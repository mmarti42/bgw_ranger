#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "AttributedCharacterIterator@dAttribute.h"

extern void sysinitclass_jt_AttributedCharacterIterator_Attribute();
typedef struct cls_jt_AttributedCharacterIterator_Attribute {
    struct TeaVM_Object parent;
    void* fld_name;
} cls_jt_AttributedCharacterIterator_Attribute;
extern void* sfld_jt_AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT;
extern void* sfld_jt_AttributedCharacterIterator_Attribute_LANGUAGE;
extern void* sfld_jt_AttributedCharacterIterator_Attribute_READING;
extern void meth_jt_AttributedCharacterIterator_Attribute__init_(void*, void*);
extern void meth_jt_AttributedCharacterIterator_Attribute__clinit_();
extern void initclass_jt_AttributedCharacterIterator_Attribute();
extern int32_t supertypeof_jt_AttributedCharacterIterator_Attribute(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_AttributedCharacterIterator_Attribute_VT {
    jl_Object_VT parent;
} jt_AttributedCharacterIterator_Attribute_VT;
extern jt_AttributedCharacterIterator_Attribute_VT jt_AttributedCharacterIterator_Attribute_Cls;
