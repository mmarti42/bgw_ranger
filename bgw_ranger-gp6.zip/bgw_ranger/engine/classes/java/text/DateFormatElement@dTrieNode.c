#include "DateFormatElement@dTrieNode.h"
#include "../lang/Object.h"
#include "DateFormatElement.h"
#include "../../../strings.h"

void meth_jt_DateFormatElement_TrieNode__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(17941, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jt_DateFormatElement_TrieNode(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1009 || tag >= 1011) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DateFormatElement_TrieNode_Cls[4];
alignas(8) jt_DateFormatElement_TrieNode_VT jt_DateFormatElement_TrieNode_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DateFormatElement_TrieNode), sizeof(void*)),
            .flags = 0,
            .tag = 1009,
            .modifiers = 0,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(2671),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jt_DateFormatElement_TrieNode,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jt_DateFormatElement_TrieNode_Cls,
            .enumValues = NULL,
            .declaringClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .enclosingClass = (TeaVM_Class*) &jt_DateFormatElement_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_jt_DateFormatElement_TrieNode_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_jt_DateFormatElement_TrieNode, fld_chars), (int16_t) offsetof(cls_jt_DateFormatElement_TrieNode, fld_childNodes), (int16_t) offsetof(cls_jt_DateFormatElement_TrieNode, fld_tz)
};
void sysinitclass_jt_DateFormatElement_TrieNode() {
}
