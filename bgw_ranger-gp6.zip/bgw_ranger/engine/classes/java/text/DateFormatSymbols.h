#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "DateFormatSymbols.h"

extern void sysinitclass_jt_DateFormatSymbols();
typedef struct cls_jt_DateFormatSymbols {
    struct TeaVM_Object parent;
    void* fld_locale;
    void* fld_localPatternChars;
    TeaVM_Array* fld_ampms;
    TeaVM_Array* fld_eras;
    TeaVM_Array* fld_months;
    TeaVM_Array* fld_shortMonths;
    TeaVM_Array* fld_shortWeekdays;
    TeaVM_Array* fld_weekdays;
    TeaVM_Array* fld_zoneStrings;
} cls_jt_DateFormatSymbols;
extern void meth_jt_DateFormatSymbols__init_(void*, void*);
extern void* meth_jt_DateFormatSymbols_clone(void*);
extern int32_t meth_jt_DateFormatSymbols_equals(void*, void*);
extern TeaVM_Array* meth_jt_DateFormatSymbols_getAmPmStrings(void*);
extern TeaVM_Array* meth_jt_DateFormatSymbols_getEras(void*);
extern TeaVM_Array* meth_jt_DateFormatSymbols_getMonths(void*);
extern TeaVM_Array* meth_jt_DateFormatSymbols_getShortMonths(void*);
extern TeaVM_Array* meth_jt_DateFormatSymbols_getShortWeekdays(void*);
extern TeaVM_Array* meth_jt_DateFormatSymbols_getWeekdays(void*);
extern int32_t meth_jt_DateFormatSymbols_hashCode(void*);
extern int32_t supertypeof_jt_DateFormatSymbols(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_DateFormatSymbols_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    TeaVM_Array* (*virt_getShortWeekdays)(void*); // 11
    TeaVM_Array* (*virt_getShortMonths)(void*); // 12
    void (*pad0)(); // 13
    TeaVM_Array* (*virt_getMonths)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    TeaVM_Array* (*virt_getEras)(void*); // 21
    TeaVM_Array* (*virt_getWeekdays)(void*); // 22
    void (*pad7)(); // 23
    void (*pad8)(); // 24
    void (*pad9)(); // 25
    void (*pad10)(); // 26
    void (*pad11)(); // 27
    TeaVM_Array* (*virt_getAmPmStrings)(void*); // 28
    void (*pad12)(); // 29
    void (*pad13)(); // 30
    void (*pad14)(); // 31
    void (*pad15)(); // 32
    void (*pad16)(); // 33
    void (*pad17)(); // 34
    void (*pad18)(); // 35
    void (*pad19)(); // 36
    void (*pad20)(); // 37
    void (*pad21)(); // 38
    void (*pad22)(); // 39
    void (*pad23)(); // 40
    void (*pad24)(); // 41
    void (*pad25)(); // 42
    void (*pad26)(); // 43
    void (*pad27)(); // 44
    void (*pad28)(); // 45
    void (*pad29)(); // 46
    void (*pad30)(); // 47
    void (*pad31)(); // 48
    void (*pad32)(); // 49
} jt_DateFormatSymbols_VT;
extern jt_DateFormatSymbols_VT jt_DateFormatSymbols_Cls;
