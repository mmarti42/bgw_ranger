#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Format.h"

extern void sysinitclass_jt_Format();
typedef struct cls_jt_Format {
    struct TeaVM_Object parent;
} cls_jt_Format;
extern void meth_jt_Format__init_(void*);
extern void* meth_jt_Format_format(void*, void*);
extern void* meth_jt_Format_formatToCharacterIterator(void*, void*);
extern int32_t meth_jt_Format_upTo(void*, void*, void*, int32_t);
extern int32_t meth_jt_Format_upToWithQuotes(void*, void*, void*, int32_t, int32_t);
extern int32_t supertypeof_jt_Format(TeaVM_Class*, TeaVM_Class*);
typedef struct jt_Format_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_format_2)(void*, void*, void*, void*); // 11
    void* (*virt_formatToCharacterIterator)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void* (*virt_format_3)(void*, void*); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} jt_Format_VT;
extern jt_Format_VT jt_Format_Cls;
