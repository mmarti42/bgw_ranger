#include "DecimalFormat@dTextField.h"
#include "../lang/Object.h"
#include "../lang/StringBuffer.h"
#include "../lang/String.h"
#include "DecimalFormat.h"
#include "../../../strings.h"

void meth_jt_DecimalFormat_TextField__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9083, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat_TextField, fld_text) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jt_DecimalFormat_TextField_render(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat_TextField, fld_text);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9084, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(9085, TEAVM_METHOD(teavm_local_2, jl_StringBuffer_VT, virt_append_22)(teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jt_DecimalFormat_TextField_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jt_DecimalFormat_TextField_Cls, &supertypeof_jt_DecimalFormat_TextField))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9086, teavm_checkcast(teavm_local_1, &jt_DecimalFormat_TextField_Cls, &supertypeof_jt_DecimalFormat_TextField));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat_TextField, fld_text);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9087, teavm_nullCheck(teavm_local_3));
        teavm_local_5 = TEAVM_FIELD(teavm_local_3, cls_jt_DecimalFormat_TextField, fld_text);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9088, meth_jl_String_equals(TEAVM_WITH_CALL_SITE_ID(9089, teavm_nullCheck(teavm_local_4)), teavm_local_5));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_DecimalFormat_TextField_hashCode(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jt_DecimalFormat_TextField, fld_text);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9090, meth_jl_String_hashCode(TEAVM_WITH_CALL_SITE_ID(9091, teavm_nullCheck(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jt_DecimalFormat_TextField(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 345 || tag >= 347) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_DecimalFormat_TextField_Cls[2];
alignas(8) jt_DecimalFormat_TextField_VT jt_DecimalFormat_TextField_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_DecimalFormat_TextField), sizeof(void*)),
        .flags = 0,
        .tag = 345,
        .modifiers = 0,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(672),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_DecimalFormat_TextField,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jt_DecimalFormat_TextField_Cls,
        .enumValues = NULL,
        .declaringClass = (TeaVM_Class*) &jt_DecimalFormat_Cls,
        .enclosingClass = (TeaVM_Class*) &jt_DecimalFormat_Cls,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_DecimalFormat_TextField_hashCode,
    .virt_equals = &meth_jt_DecimalFormat_TextField_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_render = &meth_jt_DecimalFormat_TextField_render
};
static int16_t teavm_classLayouts_jt_DecimalFormat_TextField_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jt_DecimalFormat_TextField, fld_text)
};
void sysinitclass_jt_DecimalFormat_TextField() {
}
