#include "NumberFormat.h"
#include "Format.h"
#include "../math/RoundingMode.h"
#include "../util/Locale.h"
#include "../util/Currency.h"
#include "../lang/Number.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../org/teavm/classlib/impl/unicode/CLDRHelper.h"
#include "DecimalFormat.h"
#include "DecimalFormatSymbols.h"
#include "../lang/Enum.h"
#include "../util/Objects.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_jt_NumberFormat__init_(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8199, meth_jt_Format__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_groupingUsed) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits) = INT32_C(40);
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits) = INT32_C(3);
    TEAVM_WITH_CALL_SITE_ID(8200, teavm_initializeClass((TeaVM_Class*) &jm_RoundingMode_Cls, &initclass_jm_RoundingMode));
    teavm_local_1 = sfld_jm_RoundingMode_HALF_EVEN;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_roundingMode) = teavm_local_1;
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8201, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8202, meth_ju_Currency_getInstance_0(teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_currency) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jt_NumberFormat_getCurrency(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_currency);
}
int32_t meth_jt_NumberFormat_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == teavm_this_)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jt_NumberFormat_Cls, &supertypeof_jt_NumberFormat))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8203, teavm_checkcast(teavm_local_1, &jt_NumberFormat_Cls, &supertypeof_jt_NumberFormat));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_groupingUsed);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8204, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = ((!((teavm_local_2 == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_groupingUsed)) && ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_parseIntegerOnly) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_parseIntegerOnly)) && ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_maximumFractionDigits)) && ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_maximumIntegerDigits)) && ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_minimumFractionDigits)) && ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_minimumIntegerDigits)) && ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_roundingMode) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_roundingMode)) && (TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_currency) == TEAVM_FIELD(teavm_local_3, cls_jt_NumberFormat, fld_currency)))))))))) ? INT32_C(0) : INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jt_NumberFormat_format(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    double teavm_local_5;
    int64_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (teavm_instanceof(teavm_local_1, &jl_Number_Cls, &supertypeof_jl_Number)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8205, teavm_checkcast(teavm_local_1, &jl_Number_Cls, &supertypeof_jl_Number));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8206, teavm_nullCheck(teavm_local_4));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8207, TEAVM_METHOD(teavm_local_4, jl_Number_VT, virt_doubleValue)(teavm_local_4));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8208, TEAVM_METHOD(teavm_local_4, jl_Number_VT, virt_longValue)(teavm_local_4));
        if ((teavm_local_5 != ((double) teavm_local_6))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8209, TEAVM_METHOD(teavm_this_, jt_NumberFormat_VT, virt_format_0)(teavm_this_, teavm_local_5, teavm_local_2, teavm_local_3));
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8210, TEAVM_METHOD(teavm_this_, jt_NumberFormat_VT, virt_format_1)(teavm_this_, teavm_local_6, teavm_local_2, teavm_local_3));
        }
        TEAVM_RELEASE_STACK;
        return teavm_local_4;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8211, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(8212, meth_jl_IllegalArgumentException__init_(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(8213, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
void* meth_jt_NumberFormat_getIntegerInstance(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8214, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8215, meth_ju_Locale_getLanguage(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8216, meth_ju_Locale_getCountry(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8217, meth_otciu_CLDRHelper_resolveNumberFormat(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8218, meth_otr_Allocator_allocate(&jt_DecimalFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8219, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8220, meth_jt_DecimalFormatSymbols__init_(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8221, meth_jt_DecimalFormat__init_(teavm_local_5, teavm_local_4, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(8222, TEAVM_METHOD(teavm_local_5, jt_DecimalFormat_VT, virt_setParseIntegerOnly)(teavm_local_5, INT32_C(1)));
    TEAVM_WITH_CALL_SITE_ID(8223, TEAVM_METHOD(teavm_local_5, jt_DecimalFormat_VT, virt_setMinimumFractionDigits)(teavm_local_5, INT32_C(0)));
    TEAVM_WITH_CALL_SITE_ID(8224, TEAVM_METHOD(teavm_local_5, jt_DecimalFormat_VT, virt_setMaximumFractionDigits)(teavm_local_5, INT32_C(0)));
    TEAVM_WITH_CALL_SITE_ID(8225, TEAVM_METHOD(teavm_local_5, jt_DecimalFormat_VT, virt_setDecimalSeparatorAlwaysShown)(teavm_local_5, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jt_NumberFormat_getInstance() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8226, meth_jt_NumberFormat_getNumberInstance());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jt_NumberFormat_getInstance_0(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8227, meth_jt_NumberFormat_getNumberInstance_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jt_NumberFormat_getMaximumFractionDigits(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits);
}
int32_t meth_jt_NumberFormat_getMaximumIntegerDigits(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits);
}
int32_t meth_jt_NumberFormat_getMinimumFractionDigits(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits);
}
int32_t meth_jt_NumberFormat_getMinimumIntegerDigits(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits);
}
void* meth_jt_NumberFormat_getNumberInstance() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8228, meth_ju_Locale_getDefault());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8229, meth_jt_NumberFormat_getNumberInstance_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jt_NumberFormat_getNumberInstance_0(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8230, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8231, meth_ju_Locale_getLanguage(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8232, meth_ju_Locale_getCountry(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8233, meth_otciu_CLDRHelper_resolveNumberFormat(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8234, meth_otr_Allocator_allocate(&jt_DecimalFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8235, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8236, meth_jt_DecimalFormatSymbols__init_(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8237, meth_jt_DecimalFormat__init_(teavm_local_3, teavm_local_4, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_NumberFormat_getPercentInstance(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8238, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8239, meth_ju_Locale_getLanguage(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8240, meth_ju_Locale_getCountry(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8241, meth_otciu_CLDRHelper_resolvePercentFormat(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8242, meth_otr_Allocator_allocate(&jt_DecimalFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8243, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8244, meth_jt_DecimalFormatSymbols__init_(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8245, meth_jt_DecimalFormat__init_(teavm_local_3, teavm_local_4, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jt_NumberFormat_getCurrencyInstance(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8246, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8247, meth_ju_Locale_getLanguage(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8248, meth_ju_Locale_getCountry(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8249, meth_otciu_CLDRHelper_resolveCurrencyFormat(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8250, meth_otr_Allocator_allocate(&jt_DecimalFormat_Cls));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8251, meth_otr_Allocator_allocate(&jt_DecimalFormatSymbols_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8252, meth_jt_DecimalFormatSymbols__init_(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8253, meth_jt_DecimalFormat__init_(teavm_local_3, teavm_local_4, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jt_NumberFormat_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = (((((((!TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_groupingUsed)) ? INT32_C(1237) : INT32_C(1231)) + ((!TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_parseIntegerOnly)) ? INT32_C(1237) : INT32_C(1231))) + TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits)) + TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits)) + TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits)) + TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_roundingMode);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = (teavm_local_1 + TEAVM_WITH_CALL_SITE_ID(8254, meth_jl_Enum_hashCode(TEAVM_WITH_CALL_SITE_ID(8255, teavm_nullCheck(teavm_local_2)))));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_currency);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = (teavm_local_1 + TEAVM_WITH_CALL_SITE_ID(8256, meth_ju_Objects_hashCode(teavm_local_2)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jt_NumberFormat_isGroupingUsed(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_groupingUsed);
}
void meth_jt_NumberFormat_setGroupingUsed(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_groupingUsed) = teavm_local_1;
}
void meth_jt_NumberFormat_setMaximumFractionDigits(void* teavm_this_, int32_t teavm_local_1) {
    if ((teavm_local_1 < INT32_C(0))) {
        teavm_local_1 = INT32_C(0);
    }
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits) = teavm_local_1;
    if ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits) < TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits))) {
        TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits) = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits);
    }
}
void meth_jt_NumberFormat_setMaximumIntegerDigits(void* teavm_this_, int32_t teavm_local_1) {
    if ((teavm_local_1 < INT32_C(0))) {
        teavm_local_1 = INT32_C(0);
    }
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits) = teavm_local_1;
    if ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits) < TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits))) {
        TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits) = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits);
    }
}
void meth_jt_NumberFormat_setMinimumFractionDigits(void* teavm_this_, int32_t teavm_local_1) {
    if ((teavm_local_1 < INT32_C(0))) {
        teavm_local_1 = INT32_C(0);
    }
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits) = teavm_local_1;
    if ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits) < TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits))) {
        TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumFractionDigits) = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumFractionDigits);
    }
}
void meth_jt_NumberFormat_setMinimumIntegerDigits(void* teavm_this_, int32_t teavm_local_1) {
    if ((teavm_local_1 < INT32_C(0))) {
        teavm_local_1 = INT32_C(0);
    }
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits) = teavm_local_1;
    if ((TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits) < TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits))) {
        TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_maximumIntegerDigits) = TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_minimumIntegerDigits);
    }
}
void meth_jt_NumberFormat_setParseIntegerOnly(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_parseIntegerOnly) = teavm_local_1;
}
void* meth_jt_NumberFormat_getRoundingMode(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jt_NumberFormat, fld_roundingMode);
}
int32_t supertypeof_jt_NumberFormat(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1216 || tag >= 1222) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jt_NumberFormat_Cls[3];
alignas(8) jt_NumberFormat_VT jt_NumberFormat_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jt_NumberFormat), sizeof(void*)),
        .flags = 0,
        .tag = 1216,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jt_NumberFormat,
        .superclass = (TeaVM_Class*) &jt_Format_Cls,
        .layout = teavm_classLayouts_jt_NumberFormat_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jt_NumberFormat_hashCode,
    .virt_equals = &meth_jt_NumberFormat_equals,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_format_2 = &meth_jt_NumberFormat_format,
    .virt_formatToCharacterIterator = &meth_jt_Format_formatToCharacterIterator,
    .virt_setMaximumFractionDigits = &meth_jt_NumberFormat_setMaximumFractionDigits,
    .virt_setMaximumIntegerDigits = &meth_jt_NumberFormat_setMaximumIntegerDigits,
    .virt_setMinimumFractionDigits = &meth_jt_NumberFormat_setMinimumFractionDigits,
    .virt_getMinimumIntegerDigits = &meth_jt_NumberFormat_getMinimumIntegerDigits,
    .virt_isGroupingUsed = &meth_jt_NumberFormat_isGroupingUsed,
    .virt_getMaximumIntegerDigits = &meth_jt_NumberFormat_getMaximumIntegerDigits,
    .virt_setMinimumIntegerDigits = &meth_jt_NumberFormat_setMinimumIntegerDigits,
    .virt_setParseIntegerOnly = &meth_jt_NumberFormat_setParseIntegerOnly,
    .virt_getMaximumFractionDigits = &meth_jt_NumberFormat_getMaximumFractionDigits,
    .virt_format_3 = &meth_jt_Format_format,
    .virt_getMinimumFractionDigits = &meth_jt_NumberFormat_getMinimumFractionDigits,
    .virt_getCurrency = &meth_jt_NumberFormat_getCurrency,
    .virt_getRoundingMode = &meth_jt_NumberFormat_getRoundingMode,
    .virt_setGroupingUsed = &meth_jt_NumberFormat_setGroupingUsed
};
static int16_t teavm_classLayouts_jt_NumberFormat_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jt_NumberFormat, fld_roundingMode), (int16_t) offsetof(cls_jt_NumberFormat, fld_currency)
};
void sysinitclass_jt_NumberFormat() {
}
