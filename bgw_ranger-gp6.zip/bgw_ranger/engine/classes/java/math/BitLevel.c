#include "BitLevel.h"
#include "../lang/Object.h"
#include "BigInteger.h"
#include "../lang/Integer.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/System.h"
#include "../../../strings.h"

int32_t meth_jm_BitLevel_bitLength(void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8403, teavm_nullCheck(teavm_local_1));
    if ((!TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign))) {
        teavm_local_2 = INT32_C(0);
    } else {
        teavm_local_3 = (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) << INT32_C(5));
        teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        teavm_local_2 = (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8404, teavm_nullCheck(teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, TEAVM_WITH_CALL_SITE_ID(8405, teavm_checkBounds(teavm_local_2, teavm_local_4)));
        if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) < INT32_C(0))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8406, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_getFirstNonzeroDigit)(teavm_local_1));
            if ((teavm_local_6 == (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) - INT32_C(1)))) {
                teavm_local_5 = (teavm_local_5 + -INT32_C(1));
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = (teavm_local_3 - TEAVM_WITH_CALL_SITE_ID(8407, meth_jl_Integer_numberOfLeadingZeros(teavm_local_5)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BitLevel_nonZeroDroppedBits(int32_t teavm_local_1, TeaVM_Array* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = (teavm_local_1 >> INT32_C(5));
    teavm_local_4 = (teavm_local_1 & INT32_C(31));
    teavm_local_5 = INT32_C(0);
    while (1) {
        teavm_local_6 = teavm_compare_i32(teavm_local_5, teavm_local_3);
        if ((teavm_local_6 >= INT32_C(0))) {
            goto teavm_label_3;
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8408, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = teavm_local_2;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8409, teavm_checkBounds(teavm_local_5, teavm_local_7));
        if (TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_5)) {
            goto teavm_label_2;
        }
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
teavm_label_1:;
    if ((!teavm_local_6)) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8410, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = teavm_local_2;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8411, teavm_checkBounds(teavm_local_5, teavm_local_7));
        if ((!(TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_5) << (INT32_C(32) - teavm_local_4)))) {
            goto teavm_label_5;
        }
    }
    teavm_local_6 = INT32_C(1);
    goto teavm_label_4;
teavm_label_5:;
    teavm_local_6 = INT32_C(0);
teavm_label_4:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void* meth_jm_BitLevel_shiftLeft_0(void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TeaVM_Array* teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_3 = (teavm_local_2 >> INT32_C(5));
    teavm_local_4 = (teavm_local_2 & INT32_C(31));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8412, teavm_nullCheck(teavm_local_1));
    teavm_local_5 = ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) + teavm_local_3) + (teavm_local_4 ? INT32_C(1) : INT32_C(0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8413, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_5));
    teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(8414, meth_jm_BitLevel_shiftLeft(teavm_local_6, teavm_local_7, teavm_local_3, teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8415, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(8416, meth_jm_BigInteger__init_(teavm_local_8, teavm_local_4, teavm_local_5, teavm_local_6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(8417, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_8));
    TEAVM_RELEASE_STACK;
    return teavm_local_8;
}
void meth_jm_BitLevel_shiftLeft(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    TeaVM_Array* teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((!teavm_local_4)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8418, teavm_nullCheck(teavm_local_1));
        teavm_local_5 = (TEAVM_ARRAY_LENGTH(teavm_local_1) - teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(8419, meth_jl_System_fastArraycopy(teavm_local_2, INT32_C(0), teavm_local_1, teavm_local_3, teavm_local_5));
    } else {
        teavm_local_6 = (INT32_C(32) - teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8420, teavm_nullCheck(teavm_local_1));
        teavm_local_7 = teavm_local_1;
        teavm_local_8 = (TEAVM_ARRAY_LENGTH(teavm_local_7) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8421, teavm_checkBounds(teavm_local_8, teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_9) = INT32_C(0);
        while (1) {
            if (!(teavm_local_9 > teavm_local_3)) break;
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8422, teavm_checkBounds(teavm_local_9, teavm_local_7));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_9);
            teavm_local_10 = ((teavm_local_9 - teavm_local_3) - INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8423, teavm_nullCheck(teavm_local_2));
            teavm_local_11 = teavm_local_2;
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8424, teavm_checkBounds(teavm_local_10, teavm_local_11));
            TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_9) = (teavm_local_5 | ((int32_t) ((uint32_t) TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_8) >> teavm_local_6)));
            teavm_local_5 = (teavm_local_9 - INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_7, int32_t, TEAVM_WITH_CALL_SITE_ID(8425, teavm_checkBounds(teavm_local_5, teavm_local_7))) = (TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_8) << teavm_local_4);
            teavm_local_9 = (teavm_local_9 + -INT32_C(1));
        }
    }
    teavm_local_9 = INT32_C(0);
    while (1) {
        if (!(teavm_local_9 < teavm_local_3)) break;
        teavm_local_11 = teavm_local_1;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8426, teavm_checkBounds(teavm_local_9, teavm_local_11));
        TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_9) = INT32_C(0);
        teavm_local_9 = (teavm_local_9 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jm_BitLevel_shiftLeftOneBit(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_3)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8427, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = teavm_local_2;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8428, teavm_checkBounds(teavm_local_5, teavm_local_6));
        teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_5);
        teavm_local_8 = ((teavm_local_7 << INT32_C(1)) | teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8429, teavm_nullCheck(teavm_local_1));
        teavm_local_6 = teavm_local_1;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8430, teavm_checkUpperBound(teavm_local_5, teavm_local_6));
        TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_5) = teavm_local_8;
        teavm_local_4 = ((int32_t) ((uint32_t) teavm_local_7 >> INT32_C(31)));
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
    if (teavm_local_4) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8431, teavm_nullCheck(teavm_local_1));
        teavm_local_6 = teavm_local_1;
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8432, teavm_checkBounds(teavm_local_3, teavm_local_6));
        TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_3) = teavm_local_4;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jm_BitLevel_shiftLeftOneBit_0(void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8433, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
    teavm_local_3 = (teavm_local_2 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8434, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_3));
    teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(8435, meth_jm_BitLevel_shiftLeftOneBit(teavm_local_4, teavm_local_5, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8436, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(8437, meth_jm_BigInteger__init_(teavm_local_6, teavm_local_7, teavm_local_3, teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(8438, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_6));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void* meth_jm_BitLevel_shiftRight_0(void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_3 = (teavm_local_2 >> INT32_C(5));
    teavm_local_4 = (teavm_local_2 & INT32_C(31));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8439, teavm_nullCheck(teavm_local_1));
    if ((teavm_local_3 >= TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength))) {
        if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) >= INT32_C(0))) {
            TEAVM_WITH_CALL_SITE_ID(8440, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
            teavm_local_5 = sfld_jm_BigInteger_ZERO;
        } else {
            TEAVM_WITH_CALL_SITE_ID(8441, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
            teavm_local_5 = sfld_jm_BigInteger_MINUS_ONE;
        }
    } else {
        teavm_local_6 = (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) - teavm_local_3);
        teavm_local_7 = (teavm_local_6 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8442, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_7));
        teavm_local_9 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        TEAVM_WITH_CALL_SITE_ID(8443, meth_jm_BitLevel_shiftRight(teavm_local_8, teavm_local_6, teavm_local_9, teavm_local_3, teavm_local_4));
        if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) >= INT32_C(0))) {
            teavm_local_7 = teavm_local_6;
        } else {
            teavm_local_10 = INT32_C(0);
            while (1) {
                teavm_local_11 = teavm_compare_i32(teavm_local_10, teavm_local_3);
                if ((teavm_local_11 >= INT32_C(0))) {
                    goto teavm_label_4;
                }
                teavm_local_9 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8444, teavm_nullCheck(teavm_local_9));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8445, teavm_checkBounds(teavm_local_10, teavm_local_9));
                if (TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_10)) {
                    goto teavm_label_3;
                }
                teavm_local_10 = (teavm_local_10 + INT32_C(1));
            }
        teavm_label_4:;
            goto teavm_label_2;
        teavm_label_3:;
        teavm_label_2:;
            if ((teavm_local_11 >= INT32_C(0))) {
                if ((teavm_local_4 <= INT32_C(0))) {
                    teavm_local_7 = teavm_local_6;
                    goto teavm_label_1;
                }
                teavm_local_9 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8446, teavm_nullCheck(teavm_local_9));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8447, teavm_checkBounds(teavm_local_10, teavm_local_9));
                if ((!(TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_10) << (INT32_C(32) - teavm_local_4)))) {
                    teavm_local_7 = teavm_local_6;
                    goto teavm_label_1;
                }
            }
            teavm_local_12 = INT32_C(0);
            while (1) {
                teavm_local_11 = teavm_compare_i32(teavm_local_12, teavm_local_6);
                if ((teavm_local_11 >= INT32_C(0))) {
                    goto teavm_label_7;
                }
                teavm_local_9 = teavm_local_8;
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8448, teavm_checkBounds(teavm_local_12, teavm_local_9));
                if ((TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_12) != -INT32_C(1))) {
                    goto teavm_label_6;
                }
                TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_12) = INT32_C(0);
                teavm_local_12 = (teavm_local_12 + INT32_C(1));
            }
        teavm_label_7:;
            goto teavm_label_5;
        teavm_label_6:;
        teavm_label_5:;
            if (teavm_local_11) {
                teavm_local_7 = teavm_local_6;
            }
            teavm_local_9 = teavm_local_8;
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(8449, teavm_checkBounds(teavm_local_12, teavm_local_9));
            TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_11) = (TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_11) + INT32_C(1));
        }
    teavm_label_1:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8450, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        teavm_local_12 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_WITH_CALL_SITE_ID(8451, meth_jm_BigInteger__init_(teavm_local_5, teavm_local_12, teavm_local_7, teavm_local_8));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(8452, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_5));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void meth_jm_BitLevel_inplaceShiftRight(void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8453, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8454, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_signum)(teavm_local_1));
    if ((teavm_local_2 && TEAVM_WITH_CALL_SITE_ID(8455, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_signum)(teavm_local_1)))) {
        teavm_local_4 = (teavm_local_2 >> INT32_C(5));
        TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) = (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) - teavm_local_4);
        teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        teavm_local_6 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        teavm_local_8 = (teavm_local_2 & INT32_C(31));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        if (((!TEAVM_WITH_CALL_SITE_ID(8456, meth_jm_BitLevel_shiftRight(teavm_local_5, teavm_local_6, teavm_local_7, teavm_local_4, teavm_local_8))) && (teavm_local_3 < INT32_C(0)))) {
            teavm_local_9 = INT32_C(0);
            while (1) {
                if (!(teavm_local_9 < TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength))) break;
                teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8457, teavm_nullCheck(teavm_local_5));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8458, teavm_checkBounds(teavm_local_9, teavm_local_5));
                if ((TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_9) != -INT32_C(1))) {
                    goto teavm_label_2;
                }
                teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8459, teavm_nullCheck(teavm_local_5));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8460, teavm_checkUpperBound(teavm_local_9, teavm_local_5));
                TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_9) = INT32_C(0);
                teavm_local_9 = (teavm_local_9 + INT32_C(1));
            }
            goto teavm_label_1;
        teavm_label_2:;
        teavm_label_1:;
            if ((teavm_local_9 == TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength))) {
                TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) = (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) + INT32_C(1));
            }
            teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8461, teavm_nullCheck(teavm_local_5));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8462, teavm_checkBounds(teavm_local_9, teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_9) = (TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_9) + INT32_C(1));
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(8463, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(8464, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_unCache)(teavm_local_1));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jm_BitLevel_shiftRight(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    TeaVM_Array* teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_6 = INT32_C(1);
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_4)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8465, teavm_nullCheck(teavm_local_3));
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8466, teavm_checkBounds(teavm_local_7, teavm_local_8));
        teavm_local_6 = (teavm_local_6 & (TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7) ? INT32_C(0) : INT32_C(1)));
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    if ((!teavm_local_5)) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(8467, meth_jl_System_fastArraycopy(teavm_local_3, teavm_local_4, teavm_local_1, INT32_C(0), teavm_local_2));
    } else {
        teavm_local_9 = (INT32_C(32) - teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8468, teavm_nullCheck(teavm_local_3));
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8469, teavm_checkBounds(teavm_local_7, teavm_local_8));
        teavm_local_6 = (teavm_local_6 & ((TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7) << teavm_local_9) ? INT32_C(0) : INT32_C(1)));
        teavm_local_10 = INT32_C(0);
        while (1) {
            if (!(teavm_local_10 < (teavm_local_2 - INT32_C(1)))) break;
            teavm_local_11 = (teavm_local_10 + teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8470, teavm_checkBounds(teavm_local_11, teavm_local_8));
            teavm_local_11 = (((int32_t) ((uint32_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12) >> teavm_local_5)) | (TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(8471, teavm_checkBounds((teavm_local_12 + INT32_C(1)), teavm_local_8))) << teavm_local_9));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8472, teavm_nullCheck(teavm_local_1));
            teavm_local_13 = teavm_local_1;
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8473, teavm_checkBounds(teavm_local_10, teavm_local_13));
            TEAVM_ARRAY_AT(teavm_local_13, int32_t, teavm_local_12) = teavm_local_11;
            teavm_local_10 = (teavm_local_12 + INT32_C(1));
        }
        teavm_local_11 = (teavm_local_10 + teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_12 = ((int32_t) ((uint32_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(8474, teavm_checkBounds(teavm_local_11, teavm_local_8))) >> teavm_local_5));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8475, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(8476, teavm_checkBounds(teavm_local_10, teavm_local_8))) = teavm_local_12;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t supertypeof_jm_BitLevel(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 329 || tag >= 331) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jm_BitLevel_VT jm_BitLevel_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_BitLevel), sizeof(void*)),
            .flags = 0,
            .tag = 329,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jm_BitLevel,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_jm_BitLevel() {
}
