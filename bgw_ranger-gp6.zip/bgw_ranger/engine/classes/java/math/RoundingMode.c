#include "RoundingMode.h"
#include "../lang/Enum.h"
#include "../lang/Object.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"

void* sfld_jm_RoundingMode_UP;
void* sfld_jm_RoundingMode_DOWN;
void* sfld_jm_RoundingMode_CEILING;
void* sfld_jm_RoundingMode_FLOOR;
void* sfld_jm_RoundingMode_HALF_UP;
void* sfld_jm_RoundingMode_HALF_DOWN;
void* sfld_jm_RoundingMode_HALF_EVEN;
void* sfld_jm_RoundingMode_UNNECESSARY;
TeaVM_Array* sfld_jm_RoundingMode__VALUES;
TeaVM_Array* meth_jm_RoundingMode_values() {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44325, teavm_initializeClass((TeaVM_Class*) &jm_RoundingMode_Cls, &initclass_jm_RoundingMode));
    teavm_local_1 = sfld_jm_RoundingMode__VALUES;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44326, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(44327, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44328, teavm_checkcast(teavm_local_2, teavm_getArrayClass((TeaVM_Class*) &jm_RoundingMode_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jm_RoundingMode__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44329, teavm_initializeClass((TeaVM_Class*) &jm_RoundingMode_Cls, &initclass_jm_RoundingMode));
    TEAVM_WITH_CALL_SITE_ID(44330, meth_jl_Enum__init_(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_FIELD(teavm_this_, cls_jm_RoundingMode, fld_bigDecimalRM) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
TeaVM_Array* meth_jm_RoundingMode__values() {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44331, teavm_initializeClass((TeaVM_Class*) &jm_RoundingMode_Cls, &initclass_jm_RoundingMode));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44332, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_RoundingMode_Cls), INT32_C(8)));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = sfld_jm_RoundingMode_UP;
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(0)) = teavm_local_3;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(1)) = sfld_jm_RoundingMode_DOWN;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(2)) = sfld_jm_RoundingMode_CEILING;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(3)) = sfld_jm_RoundingMode_FLOOR;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(4)) = sfld_jm_RoundingMode_HALF_UP;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(5)) = sfld_jm_RoundingMode_HALF_DOWN;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(6)) = sfld_jm_RoundingMode_HALF_EVEN;
    TEAVM_ARRAY_AT(teavm_local_2, void*, INT32_C(7)) = sfld_jm_RoundingMode_UNNECESSARY;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jm_RoundingMode__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44333, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44334, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8163), INT32_C(0), INT32_C(0)));
    sfld_jm_RoundingMode_UP = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44335, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44336, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8164), INT32_C(1), INT32_C(1)));
    sfld_jm_RoundingMode_DOWN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44337, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44338, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8165), INT32_C(2), INT32_C(2)));
    sfld_jm_RoundingMode_CEILING = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44339, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44340, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8166), INT32_C(3), INT32_C(3)));
    sfld_jm_RoundingMode_FLOOR = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44341, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44342, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8167), INT32_C(4), INT32_C(4)));
    sfld_jm_RoundingMode_HALF_UP = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44343, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44344, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8168), INT32_C(5), INT32_C(5)));
    sfld_jm_RoundingMode_HALF_DOWN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44345, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44346, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8169), INT32_C(6), INT32_C(6)));
    sfld_jm_RoundingMode_HALF_EVEN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44347, meth_otr_Allocator_allocate(&jm_RoundingMode_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44348, meth_jm_RoundingMode__init_(teavm_local_1, TEAVM_GET_STRING(8170), INT32_C(7), INT32_C(7)));
    sfld_jm_RoundingMode_UNNECESSARY = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jm_RoundingMode__VALUES = TEAVM_WITH_CALL_SITE_ID(44349, meth_jm_RoundingMode__values());
    TEAVM_RELEASE_STACK;
}
void initclass_jm_RoundingMode() {
    TeaVM_Class* cls = (TeaVM_Class*) &jm_RoundingMode_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jm_RoundingMode__clinit_();
    }
}
int32_t supertypeof_jm_RoundingMode(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2202 || tag >= 2204) return INT32_C(0);
    return INT32_C(1);
}
static void* jm_RoundingMode_Cls_enumConstants[9] = { (void*) (intptr_t) 8, &sfld_jm_RoundingMode_UP, &sfld_jm_RoundingMode_DOWN, &sfld_jm_RoundingMode_CEILING, &sfld_jm_RoundingMode_FLOOR, &sfld_jm_RoundingMode_HALF_UP, &sfld_jm_RoundingMode_HALF_DOWN, &sfld_jm_RoundingMode_HALF_EVEN, &sfld_jm_RoundingMode_UNNECESSARY };
alignas(8) jm_RoundingMode_VT jm_RoundingMode_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_RoundingMode), sizeof(void*)),
            .flags = 0,
            .tag = 2202,
            .modifiers = 65553,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(8171),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jm_RoundingMode,
            .superclass = (TeaVM_Class*) &jl_Enum_Cls,
            .layout = NULL,
            .enumValues = jm_RoundingMode_Cls_enumConstants,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Enum_hashCode,
        .virt_equals = &meth_jl_Enum_equals,
        .virt_toString = &meth_jl_Enum_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_name = &meth_jl_Enum_name,
        .virt_compareTo = &meth_jl_Enum_compareTo,
        .virt_getDeclaringClass = &meth_jl_Enum_getDeclaringClass,
        .virt_compareTo_0 = &meth_jl_Enum_compareTo_0,
        .virt_ordinal = &meth_jl_Enum_ordinal
    }
};
static void** teavm_gc_localStaticRoots_jm_RoundingMode_Cls[9] = {
(void**) &sfld_jm_RoundingMode_UP, (void**) &sfld_jm_RoundingMode_DOWN, (void**) &sfld_jm_RoundingMode_CEILING, (void**) &sfld_jm_RoundingMode_FLOOR, (void**) &sfld_jm_RoundingMode_HALF_UP, (void**) &sfld_jm_RoundingMode_HALF_DOWN, (void**) &sfld_jm_RoundingMode_HALF_EVEN, (void**) &sfld_jm_RoundingMode_UNNECESSARY, (void**) &sfld_jm_RoundingMode__VALUES
};
void sysinitclass_jm_RoundingMode() {
sfld_jm_RoundingMode_UP = NULL;
sfld_jm_RoundingMode_DOWN = NULL;
sfld_jm_RoundingMode_CEILING = NULL;
sfld_jm_RoundingMode_FLOOR = NULL;
sfld_jm_RoundingMode_HALF_UP = NULL;
sfld_jm_RoundingMode_HALF_DOWN = NULL;
sfld_jm_RoundingMode_HALF_EVEN = NULL;
sfld_jm_RoundingMode_UNNECESSARY = NULL;
sfld_jm_RoundingMode__VALUES = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jm_RoundingMode_Cls, 9);
}
