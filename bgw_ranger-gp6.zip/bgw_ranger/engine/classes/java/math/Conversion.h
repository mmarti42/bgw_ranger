#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Conversion.h"

extern void sysinitclass_jm_Conversion();
typedef struct cls_jm_Conversion {
    struct TeaVM_Object parent;
} cls_jm_Conversion;
extern TeaVM_Array* sfld_jm_Conversion_digitFitInInt;
extern TeaVM_Array* sfld_jm_Conversion_bigRadices;
extern double meth_jm_Conversion_bigInteger2Double(void*);
extern void meth_jm_Conversion__clinit_();
extern void initclass_jm_Conversion();
extern int32_t supertypeof_jm_Conversion(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_Conversion_VT {
    jl_Object_VT parent;
} jm_Conversion_VT;
extern jm_Conversion_VT jm_Conversion_Cls;
