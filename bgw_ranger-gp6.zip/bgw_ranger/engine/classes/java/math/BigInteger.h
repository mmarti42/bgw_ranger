#pragma once
#include "../../../runtime.h"
#include "../lang/Number.h"
#include "BigInteger.h"

extern void sysinitclass_jm_BigInteger();
typedef struct cls_jm_BigInteger {
    struct cls_jl_Number parent;
    TeaVM_Array* fld_digits;
    int32_t fld_numberLength;
    int32_t fld_sign;
    int32_t fld_firstNonzeroDigit;
} cls_jm_BigInteger;
extern void* sfld_jm_BigInteger_ZERO;
extern void* sfld_jm_BigInteger_ONE;
extern void* sfld_jm_BigInteger_TWO;
extern void* sfld_jm_BigInteger_TEN;
extern void* sfld_jm_BigInteger_MINUS_ONE;
extern TeaVM_Array* sfld_jm_BigInteger_SMALL_VALUES;
extern TeaVM_Array* sfld_jm_BigInteger_TWO_POWS;
extern void meth_jm_BigInteger__init__0(void*, int32_t, int32_t);
extern void meth_jm_BigInteger__init_(void*, int32_t, int32_t, TeaVM_Array*);
extern void meth_jm_BigInteger__init__1(void*, int32_t, int64_t);
extern void meth_jm_BigInteger__init__2(void*, int32_t, TeaVM_Array*);
extern void* meth_jm_BigInteger_valueOf(int64_t);
extern void* meth_jm_BigInteger_abs(void*);
extern void* meth_jm_BigInteger_negate(void*);
extern void* meth_jm_BigInteger_add(void*, void*);
extern void* meth_jm_BigInteger_subtract(void*, void*);
extern int32_t meth_jm_BigInteger_signum(void*);
extern void* meth_jm_BigInteger_shiftRight(void*, int32_t);
extern void* meth_jm_BigInteger_shiftLeft(void*, int32_t);
extern void* meth_jm_BigInteger_shiftLeftOneBit(void*);
extern int32_t meth_jm_BigInteger_bitLength(void*);
extern int32_t meth_jm_BigInteger_testBit(void*, int32_t);
extern int32_t meth_jm_BigInteger_getLowestSetBit(void*);
extern int32_t meth_jm_BigInteger_intValue(void*);
extern int64_t meth_jm_BigInteger_longValue(void*);
extern double meth_jm_BigInteger_doubleValue(void*);
extern int32_t meth_jm_BigInteger_compareTo(void*, void*);
extern int32_t meth_jm_BigInteger_equals(void*, void*);
extern int32_t meth_jm_BigInteger_equalsArrays(void*, TeaVM_Array*);
extern void* meth_jm_BigInteger_gcd(void*, void*);
extern void* meth_jm_BigInteger_multiply(void*, void*);
extern void* meth_jm_BigInteger_pow(void*, int32_t);
extern TeaVM_Array* meth_jm_BigInteger_divideAndRemainder(void*, void*);
extern void* meth_jm_BigInteger_divide(void*, void*);
extern void* meth_jm_BigInteger_remainder(void*, void*);
extern void meth_jm_BigInteger_cutOffLeadingZeroes(void*);
extern int32_t meth_jm_BigInteger_isOne(void*);
extern int32_t meth_jm_BigInteger_getFirstNonzeroDigit(void*);
extern void* meth_jm_BigInteger_copy(void*);
extern void meth_jm_BigInteger_unCache(void*);
extern void* meth_jm_BigInteger_getPowerOfTwo(int32_t);
extern void meth_jm_BigInteger__clinit_();
extern void initclass_jm_BigInteger();
extern int32_t supertypeof_jm_BigInteger(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_BigInteger_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_intValue)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    int32_t (*virt_isOne)(void*); // 13
    int64_t (*virt_longValue)(void*); // 14
    void (*pad0)(); // 15
    void* (*virt_remainder)(void*, void*); // 16
    int32_t (*virt_testBit)(void*, int32_t); // 17
    void (*pad1)(); // 18
    int32_t (*virt_compareTo_3)(void*, void*); // 19
    void* (*virt_abs)(void*); // 20
    void* (*virt_gcd)(void*, void*); // 21
    int32_t (*virt_signum)(void*); // 22
    int32_t (*virt_getFirstNonzeroDigit)(void*); // 23
    void* (*virt_shiftLeft)(void*, int32_t); // 24
    TeaVM_Array* (*virt_divideAndRemainder)(void*, void*); // 25
    void* (*virt_shiftRight)(void*, int32_t); // 26
    int32_t (*virt_bitLength)(void*); // 27
    double (*virt_doubleValue)(void*); // 28
    void* (*virt_divide)(void*, void*); // 29
    void* (*virt_add_6)(void*, void*); // 30
    void* (*virt_multiply)(void*, void*); // 31
    void* (*virt_negate)(void*); // 32
    void* (*virt_shiftLeftOneBit)(void*); // 33
    void (*pad2)(); // 34
    void (*pad3)(); // 35
    void* (*virt_subtract)(void*, void*); // 36
    int32_t (*virt_equalsArrays)(void*, TeaVM_Array*); // 37
    void (*virt_unCache)(void*); // 38
    void (*pad4)(); // 39
    void (*pad5)(); // 40
    void (*pad6)(); // 41
    void (*virt_cutOffLeadingZeroes)(void*); // 42
    void (*pad7)(); // 43
    void (*pad8)(); // 44
    void (*pad9)(); // 45
    void (*pad10)(); // 46
    void* (*virt_copy)(void*); // 47
    int32_t (*virt_getLowestSetBit)(void*); // 48
    void* (*virt_pow)(void*, int32_t); // 49
} jm_BigInteger_VT;
extern jm_BigInteger_VT jm_BigInteger_Cls;
