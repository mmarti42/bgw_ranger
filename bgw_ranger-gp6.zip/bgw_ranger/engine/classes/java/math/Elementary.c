#include "Elementary.h"
#include "../lang/Object.h"
#include "BigInteger.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrays/primitives/int.h"
#include "../../../strings.h"

int32_t meth_jm_Elementary_compareArrays(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int64_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_4 = (teavm_local_3 - INT32_C(1));
    while (1) {
        if (!(teavm_local_4 >= INT32_C(0))) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17286, teavm_nullCheck(teavm_local_1));
        teavm_local_5 = teavm_local_1;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17287, teavm_checkBounds(teavm_local_4, teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_4);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17288, teavm_nullCheck(teavm_local_2));
        teavm_local_5 = teavm_local_2;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17289, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
        if ((teavm_local_6 != TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_4))) {
            goto teavm_label_2;
        }
        teavm_local_4 = (teavm_local_4 + -INT32_C(1));
    }
    goto teavm_label_1;
teavm_label_2:;
teavm_label_1:;
    if ((teavm_local_4 < INT32_C(0))) {
        teavm_local_6 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17290, teavm_nullCheck(teavm_local_1));
        teavm_local_5 = teavm_local_1;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17291, teavm_checkBounds(teavm_local_4, teavm_local_5));
        teavm_local_7 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_4)) & INT64_C(4294967295));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17292, teavm_nullCheck(teavm_local_2));
        teavm_local_5 = teavm_local_2;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17293, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
        teavm_local_6 = ((teavm_local_7 >= (((int64_t) TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_4)) & INT64_C(4294967295))) ? INT32_C(1) : -INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void* meth_jm_Elementary_add(void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    int64_t teavm_local_9;
    int64_t teavm_local_10;
    int64_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    TeaVM_Array* teavm_local_14;
    TeaVM_Array* teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17294, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17295, teavm_nullCheck(teavm_local_2));
    teavm_local_4 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_sign);
    if (teavm_local_3) {
        if ((!teavm_local_4)) {
            teavm_local_2 = teavm_local_1;
        } else {
            teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
            teavm_local_6 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength);
            if (((teavm_local_5 + teavm_local_6) == INT32_C(2))) {
                teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17296, teavm_nullCheck(teavm_local_7));
                teavm_local_8 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_7, int32_t, TEAVM_WITH_CALL_SITE_ID(17297, teavm_checkUpperBound(INT32_C(0), teavm_local_7)))) & INT64_C(4294967295));
                teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17298, teavm_nullCheck(teavm_local_7));
                teavm_local_9 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_7, int32_t, TEAVM_WITH_CALL_SITE_ID(17299, teavm_checkUpperBound(INT32_C(0), teavm_local_7)))) & INT64_C(4294967295));
                if ((teavm_local_3 != teavm_local_4)) {
                    teavm_local_10 = ((teavm_local_3 >= INT32_C(0)) ? (teavm_local_8 - teavm_local_9) : (teavm_local_9 - teavm_local_8));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17300, meth_jm_BigInteger_valueOf(teavm_local_10));
                } else {
                    teavm_local_11 = (teavm_local_8 + teavm_local_9);
                    teavm_local_12 = ((int32_t) teavm_local_11);
                    teavm_local_13 = ((int32_t) ((int64_t) ((uint64_t) teavm_local_11 >> INT32_C(32))));
                    if ((!teavm_local_13)) {
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17301, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                        TEAVM_WITH_CALL_SITE_ID(17302, meth_jm_BigInteger__init__0(teavm_local_2, teavm_local_3, teavm_local_12));
                    } else {
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17303, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17304, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 2), teavm_local_12, teavm_local_13));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                        TEAVM_WITH_CALL_SITE_ID(17305, meth_jm_BigInteger__init_(teavm_local_2, teavm_local_3, INT32_C(2), teavm_local_7));
                    }
                }
            } else {
                if ((teavm_local_3 == teavm_local_4)) {
                    if ((teavm_local_5 < teavm_local_6)) {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        teavm_local_14 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17306, meth_jm_Elementary_add_0(teavm_local_7, teavm_local_6, teavm_local_14, teavm_local_5));
                    } else {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        teavm_local_14 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17307, meth_jm_Elementary_add_0(teavm_local_7, teavm_local_5, teavm_local_14, teavm_local_6));
                    }
                } else {
                    teavm_local_16 = teavm_compare_i32(teavm_local_5, teavm_local_6);
                    if ((!teavm_local_16)) {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        teavm_local_14 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                        teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(17308, meth_jm_Elementary_compareArrays(teavm_local_7, teavm_local_14, teavm_local_5));
                    } else {
                        teavm_local_17 = ((teavm_local_16 <= INT32_C(0)) ? -INT32_C(1) : INT32_C(1));
                    }
                    if ((!teavm_local_17)) {
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_WITH_CALL_SITE_ID(17309, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
                        teavm_local_2 = sfld_jm_BigInteger_ZERO;
                        goto teavm_label_1;
                    }
                    if ((teavm_local_17 != INT32_C(1))) {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        teavm_local_14 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17310, meth_jm_Elementary_subtract_0(teavm_local_7, teavm_local_6, teavm_local_14, teavm_local_5));
                        teavm_local_3 = teavm_local_4;
                    } else {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        teavm_local_14 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17311, meth_jm_Elementary_subtract_0(teavm_local_7, teavm_local_5, teavm_local_14, teavm_local_6));
                    }
                }
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_15);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17312, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17313, teavm_nullCheck(teavm_local_15));
                TEAVM_WITH_CALL_SITE_ID(17314, meth_jm_BigInteger__init_(teavm_local_2, teavm_local_3, TEAVM_ARRAY_LENGTH(teavm_local_15), teavm_local_15));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(17315, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_2));
            }
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jm_Elementary_add_1(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, TeaVM_Array* teavm_local_4, int32_t teavm_local_5) {
    TeaVM_Array* teavm_local_6;
    int64_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int64_t teavm_local_9;
    int32_t teavm_local_10;
    TeaVM_Array* teavm_local_11;
    int32_t teavm_local_12;
    int64_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17316, teavm_nullCheck(teavm_local_2));
    teavm_local_6 = teavm_local_2;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    teavm_local_7 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_6, int32_t, TEAVM_WITH_CALL_SITE_ID(17317, teavm_checkUpperBound(INT32_C(0), teavm_local_6)))) & INT64_C(4294967295));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17318, teavm_nullCheck(teavm_local_4));
    teavm_local_8 = teavm_local_4;
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
    teavm_local_9 = (teavm_local_7 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(17319, teavm_checkUpperBound(INT32_C(0), teavm_local_8)))) & INT64_C(4294967295)));
    teavm_local_10 = ((int32_t) teavm_local_9);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17320, teavm_nullCheck(teavm_local_1));
    teavm_local_11 = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
    TEAVM_ARRAY_AT(teavm_local_11, int32_t, TEAVM_WITH_CALL_SITE_ID(17321, teavm_checkUpperBound(INT32_C(0), teavm_local_11))) = teavm_local_10;
    teavm_local_7 = (teavm_local_9 >> INT32_C(32));
    if ((teavm_local_3 < teavm_local_5)) {
        teavm_local_12 = INT32_C(1);
        while (1) {
            if (!(teavm_local_12 < teavm_local_3)) break;
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(17322, teavm_checkBounds(teavm_local_12, teavm_local_6));
            teavm_local_13 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_12)) & INT64_C(4294967295));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(17323, teavm_checkUpperBound(teavm_local_12, teavm_local_8));
            teavm_local_7 = (teavm_local_7 + (teavm_local_13 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12)) & INT64_C(4294967295))));
            teavm_local_14 = ((int32_t) teavm_local_7);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(17324, teavm_checkUpperBound(teavm_local_12, teavm_local_11));
            TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_12) = teavm_local_14;
            teavm_local_7 = (teavm_local_7 >> INT32_C(32));
            teavm_local_12 = (teavm_local_12 + INT32_C(1));
        }
        while (1) {
            if (!(teavm_local_12 < teavm_local_5)) break;
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(17325, teavm_checkBounds(teavm_local_12, teavm_local_8));
            teavm_local_7 = (teavm_local_7 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_14)) & INT64_C(4294967295)));
            teavm_local_15 = ((int32_t) teavm_local_7);
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(17326, teavm_checkUpperBound(teavm_local_14, teavm_local_11));
            TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_14) = teavm_local_15;
            teavm_local_7 = (teavm_local_7 >> INT32_C(32));
            teavm_local_12 = (teavm_local_14 + INT32_C(1));
        }
    } else {
        teavm_local_12 = INT32_C(1);
        while (1) {
            if (!(teavm_local_12 < teavm_local_5)) break;
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(17327, teavm_checkBounds(teavm_local_12, teavm_local_6));
            teavm_local_13 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_12)) & INT64_C(4294967295));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(17328, teavm_checkUpperBound(teavm_local_12, teavm_local_8));
            teavm_local_7 = (teavm_local_7 + (teavm_local_13 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12)) & INT64_C(4294967295))));
            teavm_local_14 = ((int32_t) teavm_local_7);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(17329, teavm_checkUpperBound(teavm_local_12, teavm_local_11));
            TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_12) = teavm_local_14;
            teavm_local_7 = (teavm_local_7 >> INT32_C(32));
            teavm_local_12 = (teavm_local_12 + INT32_C(1));
        }
        while (1) {
            if (!(teavm_local_12 < teavm_local_3)) break;
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(17330, teavm_checkBounds(teavm_local_12, teavm_local_6));
            teavm_local_7 = (teavm_local_7 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_14)) & INT64_C(4294967295)));
            teavm_local_15 = ((int32_t) teavm_local_7);
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(17331, teavm_checkUpperBound(teavm_local_14, teavm_local_11));
            TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_14) = teavm_local_15;
            teavm_local_7 = (teavm_local_7 >> INT32_C(32));
            teavm_local_12 = (teavm_local_14 + INT32_C(1));
        }
    }
    if ((teavm_local_7 != INT64_C(0))) {
        teavm_local_14 = ((int32_t) teavm_local_7);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_ARRAY_AT(teavm_local_11, int32_t, TEAVM_WITH_CALL_SITE_ID(17332, teavm_checkBounds(teavm_local_12, teavm_local_11))) = teavm_local_14;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jm_Elementary_subtract(void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    int64_t teavm_local_9;
    int64_t teavm_local_10;
    int32_t teavm_local_11;
    TeaVM_Array* teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    TeaVM_Array* teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17333, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17334, teavm_nullCheck(teavm_local_2));
    teavm_local_4 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_sign);
    if (teavm_local_4) {
        if ((!teavm_local_3)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17335, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_negate)(teavm_local_2));
        } else {
            teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
            teavm_local_6 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength);
            if (((teavm_local_5 + teavm_local_6) == INT32_C(2))) {
                teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17336, teavm_nullCheck(teavm_local_7));
                teavm_local_8 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_7, int32_t, TEAVM_WITH_CALL_SITE_ID(17337, teavm_checkUpperBound(INT32_C(0), teavm_local_7)))) & INT64_C(4294967295));
                teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17338, teavm_nullCheck(teavm_local_7));
                teavm_local_9 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_7, int32_t, TEAVM_WITH_CALL_SITE_ID(17339, teavm_checkUpperBound(INT32_C(0), teavm_local_7)))) & INT64_C(4294967295));
                if ((teavm_local_3 < INT32_C(0))) {
                    teavm_local_8 = (-teavm_local_8);
                }
                if ((teavm_local_4 < INT32_C(0))) {
                    teavm_local_9 = (-teavm_local_9);
                }
                teavm_local_10 = (teavm_local_8 - teavm_local_9);
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17340, meth_jm_BigInteger_valueOf(teavm_local_10));
            } else {
                teavm_local_11 = teavm_compare_i32(teavm_local_5, teavm_local_6);
                if ((!teavm_local_11)) {
                    teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                    teavm_local_12 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_12);
                    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(17341, meth_jm_Elementary_compareArrays(teavm_local_7, teavm_local_12, teavm_local_5));
                } else {
                    teavm_local_13 = ((teavm_local_11 <= INT32_C(0)) ? -INT32_C(1) : INT32_C(1));
                }
                if ((teavm_local_13 == -INT32_C(1))) {
                    teavm_local_14 = (-teavm_local_4);
                    if ((teavm_local_3 != teavm_local_4)) {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        teavm_local_12 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17342, meth_jm_Elementary_add_0(teavm_local_7, teavm_local_6, teavm_local_12, teavm_local_5));
                    } else {
                        teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                        teavm_local_12 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17343, meth_jm_Elementary_subtract_0(teavm_local_7, teavm_local_6, teavm_local_12, teavm_local_5));
                    }
                } else if ((teavm_local_3 != teavm_local_4)) {
                    teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                    teavm_local_12 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17344, meth_jm_Elementary_add_0(teavm_local_7, teavm_local_5, teavm_local_12, teavm_local_6));
                    teavm_local_14 = teavm_local_3;
                } else {
                    if ((!teavm_local_13)) {
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_WITH_CALL_SITE_ID(17345, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
                        teavm_local_1 = sfld_jm_BigInteger_ZERO;
                        goto teavm_label_1;
                    }
                    teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                    teavm_local_12 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17346, meth_jm_Elementary_subtract_0(teavm_local_7, teavm_local_5, teavm_local_12, teavm_local_6));
                    teavm_local_14 = teavm_local_3;
                }
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_15);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17347, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(17348, teavm_nullCheck(teavm_local_15));
                TEAVM_WITH_CALL_SITE_ID(17349, meth_jm_BigInteger__init_(teavm_local_1, teavm_local_14, TEAVM_ARRAY_LENGTH(teavm_local_15), teavm_local_15));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(17350, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_1));
            }
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jm_Elementary_subtract_1(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, TeaVM_Array* teavm_local_4, int32_t teavm_local_5) {
    int64_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int64_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_6 = INT64_C(0);
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_5)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17351, teavm_nullCheck(teavm_local_2));
        teavm_local_8 = teavm_local_2;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17352, teavm_checkBounds(teavm_local_7, teavm_local_8));
        teavm_local_9 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7)) & INT64_C(4294967295));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17353, teavm_nullCheck(teavm_local_4));
        teavm_local_8 = teavm_local_4;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17354, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        teavm_local_9 = (teavm_local_6 + (teavm_local_9 - (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7)) & INT64_C(4294967295))));
        teavm_local_10 = ((int32_t) teavm_local_9);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17355, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(17356, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7) = teavm_local_10;
        teavm_local_6 = (teavm_local_9 >> INT32_C(32));
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    while (1) {
        if (!(teavm_local_7 < teavm_local_3)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17357, teavm_nullCheck(teavm_local_2));
        teavm_local_8 = teavm_local_2;
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(17358, teavm_checkBounds(teavm_local_7, teavm_local_8));
        teavm_local_9 = (teavm_local_6 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_11)) & INT64_C(4294967295)));
        teavm_local_10 = ((int32_t) teavm_local_9);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17359, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(17360, teavm_checkUpperBound(teavm_local_11, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_11) = teavm_local_10;
        teavm_local_6 = (teavm_local_9 >> INT32_C(32));
        teavm_local_7 = (teavm_local_11 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
TeaVM_Array* meth_jm_Elementary_add_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_5 = (teavm_local_2 + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(17361, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(17362, meth_jm_Elementary_add_1(teavm_local_6, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void meth_jm_Elementary_inplaceSubtract(void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17363, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
    teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
    teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17364, teavm_nullCheck(teavm_local_2));
    teavm_local_6 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
    teavm_local_7 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(17365, meth_jm_Elementary_subtract_1(teavm_local_3, teavm_local_4, teavm_local_5, teavm_local_6, teavm_local_7));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(17366, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(17367, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_unCache)(teavm_local_1));
    TEAVM_RELEASE_STACK;
}
TeaVM_Array* meth_jm_Elementary_subtract_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4) {
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(17368, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(17369, meth_jm_Elementary_subtract_1(teavm_local_5, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t supertypeof_jm_Elementary(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 963 || tag >= 965) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jm_Elementary_VT jm_Elementary_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_Elementary), sizeof(void*)),
            .flags = 0,
            .tag = 963,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jm_Elementary,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_jm_Elementary() {
}
