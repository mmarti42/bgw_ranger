#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "BitLevel.h"

extern void sysinitclass_jm_BitLevel();
typedef struct cls_jm_BitLevel {
    struct TeaVM_Object parent;
} cls_jm_BitLevel;
extern int32_t meth_jm_BitLevel_bitLength(void*);
extern int32_t meth_jm_BitLevel_nonZeroDroppedBits(int32_t, TeaVM_Array*);
extern void* meth_jm_BitLevel_shiftLeft_0(void*, int32_t);
extern void meth_jm_BitLevel_shiftLeft(TeaVM_Array*, TeaVM_Array*, int32_t, int32_t);
extern void meth_jm_BitLevel_shiftLeftOneBit(TeaVM_Array*, TeaVM_Array*, int32_t);
extern void* meth_jm_BitLevel_shiftLeftOneBit_0(void*);
extern void* meth_jm_BitLevel_shiftRight_0(void*, int32_t);
extern void meth_jm_BitLevel_inplaceShiftRight(void*, int32_t);
extern int32_t meth_jm_BitLevel_shiftRight(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern int32_t supertypeof_jm_BitLevel(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_BitLevel_VT {
    jl_Object_VT parent;
} jm_BitLevel_VT;
extern jm_BitLevel_VT jm_BitLevel_Cls;
