#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Division.h"

extern void sysinitclass_jm_Division();
typedef struct cls_jm_Division {
    struct TeaVM_Object parent;
} cls_jm_Division;
extern TeaVM_Array* meth_jm_Division_divide(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t, TeaVM_Array*, int32_t);
extern int32_t meth_jm_Division_divideArrayByInt(TeaVM_Array*, TeaVM_Array*, int32_t, int32_t);
extern int32_t meth_jm_Division_remainderArrayByInt(TeaVM_Array*, int32_t, int32_t);
extern int64_t meth_jm_Division_divideLongByInt(int64_t, int32_t);
extern TeaVM_Array* meth_jm_Division_divideAndRemainderByInteger(void*, int32_t, int32_t);
extern int32_t meth_jm_Division_multiplyAndSubtract(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jm_Division_gcdBinary(void*, void*);
extern int64_t meth_jm_Division_gcdBinary_0(int64_t, int64_t);
extern int32_t supertypeof_jm_Division(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_Division_VT {
    jl_Object_VT parent;
} jm_Division_VT;
extern jm_Division_VT jm_Division_Cls;
