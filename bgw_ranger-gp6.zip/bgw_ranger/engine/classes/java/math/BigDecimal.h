#pragma once
#include "../../../runtime.h"
#include "../lang/Number.h"
#include "BigDecimal.h"

extern void sysinitclass_jm_BigDecimal();
typedef struct cls_jm_BigDecimal {
    struct cls_jl_Number parent;
    void* fld_intVal;
    int32_t fld_bitLength;
    int64_t fld_smallValue;
    int32_t fld_scale;
    int32_t fld_precision;
} cls_jm_BigDecimal;
extern void* sfld_jm_BigDecimal_ZERO;
extern void* sfld_jm_BigDecimal_ONE;
extern void* sfld_jm_BigDecimal_TEN;
extern TeaVM_Array* sfld_jm_BigDecimal_FIVE_POW;
extern TeaVM_Array* sfld_jm_BigDecimal_TEN_POW;
extern TeaVM_Array* sfld_jm_BigDecimal_LONG_TEN_POW;
extern TeaVM_Array* sfld_jm_BigDecimal_LONG_FIVE_POW;
extern TeaVM_Array* sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH;
extern TeaVM_Array* sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH;
extern TeaVM_Array* sfld_jm_BigDecimal_BI_SCALED_BY_ZERO;
extern TeaVM_Array* sfld_jm_BigDecimal_ZERO_SCALED_BY;
extern TeaVM_Array* sfld_jm_BigDecimal_CH_ZEROS;
extern void meth_jm_BigDecimal__init__1(void*, int64_t, int32_t);
extern void meth_jm_BigDecimal__init__2(void*, int32_t, int32_t);
extern void meth_jm_BigDecimal__init__0(void*, void*);
extern void meth_jm_BigDecimal__init_(void*, void*, int32_t);
extern void* meth_jm_BigDecimal_valueOf_0(int64_t, int32_t);
extern void* meth_jm_BigDecimal_valueOf(int64_t);
extern void* meth_jm_BigDecimal_multiply(void*, void*);
extern void* meth_jm_BigDecimal_divide(void*, void*);
extern void* meth_jm_BigDecimal_negate(void*);
extern int32_t meth_jm_BigDecimal_signum(void*);
extern int32_t meth_jm_BigDecimal_isZero(void*);
extern int32_t meth_jm_BigDecimal_scale(void*);
extern int32_t meth_jm_BigDecimal_precision(void*);
extern void* meth_jm_BigDecimal_unscaledValue(void*);
extern int32_t meth_jm_BigDecimal_compareTo(void*, void*);
extern double meth_jm_BigDecimal_doubleValue(void*);
extern int32_t meth_jm_BigDecimal_aproxPrecision(void*);
extern int32_t meth_jm_BigDecimal_toIntScale(int64_t);
extern void* meth_jm_BigDecimal_zeroScaledBy(int64_t);
extern void* meth_jm_BigDecimal_getUnscaledValue(void*);
extern void meth_jm_BigDecimal_setUnscaledValue(void*, void*);
extern int32_t meth_jm_BigDecimal_bitLength(int64_t);
extern int32_t meth_jm_BigDecimal_bitLength_0(int32_t);
extern void meth_jm_BigDecimal__clinit_();
extern void initclass_jm_BigDecimal();
extern int32_t supertypeof_jm_BigDecimal(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_BigDecimal_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_intValue)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    int64_t (*virt_longValue)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    int32_t (*virt_precision)(void*); // 21
    int32_t (*virt_signum)(void*); // 22
    void* (*virt_divide_0)(void*, void*); // 23
    int32_t (*virt_compareTo_8)(void*, void*); // 24
    void (*pad7)(); // 25
    void (*pad8)(); // 26
    int32_t (*virt_scale)(void*); // 27
    double (*virt_doubleValue)(void*); // 28
    void (*pad9)(); // 29
    void (*pad10)(); // 30
    void* (*virt_negate_0)(void*); // 31
    void (*pad11)(); // 32
    void (*pad12)(); // 33
    void (*pad13)(); // 34
    void (*pad14)(); // 35
    void (*pad15)(); // 36
    void* (*virt_unscaledValue)(void*); // 37
    void (*pad16)(); // 38
    void (*pad17)(); // 39
    void (*pad18)(); // 40
    void (*pad19)(); // 41
    void (*pad20)(); // 42
    void (*pad21)(); // 43
    void (*pad22)(); // 44
    void (*pad23)(); // 45
    void (*pad24)(); // 46
    void (*pad25)(); // 47
    void* (*virt_multiply_0)(void*, void*); // 48
    void (*pad26)(); // 49
} jm_BigDecimal_VT;
extern jm_BigDecimal_VT jm_BigDecimal_Cls;
