#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Elementary.h"

extern void sysinitclass_jm_Elementary();
typedef struct cls_jm_Elementary {
    struct TeaVM_Object parent;
} cls_jm_Elementary;
extern int32_t meth_jm_Elementary_compareArrays(TeaVM_Array*, TeaVM_Array*, int32_t);
extern void* meth_jm_Elementary_add(void*, void*);
extern void meth_jm_Elementary_add_1(TeaVM_Array*, TeaVM_Array*, int32_t, TeaVM_Array*, int32_t);
extern void* meth_jm_Elementary_subtract(void*, void*);
extern void meth_jm_Elementary_subtract_1(TeaVM_Array*, TeaVM_Array*, int32_t, TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_jm_Elementary_add_0(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t);
extern void meth_jm_Elementary_inplaceSubtract(void*, void*);
extern TeaVM_Array* meth_jm_Elementary_subtract_0(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t);
extern int32_t supertypeof_jm_Elementary(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_Elementary_VT {
    jl_Object_VT parent;
} jm_Elementary_VT;
extern jm_Elementary_VT jm_Elementary_Cls;
