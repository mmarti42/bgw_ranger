#include "Conversion.h"
#include "../lang/Object.h"
#include "BigInteger.h"
#include "BitLevel.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrays/primitives/int.h"
#include "../../../strings.h"

TeaVM_Array* sfld_jm_Conversion_digitFitInInt;
TeaVM_Array* sfld_jm_Conversion_bigRadices;
double meth_jm_Conversion_bigInteger2Double(void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    double teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    int64_t teavm_local_6;
    int32_t teavm_local_7;
    int64_t teavm_local_8;
    int64_t teavm_local_9;
    int64_t teavm_local_10;
    int64_t teavm_local_11;
    int64_t teavm_local_12;
    int64_t teavm_local_13;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(40185, teavm_initializeClass((TeaVM_Class*) &jm_Conversion_Cls, &initclass_jm_Conversion));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40186, teavm_nullCheck(teavm_local_1));
    if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) >= INT32_C(2))) {
        if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) != INT32_C(2))) {
            goto teavm_label_2;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40187, teavm_nullCheck(teavm_local_2));
        if ((TEAVM_ARRAY_AT(teavm_local_2, int32_t, TEAVM_WITH_CALL_SITE_ID(40188, teavm_checkUpperBound(INT32_C(1), teavm_local_2))) <= INT32_C(0))) {
            goto teavm_label_2;
        }
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = ((double) TEAVM_WITH_CALL_SITE_ID(40189, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_longValue)(teavm_local_1)));
    goto teavm_label_1;
teavm_label_2:;
    if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) > INT32_C(32))) {
        teavm_local_3 = ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) <= INT32_C(0)) ? -INFINITY : INFINITY);
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(40190, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_abs)(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(40191, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40192, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_bitLength)(teavm_tmp_ptr_0)));
        teavm_local_6 = ((int64_t) (teavm_local_5 - INT32_C(1)));
        teavm_local_7 = (teavm_local_5 - INT32_C(54));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(40193, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_abs)(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(40194, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40195, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftRight)(teavm_tmp_ptr_0, teavm_local_7)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40196, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40197, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_longValue)(teavm_tmp_ptr_0)));
        teavm_local_9 = (teavm_local_8 & INT64_C(9007199254740991));
        if ((teavm_local_6 == INT64_C(1023))) {
            if ((teavm_local_9 == INT64_C(9007199254740991))) {
                teavm_local_3 = ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) <= INT32_C(0)) ? -INFINITY : INFINITY);
                goto teavm_label_1;
            }
            if ((teavm_local_9 == INT64_C(9007199254740990))) {
                teavm_local_3 = ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) <= INT32_C(0)) ? -0x1.fffffffffffffp1023 : 0x1.fffffffffffffp1023);
                goto teavm_label_1;
            }
        }
        if ((!(((teavm_local_9 & INT64_C(1)) == INT64_C(1)) && ((teavm_local_9 & INT64_C(2)) == INT64_C(2))))) {
            teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            if ((!TEAVM_WITH_CALL_SITE_ID(40198, meth_jm_BitLevel_nonZeroDroppedBits(teavm_local_7, teavm_local_2)))) {
                goto teavm_label_3;
            }
        }
        teavm_local_9 = (teavm_local_9 + INT64_C(2));
    teavm_label_3:;
        teavm_local_10 = (teavm_local_9 >> INT32_C(1));
        teavm_local_11 = ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) >= INT32_C(0)) ? INT64_C(0) : (int64_t) INT64_C(0x8000000000000000));
        teavm_local_12 = (((INT64_C(1023) + teavm_local_6) << INT32_C(52)) & INT64_C(9218868437227405312));
        teavm_local_13 = ((teavm_local_11 | teavm_local_12) | teavm_local_10);
        teavm_local_3 = teavm_reinterpretLongToDouble(teavm_local_13);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jm_Conversion__clinit_() {
    TEAVM_ALLOC_STACK(INT32_C(0));
    sfld_jm_Conversion_digitFitInInt = TEAVM_WITH_CALL_SITE_ID(40199, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 37), -INT32_C(1), -INT32_C(1), INT32_C(31), INT32_C(19), INT32_C(15), INT32_C(13), INT32_C(11), INT32_C(11), INT32_C(10), INT32_C(9), INT32_C(9), INT32_C(8), INT32_C(8), INT32_C(8), INT32_C(8), INT32_C(7), INT32_C(7), INT32_C(7), INT32_C(7), INT32_C(7), INT32_C(7), INT32_C(7), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(6), INT32_C(5)));
    sfld_jm_Conversion_bigRadices = TEAVM_WITH_CALL_SITE_ID(40200, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 35), (int32_t) INT32_C(0x80000000), INT32_C(1162261467), INT32_C(1073741824), INT32_C(1220703125), INT32_C(362797056), INT32_C(1977326743), INT32_C(1073741824), INT32_C(387420489), INT32_C(1000000000), INT32_C(214358881), INT32_C(429981696), INT32_C(815730721), INT32_C(1475789056), INT32_C(170859375), INT32_C(268435456), INT32_C(410338673), INT32_C(612220032), INT32_C(893871739), INT32_C(1280000000), INT32_C(1801088541), INT32_C(113379904), INT32_C(148035889), INT32_C(191102976), INT32_C(244140625), INT32_C(308915776), INT32_C(387420489), INT32_C(481890304), INT32_C(594823321), INT32_C(729000000), INT32_C(887503681), INT32_C(1073741824), INT32_C(1291467969), INT32_C(1544804416), INT32_C(1838265625), INT32_C(60466176)));
    TEAVM_RELEASE_STACK;
}
void initclass_jm_Conversion() {
    TeaVM_Class* cls = (TeaVM_Class*) &jm_Conversion_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jm_Conversion__clinit_();
    }
}
int32_t supertypeof_jm_Conversion(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1887 || tag >= 1889) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jm_Conversion_VT jm_Conversion_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_Conversion), sizeof(void*)),
            .flags = 0,
            .tag = 1887,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jm_Conversion,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jm_Conversion_Cls[2] = {
(void**) &sfld_jm_Conversion_digitFitInInt, (void**) &sfld_jm_Conversion_bigRadices
};
void sysinitclass_jm_Conversion() {
sfld_jm_Conversion_digitFitInInt = NULL;
sfld_jm_Conversion_bigRadices = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jm_Conversion_Cls, 2);
}
