#include "Division.h"
#include "../lang/Object.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Integer.h"
#include "../lang/System.h"
#include "BitLevel.h"
#include "BigInteger.h"
#include "../../../arrayclass.h"
#include "Multiplication.h"
#include "../lang/Math.h"
#include "Elementary.h"
#include "../lang/Long.h"
#include "../../../strings.h"

TeaVM_Array* meth_jm_Division_divide(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, TeaVM_Array* teavm_local_5, int32_t teavm_local_6) {
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    TeaVM_Array* teavm_local_11;
    int32_t teavm_local_12;
    TeaVM_Array* teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int64_t teavm_local_16;
    int64_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    int64_t teavm_local_20;
    int64_t teavm_local_21;
    int64_t teavm_local_22;
    int64_t teavm_local_23;
    int32_t teavm_local_24;
    int32_t teavm_local_25;
    int64_t teavm_local_26;
    int32_t teavm_local_27;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_7 = (teavm_local_4 + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8321, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_7));
    teavm_local_9 = (teavm_local_6 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8322, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_9));
    teavm_local_9 = (teavm_local_6 - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8323, teavm_nullCheck(teavm_local_5));
    teavm_local_11 = teavm_local_5;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8324, teavm_checkBounds(teavm_local_9, teavm_local_11));
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8325, meth_jl_Integer_numberOfLeadingZeros(TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_9)));
    if ((!teavm_local_12)) {
        TEAVM_WITH_CALL_SITE_ID(8326, meth_jl_System_fastArraycopy(teavm_local_3, INT32_C(0), teavm_local_8, INT32_C(0), teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(8327, meth_jl_System_fastArraycopy(teavm_local_5, INT32_C(0), teavm_local_10, INT32_C(0), teavm_local_6));
    } else {
        TEAVM_WITH_CALL_SITE_ID(8328, meth_jm_BitLevel_shiftLeft(teavm_local_10, teavm_local_5, INT32_C(0), teavm_local_12));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(8329, meth_jm_BitLevel_shiftLeft(teavm_local_8, teavm_local_3, INT32_C(0), teavm_local_12));
    }
    teavm_local_13 = teavm_local_10;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_13, int32_t, TEAVM_WITH_CALL_SITE_ID(8330, teavm_checkUpperBound(teavm_local_9, teavm_local_13)));
    teavm_local_15 = (teavm_local_2 - INT32_C(1));
    while (1) {
        if (!(teavm_local_15 >= INT32_C(0))) break;
        teavm_local_11 = teavm_local_8;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8331, teavm_checkBounds(teavm_local_4, teavm_local_11));
        if ((TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_4) == teavm_local_14)) {
            teavm_local_9 = -INT32_C(1);
        } else {
            teavm_local_16 = (((((int64_t) TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_4)) & INT64_C(4294967295)) << INT32_C(32)) + (((int64_t) TEAVM_ARRAY_AT(teavm_local_11, int32_t, TEAVM_WITH_CALL_SITE_ID(8332, teavm_checkBounds((teavm_local_4 - INT32_C(1)), teavm_local_11)))) & INT64_C(4294967295)));
            teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(8333, meth_jm_Division_divideLongByInt(teavm_local_16, teavm_local_14));
            teavm_local_9 = ((int32_t) teavm_local_17);
            teavm_local_18 = ((int32_t) (teavm_local_17 >> INT32_C(32)));
            if (teavm_local_9) {
                teavm_local_19 = INT32_C(0);
                teavm_local_9 = (teavm_local_9 + INT32_C(1));
                while (1) {
                    teavm_local_9 = (teavm_local_9 + -INT32_C(1));
                    if (teavm_local_19) {
                        goto teavm_label_4;
                    }
                    teavm_local_20 = ((((int64_t) teavm_local_9) & INT64_C(4294967295)) * (((int64_t) TEAVM_ARRAY_AT(teavm_local_13, int32_t, TEAVM_WITH_CALL_SITE_ID(8334, teavm_checkBounds((teavm_local_6 - INT32_C(2)), teavm_local_13)))) & INT64_C(4294967295)));
                    teavm_local_21 = ((int64_t) teavm_local_18);
                    teavm_local_22 = ((teavm_local_21 << INT32_C(32)) + (((int64_t) TEAVM_ARRAY_AT(teavm_local_11, int32_t, TEAVM_WITH_CALL_SITE_ID(8335, teavm_checkBounds((teavm_local_4 - INT32_C(2)), teavm_local_11)))) & INT64_C(4294967295)));
                    teavm_local_23 = ((teavm_local_21 & INT64_C(4294967295)) + (((int64_t) teavm_local_14) & INT64_C(4294967295)));
                    if ((TEAVM_WITH_CALL_SITE_ID(8336, meth_jl_Integer_numberOfLeadingZeros(((int32_t) ((int64_t) ((uint64_t) teavm_local_23 >> INT32_C(32)))))) >= INT32_C(32))) {
                        teavm_local_18 = ((int32_t) teavm_local_23);
                    } else {
                        teavm_local_19 = INT32_C(1);
                    }
                    if (((teavm_local_20 ^ (int64_t) INT64_C(0x8000000000000000)) <= (teavm_local_22 ^ (int64_t) INT64_C(0x8000000000000000)))) {
                        goto teavm_label_3;
                    }
                }
            teavm_label_4:;
                goto teavm_label_2;
            teavm_label_3:;
            }
        }
    teavm_label_2:;
        if (teavm_local_9) {
            teavm_local_24 = (teavm_local_4 - teavm_local_6);
            teavm_local_25 = TEAVM_WITH_CALL_SITE_ID(8337, meth_jm_Division_multiplyAndSubtract(teavm_local_8, teavm_local_24, teavm_local_10, teavm_local_6, teavm_local_9));
            if (teavm_local_25) {
                teavm_local_9 = (teavm_local_9 + -INT32_C(1));
                teavm_local_26 = INT64_C(0);
                teavm_local_27 = INT32_C(0);
                while (1) {
                    if (!(teavm_local_27 < teavm_local_6)) break;
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8338, teavm_checkBounds((teavm_local_24 + teavm_local_27), teavm_local_11));
                    teavm_local_21 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_7)) & INT64_C(4294967295));
                    teavm_local_27 = TEAVM_WITH_CALL_SITE_ID(8339, teavm_checkBounds(teavm_local_27, teavm_local_13));
                    teavm_local_20 = (teavm_local_26 + (teavm_local_21 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_13, int32_t, teavm_local_27)) & INT64_C(4294967295))));
                    TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_7) = ((int32_t) teavm_local_20);
                    teavm_local_26 = ((int64_t) ((uint64_t) teavm_local_20 >> INT32_C(32)));
                    teavm_local_27 = (teavm_local_27 + INT32_C(1));
                }
            }
        }
        if ((teavm_local_1 != NULL)) {
            teavm_local_11 = teavm_local_1;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
            teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(8340, teavm_checkBounds(teavm_local_15, teavm_local_11));
            TEAVM_ARRAY_AT(teavm_local_11, int32_t, teavm_local_15) = teavm_local_9;
        }
        teavm_local_4 = (teavm_local_4 + -INT32_C(1));
        teavm_local_15 = (teavm_local_15 + -INT32_C(1));
    }
    if ((!teavm_local_12)) {
        TEAVM_WITH_CALL_SITE_ID(8341, meth_jl_System_fastArraycopy(teavm_local_8, INT32_C(0), teavm_local_10, INT32_C(0), teavm_local_6));
    } else {
        TEAVM_WITH_CALL_SITE_ID(8342, meth_jm_BitLevel_shiftRight(teavm_local_10, teavm_local_6, teavm_local_8, INT32_C(0), teavm_local_12));
        teavm_local_8 = teavm_local_10;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_8;
}
int32_t meth_jm_Division_divideArrayByInt(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int64_t teavm_local_5;
    int64_t teavm_local_6;
    int32_t teavm_local_7;
    int64_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int64_t teavm_local_10;
    int64_t teavm_local_11;
    int64_t teavm_local_12;
    int64_t teavm_local_13;
    int64_t teavm_local_14;
    int32_t teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_5 = INT64_C(0);
    teavm_local_6 = (((int64_t) teavm_local_4) & INT64_C(4294967295));
    teavm_local_7 = (teavm_local_3 - INT32_C(1));
    while (1) {
        if (!(teavm_local_7 >= INT32_C(0))) break;
        teavm_local_8 = (teavm_local_5 << INT32_C(32));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8343, teavm_nullCheck(teavm_local_2));
        teavm_local_9 = teavm_local_2;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8344, teavm_checkBounds(teavm_local_7, teavm_local_9));
        teavm_local_10 = (teavm_local_8 | (((int64_t) TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_7)) & INT64_C(4294967295)));
        if ((teavm_local_10 >= INT64_C(0))) {
            teavm_local_11 = (teavm_local_10 / teavm_local_6);
            teavm_local_5 = (teavm_local_10 % teavm_local_6);
        } else {
            teavm_local_12 = ((int64_t) ((uint64_t) teavm_local_10 >> INT32_C(1)));
            teavm_local_13 = ((int64_t) ((int32_t) ((uint32_t) teavm_local_4 >> INT32_C(1))));
            teavm_local_11 = (teavm_local_12 / teavm_local_13);
            teavm_local_14 = (teavm_local_12 % teavm_local_13);
            teavm_local_5 = ((teavm_local_14 << INT32_C(1)) + (teavm_local_10 & INT64_C(1)));
            if ((teavm_local_4 & INT32_C(1))) {
                if ((teavm_local_11 <= teavm_local_5)) {
                    teavm_local_5 = (teavm_local_5 - teavm_local_11);
                } else if (((teavm_local_11 - teavm_local_5) <= teavm_local_6)) {
                    teavm_local_5 = (teavm_local_5 + (teavm_local_6 - teavm_local_11));
                    teavm_local_11 = (teavm_local_11 - INT64_C(1));
                } else {
                    teavm_local_5 = (teavm_local_5 + ((teavm_local_6 << INT32_C(1)) - teavm_local_11));
                    teavm_local_11 = (teavm_local_11 - INT64_C(2));
                }
            }
        }
        teavm_local_15 = ((int32_t) (teavm_local_11 & INT64_C(4294967295)));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8345, teavm_nullCheck(teavm_local_1));
        teavm_local_9 = teavm_local_1;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8346, teavm_checkUpperBound(teavm_local_7, teavm_local_9));
        TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_7) = teavm_local_15;
        teavm_local_7 = (teavm_local_7 + -INT32_C(1));
    }
    teavm_local_15 = ((int32_t) teavm_local_5);
    TEAVM_RELEASE_STACK;
    return teavm_local_15;
}
int32_t meth_jm_Division_remainderArrayByInt(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int64_t teavm_local_4;
    int32_t teavm_local_5;
    int64_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    int64_t teavm_local_9;
    int32_t teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_4 = INT64_C(0);
    teavm_local_5 = (teavm_local_2 - INT32_C(1));
    while (1) {
        if (!(teavm_local_5 >= INT32_C(0))) break;
        teavm_local_6 = (teavm_local_4 << INT32_C(32));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8347, teavm_nullCheck(teavm_local_1));
        teavm_local_7 = teavm_local_1;
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8348, teavm_checkBounds(teavm_local_5, teavm_local_7));
        teavm_local_8 = (teavm_local_6 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_5)) & INT64_C(4294967295)));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8349, meth_jm_Division_divideLongByInt(teavm_local_8, teavm_local_3));
        teavm_local_4 = ((int64_t) ((int32_t) (teavm_local_9 >> INT32_C(32))));
        teavm_local_5 = (teavm_local_5 + -INT32_C(1));
    }
    teavm_local_10 = ((int32_t) teavm_local_4);
    TEAVM_RELEASE_STACK;
    return teavm_local_10;
}
int64_t meth_jm_Division_divideLongByInt(int64_t teavm_local_1, int32_t teavm_local_2) {
    int64_t teavm_local_3;
    int64_t teavm_local_4;
    int64_t teavm_local_5;
    int64_t teavm_local_6;
    int64_t teavm_local_7;
    teavm_local_3 = (((int64_t) teavm_local_2) & INT64_C(4294967295));
    if ((teavm_local_1 >= INT64_C(0))) {
        teavm_local_4 = (teavm_local_1 / teavm_local_3);
        teavm_local_5 = (teavm_local_1 % teavm_local_3);
    } else {
        teavm_local_6 = ((int64_t) ((uint64_t) teavm_local_1 >> INT32_C(1)));
        teavm_local_7 = ((int64_t) ((int32_t) ((uint32_t) teavm_local_2 >> INT32_C(1))));
        teavm_local_4 = (teavm_local_6 / teavm_local_7);
        teavm_local_5 = (teavm_local_6 % teavm_local_7);
        teavm_local_5 = ((teavm_local_5 << INT32_C(1)) + (teavm_local_1 & INT64_C(1)));
        if ((teavm_local_2 & INT32_C(1))) {
            if ((teavm_local_4 <= teavm_local_5)) {
                teavm_local_5 = (teavm_local_5 - teavm_local_4);
            } else if (((teavm_local_4 - teavm_local_5) <= teavm_local_3)) {
                teavm_local_5 = (teavm_local_5 + (teavm_local_3 - teavm_local_4));
                teavm_local_4 = (teavm_local_4 - INT64_C(1));
            } else {
                teavm_local_5 = (teavm_local_5 + ((teavm_local_3 << INT32_C(1)) - teavm_local_4));
                teavm_local_4 = (teavm_local_4 - INT64_C(2));
            }
        }
    }
    return ((teavm_local_5 << INT32_C(32)) | (teavm_local_4 & INT64_C(4294967295)));
}
TeaVM_Array* meth_jm_Division_divideAndRemainderByInteger(void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TeaVM_Array* teavm_local_9;
    TeaVM_Array* teavm_local_10;
    void* teavm_local_11;
    void* teavm_local_12;
    TeaVM_Array* teavm_local_13;
    int64_t teavm_local_14;
    int64_t teavm_local_15;
    int64_t teavm_local_16;
    int64_t teavm_local_17;
    void* teavm_local_18;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8350, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
    teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
    teavm_local_6 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    if ((teavm_local_5 != INT32_C(1))) {
        teavm_local_7 = ((teavm_local_6 != teavm_local_3) ? -INT32_C(1) : INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8351, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8352, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(1)));
        teavm_local_10 = teavm_local_9;
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
        TEAVM_ARRAY_AT(teavm_local_10, int32_t, INT32_C(0)) = TEAVM_WITH_CALL_SITE_ID(8353, meth_jm_Division_divideArrayByInt(teavm_local_8, teavm_local_4, teavm_local_5, teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(8354, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
        TEAVM_WITH_CALL_SITE_ID(8355, meth_jm_BigInteger__init_(teavm_local_11, teavm_local_7, teavm_local_5, teavm_local_8));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8356, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
        TEAVM_WITH_CALL_SITE_ID(8357, meth_jm_BigInteger__init_(teavm_local_12, teavm_local_6, INT32_C(1), teavm_local_9));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(8358, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_11));
        TEAVM_WITH_CALL_SITE_ID(8359, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_12));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8360, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(2)));
        teavm_local_13 = teavm_local_10;
        teavm_gc_writeBarrier(teavm_local_13);
        TEAVM_ARRAY_AT(teavm_local_13, void*, INT32_C(0)) = teavm_local_11;
        TEAVM_ARRAY_AT(teavm_local_13, void*, INT32_C(1)) = teavm_local_12;
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8361, teavm_nullCheck(teavm_local_4));
        teavm_local_10 = teavm_local_4;
        teavm_local_14 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_10, int32_t, TEAVM_WITH_CALL_SITE_ID(8362, teavm_checkUpperBound(INT32_C(0), teavm_local_10)))) & INT64_C(4294967295));
        teavm_local_15 = (((int64_t) teavm_local_2) & INT64_C(4294967295));
        teavm_local_16 = (teavm_local_14 / teavm_local_15);
        teavm_local_17 = (teavm_local_14 % teavm_local_15);
        if ((teavm_local_6 != teavm_local_3)) {
            teavm_local_16 = (-teavm_local_16);
        }
        if ((teavm_local_6 < INT32_C(0))) {
            teavm_local_17 = (-teavm_local_17);
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8363, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(2)));
        teavm_local_13 = teavm_local_10;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(8364, meth_jm_BigInteger_valueOf(teavm_local_16));
        teavm_gc_writeBarrier(teavm_local_13);
        TEAVM_ARRAY_AT(teavm_local_13, void*, INT32_C(0)) = teavm_local_18;
        teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(8365, meth_jm_BigInteger_valueOf(teavm_local_17));
        teavm_gc_writeBarrier(teavm_local_13);
        TEAVM_ARRAY_AT(teavm_local_13, void*, INT32_C(1)) = teavm_local_18;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_10;
}
int32_t meth_jm_Division_multiplyAndSubtract(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int64_t teavm_local_6;
    int64_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int64_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int64_t teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_6 = INT64_C(0);
    teavm_local_7 = INT64_C(0);
    teavm_local_8 = INT32_C(0);
    while (1) {
        if (!(teavm_local_8 < teavm_local_4)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8366, teavm_nullCheck(teavm_local_3));
        teavm_local_9 = teavm_local_3;
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8367, teavm_checkBounds(teavm_local_8, teavm_local_9));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8368, meth_jm_Multiplication_unsignedMultAddAdd(TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_8), teavm_local_5, ((int32_t) teavm_local_6), INT32_C(0)));
        teavm_local_11 = (teavm_local_2 + teavm_local_8);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8369, teavm_nullCheck(teavm_local_1));
        teavm_local_9 = teavm_local_1;
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8370, teavm_checkBounds(teavm_local_11, teavm_local_9));
        teavm_local_13 = (((((int64_t) TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_12)) & INT64_C(4294967295)) - (teavm_local_10 & INT64_C(4294967295))) + teavm_local_7);
        TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_12) = ((int32_t) teavm_local_13);
        teavm_local_7 = (teavm_local_13 >> INT32_C(32));
        teavm_local_6 = ((int64_t) ((uint64_t) teavm_local_10 >> INT32_C(32)));
        teavm_local_8 = (teavm_local_8 + INT32_C(1));
    }
    teavm_local_11 = (teavm_local_2 + teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8371, teavm_nullCheck(teavm_local_1));
    teavm_local_9 = teavm_local_1;
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8372, teavm_checkBounds(teavm_local_11, teavm_local_9));
    teavm_local_10 = (((((int64_t) TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_12)) & INT64_C(4294967295)) - teavm_local_6) + teavm_local_7);
    TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_12) = ((int32_t) teavm_local_10);
    teavm_local_11 = ((int32_t) (teavm_local_10 >> INT32_C(32)));
    TEAVM_RELEASE_STACK;
    return teavm_local_11;
}
void* meth_jm_Division_gcdBinary(void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    int64_t teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8373, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8374, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_getLowestSetBit)(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8375, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8376, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_getLowestSetBit)(teavm_local_2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8377, meth_jl_Math_min(teavm_local_3, teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(8378, meth_jm_BitLevel_inplaceShiftRight(teavm_local_1, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(8379, meth_jm_BitLevel_inplaceShiftRight(teavm_local_2, teavm_local_4));
    if ((TEAVM_WITH_CALL_SITE_ID(8380, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_compareTo_3)(teavm_local_1, teavm_local_2)) != INT32_C(1))) {
        teavm_local_6 = teavm_local_2;
        teavm_local_2 = teavm_local_1;
        teavm_local_1 = teavm_local_6;
    }
    while (1) {
        if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) == INT32_C(1))) {
            goto teavm_label_2;
        }
        if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) == INT32_C(2))) {
            teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8381, teavm_nullCheck(teavm_local_7));
            if ((TEAVM_ARRAY_AT(teavm_local_7, int32_t, TEAVM_WITH_CALL_SITE_ID(8382, teavm_checkUpperBound(INT32_C(1), teavm_local_7))) > INT32_C(0))) {
                goto teavm_label_2;
            }
        }
        if ((!(((double) TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength)) > (((double) TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength)) * 0x1.3333333333333p0)))) {
            while (1) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                TEAVM_WITH_CALL_SITE_ID(8383, meth_jm_Elementary_inplaceSubtract(teavm_local_1, teavm_local_2));
                TEAVM_WITH_CALL_SITE_ID(8384, meth_jm_BitLevel_inplaceShiftRight(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(8385, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_getLowestSetBit)(teavm_local_1))));
                if ((TEAVM_WITH_CALL_SITE_ID(8386, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_compareTo_3)(teavm_local_1, teavm_local_2)) >= INT32_C(0))) {
                    goto teavm_cnt_4;
                } else {
                    goto teavm_label_4;
                }
            teavm_cnt_4:;
            }
        teavm_label_4:;
            teavm_local_6 = teavm_local_1;
        } else {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8387, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_remainder)(teavm_local_1, teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8388, teavm_nullCheck(teavm_local_6));
            if (TEAVM_WITH_CALL_SITE_ID(8389, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_signum)(teavm_local_6))) {
                TEAVM_WITH_CALL_SITE_ID(8390, meth_jm_BitLevel_inplaceShiftRight(teavm_local_6, TEAVM_WITH_CALL_SITE_ID(8391, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_getLowestSetBit)(teavm_local_6))));
            }
        }
        if ((!TEAVM_FIELD(teavm_local_6, cls_jm_BigInteger, fld_sign))) {
            goto teavm_label_3;
        }
        teavm_local_1 = teavm_local_2;
        teavm_local_2 = teavm_local_6;
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8392, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_longValue)(teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8393, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_longValue)(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8394, meth_jm_BigInteger_valueOf(TEAVM_WITH_CALL_SITE_ID(8395, meth_jm_Division_gcdBinary_0(teavm_local_8, teavm_local_9))));
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8396, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(8397, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, teavm_local_5)));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int64_t meth_jm_Division_gcdBinary_0(int64_t teavm_local_1, int64_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int64_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8398, meth_jl_Long_numberOfTrailingZeros(teavm_local_1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8399, meth_jl_Long_numberOfTrailingZeros(teavm_local_2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8400, meth_jl_Math_min(teavm_local_3, teavm_local_4));
    if (teavm_local_3) {
        teavm_local_1 = ((int64_t) ((uint64_t) teavm_local_1 >> teavm_local_3));
    }
    if (teavm_local_4) {
        teavm_local_2 = ((int64_t) ((uint64_t) teavm_local_2 >> teavm_local_4));
    }
    while (1) {
        if ((teavm_local_1 < teavm_local_2)) {
            teavm_local_6 = (teavm_local_2 - teavm_local_1);
            teavm_local_2 = ((int64_t) ((uint64_t) teavm_local_6 >> TEAVM_WITH_CALL_SITE_ID(8401, meth_jl_Long_numberOfTrailingZeros(teavm_local_6))));
        } else {
            teavm_local_6 = (teavm_local_1 - teavm_local_2);
            teavm_local_1 = ((int64_t) ((uint64_t) teavm_local_6 >> TEAVM_WITH_CALL_SITE_ID(8402, meth_jl_Long_numberOfTrailingZeros(teavm_local_6))));
        }
        if ((teavm_local_1 == INT64_C(0))) {
            goto teavm_label_1;
        }
    }
teavm_label_1:;
    teavm_local_6 = (teavm_local_2 << teavm_local_5);
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t supertypeof_jm_Division(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 327 || tag >= 329) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jm_Division_VT jm_Division_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_Division), sizeof(void*)),
            .flags = 0,
            .tag = 327,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jm_Division,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_jm_Division() {
}
