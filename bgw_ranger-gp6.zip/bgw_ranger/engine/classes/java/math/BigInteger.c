#include "BigInteger.h"
#include "../lang/Number.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "Elementary.h"
#include "BitLevel.h"
#include "../lang/ArithmeticException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/Integer.h"
#include "Conversion.h"
#include "Division.h"
#include "Multiplication.h"
#include "../../../arrayclass.h"
#include "../lang/System.h"
#include "../lang/Object.h"

void* sfld_jm_BigInteger_ZERO;
void* sfld_jm_BigInteger_ONE;
void* sfld_jm_BigInteger_TWO;
void* sfld_jm_BigInteger_TEN;
void* sfld_jm_BigInteger_MINUS_ONE;
TeaVM_Array* sfld_jm_BigInteger_SMALL_VALUES;
TeaVM_Array* sfld_jm_BigInteger_TWO_POWS;
void meth_jm_BigInteger__init__0(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(11545, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    TEAVM_WITH_CALL_SITE_ID(11546, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) = -INT32_C(2);
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = INT32_C(1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11547, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(1)));
    TEAVM_ARRAY_AT(teavm_local_3, int32_t, INT32_C(0)) = teavm_local_2;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void meth_jm_BigInteger__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(11548, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    TEAVM_WITH_CALL_SITE_ID(11549, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) = -INT32_C(2);
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = teavm_local_2;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void meth_jm_BigInteger__init__1(void* teavm_this_, int32_t teavm_local_1, int64_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(11550, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    TEAVM_WITH_CALL_SITE_ID(11551, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) = -INT32_C(2);
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) = teavm_local_1;
    if (((teavm_local_2 & -INT64_C(4294967296)) == INT64_C(0))) {
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = INT32_C(1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11552, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(1)));
        TEAVM_ARRAY_AT(teavm_local_3, int32_t, INT32_C(0)) = ((int32_t) teavm_local_2);
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits) = teavm_local_3;
    } else {
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = INT32_C(2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11553, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 2), ((int32_t) teavm_local_2), ((int32_t) (teavm_local_2 >> INT32_C(32)))));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits) = teavm_local_3;
    }
    TEAVM_RELEASE_STACK;
}
void meth_jm_BigInteger__init__2(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(11554, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    TEAVM_WITH_CALL_SITE_ID(11555, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) = -INT32_C(2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11556, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_2);
    if (teavm_local_3) {
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) = teavm_local_1;
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = teavm_local_3;
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits) = teavm_local_2;
        TEAVM_WITH_CALL_SITE_ID(11557, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_this_));
    } else {
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) = INT32_C(0);
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = INT32_C(1);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11558, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(1)));
        TEAVM_ARRAY_AT(teavm_local_4, int32_t, INT32_C(0)) = INT32_C(0);
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits) = teavm_local_4;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jm_BigInteger_valueOf(int64_t teavm_local_1) {
    void* teavm_local_2;
    int64_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(11559, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    if ((teavm_local_1 < INT64_C(0))) {
        if ((teavm_local_1 == -INT64_C(1))) {
            teavm_local_2 = sfld_jm_BigInteger_MINUS_ONE;
        } else {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11560, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
            teavm_local_3 = (-teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(11561, meth_jm_BigInteger__init__1(teavm_local_2, -INT32_C(1), teavm_local_3));
        }
    } else if ((teavm_local_1 > INT64_C(10))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11562, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(11563, meth_jm_BigInteger__init__1(teavm_local_2, INT32_C(1), teavm_local_1));
    } else {
        teavm_local_4 = sfld_jm_BigInteger_SMALL_VALUES;
        teavm_local_5 = ((int32_t) teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11564, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_4, void*, TEAVM_WITH_CALL_SITE_ID(11565, teavm_checkBounds(teavm_local_5, teavm_local_4)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jm_BigInteger_abs(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) < INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11566, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(11567, meth_jm_BigInteger__init_(teavm_local_1, INT32_C(1), teavm_local_2, teavm_local_3));
        teavm_this_ = teavm_local_1;
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jm_BigInteger_negate(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((!TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign))) {
        teavm_local_1 = teavm_this_;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11568, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        teavm_local_2 = (-TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(11569, meth_jm_BigInteger__init_(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jm_BigInteger_add(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11570, meth_jm_Elementary_add(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jm_BigInteger_subtract(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11571, meth_jm_Elementary_subtract(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BigInteger_signum(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
}
void* meth_jm_BigInteger_shiftRight(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((teavm_local_1 && TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign))) {
        teavm_this_ = ((teavm_local_1 > INT32_C(0)) ? TEAVM_WITH_CALL_SITE_ID(11572, meth_jm_BitLevel_shiftRight_0(teavm_this_, teavm_local_1)) : TEAVM_WITH_CALL_SITE_ID(11573, meth_jm_BitLevel_shiftLeft_0(teavm_this_, (-teavm_local_1))));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jm_BigInteger_shiftLeft(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((teavm_local_1 && TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign))) {
        teavm_this_ = ((teavm_local_1 > INT32_C(0)) ? TEAVM_WITH_CALL_SITE_ID(11574, meth_jm_BitLevel_shiftLeft_0(teavm_this_, teavm_local_1)) : TEAVM_WITH_CALL_SITE_ID(11575, meth_jm_BitLevel_shiftRight_0(teavm_this_, (-teavm_local_1))));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jm_BigInteger_shiftLeftOneBit(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if (TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign)) {
        teavm_this_ = TEAVM_WITH_CALL_SITE_ID(11576, meth_jm_BitLevel_shiftLeftOneBit_0(teavm_this_));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
int32_t meth_jm_BigInteger_bitLength(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11577, meth_jm_BitLevel_bitLength(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jm_BigInteger_testBit(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!teavm_local_1)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11578, teavm_nullCheck(teavm_local_2));
        teavm_local_3 = ((!(TEAVM_ARRAY_AT(teavm_local_2, int32_t, TEAVM_WITH_CALL_SITE_ID(11579, teavm_checkUpperBound(INT32_C(0), teavm_local_2))) & INT32_C(1))) ? INT32_C(0) : INT32_C(1));
    } else if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_4 = (teavm_local_1 >> INT32_C(5));
        if ((teavm_local_4 >= TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength))) {
            teavm_local_3 = ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) >= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
        } else {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11580, teavm_nullCheck(teavm_local_2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11581, teavm_checkBounds(teavm_local_4, teavm_local_2));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4);
            teavm_local_3 = (INT32_C(1) << (teavm_local_1 & INT32_C(31)));
            if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) < INT32_C(0))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(11582, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_getFirstNonzeroDigit)(teavm_this_));
                if ((teavm_local_4 < teavm_local_6)) {
                    teavm_local_3 = INT32_C(0);
                    goto teavm_label_1;
                }
                teavm_local_5 = ((teavm_local_6 == teavm_local_4) ? (-teavm_local_5) : (teavm_local_5 ^ -INT32_C(1)));
            }
            teavm_local_3 = ((!(teavm_local_5 & teavm_local_3)) ? INT32_C(0) : INT32_C(1));
        }
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(11583, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(11584, meth_jl_ArithmeticException__init_(teavm_local_7, TEAVM_GET_STRING(804)));
        TEAVM_WITH_CALL_SITE_ID(11585, meth_otr_ExceptionHandling_throwException(teavm_local_7));
        TEAVM_UNREACHABLE
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jm_BigInteger_getLowestSetBit(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign))) {
        teavm_local_1 = -INT32_C(1);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11586, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_getFirstNonzeroDigit)(teavm_this_));
        teavm_local_1 = (teavm_local_2 << INT32_C(5));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11587, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11588, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = (teavm_local_1 + TEAVM_WITH_CALL_SITE_ID(11589, meth_jl_Integer_numberOfTrailingZeros(teavm_local_4)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jm_BigInteger_intValue(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11590, teavm_nullCheck(teavm_local_2));
    teavm_local_1 = (teavm_local_1 * TEAVM_ARRAY_AT(teavm_local_2, int32_t, TEAVM_WITH_CALL_SITE_ID(11591, teavm_checkUpperBound(INT32_C(0), teavm_local_2))));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int64_t meth_jm_BigInteger_longValue(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int64_t teavm_local_2;
    int64_t teavm_local_3;
    int64_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) <= INT32_C(1))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11592, teavm_nullCheck(teavm_local_1));
        teavm_local_2 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(11593, teavm_checkUpperBound(INT32_C(0), teavm_local_1)))) & INT64_C(4294967295));
    } else {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11594, teavm_nullCheck(teavm_local_1));
        teavm_local_3 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(11595, teavm_checkUpperBound(INT32_C(1), teavm_local_1)))) << INT32_C(32));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11596, teavm_nullCheck(teavm_local_1));
        teavm_local_2 = (teavm_local_3 | (((int64_t) TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(11597, teavm_checkUpperBound(INT32_C(0), teavm_local_1)))) & INT64_C(4294967295)));
    }
    teavm_local_4 = (((int64_t) TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign)) * teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
double meth_jm_BigInteger_doubleValue(void* teavm_this_) {
    double teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11598, meth_jm_Conversion_bigInteger2Double(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jm_BigInteger_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11599, teavm_nullCheck(teavm_local_1));
    if ((teavm_local_2 > TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign))) {
        teavm_local_2 = INT32_C(1);
    } else if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) < TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign))) {
        teavm_local_2 = -INT32_C(1);
    } else if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) > TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
    } else if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) < TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength))) {
        teavm_local_2 = (-TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign));
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_2 = (teavm_local_2 * TEAVM_WITH_CALL_SITE_ID(11600, meth_jm_Elementary_compareArrays(teavm_local_3, teavm_local_4, teavm_local_5)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BigInteger_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jm_BigInteger_Cls, &supertypeof_jm_BigInteger))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11601, teavm_checkcast(teavm_local_1, &jm_BigInteger_Cls, &supertypeof_jm_BigInteger));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11602, teavm_nullCheck(teavm_local_3));
        if (((teavm_local_2 == TEAVM_FIELD(teavm_local_3, cls_jm_BigInteger, fld_sign)) && (TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) == TEAVM_FIELD(teavm_local_3, cls_jm_BigInteger, fld_numberLength)))) {
            teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jm_BigInteger, fld_digits);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            if (TEAVM_WITH_CALL_SITE_ID(11603, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_equalsArrays)(teavm_this_, teavm_local_4))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BigInteger_equalsArrays(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) - INT32_C(1));
    while (1) {
        if (!(teavm_local_2 >= INT32_C(0))) break;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11604, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11605, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11606, teavm_nullCheck(teavm_local_1));
        teavm_local_3 = teavm_local_1;
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11607, teavm_checkUpperBound(teavm_local_2, teavm_local_3));
        if ((teavm_local_4 != TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2))) {
            goto teavm_label_2;
        }
        teavm_local_2 = (teavm_local_2 + -INT32_C(1));
    }
    goto teavm_label_1;
teavm_label_2:;
teavm_label_1:;
    teavm_local_4 = ((teavm_local_2 >= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jm_BigInteger_gcd(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int64_t teavm_local_7;
    int64_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11608, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_abs)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11609, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11610, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_abs)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11611, teavm_nullCheck(teavm_local_2));
    if (TEAVM_WITH_CALL_SITE_ID(11612, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_signum)(teavm_local_2))) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11613, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(11614, TEAVM_METHOD(teavm_local_3, jm_BigInteger_VT, virt_signum)(teavm_local_3)))) {
            teavm_local_3 = teavm_local_2;
        } else {
            if ((TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength) != INT32_C(1))) {
                if ((TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength) != INT32_C(2))) {
                    goto teavm_label_3;
                }
                teavm_local_4 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11615, teavm_nullCheck(teavm_local_4));
                if ((TEAVM_ARRAY_AT(teavm_local_4, int32_t, TEAVM_WITH_CALL_SITE_ID(11616, teavm_checkUpperBound(INT32_C(1), teavm_local_4))) <= INT32_C(0))) {
                    goto teavm_label_3;
                }
            }
            if ((TEAVM_FIELD(teavm_local_3, cls_jm_BigInteger, fld_numberLength) == INT32_C(1))) {
                goto teavm_label_2;
            }
            if ((TEAVM_FIELD(teavm_local_3, cls_jm_BigInteger, fld_numberLength) == INT32_C(2))) {
                teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11617, teavm_nullCheck(teavm_local_4));
                if ((TEAVM_ARRAY_AT(teavm_local_4, int32_t, TEAVM_WITH_CALL_SITE_ID(11618, teavm_checkUpperBound(INT32_C(1), teavm_local_4))) > INT32_C(0))) {
                    goto teavm_label_2;
                }
            }
        teavm_label_3:;
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(11619, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_copy)(teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(11620, TEAVM_METHOD(teavm_local_3, jm_BigInteger_VT, virt_copy)(teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11621, meth_jm_Division_gcdBinary(teavm_local_5, teavm_local_6));
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(11622, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_longValue)(teavm_local_2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(11623, TEAVM_METHOD(teavm_local_3, jm_BigInteger_VT, virt_longValue)(teavm_local_3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11624, meth_jm_BigInteger_valueOf(TEAVM_WITH_CALL_SITE_ID(11625, meth_jm_Division_gcdBinary_0(teavm_local_7, teavm_local_8))));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jm_BigInteger_multiply(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11626, teavm_nullCheck(teavm_local_1));
    if ((!TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign))) {
        TEAVM_WITH_CALL_SITE_ID(11627, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
        teavm_local_2 = sfld_jm_BigInteger_ZERO;
    } else if ((!TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign))) {
        TEAVM_WITH_CALL_SITE_ID(11628, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
        teavm_local_2 = sfld_jm_BigInteger_ZERO;
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11629, meth_jm_Multiplication_multiply(teavm_this_, teavm_local_1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jm_BigInteger_pow(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_1 >= INT32_C(0))) {
        if ((!teavm_local_1)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(11630, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
            teavm_this_ = sfld_jm_BigInteger_ONE;
        } else {
            if ((teavm_local_1 != INT32_C(1))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(11631, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
                teavm_local_2 = sfld_jm_BigInteger_ONE;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                if ((!TEAVM_WITH_CALL_SITE_ID(11632, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_equals)(teavm_this_, teavm_local_2)))) {
                    teavm_local_2 = sfld_jm_BigInteger_ZERO;
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                    if ((!TEAVM_WITH_CALL_SITE_ID(11633, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_equals)(teavm_this_, teavm_local_2)))) {
                        goto teavm_label_2;
                    }
                }
            }
            goto teavm_label_1;
        teavm_label_2:;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if (TEAVM_WITH_CALL_SITE_ID(11634, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_testBit)(teavm_this_, INT32_C(0)))) {
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(11635, meth_jm_Multiplication_pow(teavm_this_, teavm_local_1));
            } else {
                teavm_local_3 = INT32_C(1);
                while (1) {
                    if (!(!TEAVM_WITH_CALL_SITE_ID(11636, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_testBit)(teavm_this_, teavm_local_3)))) break;
                    teavm_local_3 = (teavm_local_3 + INT32_C(1));
                }
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11637, meth_jm_BigInteger_getPowerOfTwo((teavm_local_3 * teavm_local_1)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11638, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_shiftRight)(teavm_this_, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11639, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(11640, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, teavm_local_1)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(11641, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(11642, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_4)));
            }
        }
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_this_;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11643, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(11644, meth_jl_ArithmeticException__init_(teavm_local_2, TEAVM_GET_STRING(805)));
    TEAVM_WITH_CALL_SITE_ID(11645, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
TeaVM_Array* meth_jm_BigInteger_divideAndRemainder(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    TeaVM_Array* teavm_local_15;
    TeaVM_Array* teavm_local_16;
    void* teavm_local_17;
    void* teavm_local_18;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11646, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    if (teavm_local_2) {
        teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
        teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        if ((teavm_local_3 == INT32_C(1))) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11647, teavm_nullCheck(teavm_local_4));
            teavm_local_5 = teavm_local_4;
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, int32_t, TEAVM_WITH_CALL_SITE_ID(11648, teavm_checkUpperBound(INT32_C(0), teavm_local_5)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(11649, meth_jm_Division_divideAndRemainderByInteger(teavm_this_, teavm_local_6, teavm_local_2));
        } else {
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
            teavm_local_6 = teavm_compare_i32(teavm_local_8, teavm_local_3);
            if ((!teavm_local_6)) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(11650, meth_jm_Elementary_compareArrays(teavm_local_7, teavm_local_4, teavm_local_8));
            } else {
                teavm_local_9 = ((teavm_local_6 <= INT32_C(0)) ? -INT32_C(1) : INT32_C(1));
            }
            if ((teavm_local_9 < INT32_C(0))) {
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(11651, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(2)));
                teavm_local_10 = teavm_local_5;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                TEAVM_WITH_CALL_SITE_ID(11652, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
                teavm_local_11 = sfld_jm_BigInteger_ZERO;
                teavm_gc_writeBarrier(teavm_local_10);
                TEAVM_ARRAY_AT(teavm_local_10, void*, INT32_C(0)) = teavm_local_11;
                TEAVM_ARRAY_AT(teavm_local_10, void*, INT32_C(1)) = teavm_this_;
            } else {
                teavm_local_12 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
                teavm_local_13 = ((teavm_local_8 - teavm_local_3) + INT32_C(1));
                teavm_local_14 = ((teavm_local_12 != teavm_local_2) ? -INT32_C(1) : INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(11653, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_13));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_15);
                teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(11654, meth_jm_Division_divide(teavm_local_15, teavm_local_13, teavm_local_7, teavm_local_8, teavm_local_4, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_16);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_17 = TEAVM_WITH_CALL_SITE_ID(11655, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_17);
                TEAVM_WITH_CALL_SITE_ID(11656, meth_jm_BigInteger__init_(teavm_local_17, teavm_local_14, teavm_local_13, teavm_local_15));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_18 = TEAVM_WITH_CALL_SITE_ID(11657, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_18);
                TEAVM_WITH_CALL_SITE_ID(11658, meth_jm_BigInteger__init_(teavm_local_18, teavm_local_12, teavm_local_3, teavm_local_16));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(11659, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_17));
                TEAVM_WITH_CALL_SITE_ID(11660, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_18));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(11661, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(2)));
                teavm_local_10 = teavm_local_5;
                teavm_gc_writeBarrier(teavm_local_10);
                TEAVM_ARRAY_AT(teavm_local_10, void*, INT32_C(0)) = teavm_local_17;
                TEAVM_ARRAY_AT(teavm_local_10, void*, INT32_C(1)) = teavm_local_18;
            }
        }
        TEAVM_RELEASE_STACK;
        return teavm_local_5;
    }
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(11662, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(11663, meth_jl_ArithmeticException__init_(teavm_local_11, TEAVM_GET_STRING(806)));
    TEAVM_WITH_CALL_SITE_ID(11664, meth_otr_ExceptionHandling_throwException(teavm_local_11));
    TEAVM_UNREACHABLE
}
void* meth_jm_BigInteger_divide(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int64_t teavm_local_7;
    int64_t teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    TeaVM_Array* teavm_local_13;
    int32_t teavm_local_14;
    void* teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11665, teavm_nullCheck(teavm_local_1));
    if (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign)) {
        teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        if ((!TEAVM_WITH_CALL_SITE_ID(11666, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_isOne)(teavm_local_1)))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
            teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
            if (((teavm_local_4 + teavm_local_5) == INT32_C(2))) {
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(11667, teavm_nullCheck(teavm_local_6));
                teavm_local_7 = (((int64_t) TEAVM_ARRAY_AT(teavm_local_6, int32_t, TEAVM_WITH_CALL_SITE_ID(11668, teavm_checkUpperBound(INT32_C(0), teavm_local_6)))) & INT64_C(4294967295));
                teavm_local_6 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(11669, teavm_nullCheck(teavm_local_6));
                teavm_local_8 = (teavm_local_7 / (((int64_t) TEAVM_ARRAY_AT(teavm_local_6, int32_t, TEAVM_WITH_CALL_SITE_ID(11670, teavm_checkUpperBound(INT32_C(0), teavm_local_6)))) & INT64_C(4294967295)));
                if ((teavm_local_3 != teavm_local_2)) {
                    teavm_local_8 = (-teavm_local_8);
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(11671, meth_jm_BigInteger_valueOf(teavm_local_8));
            } else {
                teavm_local_9 = teavm_compare_i32(teavm_local_4, teavm_local_5);
                if ((!teavm_local_9)) {
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                    teavm_local_10 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(11672, meth_jm_Elementary_compareArrays(teavm_local_6, teavm_local_10, teavm_local_4));
                } else {
                    teavm_local_11 = ((teavm_local_9 <= INT32_C(0)) ? -INT32_C(1) : INT32_C(1));
                }
                if ((!teavm_local_11)) {
                    teavm_this_ = ((teavm_local_3 != teavm_local_2) ? sfld_jm_BigInteger_MINUS_ONE : sfld_jm_BigInteger_ONE);
                } else if ((teavm_local_11 == -INT32_C(1))) {
                    teavm_this_ = sfld_jm_BigInteger_ZERO;
                } else {
                    teavm_local_12 = ((teavm_local_4 - teavm_local_5) + INT32_C(1));
                    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(11673, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_12));
                    teavm_local_14 = ((teavm_local_3 != teavm_local_2) ? -INT32_C(1) : INT32_C(1));
                    if ((teavm_local_5 != INT32_C(1))) {
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                        teavm_local_10 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                        TEAVM_WITH_CALL_SITE_ID(11674, meth_jm_Division_divide(teavm_local_13, teavm_local_12, teavm_local_6, teavm_local_4, teavm_local_10, teavm_local_5));
                    } else {
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                        teavm_local_10 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(11675, teavm_nullCheck(teavm_local_10));
                        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_10, int32_t, TEAVM_WITH_CALL_SITE_ID(11676, teavm_checkUpperBound(INT32_C(0), teavm_local_10)));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        TEAVM_WITH_CALL_SITE_ID(11677, meth_jm_Division_divideArrayByInt(teavm_local_13, teavm_local_6, teavm_local_4, teavm_local_9));
                    }
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                    teavm_this_ = TEAVM_WITH_CALL_SITE_ID(11678, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_this_);
                    TEAVM_WITH_CALL_SITE_ID(11679, meth_jm_BigInteger__init_(teavm_this_, teavm_local_14, teavm_local_12, teavm_local_13));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_WITH_CALL_SITE_ID(11680, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_this_));
                }
            }
        } else if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) <= INT32_C(0))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_this_ = TEAVM_WITH_CALL_SITE_ID(11681, TEAVM_METHOD(teavm_this_, jm_BigInteger_VT, virt_negate)(teavm_this_));
        }
        TEAVM_RELEASE_STACK;
        return teavm_this_;
    }
    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(11682, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_15);
    TEAVM_WITH_CALL_SITE_ID(11683, meth_jl_ArithmeticException__init_(teavm_local_15, TEAVM_GET_STRING(806)));
    TEAVM_WITH_CALL_SITE_ID(11684, meth_otr_ExceptionHandling_throwException(teavm_local_15));
    TEAVM_UNREACHABLE
}
void* meth_jm_BigInteger_remainder(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_local_12;
    int32_t teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11685, teavm_nullCheck(teavm_local_1));
    if (TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
        teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
        teavm_local_4 = teavm_compare_i32(teavm_local_2, teavm_local_3);
        if ((!teavm_local_4)) {
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
            teavm_local_6 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11686, meth_jm_Elementary_compareArrays(teavm_local_5, teavm_local_6, teavm_local_2));
        } else {
            teavm_local_4 = ((teavm_local_4 <= INT32_C(0)) ? -INT32_C(1) : INT32_C(1));
        }
        if ((teavm_local_4 != -INT32_C(1))) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(11687, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_3));
            if ((teavm_local_3 != INT32_C(1))) {
                teavm_local_8 = ((teavm_local_2 - teavm_local_3) + INT32_C(1));
                teavm_local_9 = NULL;
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                teavm_local_6 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(11688, meth_jm_Division_divide(teavm_local_9, teavm_local_8, teavm_local_5, teavm_local_2, teavm_local_6, teavm_local_3));
            } else {
                teavm_local_10 = teavm_local_7;
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(11689, teavm_nullCheck(teavm_local_5));
                teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_5, int32_t, TEAVM_WITH_CALL_SITE_ID(11690, teavm_checkUpperBound(INT32_C(0), teavm_local_5)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(11691, meth_jm_Division_remainderArrayByInt(teavm_local_6, teavm_local_2, teavm_local_11));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_ARRAY_AT(teavm_local_10, int32_t, TEAVM_WITH_CALL_SITE_ID(11692, teavm_checkUpperBound(INT32_C(0), teavm_local_10))) = teavm_local_11;
            }
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(11693, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
            teavm_local_13 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
            TEAVM_WITH_CALL_SITE_ID(11694, meth_jm_BigInteger__init_(teavm_local_12, teavm_local_13, teavm_local_3, teavm_local_7));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(11695, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_12));
            teavm_this_ = teavm_local_12;
        }
        TEAVM_RELEASE_STACK;
        return teavm_this_;
    }
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(11696, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(11697, meth_jl_ArithmeticException__init_(teavm_local_9, TEAVM_GET_STRING(806)));
    TEAVM_WITH_CALL_SITE_ID(11698, meth_otr_ExceptionHandling_throwException(teavm_local_9));
    TEAVM_UNREACHABLE
}
void meth_jm_BigInteger_cutOffLeadingZeroes(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    while (1) {
        if (!(TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) > INT32_C(0))) break;
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) - INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = teavm_local_2;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11699, teavm_nullCheck(teavm_local_1));
        if (TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(11700, teavm_checkBounds(teavm_local_2, teavm_local_1)))) {
            goto teavm_label_1;
        }
    }
teavm_label_1:;
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) = (teavm_local_3 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11701, teavm_nullCheck(teavm_local_1));
    if ((!TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(11702, teavm_checkBounds(teavm_local_3, teavm_local_1))))) {
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign) = INT32_C(0);
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jm_BigInteger_isOne(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength) == INT32_C(1))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11703, teavm_nullCheck(teavm_local_1));
        if ((TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(11704, teavm_checkUpperBound(INT32_C(0), teavm_local_1))) == INT32_C(1))) {
            goto teavm_label_2;
        }
    }
    teavm_local_2 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BigInteger_getFirstNonzeroDigit(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) == -INT32_C(2))) {
        if ((!TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign))) {
            teavm_local_1 = -INT32_C(1);
        } else {
            teavm_local_1 = INT32_C(0);
            while (1) {
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11705, teavm_nullCheck(teavm_local_2));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11706, teavm_checkBounds(teavm_local_1, teavm_local_2));
                if (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_1)) {
                    goto teavm_label_1;
                }
                teavm_local_1 = (teavm_local_1 + INT32_C(1));
            }
        teavm_label_1:;
        }
        TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) = teavm_local_1;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jm_BigInteger_copy(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11707, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_digits);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(11708, meth_jl_System_fastArraycopy(teavm_local_3, INT32_C(0), teavm_local_2, INT32_C(0), teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(11709, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_sign);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(11710, meth_jm_BigInteger__init_(teavm_local_5, teavm_local_6, teavm_local_4, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void meth_jm_BigInteger_unCache(void* teavm_this_) {
    TEAVM_FIELD(teavm_this_, cls_jm_BigInteger, fld_firstNonzeroDigit) = -INT32_C(2);
}
void* meth_jm_BigInteger_getPowerOfTwo(int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(11711, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_2 = sfld_jm_BigInteger_TWO_POWS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((teavm_local_1 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(11712, teavm_nullCheck(teavm_local_2))))) {
        teavm_local_2 = sfld_jm_BigInteger_TWO_POWS;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11713, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11714, teavm_checkBounds(teavm_local_1, teavm_local_2));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1);
    } else {
        teavm_local_4 = (teavm_local_1 >> INT32_C(5));
        teavm_local_5 = (teavm_local_1 & INT32_C(31));
        teavm_local_6 = (teavm_local_4 + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(11715, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_6));
        teavm_local_2 = teavm_local_7;
        teavm_local_8 = (INT32_C(1) << teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11716, teavm_checkBounds(teavm_local_4, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) = teavm_local_8;
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(11717, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(11718, meth_jm_BigInteger__init_(teavm_local_3, INT32_C(1), teavm_local_6, teavm_local_7));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jm_BigInteger__clinit_() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int64_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11719, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11720, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(0), INT32_C(0)));
    sfld_jm_BigInteger_ZERO = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11721, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11722, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(1)));
    sfld_jm_BigInteger_ONE = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11723, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11724, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(2)));
    sfld_jm_BigInteger_TWO = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11725, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11726, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(10)));
    sfld_jm_BigInteger_TEN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11727, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11728, meth_jm_BigInteger__init__0(teavm_local_1, -INT32_C(1), INT32_C(1)));
    sfld_jm_BigInteger_MINUS_ONE = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11729, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(11)));
    teavm_local_3 = teavm_local_2;
    teavm_local_1 = sfld_jm_BigInteger_ZERO;
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(0)) = teavm_local_1;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(1)) = sfld_jm_BigInteger_ONE;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(2)) = sfld_jm_BigInteger_TWO;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11730, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11731, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(3)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(3)) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11732, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11733, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(4)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(4)) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11734, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11735, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(5)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(5)) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11736, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11737, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(6)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(6)) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11738, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11739, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(7)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(7)) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11740, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11741, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(8)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(8)) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11742, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(11743, meth_jm_BigInteger__init__0(teavm_local_1, INT32_C(1), INT32_C(9)));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(9)) = teavm_local_1;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(10)) = sfld_jm_BigInteger_TEN;
    sfld_jm_BigInteger_SMALL_VALUES = teavm_local_2;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    sfld_jm_BigInteger_TWO_POWS = TEAVM_WITH_CALL_SITE_ID(11744, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(32)));
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_2 = sfld_jm_BigInteger_TWO_POWS;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(11745, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_1;
        }
        teavm_local_2 = sfld_jm_BigInteger_TWO_POWS;
        teavm_local_5 = (INT64_C(1) << teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(11746, meth_jm_BigInteger_valueOf(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(11747, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(11748, teavm_checkBounds(teavm_local_4, teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_4) = teavm_local_1;
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void initclass_jm_BigInteger() {
    TeaVM_Class* cls = (TeaVM_Class*) &jm_BigInteger_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jm_BigInteger__clinit_();
    }
}
int32_t supertypeof_jm_BigInteger(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1966 || tag >= 1968) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jm_BigInteger_Cls[2];
alignas(8) jm_BigInteger_VT jm_BigInteger_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_BigInteger), sizeof(void*)),
        .flags = 0,
        .tag = 1966,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jm_BigInteger,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = teavm_classLayouts_jm_BigInteger_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_equals = &meth_jm_BigInteger_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_intValue = &meth_jm_BigInteger_intValue,
    .virt_isOne = &meth_jm_BigInteger_isOne,
    .virt_longValue = &meth_jm_BigInteger_longValue,
    .virt_remainder = &meth_jm_BigInteger_remainder,
    .virt_testBit = &meth_jm_BigInteger_testBit,
    .virt_compareTo_3 = &meth_jm_BigInteger_compareTo,
    .virt_abs = &meth_jm_BigInteger_abs,
    .virt_gcd = &meth_jm_BigInteger_gcd,
    .virt_signum = &meth_jm_BigInteger_signum,
    .virt_getFirstNonzeroDigit = &meth_jm_BigInteger_getFirstNonzeroDigit,
    .virt_shiftLeft = &meth_jm_BigInteger_shiftLeft,
    .virt_divideAndRemainder = &meth_jm_BigInteger_divideAndRemainder,
    .virt_shiftRight = &meth_jm_BigInteger_shiftRight,
    .virt_bitLength = &meth_jm_BigInteger_bitLength,
    .virt_doubleValue = &meth_jm_BigInteger_doubleValue,
    .virt_divide = &meth_jm_BigInteger_divide,
    .virt_add_6 = &meth_jm_BigInteger_add,
    .virt_multiply = &meth_jm_BigInteger_multiply,
    .virt_negate = &meth_jm_BigInteger_negate,
    .virt_shiftLeftOneBit = &meth_jm_BigInteger_shiftLeftOneBit,
    .virt_subtract = &meth_jm_BigInteger_subtract,
    .virt_equalsArrays = &meth_jm_BigInteger_equalsArrays,
    .virt_unCache = &meth_jm_BigInteger_unCache,
    .virt_cutOffLeadingZeroes = &meth_jm_BigInteger_cutOffLeadingZeroes,
    .virt_copy = &meth_jm_BigInteger_copy,
    .virt_getLowestSetBit = &meth_jm_BigInteger_getLowestSetBit,
    .virt_pow = &meth_jm_BigInteger_pow
};
static void** teavm_gc_localStaticRoots_jm_BigInteger_Cls[7] = {
(void**) &sfld_jm_BigInteger_ZERO, (void**) &sfld_jm_BigInteger_ONE, (void**) &sfld_jm_BigInteger_TWO, (void**) &sfld_jm_BigInteger_TEN, (void**) &sfld_jm_BigInteger_MINUS_ONE, (void**) &sfld_jm_BigInteger_SMALL_VALUES, (void**) &sfld_jm_BigInteger_TWO_POWS
};
static int16_t teavm_classLayouts_jm_BigInteger_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jm_BigInteger, fld_digits)
};
void sysinitclass_jm_BigInteger() {
sfld_jm_BigInteger_ZERO = NULL;
sfld_jm_BigInteger_ONE = NULL;
sfld_jm_BigInteger_TWO = NULL;
sfld_jm_BigInteger_TEN = NULL;
sfld_jm_BigInteger_MINUS_ONE = NULL;
sfld_jm_BigInteger_SMALL_VALUES = NULL;
sfld_jm_BigInteger_TWO_POWS = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jm_BigInteger_Cls, 7);
}
