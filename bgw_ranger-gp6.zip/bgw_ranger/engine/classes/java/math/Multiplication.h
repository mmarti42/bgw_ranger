#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Multiplication.h"

extern void sysinitclass_jm_Multiplication();
typedef struct cls_jm_Multiplication {
    struct TeaVM_Object parent;
} cls_jm_Multiplication;
extern TeaVM_Array* sfld_jm_Multiplication_tenPows;
extern TeaVM_Array* sfld_jm_Multiplication_fivePows;
extern TeaVM_Array* sfld_jm_Multiplication_bigTenPows;
extern TeaVM_Array* sfld_jm_Multiplication_bigFivePows;
extern void* meth_jm_Multiplication_multiply(void*, void*);
extern void* meth_jm_Multiplication_karatsuba(void*, void*);
extern void* meth_jm_Multiplication_multiplyPAP(void*, void*);
extern void meth_jm_Multiplication_multArraysPAP(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t, TeaVM_Array*);
extern void meth_jm_Multiplication_multPAP(TeaVM_Array*, TeaVM_Array*, TeaVM_Array*, int32_t, int32_t);
extern int32_t meth_jm_Multiplication_multiplyByInt(TeaVM_Array*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jm_Multiplication_multiplyByPositiveInt(void*, int32_t);
extern void* meth_jm_Multiplication_pow(void*, int32_t);
extern TeaVM_Array* meth_jm_Multiplication_square(TeaVM_Array*, int32_t, TeaVM_Array*);
extern void* meth_jm_Multiplication_powerOf10(int64_t);
extern void* meth_jm_Multiplication_multiplyByFivePow(void*, int32_t);
extern int64_t meth_jm_Multiplication_unsignedMultAddAdd(int32_t, int32_t, int32_t, int32_t);
extern void meth_jm_Multiplication__clinit_();
extern void initclass_jm_Multiplication();
extern int32_t supertypeof_jm_Multiplication(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_Multiplication_VT {
    jl_Object_VT parent;
} jm_Multiplication_VT;
extern jm_Multiplication_VT jm_Multiplication_Cls;
