#include "BigDecimal.h"
#include "../lang/Number.h"
#include "../lang/NullPointerException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "BigInteger.h"
#include "../lang/Math.h"
#include "Multiplication.h"
#include "../lang/ArithmeticException.h"
#include "../../../strings.h"
#include "../lang/Long.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer.h"
#include "../lang/Integer.h"
#include "../../../arrays/primitives/long.h"
#include "../../../arrays/primitives/int.h"
#include "../../../arrayclass.h"
#include "../../../arrays/primitives/char.h"
#include "../lang/Object.h"

void* sfld_jm_BigDecimal_ZERO;
void* sfld_jm_BigDecimal_ONE;
void* sfld_jm_BigDecimal_TEN;
TeaVM_Array* sfld_jm_BigDecimal_FIVE_POW;
TeaVM_Array* sfld_jm_BigDecimal_TEN_POW;
TeaVM_Array* sfld_jm_BigDecimal_LONG_TEN_POW;
TeaVM_Array* sfld_jm_BigDecimal_LONG_FIVE_POW;
TeaVM_Array* sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH;
TeaVM_Array* sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH;
TeaVM_Array* sfld_jm_BigDecimal_BI_SCALED_BY_ZERO;
TeaVM_Array* sfld_jm_BigDecimal_ZERO_SCALED_BY;
TeaVM_Array* sfld_jm_BigDecimal_CH_ZEROS;
void meth_jm_BigDecimal__init__1(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28549, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    TEAVM_WITH_CALL_SITE_ID(28550, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) = TEAVM_WITH_CALL_SITE_ID(28551, meth_jm_BigDecimal_bitLength(teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jm_BigDecimal__init__2(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28552, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    TEAVM_WITH_CALL_SITE_ID(28553, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) = ((int64_t) teavm_local_1);
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) = TEAVM_WITH_CALL_SITE_ID(28554, meth_jm_BigDecimal_bitLength_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jm_BigDecimal__init__0(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28555, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    TEAVM_WITH_CALL_SITE_ID(28556, meth_jm_BigDecimal__init_(teavm_this_, teavm_local_1, INT32_C(0)));
    TEAVM_RELEASE_STACK;
}
void meth_jm_BigDecimal__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28557, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    TEAVM_WITH_CALL_SITE_ID(28558, meth_jl_Number__init_(teavm_this_));
    if ((teavm_local_1 == NULL)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28559, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(28560, meth_jl_NullPointerException__init_(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(28561, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale) = teavm_local_2;
    TEAVM_WITH_CALL_SITE_ID(28562, meth_jm_BigDecimal_setUnscaledValue(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jm_BigDecimal_valueOf_0(int64_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28563, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    if ((!teavm_local_2)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28564, meth_jm_BigDecimal_valueOf(teavm_local_1));
    } else {
        if (((teavm_local_1 == INT64_C(0)) && (teavm_local_2 >= INT32_C(0)))) {
            teavm_local_4 = sfld_jm_BigDecimal_ZERO_SCALED_BY;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28565, teavm_nullCheck(teavm_local_4))))) {
                goto teavm_label_2;
            }
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28566, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(28567, meth_jm_BigDecimal__init__1(teavm_local_3, teavm_local_1, teavm_local_2));
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_4 = sfld_jm_BigDecimal_ZERO_SCALED_BY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28568, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28569, teavm_checkBounds(teavm_local_2, teavm_local_4));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_2);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jm_BigDecimal_valueOf(int64_t teavm_local_1) {
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28570, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    if ((!((teavm_local_1 >= INT64_C(0)) && (teavm_local_1 < INT64_C(11))))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28571, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(28572, meth_jm_BigDecimal__init__1(teavm_local_2, teavm_local_1, INT32_C(0)));
    } else {
        teavm_local_3 = sfld_jm_BigDecimal_BI_SCALED_BY_ZERO;
        teavm_local_4 = ((int32_t) teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28573, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(28574, teavm_checkBounds(teavm_local_4, teavm_local_3)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jm_BigDecimal_multiply(void* teavm_this_, void* teavm_local_1) {
    int64_t teavm_local_2;
    int64_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = ((int64_t) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28575, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = (teavm_local_2 + ((int64_t) TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_scale)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!((!TEAVM_WITH_CALL_SITE_ID(28576, meth_jm_BigDecimal_isZero(teavm_this_))) && (!TEAVM_WITH_CALL_SITE_ID(28577, meth_jm_BigDecimal_isZero(teavm_local_1)))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28578, meth_jm_BigDecimal_zeroScaledBy(teavm_local_3));
    } else if (((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) + TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_bitLength)) < INT32_C(64))) {
        teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) * TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_smallValue));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28579, meth_jm_BigDecimal_valueOf_0(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(28580, meth_jm_BigDecimal_toIntScale(teavm_local_3))));
    } else {
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28581, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28582, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28583, meth_jm_BigDecimal_getUnscaledValue(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28584, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28585, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(28586, meth_jm_BigDecimal__init_(teavm_local_4, teavm_local_5, TEAVM_WITH_CALL_SITE_ID(28587, meth_jm_BigDecimal_toIntScale(teavm_local_3))));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jm_BigDecimal_divide(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int64_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    void* teavm_local_13;
    TeaVM_Array* teavm_local_14;
    void* teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28588, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28589, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28590, meth_jm_BigDecimal_getUnscaledValue(teavm_local_1));
    teavm_local_4 = (((int64_t) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale)) - ((int64_t) TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_scale)));
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = INT32_C(1);
    teavm_local_7 = sfld_jm_BigDecimal_FIVE_POW;
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
    teavm_local_8 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28591, teavm_nullCheck(teavm_local_7))) - INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    if ((!TEAVM_WITH_CALL_SITE_ID(28592, meth_jm_BigDecimal_isZero(teavm_local_1)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28593, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(28594, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_signum)(teavm_local_2)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28595, meth_jm_BigDecimal_zeroScaledBy(teavm_local_4));
        } else {
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(28596, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_gcd)(teavm_local_2, teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28597, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_divide)(teavm_local_2, teavm_local_10));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28598, teavm_nullCheck(teavm_local_3));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28599, TEAVM_METHOD(teavm_local_3, jm_BigInteger_VT, virt_divide)(teavm_local_3, teavm_local_10));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28600, teavm_nullCheck(teavm_local_11));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(28601, TEAVM_METHOD(teavm_local_11, jm_BigInteger_VT, virt_getLowestSetBit)(teavm_local_11));
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(28602, TEAVM_METHOD(teavm_local_11, jm_BigInteger_VT, virt_shiftRight)(teavm_local_11, teavm_local_12));
            while (1) {
                teavm_local_7 = sfld_jm_BigDecimal_FIVE_POW;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28603, teavm_nullCheck(teavm_local_7));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28604, teavm_checkBounds(teavm_local_6, teavm_local_7));
                teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_7, void*, teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(28605, teavm_nullCheck(teavm_local_13));
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(28606, TEAVM_METHOD(teavm_local_13, jm_BigInteger_VT, virt_divideAndRemainder)(teavm_local_13, teavm_local_11));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_14);
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(28607, teavm_nullCheck(teavm_local_14));
                teavm_local_7 = teavm_local_14;
                teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_7, void*, TEAVM_WITH_CALL_SITE_ID(28608, teavm_checkUpperBound(INT32_C(1), teavm_local_7)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
                if ((!TEAVM_WITH_CALL_SITE_ID(28609, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28610, teavm_nullCheck(teavm_local_11))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_signum)(teavm_tmp_ptr_0))))) {
                    teavm_local_5 = (teavm_local_5 + teavm_local_6);
                    if ((teavm_local_6 < teavm_local_8)) {
                        teavm_local_6 = (teavm_local_6 + INT32_C(1));
                    }
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                    teavm_local_13 = TEAVM_ARRAY_AT(teavm_local_7, void*, TEAVM_WITH_CALL_SITE_ID(28611, teavm_checkUpperBound(INT32_C(0), teavm_local_7)));
                    goto teavm_cnt_1;
                }
                if ((teavm_local_6 == INT32_C(1))) {
                    goto teavm_label_1;
                }
                teavm_local_6 = INT32_C(1);
            teavm_cnt_1:;
            }
        teavm_label_1:;
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28612, TEAVM_METHOD(teavm_local_13, jm_BigInteger_VT, virt_abs)(teavm_local_13));
            teavm_local_15 = sfld_jm_BigInteger_ONE;
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_15);
            if (TEAVM_WITH_CALL_SITE_ID(28613, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28614, teavm_nullCheck(teavm_local_11))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_equals)(teavm_tmp_ptr_0, teavm_local_15)))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                if ((TEAVM_WITH_CALL_SITE_ID(28615, TEAVM_METHOD(teavm_local_13, jm_BigInteger_VT, virt_signum)(teavm_local_13)) < INT32_C(0))) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28616, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28617, teavm_nullCheck(teavm_local_9))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_negate)(teavm_tmp_ptr_0)));
                }
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(28618, meth_jm_BigDecimal_toIntScale((teavm_local_4 + ((int64_t) TEAVM_WITH_CALL_SITE_ID(28619, meth_jl_Math_max(teavm_local_12, teavm_local_5))))));
                teavm_local_17 = (teavm_local_12 - teavm_local_5);
                teavm_local_11 = ((teavm_local_17 > INT32_C(0)) ? TEAVM_WITH_CALL_SITE_ID(28620, meth_jm_Multiplication_multiplyByFivePow(teavm_local_9, teavm_local_17)) : TEAVM_WITH_CALL_SITE_ID(28621, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28622, teavm_nullCheck(teavm_local_9))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, (-teavm_local_17)))));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28623, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                TEAVM_WITH_CALL_SITE_ID(28624, meth_jm_BigDecimal__init_(teavm_local_9, teavm_local_11, teavm_local_16));
            } else {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28625, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
                TEAVM_WITH_CALL_SITE_ID(28626, meth_jl_ArithmeticException__init_(teavm_local_11, TEAVM_GET_STRING(7357)));
                TEAVM_WITH_CALL_SITE_ID(28627, meth_otr_ExceptionHandling_throwException(teavm_local_11));
                TEAVM_UNREACHABLE
            }
        }
        TEAVM_RELEASE_STACK;
        return teavm_local_9;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28628, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(28629, meth_jl_ArithmeticException__init_(teavm_local_11, TEAVM_GET_STRING(7358)));
    TEAVM_WITH_CALL_SITE_ID(28630, meth_otr_ExceptionHandling_throwException(teavm_local_11));
    TEAVM_UNREACHABLE
}
void* meth_jm_BigDecimal_negate(void* teavm_this_) {
    int64_t teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) >= INT32_C(63))) {
        if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) != INT32_C(63))) {
            goto teavm_label_2;
        }
        if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) == (int64_t) INT64_C(0x8000000000000000))) {
            goto teavm_label_2;
        }
    }
    teavm_local_1 = (-TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28631, meth_jm_BigDecimal_valueOf_0(teavm_local_1, teavm_local_2));
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28632, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28633, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28634, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28635, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_negate)(teavm_tmp_ptr_0)));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(28636, meth_jm_BigDecimal__init_(teavm_local_3, teavm_local_4, teavm_local_2));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jm_BigDecimal_signum(void* teavm_this_) {
    int64_t teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) < INT32_C(64))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28637, meth_jl_Long_signum(teavm_local_1));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28638, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28639, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28640, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_signum)(teavm_tmp_ptr_0)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BigDecimal_isZero(void* teavm_this_) {
    return ((!((!TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength)) && (TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) != -INT64_C(1)))) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jm_BigDecimal_scale(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale);
}
int32_t meth_jm_BigDecimal_precision(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    double teavm_local_4;
    void* teavm_local_5;
    int64_t teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_precision) > INT32_C(0))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_precision);
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength);
        teavm_local_3 = INT32_C(1);
        teavm_local_4 = 1.0;
        if ((teavm_local_2 >= INT32_C(1024))) {
            teavm_local_1 = ((int32_t) (1.0 + (((double) (teavm_local_2 - INT32_C(1))) * 0x1.34413509f79ffp-2)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28641, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
            teavm_local_6 = ((int64_t) teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28642, meth_jm_Multiplication_powerOf10(teavm_local_6));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28643, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28644, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divide)(teavm_tmp_ptr_0, teavm_local_7)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if (TEAVM_WITH_CALL_SITE_ID(28645, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28646, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_signum)(teavm_tmp_ptr_0)))) {
                teavm_local_1 = (teavm_local_1 + INT32_C(1));
            }
        } else {
            if ((teavm_local_2 >= INT32_C(64))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28647, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28648, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28649, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_doubleValue)(teavm_tmp_ptr_0)));
            } else if ((teavm_local_2 >= INT32_C(1))) {
                teavm_local_4 = ((double) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue));
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_1 = (teavm_local_3 + TEAVM_WITH_CALL_SITE_ID(28650, meth_otcit_DoubleAnalyzer_fastIntLog10(TEAVM_WITH_CALL_SITE_ID(28651, meth_jl_Math_abs_1(teavm_local_4)))));
        }
        TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_precision) = teavm_local_1;
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_precision);
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jm_BigDecimal_unscaledValue(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28652, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jm_BigDecimal_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int64_t teavm_local_5;
    int32_t teavm_local_6;
    int64_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    int64_t teavm_local_10;
    void* teavm_local_11;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28653, TEAVM_METHOD(teavm_this_, jm_BigDecimal_VT, virt_signum)(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28654, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28655, TEAVM_METHOD(teavm_local_1, jm_BigDecimal_VT, virt_signum)(teavm_local_1));
    teavm_local_4 = teavm_compare_i32(teavm_local_2, teavm_local_3);
    if (teavm_local_4) {
        teavm_local_2 = ((teavm_local_4 >= INT32_C(0)) ? INT32_C(1) : -INT32_C(1));
    } else if (((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale) == TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_scale)) && ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) < INT32_C(64)) && (TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_bitLength) < INT32_C(64))))) {
        teavm_local_2 = ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) < TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_smallValue)) ? -INT32_C(1) : ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) <= TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_smallValue)) ? INT32_C(0) : INT32_C(1)));
    } else {
        teavm_local_5 = (((int64_t) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale)) - ((int64_t) TEAVM_FIELD(teavm_local_1, cls_jm_BigDecimal, fld_scale)));
        teavm_local_6 = (TEAVM_WITH_CALL_SITE_ID(28656, meth_jm_BigDecimal_aproxPrecision(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(28657, meth_jm_BigDecimal_aproxPrecision(teavm_local_1)));
        teavm_local_7 = ((int64_t) teavm_local_6);
        if ((teavm_local_7 <= (teavm_local_5 + INT64_C(1)))) {
            if ((teavm_local_7 < (teavm_local_5 - INT64_C(1)))) {
                teavm_local_2 = (-teavm_local_2);
            } else {
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(28658, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28659, meth_jm_BigDecimal_getUnscaledValue(teavm_local_1));
                teavm_local_4 = teavm_compare_i64(teavm_local_5, INT64_C(0));
                if ((teavm_local_4 < INT32_C(0))) {
                    teavm_local_10 = (-teavm_local_5);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28660, meth_jm_Multiplication_powerOf10(teavm_local_10));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(28661, teavm_nullCheck(teavm_local_8));
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(28662, TEAVM_METHOD(teavm_local_8, jm_BigInteger_VT, virt_multiply)(teavm_local_8, teavm_local_11));
                } else if ((teavm_local_4 > INT32_C(0))) {
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(28663, meth_jm_Multiplication_powerOf10(teavm_local_5));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
                    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28664, teavm_nullCheck(teavm_local_9));
                    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(28665, TEAVM_METHOD(teavm_local_9, jm_BigInteger_VT, virt_multiply)(teavm_local_9, teavm_local_11));
                }
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28666, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28667, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_compareTo_3)(teavm_tmp_ptr_0, teavm_local_9)));
            }
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
double meth_jm_BigDecimal_doubleValue(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    int64_t teavm_local_3;
    double teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int64_t teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    TeaVM_Array* teavm_local_11;
    int32_t teavm_local_12;
    void* teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int64_t teavm_local_16;
    int64_t teavm_local_17;
    int32_t teavm_local_18;
    int64_t teavm_local_19;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28668, TEAVM_METHOD(teavm_this_, jm_BigDecimal_VT, virt_signum)(teavm_this_));
    teavm_local_2 = INT32_C(1076);
    teavm_local_3 = (((int64_t) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength)) - ((int64_t) (((double) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale)) / 0x1.34413509f79ffp-2)));
    if ((!((teavm_local_3 >= -INT64_C(1074)) && teavm_local_1))) {
        teavm_local_4 = (((double) teavm_local_1) * 0.0);
    } else if ((teavm_local_3 > INT64_C(1025))) {
        teavm_local_4 = (((double) teavm_local_1) * INFINITY);
    } else {
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28669, meth_jm_BigDecimal_getUnscaledValue(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28670, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28671, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_abs)(teavm_tmp_ptr_0)));
        if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale) <= INT32_C(0))) {
            teavm_local_7 = ((int64_t) (-TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28672, meth_jm_Multiplication_powerOf10(teavm_local_7));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28673, teavm_nullCheck(teavm_local_6));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28674, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_multiply)(teavm_local_6, teavm_local_5));
        } else {
            teavm_local_7 = ((int64_t) TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_scale));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(28675, meth_jm_Multiplication_powerOf10(teavm_local_7));
            teavm_local_9 = (INT32_C(100) - ((int32_t) teavm_local_3));
            if ((teavm_local_9 > INT32_C(0))) {
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28676, teavm_nullCheck(teavm_local_6));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28677, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_shiftLeft)(teavm_local_6, teavm_local_9));
                teavm_local_2 = (teavm_local_2 - teavm_local_9);
            }
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(28678, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28679, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_divideAndRemainder)(teavm_tmp_ptr_0, teavm_local_8)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(28680, teavm_nullCheck(teavm_local_10));
            teavm_local_11 = teavm_local_10;
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_11, void*, TEAVM_WITH_CALL_SITE_ID(28681, teavm_checkUpperBound(INT32_C(1), teavm_local_11)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28682, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28683, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeftOneBit)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(28684, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28685, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_compareTo_3)(teavm_tmp_ptr_0, teavm_local_8)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_11, void*, TEAVM_WITH_CALL_SITE_ID(28686, teavm_checkUpperBound(INT32_C(0), teavm_local_11)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28687, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28688, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, INT32_C(2))));
            teavm_local_7 = ((int64_t) (((teavm_local_12 * (teavm_local_12 + INT32_C(3))) / INT32_C(2)) + INT32_C(1)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(28689, meth_jm_BigInteger_valueOf(teavm_local_7));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_13);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28690, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28691, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_13)));
            teavm_local_2 = (teavm_local_2 + -INT32_C(2));
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28692, teavm_nullCheck(teavm_local_5));
        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(28693, TEAVM_METHOD(teavm_local_5, jm_BigInteger_VT, virt_getLowestSetBit)(teavm_local_5));
        teavm_local_15 = (TEAVM_WITH_CALL_SITE_ID(28694, TEAVM_METHOD(teavm_local_5, jm_BigInteger_VT, virt_bitLength)(teavm_local_5)) - INT32_C(54));
        if ((teavm_local_15 <= INT32_C(0))) {
            teavm_local_16 = (TEAVM_WITH_CALL_SITE_ID(28695, TEAVM_METHOD(teavm_local_5, jm_BigInteger_VT, virt_longValue)(teavm_local_5)) << (-teavm_local_15));
            teavm_local_17 = (((teavm_local_16 & INT64_C(3)) != INT64_C(3)) ? teavm_local_16 : (teavm_local_16 + INT64_C(2)));
        } else {
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28696, TEAVM_METHOD(teavm_local_5, jm_BigInteger_VT, virt_shiftRight)(teavm_local_5, teavm_local_15));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(28697, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(28698, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_longValue)(teavm_tmp_ptr_0)));
            teavm_local_17 = (((!(((teavm_local_16 & INT64_C(1)) == INT64_C(1)) && (teavm_local_14 < teavm_local_15))) && ((teavm_local_16 & INT64_C(3)) != INT64_C(3))) ? teavm_local_16 : (teavm_local_16 + INT64_C(2)));
        }
        if (((teavm_local_17 & INT64_C(18014398509481984)) == INT64_C(0))) {
            teavm_local_7 = (teavm_local_17 >> INT32_C(1));
            teavm_local_18 = (teavm_local_2 + teavm_local_15);
        } else {
            teavm_local_7 = (teavm_local_17 >> INT32_C(2));
            teavm_local_18 = (teavm_local_2 + (teavm_local_15 + INT32_C(1)));
        }
        if ((teavm_local_18 > INT32_C(2046))) {
            teavm_local_4 = (((double) teavm_local_1) * INFINITY);
        } else {
            if ((teavm_local_18 <= INT32_C(0))) {
                if ((teavm_local_18 < -INT32_C(53))) {
                    teavm_local_4 = (((double) teavm_local_1) * 0.0);
                    goto teavm_label_1;
                }
                teavm_local_7 = (teavm_local_16 >> INT32_C(1));
                teavm_local_19 = (teavm_local_7 & ((int64_t) ((uint64_t) -INT64_C(1) >> (INT32_C(63) + teavm_local_18))));
                teavm_local_7 = (teavm_local_7 >> (-teavm_local_18));
                if (((teavm_local_7 & INT64_C(3)) != INT64_C(3))) {
                    if (((teavm_local_7 & INT64_C(1)) != INT64_C(1))) {
                        goto teavm_label_2;
                    }
                    if ((teavm_local_19 == INT64_C(0))) {
                        goto teavm_label_2;
                    }
                    if ((teavm_local_14 >= teavm_local_15)) {
                        goto teavm_label_2;
                    }
                }
                teavm_local_7 = (teavm_local_7 + INT64_C(1));
            teavm_label_2:;
                teavm_local_18 = INT32_C(0);
                teavm_local_7 = (teavm_local_7 >> INT32_C(1));
            }
            teavm_local_7 = (((((int64_t) teavm_local_1) & (int64_t) INT64_C(0x8000000000000000)) | (((int64_t) teavm_local_18) << INT32_C(52))) | (teavm_local_7 & INT64_C(4503599627370495)));
            teavm_local_4 = teavm_reinterpretLongToDouble(teavm_local_7);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jm_BigDecimal_aproxPrecision(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_precision) > INT32_C(0)) ? TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_precision) : (((int32_t) (((double) (TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) - INT32_C(1))) * 0x1.34413509f79ffp-2)) + INT32_C(1)));
}
int32_t meth_jm_BigDecimal_toIntScale(int64_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28699, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    if ((teavm_local_1 >= -INT64_C(2147483648))) {
        if ((teavm_local_1 > INT64_C(2147483647))) {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28700, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(28701, meth_jl_ArithmeticException__init_(teavm_local_2, TEAVM_GET_STRING(7359)));
            TEAVM_WITH_CALL_SITE_ID(28702, meth_otr_ExceptionHandling_throwException(teavm_local_2));
            TEAVM_UNREACHABLE
        }
        teavm_local_3 = ((int32_t) teavm_local_1);
        TEAVM_RELEASE_STACK;
        return teavm_local_3;
    }
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28703, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(28704, meth_jl_ArithmeticException__init_(teavm_local_2, TEAVM_GET_STRING(7360)));
    TEAVM_WITH_CALL_SITE_ID(28705, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void* meth_jm_BigDecimal_zeroScaledBy(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28706, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    teavm_local_2 = ((int32_t) teavm_local_1);
    if ((teavm_local_1 == ((int64_t) teavm_local_2))) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28707, meth_jm_BigDecimal_valueOf_0(INT64_C(0), teavm_local_2));
    } else if ((teavm_local_1 < INT64_C(0))) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28708, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(28709, meth_jm_BigDecimal__init__2(teavm_local_3, INT32_C(0), (int32_t) INT32_C(0x80000000)));
    } else {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28710, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(28711, meth_jm_BigDecimal__init__2(teavm_local_3, INT32_C(0), INT32_C(2147483647)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jm_BigDecimal_getUnscaledValue(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_intVal) == NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28712, meth_jm_BigInteger_valueOf(TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue)));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_intVal) = teavm_local_1;
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_intVal);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jm_BigDecimal_setUnscaledValue(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_intVal) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28713, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) = TEAVM_WITH_CALL_SITE_ID(28714, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_bitLength)(teavm_local_1));
    if ((TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_bitLength) < INT32_C(64))) {
        TEAVM_FIELD(teavm_this_, cls_jm_BigDecimal, fld_smallValue) = TEAVM_WITH_CALL_SITE_ID(28715, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_longValue)(teavm_local_1));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jm_BigDecimal_bitLength(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28716, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    if ((teavm_local_1 < INT64_C(0))) {
        teavm_local_1 = (teavm_local_1 ^ -INT64_C(1));
    }
    teavm_local_2 = (INT32_C(64) - TEAVM_WITH_CALL_SITE_ID(28717, meth_jl_Long_numberOfLeadingZeros(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jm_BigDecimal_bitLength_0(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28718, teavm_initializeClass((TeaVM_Class*) &jm_BigDecimal_Cls, &initclass_jm_BigDecimal));
    if ((teavm_local_1 < INT32_C(0))) {
        teavm_local_1 = (teavm_local_1 ^ -INT32_C(1));
    }
    teavm_local_2 = (INT32_C(32) - TEAVM_WITH_CALL_SITE_ID(28719, meth_jl_Integer_numberOfLeadingZeros(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jm_BigDecimal__clinit_() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28720, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(28721, meth_jm_BigDecimal__init__2(teavm_local_1, INT32_C(0), INT32_C(0)));
    sfld_jm_BigDecimal_ZERO = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28722, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(28723, meth_jm_BigDecimal__init__2(teavm_local_1, INT32_C(1), INT32_C(0)));
    sfld_jm_BigDecimal_ONE = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28724, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(28725, meth_jm_BigDecimal__init__2(teavm_local_1, INT32_C(10), INT32_C(0)));
    sfld_jm_BigDecimal_TEN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jm_BigDecimal_LONG_TEN_POW = TEAVM_WITH_CALL_SITE_ID(28726, teavm_fillLongArray(meth_otr_Allocator_allocateArray(&Arr_J_Cls, 19), INT64_C(1), INT64_C(10), INT64_C(100), INT64_C(1000), INT64_C(10000), INT64_C(100000), INT64_C(1000000), INT64_C(10000000), INT64_C(100000000), INT64_C(1000000000), INT64_C(10000000000), INT64_C(100000000000), INT64_C(1000000000000), INT64_C(10000000000000), INT64_C(100000000000000), INT64_C(1000000000000000), INT64_C(10000000000000000), INT64_C(100000000000000000), INT64_C(1000000000000000000)));
    sfld_jm_BigDecimal_LONG_FIVE_POW = TEAVM_WITH_CALL_SITE_ID(28727, teavm_fillLongArray(meth_otr_Allocator_allocateArray(&Arr_J_Cls, 28), INT64_C(1), INT64_C(5), INT64_C(25), INT64_C(125), INT64_C(625), INT64_C(3125), INT64_C(15625), INT64_C(78125), INT64_C(390625), INT64_C(1953125), INT64_C(9765625), INT64_C(48828125), INT64_C(244140625), INT64_C(1220703125), INT64_C(6103515625), INT64_C(30517578125), INT64_C(152587890625), INT64_C(762939453125), INT64_C(3814697265625), INT64_C(19073486328125), INT64_C(95367431640625), INT64_C(476837158203125), INT64_C(2384185791015625), INT64_C(11920928955078125), INT64_C(59604644775390625), INT64_C(298023223876953125), INT64_C(1490116119384765625), INT64_C(7450580596923828125)));
    teavm_local_2 = sfld_jm_BigDecimal_LONG_FIVE_POW;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28728, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH = TEAVM_WITH_CALL_SITE_ID(28729, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_3));
    teavm_local_2 = sfld_jm_BigDecimal_LONG_TEN_POW;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28730, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH = TEAVM_WITH_CALL_SITE_ID(28731, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_3));
    sfld_jm_BigDecimal_BI_SCALED_BY_ZERO = TEAVM_WITH_CALL_SITE_ID(28732, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigDecimal_Cls), INT32_C(11)));
    sfld_jm_BigDecimal_ZERO_SCALED_BY = TEAVM_WITH_CALL_SITE_ID(28733, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigDecimal_Cls), INT32_C(11)));
    sfld_jm_BigDecimal_CH_ZEROS = TEAVM_WITH_CALL_SITE_ID(28734, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(100)));
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_2 = sfld_jm_BigDecimal_ZERO_SCALED_BY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28735, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_1;
        }
        teavm_local_2 = sfld_jm_BigDecimal_BI_SCALED_BY_ZERO;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28736, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(28737, meth_jm_BigDecimal__init__2(teavm_local_1, teavm_local_4, INT32_C(0)));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28738, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28739, teavm_checkBounds(teavm_local_4, teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_4) = teavm_local_1;
        teavm_local_2 = sfld_jm_BigDecimal_ZERO_SCALED_BY;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28740, meth_otr_Allocator_allocate(&jm_BigDecimal_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(28741, meth_jm_BigDecimal__init__2(teavm_local_1, INT32_C(0), teavm_local_4));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28742, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28743, teavm_checkUpperBound(teavm_local_4, teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_4) = teavm_local_1;
        teavm_local_2 = sfld_jm_BigDecimal_CH_ZEROS;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28744, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28745, teavm_checkUpperBound(teavm_local_4, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_4) = INT32_C(48);
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    while (1) {
        teavm_local_2 = sfld_jm_BigDecimal_CH_ZEROS;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28746, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_2;
        }
        teavm_local_2 = sfld_jm_BigDecimal_CH_ZEROS;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28747, teavm_nullCheck(teavm_local_2));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28748, teavm_checkBounds(teavm_local_4, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_5) = INT32_C(48);
        teavm_local_4 = (teavm_local_5 + INT32_C(1));
    }
teavm_label_2:;
    teavm_local_6 = INT32_C(0);
    while (1) {
        teavm_local_2 = sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_6 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28749, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_3;
        }
        teavm_local_2 = sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH;
        teavm_local_7 = sfld_jm_BigDecimal_LONG_FIVE_POW;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28750, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28751, teavm_checkBounds(teavm_local_6, teavm_local_7));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, int64_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28752, meth_jm_BigDecimal_bitLength(teavm_local_8));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28753, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28754, teavm_checkUpperBound(teavm_local_6, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6) = teavm_local_3;
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
teavm_label_3:;
    teavm_local_6 = INT32_C(0);
    while (1) {
        teavm_local_2 = sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_6 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28755, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_4;
        }
        teavm_local_2 = sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH;
        teavm_local_7 = sfld_jm_BigDecimal_LONG_TEN_POW;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28756, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28757, teavm_checkBounds(teavm_local_6, teavm_local_7));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, int64_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28758, meth_jm_BigDecimal_bitLength(teavm_local_8));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28759, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28760, teavm_checkUpperBound(teavm_local_6, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6) = teavm_local_3;
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28761, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    sfld_jm_BigDecimal_TEN_POW = sfld_jm_Multiplication_bigTenPows;
    sfld_jm_BigDecimal_FIVE_POW = sfld_jm_Multiplication_bigFivePows;
    TEAVM_RELEASE_STACK;
}
void initclass_jm_BigDecimal() {
    TeaVM_Class* cls = (TeaVM_Class*) &jm_BigDecimal_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jm_BigDecimal__clinit_();
    }
}
int32_t supertypeof_jm_BigDecimal(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1976 || tag >= 1978) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jm_BigDecimal_Cls[2];
alignas(8) jm_BigDecimal_VT jm_BigDecimal_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_BigDecimal), sizeof(void*)),
        .flags = 0,
        .tag = 1976,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jm_BigDecimal,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = teavm_classLayouts_jm_BigDecimal_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_precision = &meth_jm_BigDecimal_precision,
    .virt_signum = &meth_jm_BigDecimal_signum,
    .virt_divide_0 = &meth_jm_BigDecimal_divide,
    .virt_compareTo_8 = &meth_jm_BigDecimal_compareTo,
    .virt_scale = &meth_jm_BigDecimal_scale,
    .virt_doubleValue = &meth_jm_BigDecimal_doubleValue,
    .virt_negate_0 = &meth_jm_BigDecimal_negate,
    .virt_unscaledValue = &meth_jm_BigDecimal_unscaledValue,
    .virt_multiply_0 = &meth_jm_BigDecimal_multiply
};
static void** teavm_gc_localStaticRoots_jm_BigDecimal_Cls[12] = {
(void**) &sfld_jm_BigDecimal_ZERO, (void**) &sfld_jm_BigDecimal_ONE, (void**) &sfld_jm_BigDecimal_TEN, (void**) &sfld_jm_BigDecimal_FIVE_POW, (void**) &sfld_jm_BigDecimal_TEN_POW, (void**) &sfld_jm_BigDecimal_LONG_TEN_POW, (void**) &sfld_jm_BigDecimal_LONG_FIVE_POW, (void**) &sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH, (void**) &sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH, (void**) &sfld_jm_BigDecimal_BI_SCALED_BY_ZERO, (void**) &sfld_jm_BigDecimal_ZERO_SCALED_BY, (void**) &sfld_jm_BigDecimal_CH_ZEROS
};
static int16_t teavm_classLayouts_jm_BigDecimal_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jm_BigDecimal, fld_intVal)
};
void sysinitclass_jm_BigDecimal() {
sfld_jm_BigDecimal_ZERO = NULL;
sfld_jm_BigDecimal_ONE = NULL;
sfld_jm_BigDecimal_TEN = NULL;
sfld_jm_BigDecimal_FIVE_POW = NULL;
sfld_jm_BigDecimal_TEN_POW = NULL;
sfld_jm_BigDecimal_LONG_TEN_POW = NULL;
sfld_jm_BigDecimal_LONG_FIVE_POW = NULL;
sfld_jm_BigDecimal_LONG_FIVE_POW_BIT_LENGTH = NULL;
sfld_jm_BigDecimal_LONG_TEN_POW_BIT_LENGTH = NULL;
sfld_jm_BigDecimal_BI_SCALED_BY_ZERO = NULL;
sfld_jm_BigDecimal_ZERO_SCALED_BY = NULL;
sfld_jm_BigDecimal_CH_ZEROS = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jm_BigDecimal_Cls, 12);
}
