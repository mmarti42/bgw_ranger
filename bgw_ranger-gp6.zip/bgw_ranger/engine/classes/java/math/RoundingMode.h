#pragma once
#include "../../../runtime.h"
#include "../lang/Enum.h"
#include "RoundingMode.h"

extern void sysinitclass_jm_RoundingMode();
typedef struct cls_jm_RoundingMode {
    struct cls_jl_Enum parent;
    int32_t fld_bigDecimalRM;
} cls_jm_RoundingMode;
extern void* sfld_jm_RoundingMode_UP;
extern void* sfld_jm_RoundingMode_DOWN;
extern void* sfld_jm_RoundingMode_CEILING;
extern void* sfld_jm_RoundingMode_FLOOR;
extern void* sfld_jm_RoundingMode_HALF_UP;
extern void* sfld_jm_RoundingMode_HALF_DOWN;
extern void* sfld_jm_RoundingMode_HALF_EVEN;
extern void* sfld_jm_RoundingMode_UNNECESSARY;
extern TeaVM_Array* sfld_jm_RoundingMode__VALUES;
extern TeaVM_Array* meth_jm_RoundingMode_values();
extern void meth_jm_RoundingMode__init_(void*, void*, int32_t, int32_t);
extern TeaVM_Array* meth_jm_RoundingMode__values();
extern void meth_jm_RoundingMode__clinit_();
extern void initclass_jm_RoundingMode();
extern int32_t supertypeof_jm_RoundingMode(TeaVM_Class*, TeaVM_Class*);
typedef struct jm_RoundingMode_VT {
    jl_Enum_VT parent;
} jm_RoundingMode_VT;
extern jm_RoundingMode_VT jm_RoundingMode_Cls;
