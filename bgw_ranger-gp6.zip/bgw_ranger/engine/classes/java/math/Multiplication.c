#include "Multiplication.h"
#include "../lang/Object.h"
#include "BigInteger.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "BitLevel.h"
#include "../lang/ArithmeticException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../arrayclass.h"

TeaVM_Array* sfld_jm_Multiplication_tenPows;
TeaVM_Array* sfld_jm_Multiplication_fivePows;
TeaVM_Array* sfld_jm_Multiplication_bigTenPows;
TeaVM_Array* sfld_jm_Multiplication_bigFivePows;
void* meth_jm_Multiplication_multiply(void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41192, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41193, meth_jm_Multiplication_karatsuba(teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jm_Multiplication_karatsuba(void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    void* teavm_local_12;
    void* teavm_local_13;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(5));
    TEAVM_WITH_CALL_SITE_ID(41194, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41195, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41196, teavm_nullCheck(teavm_local_1));
    if ((teavm_local_3 <= TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength))) {
        teavm_local_4 = teavm_local_2;
        teavm_local_2 = teavm_local_1;
        teavm_local_1 = teavm_local_4;
    }
    if ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength) < INT32_C(63))) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41197, meth_jm_Multiplication_multiplyPAP(teavm_local_2, teavm_local_1));
    } else {
        teavm_local_5 = ((TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength) & -INT32_C(2)) << INT32_C(4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41198, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_shiftRight)(teavm_local_2, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41199, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_shiftRight)(teavm_local_1, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41200, teavm_nullCheck(teavm_local_6));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41201, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_shiftLeft)(teavm_local_6, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_4);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(41202, TEAVM_METHOD(teavm_local_2, jm_BigInteger_VT, virt_subtract)(teavm_local_2, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41203, teavm_nullCheck(teavm_local_7));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41204, TEAVM_METHOD(teavm_local_7, jm_BigInteger_VT, virt_shiftLeft)(teavm_local_7, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_4);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(41205, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_subtract)(teavm_local_1, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41206, meth_jm_Multiplication_karatsuba(teavm_local_6, teavm_local_7));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_10);
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41207, meth_jm_Multiplication_karatsuba(teavm_local_8, teavm_local_9));
        TEAVM_GC_ROOT(INT32_C(5), teavm_local_11);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41208, TEAVM_METHOD(teavm_local_6, jm_BigInteger_VT, virt_subtract)(teavm_local_6, teavm_local_8));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(41209, teavm_nullCheck(teavm_local_9));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(41210, TEAVM_METHOD(teavm_local_9, jm_BigInteger_VT, virt_subtract)(teavm_local_9, teavm_local_7));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41211, meth_jm_Multiplication_karatsuba(teavm_local_4, teavm_local_12));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41212, teavm_nullCheck(teavm_local_13));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41213, TEAVM_METHOD(teavm_local_13, jm_BigInteger_VT, virt_add_6)(teavm_local_13, teavm_local_10));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41214, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41215, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_11)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41216, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41217, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, teavm_local_5)));
        teavm_local_3 = (teavm_local_5 << INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41218, teavm_nullCheck(teavm_local_10));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(41219, TEAVM_METHOD(teavm_local_10, jm_BigInteger_VT, virt_shiftLeft)(teavm_local_10, teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41220, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41221, teavm_nullCheck(teavm_local_12))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41222, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41223, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_add_6)(teavm_tmp_ptr_0, teavm_local_11)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jm_Multiplication_multiplyPAP(void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TeaVM_Array* teavm_local_9;
    void* teavm_local_10;
    TeaVM_Array* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int64_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(41224, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41225, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41226, teavm_nullCheck(teavm_local_2));
    teavm_local_4 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_numberLength);
    teavm_local_5 = (teavm_local_3 + teavm_local_4);
    teavm_local_6 = ((TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign) == TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_sign)) ? INT32_C(1) : -INT32_C(1));
    if ((teavm_local_5 != INT32_C(2))) {
        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        teavm_local_8 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(41227, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        TEAVM_WITH_CALL_SITE_ID(41228, meth_jm_Multiplication_multArraysPAP(teavm_local_7, teavm_local_3, teavm_local_8, teavm_local_4, teavm_local_9));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41229, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_WITH_CALL_SITE_ID(41230, meth_jm_BigInteger__init_(teavm_local_10, teavm_local_6, teavm_local_5, teavm_local_9));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(41231, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_10));
    } else {
        teavm_local_11 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41232, teavm_nullCheck(teavm_local_11));
        teavm_local_12 = TEAVM_ARRAY_AT(teavm_local_11, int32_t, TEAVM_WITH_CALL_SITE_ID(41233, teavm_checkUpperBound(INT32_C(0), teavm_local_11)));
        teavm_local_11 = TEAVM_FIELD(teavm_local_2, cls_jm_BigInteger, fld_digits);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41234, teavm_nullCheck(teavm_local_11));
        teavm_local_13 = TEAVM_ARRAY_AT(teavm_local_11, int32_t, TEAVM_WITH_CALL_SITE_ID(41235, teavm_checkUpperBound(INT32_C(0), teavm_local_11)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(41236, meth_jm_Multiplication_unsignedMultAddAdd(teavm_local_12, teavm_local_13, INT32_C(0), INT32_C(0)));
        teavm_local_15 = ((int32_t) teavm_local_14);
        teavm_local_16 = ((int32_t) ((int64_t) ((uint64_t) teavm_local_14 >> INT32_C(32))));
        if ((!teavm_local_16)) {
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41237, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(41238, meth_jm_BigInteger__init__0(teavm_local_10, teavm_local_6, teavm_local_15));
        } else {
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41239, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41240, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 2), teavm_local_15, teavm_local_16));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
            TEAVM_WITH_CALL_SITE_ID(41241, meth_jm_BigInteger__init_(teavm_local_10, teavm_local_6, INT32_C(2), teavm_local_11));
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_10;
}
void meth_jm_Multiplication_multArraysPAP(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, TeaVM_Array* teavm_local_5) {
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41242, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    if ((teavm_local_2 && teavm_local_4)) {
        if ((teavm_local_2 == INT32_C(1))) {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41243, teavm_nullCheck(teavm_local_1));
            teavm_local_6 = teavm_local_1;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_6, int32_t, TEAVM_WITH_CALL_SITE_ID(41244, teavm_checkUpperBound(INT32_C(0), teavm_local_6)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41245, meth_jm_Multiplication_multiplyByInt(teavm_local_5, teavm_local_3, teavm_local_4, teavm_local_7));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41246, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = teavm_local_5;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41247, teavm_checkBounds(teavm_local_4, teavm_local_6));
            TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) = teavm_local_7;
        } else if ((teavm_local_4 != INT32_C(1))) {
            TEAVM_WITH_CALL_SITE_ID(41248, meth_jm_Multiplication_multPAP(teavm_local_1, teavm_local_3, teavm_local_5, teavm_local_2, teavm_local_4));
        } else {
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41249, teavm_nullCheck(teavm_local_3));
            teavm_local_6 = teavm_local_3;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_6, int32_t, TEAVM_WITH_CALL_SITE_ID(41250, teavm_checkUpperBound(INT32_C(0), teavm_local_6)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41251, meth_jm_Multiplication_multiplyByInt(teavm_local_5, teavm_local_1, teavm_local_2, teavm_local_7));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41252, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = teavm_local_5;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41253, teavm_checkBounds(teavm_local_2, teavm_local_6));
            TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_2) = teavm_local_7;
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_jm_Multiplication_multPAP(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int64_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int64_t teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(41254, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    if (((teavm_local_1 == teavm_local_2) && (teavm_local_4 == teavm_local_5))) {
        TEAVM_WITH_CALL_SITE_ID(41255, meth_jm_Multiplication_square(teavm_local_1, teavm_local_4, teavm_local_3));
    } else {
        teavm_local_6 = INT32_C(0);
        while (1) {
            if (!(teavm_local_6 < teavm_local_4)) break;
            teavm_local_7 = INT64_C(0);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41256, teavm_nullCheck(teavm_local_1));
            teavm_local_8 = teavm_local_1;
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41257, teavm_checkBounds(teavm_local_6, teavm_local_8));
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_6);
            teavm_local_10 = INT32_C(0);
            while (1) {
                if (!(teavm_local_10 < teavm_local_5)) break;
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41258, teavm_nullCheck(teavm_local_2));
                teavm_local_8 = teavm_local_2;
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41259, teavm_checkBounds(teavm_local_10, teavm_local_8));
                teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_10);
                teavm_local_12 = (teavm_local_6 + teavm_local_10);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41260, teavm_nullCheck(teavm_local_3));
                teavm_local_8 = teavm_local_3;
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41261, teavm_checkBounds(teavm_local_12, teavm_local_8));
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(41262, meth_jm_Multiplication_unsignedMultAddAdd(teavm_local_9, teavm_local_11, TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_13), ((int32_t) teavm_local_7)));
                TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_13) = ((int32_t) teavm_local_14);
                teavm_local_7 = ((int64_t) ((uint64_t) teavm_local_14 >> INT32_C(32)));
                teavm_local_10 = (teavm_local_10 + INT32_C(1));
            }
            teavm_local_11 = (teavm_local_6 + teavm_local_5);
            teavm_local_12 = ((int32_t) teavm_local_7);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41263, teavm_nullCheck(teavm_local_3));
            teavm_local_8 = teavm_local_3;
            TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(41264, teavm_checkBounds(teavm_local_11, teavm_local_8))) = teavm_local_12;
            teavm_local_6 = (teavm_local_6 + INT32_C(1));
        }
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jm_Multiplication_multiplyByInt(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int64_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(41265, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_5 = INT64_C(0);
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_3)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41266, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = teavm_local_2;
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41267, teavm_checkBounds(teavm_local_6, teavm_local_7));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(41268, meth_jm_Multiplication_unsignedMultAddAdd(TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6), teavm_local_4, ((int32_t) teavm_local_5), INT32_C(0)));
        teavm_local_9 = ((int32_t) teavm_local_8);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41269, teavm_nullCheck(teavm_local_1));
        teavm_local_7 = teavm_local_1;
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41270, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6) = teavm_local_9;
        teavm_local_5 = ((int64_t) ((uint64_t) teavm_local_8 >> INT32_C(32)));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    teavm_local_9 = ((int32_t) teavm_local_5);
    TEAVM_RELEASE_STACK;
    return teavm_local_9;
}
void* meth_jm_Multiplication_multiplyByPositiveInt(void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    int64_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(41271, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41272, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_sign);
    if ((!teavm_local_3)) {
        TEAVM_WITH_CALL_SITE_ID(41273, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
        teavm_local_4 = sfld_jm_BigInteger_ZERO;
    } else {
        teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_numberLength);
        teavm_local_6 = TEAVM_FIELD(teavm_local_1, cls_jm_BigInteger, fld_digits);
        if ((teavm_local_5 != INT32_C(1))) {
            teavm_local_7 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(41274, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_7));
            teavm_local_9 = teavm_local_8;
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41275, meth_jm_Multiplication_multiplyByInt(teavm_local_8, teavm_local_6, teavm_local_5, teavm_local_2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41276, teavm_checkBounds(teavm_local_5, teavm_local_9));
            TEAVM_ARRAY_AT(teavm_local_9, int32_t, teavm_local_5) = teavm_local_10;
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41277, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(41278, meth_jm_BigInteger__init_(teavm_local_4, teavm_local_3, teavm_local_7, teavm_local_8));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(41279, meth_jm_BigInteger_cutOffLeadingZeroes(teavm_local_4));
        } else {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41280, teavm_nullCheck(teavm_local_6));
            teavm_local_9 = teavm_local_6;
            teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_9, int32_t, TEAVM_WITH_CALL_SITE_ID(41281, teavm_checkUpperBound(INT32_C(0), teavm_local_9)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41282, meth_jm_Multiplication_unsignedMultAddAdd(teavm_local_10, teavm_local_2, INT32_C(0), INT32_C(0)));
            teavm_local_12 = ((int32_t) teavm_local_11);
            teavm_local_13 = ((int32_t) ((int64_t) ((uint64_t) teavm_local_11 >> INT32_C(32))));
            if ((!teavm_local_13)) {
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41283, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                TEAVM_WITH_CALL_SITE_ID(41284, meth_jm_BigInteger__init__0(teavm_local_4, teavm_local_3, teavm_local_12));
            } else {
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41285, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(41286, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 2), teavm_local_12, teavm_local_13));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
                TEAVM_WITH_CALL_SITE_ID(41287, meth_jm_BigInteger__init_(teavm_local_4, teavm_local_3, INT32_C(2), teavm_local_9));
            }
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jm_Multiplication_pow(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(41288, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    TEAVM_WITH_CALL_SITE_ID(41289, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
    teavm_local_3 = sfld_jm_BigInteger_ONE;
    while (1) {
        if (!(teavm_local_2 > INT32_C(1))) break;
        if ((teavm_local_2 & INT32_C(1))) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41290, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41291, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_1)));
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41292, teavm_nullCheck(teavm_local_1));
        if ((TEAVM_FIELD(teavm_local_4, cls_jm_BigInteger, fld_numberLength) == INT32_C(1))) {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41293, TEAVM_METHOD(teavm_local_4, jm_BigInteger_VT, virt_multiply)(teavm_local_4, teavm_local_4));
        } else {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41294, meth_otr_Allocator_allocate(&jm_BigInteger_Cls));
            teavm_local_5 = TEAVM_FIELD(teavm_local_4, cls_jm_BigInteger, fld_digits);
            teavm_local_6 = TEAVM_FIELD(teavm_local_4, cls_jm_BigInteger, fld_numberLength);
            teavm_local_7 = (TEAVM_FIELD(teavm_local_4, cls_jm_BigInteger, fld_numberLength) << INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(41295, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_7));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41296, meth_jm_Multiplication_square(teavm_local_5, teavm_local_6, teavm_local_8));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_WITH_CALL_SITE_ID(41297, meth_jm_BigInteger__init__2(teavm_local_1, INT32_C(1), teavm_local_5));
        }
        teavm_local_2 = (teavm_local_2 >> INT32_C(1));
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(41298, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41299, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_9;
}
TeaVM_Array* meth_jm_Multiplication_square(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3) {
    int32_t teavm_local_4;
    int64_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int64_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(41300, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_4 = INT32_C(0);
    while (1) {
        if (!(teavm_local_4 < teavm_local_2)) break;
        teavm_local_5 = INT64_C(0);
        teavm_local_6 = (teavm_local_4 + INT32_C(1));
        teavm_local_7 = teavm_local_6;
        while (1) {
            if (!(teavm_local_7 < teavm_local_2)) break;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41301, teavm_nullCheck(teavm_local_1));
            teavm_local_8 = teavm_local_1;
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41302, teavm_checkBounds(teavm_local_4, teavm_local_8));
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_4);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41303, teavm_checkBounds(teavm_local_7, teavm_local_8));
            teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7);
            teavm_local_11 = (teavm_local_4 + teavm_local_7);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41304, teavm_nullCheck(teavm_local_3));
            teavm_local_8 = teavm_local_3;
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(41305, teavm_checkBounds(teavm_local_11, teavm_local_8));
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41306, meth_jm_Multiplication_unsignedMultAddAdd(teavm_local_9, teavm_local_10, TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12), ((int32_t) teavm_local_5)));
            TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12) = ((int32_t) teavm_local_13);
            teavm_local_5 = ((int64_t) ((uint64_t) teavm_local_13 >> INT32_C(32)));
            teavm_local_7 = (teavm_local_7 + INT32_C(1));
        }
        teavm_local_11 = (teavm_local_4 + teavm_local_2);
        teavm_local_12 = ((int32_t) teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41307, teavm_nullCheck(teavm_local_3));
        teavm_local_8 = teavm_local_3;
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(41308, teavm_checkBounds(teavm_local_11, teavm_local_8))) = teavm_local_12;
        teavm_local_4 = teavm_local_6;
    }
    teavm_local_11 = (teavm_local_2 << INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(41309, meth_jm_BitLevel_shiftLeftOneBit(teavm_local_3, teavm_local_3, teavm_local_11));
    teavm_local_5 = INT64_C(0);
    teavm_local_4 = INT32_C(0);
    teavm_local_14 = INT32_C(0);
    while (1) {
        if (!(teavm_local_4 < teavm_local_2)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41310, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(41311, teavm_checkBounds(teavm_local_4, teavm_local_8));
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_15);
        teavm_local_12 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_15);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41312, teavm_nullCheck(teavm_local_3));
        teavm_local_8 = teavm_local_3;
        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(41313, teavm_checkBounds(teavm_local_14, teavm_local_8));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41314, meth_jm_Multiplication_unsignedMultAddAdd(teavm_local_11, teavm_local_12, TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_14), ((int32_t) teavm_local_5)));
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_14) = ((int32_t) teavm_local_13);
        teavm_local_13 = ((int64_t) ((uint64_t) teavm_local_13 >> INT32_C(32)));
        teavm_local_11 = (teavm_local_14 + INT32_C(1));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(41315, teavm_checkBounds(teavm_local_11, teavm_local_8));
        teavm_local_13 = (teavm_local_13 + (((int64_t) TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12)) & INT64_C(4294967295)));
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_12) = ((int32_t) teavm_local_13);
        teavm_local_5 = ((int64_t) ((uint64_t) teavm_local_13 >> INT32_C(32)));
        teavm_local_4 = (teavm_local_15 + INT32_C(1));
        teavm_local_14 = (teavm_local_12 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jm_Multiplication_powerOf10(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    int64_t teavm_local_5;
    void* teavm_local_6;
    int64_t teavm_local_7;
    int32_t teavm_local_8;
    int64_t teavm_local_9;
    void* teavm_local_10;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(41316, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_2 = ((int32_t) teavm_local_1);
    teavm_local_3 = sfld_jm_Multiplication_bigTenPows;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_1 < ((int64_t) TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(41317, teavm_nullCheck(teavm_local_3)))))) {
        teavm_local_3 = sfld_jm_Multiplication_bigTenPows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41318, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41319, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2);
    } else if ((teavm_local_1 <= INT64_C(50))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(41320, teavm_initializeClass((TeaVM_Class*) &jm_BigInteger_Cls, &initclass_jm_BigInteger));
        teavm_local_4 = sfld_jm_BigInteger_TEN;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41321, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41322, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, teavm_local_2)));
    } else if ((teavm_local_1 <= INT64_C(1000))) {
        teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41323, teavm_nullCheck(teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(41324, teavm_checkUpperBound(INT32_C(1), teavm_local_3)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41325, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41326, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, teavm_local_2)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41327, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41328, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, teavm_local_2)));
    } else {
        teavm_local_5 = (INT64_C(1) + ((int64_t) (((double) teavm_local_1) / 0x1.34413509f79ffp1)));
        if ((teavm_local_5 <= INT64_C(1000000))) {
            if ((teavm_local_1 <= INT64_C(2147483647))) {
                teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41329, teavm_nullCheck(teavm_local_3));
                teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(41330, teavm_checkUpperBound(INT32_C(1), teavm_local_3)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41331, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41332, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, teavm_local_2)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41333, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41334, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, teavm_local_2)));
            } else {
                teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41335, teavm_nullCheck(teavm_local_3));
                teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(41336, teavm_checkUpperBound(INT32_C(1), teavm_local_3)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41337, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41338, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, INT32_C(2147483647))));
                teavm_local_7 = (teavm_local_1 - INT64_C(2147483647));
                teavm_local_8 = ((int32_t) (teavm_local_1 % INT64_C(2147483647)));
                teavm_local_4 = teavm_local_6;
                teavm_local_9 = teavm_local_7;
                while (1) {
                    if (!(teavm_local_9 > INT64_C(2147483647))) break;
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41339, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41340, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_6)));
                    teavm_local_9 = (teavm_local_9 - INT64_C(2147483647));
                }
                teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41341, teavm_nullCheck(teavm_local_3));
                teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(41342, teavm_checkUpperBound(INT32_C(1), teavm_local_3)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(41343, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41344, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, teavm_local_8)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41345, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41346, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_10)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41347, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41348, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, INT32_C(2147483647))));
                while (1) {
                    if (!(teavm_local_7 > INT64_C(2147483647))) break;
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41349, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41350, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, INT32_C(2147483647))));
                    teavm_local_7 = (teavm_local_7 - INT64_C(2147483647));
                }
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41351, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41352, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_shiftLeft)(teavm_tmp_ptr_0, teavm_local_8)));
            }
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41353, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(41354, meth_jl_ArithmeticException__init_(teavm_local_4, TEAVM_GET_STRING(8058)));
            TEAVM_WITH_CALL_SITE_ID(41355, meth_otr_ExceptionHandling_throwException(teavm_local_4));
            TEAVM_UNREACHABLE
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jm_Multiplication_multiplyByFivePow(void* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(41356, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_3 = sfld_jm_Multiplication_fivePows;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(41357, teavm_nullCheck(teavm_local_3))))) {
        teavm_local_3 = sfld_jm_Multiplication_fivePows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41358, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41359, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41360, meth_jm_Multiplication_multiplyByPositiveInt(teavm_local_1, teavm_local_4));
    } else {
        teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(41361, teavm_nullCheck(teavm_local_3))))) {
            teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41362, teavm_nullCheck(teavm_local_3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41363, teavm_checkBounds(teavm_local_2, teavm_local_3));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41364, teavm_nullCheck(teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41365, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_multiply)(teavm_local_1, teavm_local_5));
        } else {
            teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41366, teavm_nullCheck(teavm_local_3));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(41367, teavm_checkUpperBound(INT32_C(1), teavm_local_3)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41368, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41369, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_pow)(teavm_tmp_ptr_0, teavm_local_2)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41370, teavm_nullCheck(teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(41371, TEAVM_METHOD(teavm_local_1, jm_BigInteger_VT, virt_multiply)(teavm_local_1, teavm_local_5));
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int64_t meth_jm_Multiplication_unsignedMultAddAdd(int32_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int64_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41372, teavm_initializeClass((TeaVM_Class*) &jm_Multiplication_Cls, &initclass_jm_Multiplication));
    teavm_local_5 = ((((((int64_t) teavm_local_1) & INT64_C(4294967295)) * (((int64_t) teavm_local_2) & INT64_C(4294967295))) + (((int64_t) teavm_local_3) & INT64_C(4294967295))) + (((int64_t) teavm_local_4) & INT64_C(4294967295)));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void meth_jm_Multiplication__clinit_() {
    int64_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    int64_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    sfld_jm_Multiplication_tenPows = TEAVM_WITH_CALL_SITE_ID(41373, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 10), INT32_C(1), INT32_C(10), INT32_C(100), INT32_C(1000), INT32_C(10000), INT32_C(100000), INT32_C(1000000), INT32_C(10000000), INT32_C(100000000), INT32_C(1000000000)));
    sfld_jm_Multiplication_fivePows = TEAVM_WITH_CALL_SITE_ID(41374, teavm_fillIntArray(meth_otr_Allocator_allocateArray(&Arr_I_Cls, 14), INT32_C(1), INT32_C(5), INT32_C(25), INT32_C(125), INT32_C(625), INT32_C(3125), INT32_C(15625), INT32_C(78125), INT32_C(390625), INT32_C(1953125), INT32_C(9765625), INT32_C(48828125), INT32_C(244140625), INT32_C(1220703125)));
    sfld_jm_Multiplication_bigTenPows = TEAVM_WITH_CALL_SITE_ID(41375, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(32)));
    sfld_jm_Multiplication_bigFivePows = TEAVM_WITH_CALL_SITE_ID(41376, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jm_BigInteger_Cls), INT32_C(32)));
    teavm_local_1 = INT64_C(1);
    teavm_local_2 = INT32_C(0);
    while (1) {
        if (!(teavm_local_2 <= INT32_C(18))) break;
        teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41377, meth_jm_BigInteger_valueOf(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41378, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41379, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_gc_writeBarrier(teavm_local_3);
        TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_4;
        teavm_local_3 = sfld_jm_Multiplication_bigTenPows;
        teavm_local_5 = (teavm_local_1 << teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41380, meth_jm_BigInteger_valueOf(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41381, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41382, teavm_checkUpperBound(teavm_local_2, teavm_local_3));
        teavm_gc_writeBarrier(teavm_local_3);
        TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_4;
        teavm_local_1 = (teavm_local_1 * INT64_C(5));
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
    while (1) {
        teavm_local_3 = sfld_jm_Multiplication_bigTenPows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((teavm_local_2 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(41383, teavm_nullCheck(teavm_local_3))))) {
            goto teavm_label_2;
        }
        teavm_local_3 = sfld_jm_Multiplication_bigFivePows;
        teavm_local_6 = sfld_jm_Multiplication_bigFivePows;
        teavm_local_7 = (teavm_local_2 - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41384, teavm_nullCheck(teavm_local_6));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(41385, teavm_checkBounds(teavm_local_7, teavm_local_6));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_8);
        teavm_local_6 = sfld_jm_Multiplication_bigFivePows;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41386, teavm_nullCheck(teavm_local_6));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_6, void*, TEAVM_WITH_CALL_SITE_ID(41387, teavm_checkUpperBound(INT32_C(1), teavm_local_6)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41388, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41389, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_9)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41390, teavm_nullCheck(teavm_local_3));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41391, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_gc_writeBarrier(teavm_local_3);
        TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7) = teavm_local_4;
        teavm_local_3 = sfld_jm_Multiplication_bigTenPows;
        teavm_local_6 = sfld_jm_Multiplication_bigTenPows;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(41392, teavm_nullCheck(teavm_local_6));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_6, void*, TEAVM_WITH_CALL_SITE_ID(41393, teavm_checkUpperBound(teavm_local_8, teavm_local_6)));
        teavm_local_9 = sfld_jm_BigInteger_TEN;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41394, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41395, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jm_BigInteger_VT, virt_multiply)(teavm_tmp_ptr_0, teavm_local_9)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41396, teavm_nullCheck(teavm_local_3));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41397, teavm_checkUpperBound(teavm_local_7, teavm_local_3));
        teavm_gc_writeBarrier(teavm_local_3);
        TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7) = teavm_local_4;
        teavm_local_2 = (teavm_local_7 + INT32_C(1));
    }
teavm_label_2:;
    TEAVM_RELEASE_STACK;
}
void initclass_jm_Multiplication() {
    TeaVM_Class* cls = (TeaVM_Class*) &jm_Multiplication_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jm_Multiplication__clinit_();
    }
}
int32_t supertypeof_jm_Multiplication(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1931 || tag >= 1933) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jm_Multiplication_VT jm_Multiplication_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jm_Multiplication), sizeof(void*)),
            .flags = 0,
            .tag = 1931,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jm_Multiplication,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jm_Multiplication_Cls[4] = {
(void**) &sfld_jm_Multiplication_tenPows, (void**) &sfld_jm_Multiplication_fivePows, (void**) &sfld_jm_Multiplication_bigTenPows, (void**) &sfld_jm_Multiplication_bigFivePows
};
void sysinitclass_jm_Multiplication() {
sfld_jm_Multiplication_tenPows = NULL;
sfld_jm_Multiplication_fivePows = NULL;
sfld_jm_Multiplication_bigTenPows = NULL;
sfld_jm_Multiplication_bigFivePows = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jm_Multiplication_Cls, 4);
}
