#pragma once
#include "../../../runtime.h"
#include "Number.h"
#include "Long.h"

extern void sysinitclass_jl_Long();
typedef struct cls_jl_Long {
    struct cls_jl_Number parent;
    int64_t fld_value;
} cls_jl_Long;
extern void* sfld_jl_Long_TYPE;
extern void meth_jl_Long__init_(void*, int64_t);
extern void* meth_jl_Long_valueOf(int64_t);
extern int64_t meth_jl_Long_parseLong(void*, int32_t);
extern int64_t meth_jl_Long_parseLongImpl(void*, int32_t, int32_t, int32_t);
extern int64_t meth_jl_Long_parseLong_0(void*);
extern void* meth_jl_Long_valueOf_0(void*);
extern int32_t meth_jl_Long_decodeDigit(int32_t);
extern int64_t meth_jl_Long_longValue(void*);
extern double meth_jl_Long_doubleValue(void*);
extern void* meth_jl_Long_toString(int64_t);
extern void* meth_jl_Long_toString_0(void*);
extern int32_t meth_jl_Long_hashCode(void*);
extern int32_t meth_jl_Long_hashCode_0(int64_t);
extern int32_t meth_jl_Long_equals(void*, void*);
extern int32_t meth_jl_Long_compare(int64_t, int64_t);
extern int32_t meth_jl_Long_compareTo(void*, void*);
extern int32_t meth_jl_Long_numberOfLeadingZeros(int64_t);
extern int32_t meth_jl_Long_numberOfTrailingZeros(int64_t);
extern int32_t meth_jl_Long_signum(int64_t);
extern int32_t meth_jl_Long_compareTo_0(void*, void*);
extern void meth_jl_Long__clinit_();
extern void initclass_jl_Long();
extern int32_t supertypeof_jl_Long(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Long_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_intValue)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    int64_t (*virt_longValue)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    int32_t (*virt_compareTo_10)(void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    double (*virt_doubleValue)(void*); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*pad32)(); // 48
    void (*pad33)(); // 49
} jl_Long_VT;
extern jl_Long_VT jl_Long_Cls;
