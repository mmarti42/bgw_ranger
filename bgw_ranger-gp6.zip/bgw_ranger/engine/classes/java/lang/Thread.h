#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Thread.h"

extern void sysinitclass_jl_Thread();
typedef struct cls_jl_Thread {
    struct TeaVM_Object parent;
    void* fld_uncaughtExceptionHandler;
    int64_t fld_id;
    int8_t fld_daemon;
    int64_t fld_timeSliceStart;
    int32_t fld_yieldCount;
    void* fld_finishedLock;
    int8_t fld_interruptedFlag;
    void* fld_interruptHandler;
    void* fld_key;
    void* fld_name;
    int8_t fld_alive;
    void* fld_target;
} cls_jl_Thread;
extern void* sfld_jl_Thread_mainThread;
extern void* sfld_jl_Thread_currentThread;
extern int32_t sfld_jl_Thread_nextId;
extern int32_t sfld_jl_Thread_activeCount;
extern void* sfld_jl_Thread_defaultUncaughtExceptionHandler;
extern void meth_jl_Thread__init_(void*);
extern void meth_jl_Thread__init__1(void*, void*);
extern void meth_jl_Thread__init__0(void*, void*, void*);
extern void meth_jl_Thread_start(void*);
extern void meth_jl_Thread_runThread(void*);
extern void meth_jl_Thread_setCurrentThread(void*);
extern void* meth_jl_Thread_getMainThread();
extern void* meth_jl_Thread_currentThread();
extern void* meth_jl_Thread_getName(void*);
extern void meth_jl_Thread_setDaemon(void*, int32_t);
extern void meth_jl_Thread_join(void*, int64_t, int32_t);
extern void meth_jl_Thread_join_1(void*, int64_t);
extern void meth_jl_Thread_join_0(void*);
extern void meth_jl_Thread_yield();
extern void meth_jl_Thread_switchContext(void*);
extern void meth_jl_Thread_switchContext_0(void*, void*);
extern void meth_jl_Thread_interrupt(void*);
extern int32_t meth_jl_Thread_interrupted();
extern int32_t meth_jl_Thread_isAlive(void*);
extern int64_t meth_jl_Thread_getId(void*);
extern void* meth_jl_Thread_getUncaughtExceptionHandler(void*);
extern void meth_jl_Thread_lambda_switchContext_1(void*, void*);
extern void meth_jl_Thread_lambda_start_0(void*, int32_t);
extern void meth_jl_Thread__clinit_();
extern void initclass_jl_Thread();
extern int32_t supertypeof_jl_Thread(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Thread_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_isAlive)(void*); // 11
    int64_t (*virt_getId_0)(void*); // 12
    void (*pad0)(); // 13
    void* (*virt_getUncaughtExceptionHandler)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void* (*virt_getName)(void*); // 18
    void (*pad4)(); // 19
    void (*pad5)(); // 20
    void (*virt_setDaemon)(void*, int32_t); // 21
    void (*virt_start_1)(void*); // 22
    void (*virt_join)(void*, int64_t, int32_t); // 23
    void (*pad6)(); // 24
    void (*pad7)(); // 25
    void (*pad8)(); // 26
    void (*virt_interrupt)(void*); // 27
    void (*virt_run_0)(void*); // 28
    void (*pad9)(); // 29
    void (*pad10)(); // 30
    void (*pad11)(); // 31
    void (*pad12)(); // 32
    void (*pad13)(); // 33
    void (*pad14)(); // 34
    void (*pad15)(); // 35
    void (*pad16)(); // 36
    void (*virt_join_0)(void*); // 37
    void (*pad17)(); // 38
    void (*pad18)(); // 39
    void (*pad19)(); // 40
    void (*pad20)(); // 41
    void (*pad21)(); // 42
    void (*pad22)(); // 43
    void (*pad23)(); // 44
    void (*pad24)(); // 45
    void (*pad25)(); // 46
    void (*pad26)(); // 47
    void (*virt_join_1)(void*, int64_t); // 48
    void (*pad27)(); // 49
} jl_Thread_VT;
extern jl_Thread_VT jl_Thread_Cls;
