#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Character.h"

extern void sysinitclass_jl_Character();
typedef struct cls_jl_Character {
    struct TeaVM_Object parent;
    char16_t fld_value;
} cls_jl_Character;
extern void* sfld_jl_Character_TYPE;
extern TeaVM_Array* sfld_jl_Character_digitMapping;
extern void* sfld_jl_Character_upperCaseMapping;
extern void* sfld_jl_Character_lowerCaseMapping;
extern TeaVM_Array* sfld_jl_Character_classMapping;
extern TeaVM_Array* sfld_jl_Character_characterCache;
extern void* sfld_jl_Character___metadata__0;
extern void* sfld_jl_Character___metadata__1;
extern void* sfld_jl_Character___metadata__3;
extern void* sfld_jl_Character___metadata__4;
extern void meth_jl_Character__init_(void*, int32_t);
extern int32_t meth_jl_Character_charValue(void*);
extern void* meth_jl_Character_valueOf(int32_t);
extern void* meth_jl_Character_toString_0(void*);
extern int32_t meth_jl_Character_equals(void*, void*);
extern int32_t meth_jl_Character_hashCode(void*);
extern int32_t meth_jl_Character_hashCode_0(int32_t);
extern void* meth_jl_Character_toString(int32_t);
extern int32_t meth_jl_Character_isValidCodePoint(int32_t);
extern int32_t meth_jl_Character_isBmpCodePoint(int32_t);
extern int32_t meth_jl_Character_isSupplementaryCodePoint(int32_t);
extern int32_t meth_jl_Character_isHighSurrogate(int32_t);
extern int32_t meth_jl_Character_isLowSurrogate(int32_t);
extern int32_t meth_jl_Character_isSurrogate(int32_t);
extern int32_t meth_jl_Character_isSurrogatePair(int32_t, int32_t);
extern int32_t meth_jl_Character_toCodePoint(int32_t, int32_t);
extern int32_t meth_jl_Character_codePointAt(TeaVM_Array*, int32_t);
extern int32_t meth_jl_Character_codePointAt_0(TeaVM_Array*, int32_t, int32_t);
extern int32_t meth_jl_Character_highSurrogate(int32_t);
extern int32_t meth_jl_Character_lowSurrogate(int32_t);
extern int32_t meth_jl_Character_toLowerCase(int32_t);
extern int32_t meth_jl_Character_toLowerCase_0(int32_t);
extern void* meth_jl_Character_getLowerCaseMapping();
extern void* meth_jl_Character_acquireLowerCaseMapping();
extern int32_t meth_jl_Character_toUpperCase(int32_t);
extern int32_t meth_jl_Character_toUpperCase_0(int32_t);
extern void* meth_jl_Character_getUpperCaseMapping();
extern void* meth_jl_Character_acquireUpperCaseMapping();
extern int32_t meth_jl_Character_mapChar(void*, int32_t);
extern int32_t meth_jl_Character_binarySearchTable(TeaVM_Array*, int32_t);
extern int32_t meth_jl_Character_digit(int32_t, int32_t);
extern int32_t meth_jl_Character_digit_0(int32_t, int32_t);
extern int32_t meth_jl_Character_getNumericValue(int32_t);
extern int32_t meth_jl_Character_forDigit(int32_t, int32_t);
extern int32_t meth_jl_Character_isDigit(int32_t);
extern int32_t meth_jl_Character_isDigit_0(int32_t);
extern TeaVM_Array* meth_jl_Character_getDigitMapping();
extern void* meth_jl_Character_obtainDigitMapping();
extern TeaVM_Array* meth_jl_Character_getClasses();
extern void* meth_jl_Character_obtainClasses();
extern TeaVM_Array* meth_jl_Character_toChars(int32_t);
extern int32_t meth_jl_Character_isISOControl(int32_t);
extern int32_t meth_jl_Character_getType_0(int32_t);
extern int32_t meth_jl_Character_getType(int32_t);
extern int32_t meth_jl_Character_isLowerCase(int32_t);
extern int32_t meth_jl_Character_isUpperCase(int32_t);
extern int32_t meth_jl_Character_isTitleCase(int32_t);
extern int32_t meth_jl_Character_isDefined(int32_t);
extern int32_t meth_jl_Character_isLetter(int32_t);
extern int32_t meth_jl_Character_isLetterOrDigit(int32_t);
extern int32_t meth_jl_Character_isLetterOrDigit_0(int32_t);
extern int32_t meth_jl_Character_isJavaIdentifierStart(int32_t);
extern int32_t meth_jl_Character_isJavaIdentifierPart(int32_t);
extern int32_t meth_jl_Character_isUnicodeIdentifierStart(int32_t);
extern int32_t meth_jl_Character_isUnicodeIdentifierPart(int32_t);
extern int32_t meth_jl_Character_isIdentifierIgnorable(int32_t);
extern int32_t meth_jl_Character_isSpaceChar(int32_t);
extern int32_t meth_jl_Character_isWhitespace(int32_t);
extern int32_t meth_jl_Character_isWhitespace_0(int32_t);
extern int32_t meth_jl_Character_compareTo(void*, void*);
extern int32_t meth_jl_Character_compare(int32_t, int32_t);
extern int32_t meth_jl_Character_reverseBytes(int32_t);
extern int32_t meth_jl_Character_compareTo_0(void*, void*);
extern void meth_jl_Character__clinit_();
extern void* meth_jl_Character_acquireLowerCaseMapping__create();
extern void* meth_jl_Character_acquireUpperCaseMapping__create();
extern void* meth_jl_Character_obtainDigitMapping__create();
extern void* meth_jl_Character_obtainClasses__create();
extern void initclass_jl_Character();
extern int32_t supertypeof_jl_Character(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Character_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_compareTo_9)(void*, void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    int32_t (*virt_charValue)(void*); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} jl_Character_VT;
extern jl_Character_VT jl_Character_Cls;
