#include "Comparable.h"
#include "../../../strings.h"

int32_t supertypeof_jl_Comparable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 101 || tag >= 2205) return INT32_C(0);
    if (tag >= 105 && tag < 116) return INT32_C(0);
    if (tag >= 122 && tag < 122) return INT32_C(0);
    if (tag >= 126 && tag < 223) return INT32_C(0);
    if (tag >= 233 && tag < 333) return INT32_C(0);
    if (tag >= 335 && tag < 525) return INT32_C(0);
    if (tag >= 529 && tag < 601) return INT32_C(0);
    if (tag >= 603 && tag < 1013) return INT32_C(0);
    if (tag >= 1015 && tag < 1075) return INT32_C(0);
    if (tag >= 1077 && tag < 1407) return INT32_C(0);
    if (tag >= 1409 && tag < 1453) return INT32_C(0);
    if (tag >= 1455 && tag < 1899) return INT32_C(0);
    if (tag >= 1901 && tag < 1962) return INT32_C(0);
    if (tag >= 1964 && tag < 1964) return INT32_C(0);
    if (tag >= 1966 && tag < 1966) return INT32_C(0);
    if (tag >= 1968 && tag < 1970) return INT32_C(0);
    if (tag >= 1972 && tag < 1972) return INT32_C(0);
    if (tag >= 1974 && tag < 1976) return INT32_C(0);
    if (tag >= 1978 && tag < 1978) return INT32_C(0);
    if (tag >= 1980 && tag < 1980) return INT32_C(0);
    if (tag >= 1982 && tag < 2165) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jl_Comparable_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 101,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jl_Comparable,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jl_Comparable() {
}
