#include "System.h"
#include "Object.h"
#include "../io/PrintStream.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/classlib/impl/console/StderrOutputStream.h"
#include "reflect/Array.h"
#include "Class.h"
#include "ArrayStoreException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../arrayclass.h"
#include "IndexOutOfBoundsException.h"
#include "NullPointerException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/RuntimeArray.h"
#include "../../org/teavm/runtime/RuntimeClass.h"
#include <string.h>
#include "../../../time.h"
#include "../util/Properties.h"
#include "../../org/teavm/runtime/fs/VirtualFileSystemProvider.h"
#include "../../org/teavm/runtime/fs/VirtualFileSystem.h"
#include <stdlib.h>
#include "../../../file.h"
#include "../../../arrays/primitives/char.h"
#include "String.h"

void* sfld_jl_System_errCache;
void* sfld_jl_System_properties;
void* meth_jl_System_err() {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((sfld_jl_System_errCache == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40097, meth_otr_Allocator_allocate(&ji_PrintStream_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(40098, teavm_initializeClass((TeaVM_Class*) &otcic_StderrOutputStream_Cls, &initclass_otcic_StderrOutputStream));
        teavm_local_2 = sfld_otcic_StderrOutputStream_INSTANCE;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(40099, meth_ji_PrintStream__init_(teavm_local_1, teavm_local_2, INT32_C(0)));
        sfld_jl_System_errCache = teavm_local_1;
    }
    teavm_local_2 = sfld_jl_System_errCache;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_System_arraycopy(void* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    TeaVM_Array* teavm_local_11;
    int32_t teavm_local_12;
    TeaVM_Array* teavm_local_13;
    void* teavm_local_14;
    void* teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(5));
    if (((teavm_local_1 != NULL) && (teavm_local_3 != NULL))) {
        if (((teavm_local_2 >= INT32_C(0)) && ((teavm_local_4 >= INT32_C(0)) && (teavm_local_5 >= INT32_C(0))))) {
            teavm_local_6 = (teavm_local_2 + teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            if ((teavm_local_6 <= TEAVM_WITH_CALL_SITE_ID(40100, meth_jlr_Array_getLength(teavm_local_1)))) {
                teavm_local_7 = (teavm_local_4 + teavm_local_5);
                if ((teavm_local_7 <= TEAVM_WITH_CALL_SITE_ID(40101, meth_jlr_Array_getLength(teavm_local_3)))) {
                    if ((teavm_local_1 != teavm_local_3)) {
                        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40102, teavm_nullCheck(teavm_local_1));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40103, meth_jl_Object_getClass(teavm_local_1));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(40104, meth_jl_Class_getComponentType(TEAVM_WITH_CALL_SITE_ID(40105, teavm_nullCheck(teavm_local_8))));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40106, teavm_nullCheck(teavm_local_3));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40107, meth_jl_Object_getClass(teavm_local_3));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_8);
                        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(40108, meth_jl_Class_getComponentType(TEAVM_WITH_CALL_SITE_ID(40109, teavm_nullCheck(teavm_local_8))));
                        if ((!((teavm_local_9 != NULL) && (teavm_local_10 != NULL)))) {
                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40110, meth_otr_Allocator_allocate(&jl_ArrayStoreException_Cls));
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                            TEAVM_WITH_CALL_SITE_ID(40111, meth_jl_ArrayStoreException__init_(teavm_local_8));
                            TEAVM_WITH_CALL_SITE_ID(40112, meth_otr_ExceptionHandling_throwException(teavm_local_8));
                            TEAVM_UNREACHABLE
                        } else if ((teavm_local_9 != teavm_local_10)) {
                            TEAVM_GC_ROOT(INT32_C(3), teavm_local_10);
                            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(40113, teavm_nullCheck(teavm_local_9));
                            if ((!TEAVM_WITH_CALL_SITE_ID(40114, meth_jl_Class_isPrimitive(teavm_local_9)))) {
                                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(40115, teavm_nullCheck(teavm_local_10));
                                if ((!TEAVM_WITH_CALL_SITE_ID(40116, meth_jl_Class_isPrimitive(teavm_local_10)))) {
                                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(40117, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), &teavm_isSupertypeOfArray));
                                    teavm_local_12 = INT32_C(0);
                                    teavm_local_7 = teavm_local_2;
                                    while (1) {
                                        if (!(teavm_local_12 < teavm_local_5)) break;
                                        teavm_local_6 = (teavm_local_7 + INT32_C(1));
                                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
                                        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(40118, teavm_nullCheck(teavm_local_11));
                                        teavm_local_13 = teavm_local_11;
                                        teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_13, void*, TEAVM_WITH_CALL_SITE_ID(40119, teavm_checkBounds(teavm_local_7, teavm_local_13)));
                                        TEAVM_GC_ROOT(INT32_C(4), teavm_local_14);
                                        if ((!TEAVM_WITH_CALL_SITE_ID(40120, meth_jl_Class_isInstance(teavm_local_10, teavm_local_14)))) {
                                            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                                            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                                            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
                                            TEAVM_WITH_CALL_SITE_ID(40121, meth_jl_System_doArrayCopy(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4, teavm_local_12));
                                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                                            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                                            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40122, meth_otr_Allocator_allocate(&jl_ArrayStoreException_Cls));
                                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                                            TEAVM_WITH_CALL_SITE_ID(40123, meth_jl_ArrayStoreException__init_(teavm_local_8));
                                            TEAVM_WITH_CALL_SITE_ID(40124, meth_otr_ExceptionHandling_throwException(teavm_local_8));
                                            TEAVM_UNREACHABLE
                                        }
                                        teavm_local_12 = (teavm_local_12 + INT32_C(1));
                                        teavm_local_7 = teavm_local_6;
                                    }
                                    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                                    TEAVM_WITH_CALL_SITE_ID(40125, meth_jl_System_doArrayCopy(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4, teavm_local_5));
                                    goto teavm_label_1;
                                }
                            }
                            TEAVM_GC_ROOT(INT32_C(3), teavm_local_10);
                            if ((!TEAVM_WITH_CALL_SITE_ID(40126, meth_jl_Class_isPrimitive(teavm_local_9)))) {
                                goto teavm_label_2;
                            }
                            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(40127, teavm_nullCheck(teavm_local_10));
                            if ((!TEAVM_WITH_CALL_SITE_ID(40128, meth_jl_Class_isPrimitive(teavm_local_10)))) {
                                goto teavm_label_2;
                            }
                        }
                    }
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                    TEAVM_WITH_CALL_SITE_ID(40129, meth_jl_System_doArrayCopy(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4, teavm_local_5));
                    goto teavm_label_1;
                teavm_label_2:;
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40130, meth_otr_Allocator_allocate(&jl_ArrayStoreException_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                    TEAVM_WITH_CALL_SITE_ID(40131, meth_jl_ArrayStoreException__init_(teavm_local_8));
                    TEAVM_WITH_CALL_SITE_ID(40132, meth_otr_ExceptionHandling_throwException(teavm_local_8));
                    TEAVM_UNREACHABLE
                teavm_label_1:;
                    TEAVM_RELEASE_STACK;
                    return;
                }
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40133, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_WITH_CALL_SITE_ID(40134, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_8));
        TEAVM_WITH_CALL_SITE_ID(40135, meth_otr_ExceptionHandling_throwException(teavm_local_8));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(40136, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_15);
    TEAVM_WITH_CALL_SITE_ID(40137, meth_jl_NullPointerException__init__0(teavm_local_15, TEAVM_GET_STRING(8019)));
    TEAVM_WITH_CALL_SITE_ID(40138, meth_otr_ExceptionHandling_throwException(teavm_local_15));
    TEAVM_UNREACHABLE
}
void meth_jl_System_fastArraycopy(void* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_2 >= INT32_C(0)) && ((teavm_local_4 >= INT32_C(0)) && (teavm_local_5 >= INT32_C(0))))) {
        teavm_local_6 = (teavm_local_2 + teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if ((teavm_local_6 <= TEAVM_WITH_CALL_SITE_ID(40139, meth_jl_System_fastArrayLength(teavm_local_1)))) {
            teavm_local_7 = (teavm_local_4 + teavm_local_5);
            if ((teavm_local_7 <= TEAVM_WITH_CALL_SITE_ID(40140, meth_jl_System_fastArrayLength(teavm_local_3)))) {
                TEAVM_WITH_CALL_SITE_ID(40141, meth_jl_System_doArrayCopy(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4, teavm_local_5));
                TEAVM_RELEASE_STACK;
                return;
            }
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(40142, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(40143, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(40144, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_System_fastArrayLength(void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_local_2, TeaVM_Array, size);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jl_System_doArrayCopy(void* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    meth_jl_System_doArrayCopyLowLevel(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4, teavm_local_5);
}
void meth_jl_System_doArrayCopyLowLevel(void* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    void* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    void* teavm_local_12;
    teavm_local_6 = meth_otr_RuntimeClass_getClass(teavm_local_1);
    teavm_local_7 = TEAVM_FIELD(TEAVM_FIELD(teavm_local_6, TeaVM_Class, itemType), TeaVM_Class, size);
    if ((!meth_otr_RuntimeClass_isPrimitive(TEAVM_FIELD(teavm_local_6, TeaVM_Class, itemType)))) {
        teavm_local_7 = sizeof(void*);
        teavm_gc_writeBarrier(teavm_local_3);
    }
    teavm_local_8 = ((int32_t) (intptr_t) TEAVM_ALIGN(TEAVM_ADDRESS_ADD(((void*) (intptr_t) INT32_C(0)), INT32_C(1) * sizeof(TeaVM_Array)), teavm_local_7));
    teavm_local_9 = TEAVM_ADDRESS_ADD(teavm_local_1, teavm_local_8);
    teavm_local_10 = TEAVM_ADDRESS_ADD(teavm_local_9, (teavm_local_7 * teavm_local_2));
    teavm_local_11 = TEAVM_ADDRESS_ADD(teavm_local_3, teavm_local_8);
    teavm_local_12 = TEAVM_ADDRESS_ADD(teavm_local_11, (teavm_local_7 * teavm_local_4));
    memmove(teavm_local_12, teavm_local_10, (teavm_local_5 * teavm_local_7));
}
int64_t meth_jl_System_currentTimeMillis() {
    return meth_jl_System_currentTimeMillisLowLevel();
}
int64_t meth_jl_System_currentTimeMillisLowLevel() {
    int64_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40145, teavm_currentTimeMillis());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jl_System_initPropertiesIfNeeded() {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((sfld_jl_System_properties == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40146, meth_otr_Allocator_allocate(&ju_Properties_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(40147, meth_ju_Properties__init_(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(40148, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8020), TEAVM_GET_STRING(8021)));
        TEAVM_WITH_CALL_SITE_ID(40149, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(7386), TEAVM_GET_STRING(8022)));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40150, meth_otrf_VirtualFileSystemProvider_getInstance());
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = ((!TEAVM_WITH_CALL_SITE_ID(40151, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40152, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, otrf_VirtualFileSystem_VT, virt_isWindows)(teavm_tmp_ptr_0)))) ? TEAVM_GET_STRING(7279) : TEAVM_GET_STRING(8023));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(40153, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8024), teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40154, meth_otrf_VirtualFileSystemProvider_getInstance());
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = ((!TEAVM_WITH_CALL_SITE_ID(40155, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40156, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, otrf_VirtualFileSystem_VT, virt_isWindows)(teavm_tmp_ptr_0)))) ? TEAVM_GET_STRING(615) : TEAVM_GET_STRING(8025));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(40157, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8026), teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40158, meth_jl_System_lineSeparator());
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(40159, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8027), teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40160, meth_jl_System_getTempDir());
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(40161, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8028), teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(40162, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8029), TEAVM_GET_STRING(8021)));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40163, meth_jl_System_getHomeDir());
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(40164, TEAVM_METHOD(teavm_local_1, ju_Properties_VT, virt_put)(teavm_local_1, TEAVM_GET_STRING(8030), teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40165, meth_otr_Allocator_allocate(&ju_Properties_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(40166, meth_ju_Properties__init__0(teavm_local_3, teavm_local_1));
        sfld_jl_System_properties = teavm_local_3;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jl_System_getTempDir() {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = malloc(sizeof(void*));
    teavm_local_2 = teavm_file_tempDirectory(teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40167, meth_otrf_VirtualFileSystemProvider_getInstance());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(40168, meth_jl_System_toJavaString(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40169, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40170, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, otrf_VirtualFileSystem_VT, virt_canonicalize)(teavm_tmp_ptr_0, teavm_local_4)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_System_getHomeDir() {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = malloc(sizeof(void*));
    teavm_local_2 = teavm_file_homeDirectory(teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40171, meth_otrf_VirtualFileSystemProvider_getInstance());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(40172, meth_jl_System_toJavaString(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40173, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40174, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, otrf_VirtualFileSystem_VT, virt_canonicalize)(teavm_tmp_ptr_0, teavm_local_4)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_System_toJavaString(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = (*(void**) teavm_local_1);
    free(teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(40175, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    teavm_local_5 = teavm_local_4;
    memcpy(TEAVM_ARRAY_DATA(teavm_local_4, int32_t), teavm_local_3, (TEAVM_ARRAY_LENGTH(teavm_local_5) * INT32_C(2)));
    free(teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(40176, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(40177, meth_jl_String__init__1(teavm_local_6, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void* meth_jl_System_getProperty(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(40178, meth_jl_System_initPropertiesIfNeeded());
    teavm_local_2 = sfld_jl_System_properties;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40179, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(40180, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Properties_VT, virt_getProperty)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int64_t meth_jl_System_nanoTime() {
    int64_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40181, teavm_currentTimeNano());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_System_identityHashCode(void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(40182, teavm_checkcast(teavm_local_1, &jl_Object_Cls, &supertypeof_jl_Object));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40183, meth_jl_Object_identity(TEAVM_WITH_CALL_SITE_ID(40184, teavm_nullCheck(teavm_local_3))));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_System_lineSeparator() {
    return TEAVM_GET_STRING(8031);
}
int32_t supertypeof_jl_System(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1885 || tag >= 1887) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_System_VT jl_System_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_System), sizeof(void*)),
            .flags = 0,
            .tag = 1885,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_System,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jl_System_Cls[2] = {
(void**) &sfld_jl_System_errCache, (void**) &sfld_jl_System_properties
};
void sysinitclass_jl_System() {
sfld_jl_System_errCache = NULL;
sfld_jl_System_properties = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_System_Cls, 2);
}
