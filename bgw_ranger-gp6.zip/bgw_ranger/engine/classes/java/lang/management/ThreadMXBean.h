#pragma once
#include "../../../../runtime.h"
#include "ThreadMXBean.h"

extern void sysinitclass_jlm_ThreadMXBean();
extern int32_t supertypeof_jlm_ThreadMXBean(TeaVM_Class*, TeaVM_Class*);
typedef struct jlm_ThreadMXBean_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_isThreadCpuTimeEnabled)(void*); // 11
    int32_t (*virt_isThreadCpuTimeSupported)(void*); // 12
    void (*pad0)(); // 13
    void (*virt_setThreadCpuTimeEnabled)(void*, int32_t); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    int64_t (*virt_getThreadCpuTime)(void*, int64_t); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    void* (*virt_getThreadInfo)(void*, int64_t); // 28
} jlm_ThreadMXBean_VT;
extern TeaVM_Class jlm_ThreadMXBean_Cls;
