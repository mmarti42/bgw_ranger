#include "ThreadMXBean.h"
#include "../../../../strings.h"

int32_t supertypeof_jlm_ThreadMXBean(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1401 || tag >= 1403) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jlm_ThreadMXBean_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 1401,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jlm_ThreadMXBean,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jlm_ThreadMXBean() {
}
