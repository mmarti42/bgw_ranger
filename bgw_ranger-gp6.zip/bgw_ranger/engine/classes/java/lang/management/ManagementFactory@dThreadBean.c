#include "ManagementFactory@dThreadBean.h"
#include "../Object.h"
#include "../../../lab/ranger/translation/teavm/ThreadAccounting.h"
#include "ThreadInfo.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../UnsupportedOperationException.h"
#include "../../../../strings.h"
#include "../../../org/teavm/runtime/ExceptionHandling.h"
#include "../IllegalArgumentException.h"

void meth_jlm_ManagementFactory_ThreadBean__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24471, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jlm_ManagementFactory_ThreadBean_isThreadCpuTimeSupported(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24472, meth_lrtt_ThreadAccounting_isSupported());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jlm_ManagementFactory_ThreadBean_isThreadCpuTimeEnabled(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24473, meth_jlm_ManagementFactory_ThreadBean_requireCpuClock(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24474, meth_lrtt_ThreadAccounting_isEnabled());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jlm_ManagementFactory_ThreadBean_setThreadCpuTimeEnabled(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24475, meth_jlm_ManagementFactory_ThreadBean_requireCpuClock(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(24476, meth_lrtt_ThreadAccounting_setEnabled(teavm_local_1));
    TEAVM_RELEASE_STACK;
}
int64_t meth_jlm_ManagementFactory_ThreadBean_getThreadCpuTime(void* teavm_this_, int64_t teavm_local_1) {
    int64_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24477, meth_jlm_ManagementFactory_ThreadBean_requireValidId(teavm_this_, teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(24478, meth_jlm_ManagementFactory_ThreadBean_requireCpuClock(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24479, meth_lrtt_ThreadAccounting_cpuTime(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jlm_ManagementFactory_ThreadBean_getThreadInfo(void* teavm_this_, int64_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(24480, meth_jlm_ManagementFactory_ThreadBean_requireValidId(teavm_this_, teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24481, meth_lrtt_ThreadAccounting_findThread(teavm_local_1));
    if ((teavm_local_2 == NULL)) {
        teavm_local_3 = NULL;
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24482, meth_otr_Allocator_allocate(&jlm_ThreadInfo_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(24483, meth_jlm_ThreadInfo__init_(teavm_local_3, teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jlm_ManagementFactory_ThreadBean_requireCpuClock(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((!TEAVM_WITH_CALL_SITE_ID(24484, meth_jlm_ManagementFactory_ThreadBean_isThreadCpuTimeSupported(teavm_this_)))) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24485, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(24486, meth_jl_UnsupportedOperationException__init_(teavm_local_1, TEAVM_GET_STRING(7111)));
        TEAVM_WITH_CALL_SITE_ID(24487, meth_otr_ExceptionHandling_throwException(teavm_local_1));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
void meth_jlm_ManagementFactory_ThreadBean_requireValidId(void* teavm_this_, int64_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 <= INT64_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24488, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(24489, meth_jl_IllegalArgumentException__init__0(teavm_local_2, TEAVM_GET_STRING(7112)));
        TEAVM_WITH_CALL_SITE_ID(24490, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jlm_ManagementFactory_ThreadBean(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1401 || tag >= 1403) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlm_ManagementFactory_ThreadBean_VT jlm_ManagementFactory_ThreadBean_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jlm_ManagementFactory_ThreadBean), sizeof(void*)),
        .flags = 0,
        .tag = 1401,
        .modifiers = 16,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jlm_ManagementFactory_ThreadBean,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_isThreadCpuTimeEnabled = &meth_jlm_ManagementFactory_ThreadBean_isThreadCpuTimeEnabled,
    .virt_isThreadCpuTimeSupported = &meth_jlm_ManagementFactory_ThreadBean_isThreadCpuTimeSupported,
    .virt_setThreadCpuTimeEnabled = &meth_jlm_ManagementFactory_ThreadBean_setThreadCpuTimeEnabled,
    .virt_getThreadCpuTime = &meth_jlm_ManagementFactory_ThreadBean_getThreadCpuTime,
    .virt_getThreadInfo = &meth_jlm_ManagementFactory_ThreadBean_getThreadInfo
};
void sysinitclass_jlm_ManagementFactory_ThreadBean() {
}
