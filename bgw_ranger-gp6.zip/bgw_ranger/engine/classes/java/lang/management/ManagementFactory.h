#pragma once
#include "../../../../runtime.h"
#include "../Object.h"
#include "ManagementFactory.h"

extern void sysinitclass_jlm_ManagementFactory();
typedef struct cls_jlm_ManagementFactory {
    struct TeaVM_Object parent;
} cls_jlm_ManagementFactory;
extern void* sfld_jlm_ManagementFactory_THREADS;
extern void* meth_jlm_ManagementFactory_getThreadMXBean();
extern void meth_jlm_ManagementFactory__clinit_();
extern void initclass_jlm_ManagementFactory();
extern int32_t supertypeof_jlm_ManagementFactory(TeaVM_Class*, TeaVM_Class*);
typedef struct jlm_ManagementFactory_VT {
    jl_Object_VT parent;
} jlm_ManagementFactory_VT;
extern jlm_ManagementFactory_VT jlm_ManagementFactory_Cls;
