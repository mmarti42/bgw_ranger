#include "ManagementFactory.h"
#include "../Object.h"
#include "ManagementFactory@dThreadBean.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../../../strings.h"

void* sfld_jlm_ManagementFactory_THREADS;
void* meth_jlm_ManagementFactory_getThreadMXBean() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(17769, teavm_initializeClass((TeaVM_Class*) &jlm_ManagementFactory_Cls, &initclass_jlm_ManagementFactory));
    teavm_local_1 = sfld_jlm_ManagementFactory_THREADS;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jlm_ManagementFactory__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17770, meth_otr_Allocator_allocate(&jlm_ManagementFactory_ThreadBean_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(17771, meth_jlm_ManagementFactory_ThreadBean__init_(teavm_local_1));
    sfld_jlm_ManagementFactory_THREADS = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jlm_ManagementFactory() {
    TeaVM_Class* cls = (TeaVM_Class*) &jlm_ManagementFactory_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jlm_ManagementFactory__clinit_();
    }
}
int32_t supertypeof_jlm_ManagementFactory(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 987 || tag >= 989) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlm_ManagementFactory_VT jlm_ManagementFactory_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jlm_ManagementFactory), sizeof(void*)),
            .flags = 0,
            .tag = 987,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jlm_ManagementFactory,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jlm_ManagementFactory_Cls[1] = {
(void**) &sfld_jlm_ManagementFactory_THREADS
};
void sysinitclass_jlm_ManagementFactory() {
sfld_jlm_ManagementFactory_THREADS = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jlm_ManagementFactory_Cls, 1);
}
