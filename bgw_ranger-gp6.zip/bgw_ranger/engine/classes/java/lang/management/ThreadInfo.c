#include "ThreadInfo.h"
#include "../Object.h"
#include "../Thread.h"
#include "../../../../strings.h"

void meth_jlm_ThreadInfo__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(40441, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(40442, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_FIELD(teavm_this_, cls_jlm_ThreadInfo, fld_id) = TEAVM_WITH_CALL_SITE_ID(40443, TEAVM_METHOD(teavm_local_1, jl_Thread_VT, virt_getId_0)(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(40444, TEAVM_METHOD(teavm_local_1, jl_Thread_VT, virt_getName)(teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jlm_ThreadInfo, fld_name) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
int64_t meth_jlm_ThreadInfo_getThreadId(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jlm_ThreadInfo, fld_id);
}
void* meth_jlm_ThreadInfo_getThreadName(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jlm_ThreadInfo, fld_name);
}
int32_t supertypeof_jlm_ThreadInfo(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1893 || tag >= 1895) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jlm_ThreadInfo_Cls[2];
alignas(8) jlm_ThreadInfo_VT jlm_ThreadInfo_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jlm_ThreadInfo), sizeof(void*)),
        .flags = 0,
        .tag = 1893,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jlm_ThreadInfo,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jlm_ThreadInfo_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getThreadId = &meth_jlm_ThreadInfo_getThreadId,
    .virt_getThreadName = &meth_jlm_ThreadInfo_getThreadName
};
static int16_t teavm_classLayouts_jlm_ThreadInfo_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jlm_ThreadInfo, fld_name)
};
void sysinitclass_jlm_ThreadInfo() {
}
