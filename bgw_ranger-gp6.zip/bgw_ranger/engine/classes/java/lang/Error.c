#include "Error.h"
#include "Throwable.h"
#include "../../../strings.h"
#include "Object.h"

void meth_jl_Error__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(6541, meth_jl_Throwable__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Error__init__0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(6542, meth_jl_Throwable__init__0(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Error__init__1(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(6543, meth_jl_Throwable__init__1(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Error__init__2(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(6544, meth_jl_Throwable__init__2(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Error(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 842 || tag >= 852) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Error_VT jl_Error_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Error), sizeof(void*)),
            .flags = 0,
            .tag = 842,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_Error,
            .superclass = (TeaVM_Class*) &jl_Throwable_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Throwable_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
        .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
        .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
        .virt_getMessage = &meth_jl_Throwable_getMessage,
        .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
        .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
    }
};
void sysinitclass_jl_Error() {
}
