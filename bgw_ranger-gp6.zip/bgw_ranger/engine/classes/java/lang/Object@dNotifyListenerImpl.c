#include "Object@dNotifyListenerImpl.h"
#include "Object.h"
#include "Thread.h"
#include "../../org/teavm/runtime/EventQueue.h"
#include "Object@dNotifyListenerImpl@dinterrupted@dlambda@d_4_0.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "InterruptedException.h"
#include "../../org/teavm/interop/AsyncCallback.h"
#include "../../../strings.h"

void meth_jl_Object_NotifyListenerImpl__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(10722, meth_jl_Object__init_(teavm_this_));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10723, meth_jl_Thread_currentThread());
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_currentThread) = teavm_local_4;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId) = -INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_obj) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_callback) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_lockCount) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Object_NotifyListenerImpl_expired(void* teavm_this_) {
    int32_t teavm_local_1;
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_expired);
    TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_expired) = INT32_C(1);
    return teavm_local_1;
}
void meth_jl_Object_NotifyListenerImpl_run(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((!TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_performed))) {
        TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_performed) = INT32_C(1);
        if ((TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId) >= INT32_C(0))) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(10724, meth_otr_EventQueue_kill(teavm_local_1));
            TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId) = -INT32_C(1);
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_currentThread);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(10725, meth_jl_Thread_setCurrentThread(teavm_local_2));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_obj);
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_lockCount);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_callback);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(10726, meth_jl_Object_monitorEnterWait(teavm_local_2, teavm_local_1, teavm_local_3));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_NotifyListenerImpl_interrupted(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_performed))) {
        TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_performed) = INT32_C(1);
        if ((TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId) >= INT32_C(0))) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(10727, meth_otr_EventQueue_kill(teavm_local_1));
            TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_timerId) = -INT32_C(1);
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10728, meth_otr_Allocator_allocate(&jl_Object_NotifyListenerImpl_interrupted_lambda__4_0_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(10729, meth_jl_Object_NotifyListenerImpl_interrupted_lambda__4_0__init_(teavm_local_2, teavm_this_));
        TEAVM_WITH_CALL_SITE_ID(10730, meth_otr_EventQueue_offer(teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_NotifyListenerImpl_lambda_interrupted_2(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Object_NotifyListenerImpl, fld_callback);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10731, meth_otr_Allocator_allocate(&jl_InterruptedException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(10732, meth_jl_InterruptedException__init_(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(10733, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(10734, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, oti_AsyncCallback_VT, virt_error_0)(teavm_tmp_ptr_0, teavm_local_2)));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Object_NotifyListenerImpl(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 523 || tag >= 525) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Object_NotifyListenerImpl_Cls[4];
alignas(8) jl_Object_NotifyListenerImpl_VT jl_Object_NotifyListenerImpl_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Object_NotifyListenerImpl), sizeof(void*)),
        .flags = 0,
        .tag = 523,
        .modifiers = 0,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(772),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Object_NotifyListenerImpl,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Object_NotifyListenerImpl_Cls,
        .enumValues = NULL,
        .declaringClass = (TeaVM_Class*) &jl_Object_Cls,
        .enclosingClass = (TeaVM_Class*) &jl_Object_Cls,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_interrupted = &meth_jl_Object_NotifyListenerImpl_interrupted,
    .virt_expired = &meth_jl_Object_NotifyListenerImpl_expired,
    .virt_run_0 = &meth_jl_Object_NotifyListenerImpl_run
};
static int16_t teavm_classLayouts_jl_Object_NotifyListenerImpl_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_jl_Object_NotifyListenerImpl, fld_obj), (int16_t) offsetof(cls_jl_Object_NotifyListenerImpl, fld_callback), (int16_t) offsetof(cls_jl_Object_NotifyListenerImpl, fld_currentThread)
};
void sysinitclass_jl_Object_NotifyListenerImpl() {
}
