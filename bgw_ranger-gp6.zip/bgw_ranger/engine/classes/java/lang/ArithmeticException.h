#pragma once
#include "../../../runtime.h"
#include "RuntimeException.h"
#include "ArithmeticException.h"

extern void sysinitclass_jl_ArithmeticException();
typedef struct cls_jl_ArithmeticException {
    struct cls_jl_RuntimeException parent;
} cls_jl_ArithmeticException;
extern void meth_jl_ArithmeticException__init__0(void*);
extern void meth_jl_ArithmeticException__init_(void*, void*);
extern int32_t supertypeof_jl_ArithmeticException(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_ArithmeticException_VT {
    jl_RuntimeException_VT parent;
} jl_ArithmeticException_VT;
extern jl_ArithmeticException_VT jl_ArithmeticException_Cls;
