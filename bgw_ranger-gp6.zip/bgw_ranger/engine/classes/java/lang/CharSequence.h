#pragma once
#include "../../../runtime.h"
#include "CharSequence.h"

extern void sysinitclass_jl_CharSequence();
extern int32_t supertypeof_jl_CharSequence(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_CharSequence_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*pad1)(); // 12
    void (*pad2)(); // 13
    void (*pad3)(); // 14
    void (*pad4)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void* (*virt_subSequence)(void*, int32_t, int32_t); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    int32_t (*virt_length)(void*); // 25
    int32_t (*virt_charAt)(void*, int32_t); // 26
} jl_CharSequence_VT;
extern TeaVM_Class jl_CharSequence_Cls;
