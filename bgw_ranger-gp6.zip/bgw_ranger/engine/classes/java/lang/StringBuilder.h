#pragma once
#include "../../../runtime.h"
#include "AbstractStringBuilder.h"
#include "StringBuilder.h"

extern void sysinitclass_jl_StringBuilder();
typedef struct cls_jl_StringBuilder {
    struct cls_jl_AbstractStringBuilder parent;
} cls_jl_StringBuilder;
extern void meth_jl_StringBuilder__init__0(void*, int32_t);
extern void meth_jl_StringBuilder__init_(void*);
extern void meth_jl_StringBuilder__init__1(void*, void*);
extern void* meth_jl_StringBuilder_append(void*, void*);
extern void* meth_jl_StringBuilder_append_4(void*, void*);
extern void* meth_jl_StringBuilder_append_0(void*, int32_t);
extern void* meth_jl_StringBuilder_append_5(void*, int64_t);
extern void* meth_jl_StringBuilder_append_3(void*, float);
extern void* meth_jl_StringBuilder_append_6(void*, double);
extern void* meth_jl_StringBuilder_append_1(void*, int32_t);
extern void* meth_jl_StringBuilder_append_7(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_append_8(void*, TeaVM_Array*);
extern void* meth_jl_StringBuilder_append_9(void*, void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_append_10(void*, void*);
extern void* meth_jl_StringBuilder_append_2(void*, int32_t);
extern void* meth_jl_StringBuilder_insert(void*, int32_t, int64_t);
extern void* meth_jl_StringBuilder_insert_0(void*, int32_t, float);
extern void* meth_jl_StringBuilder_insert_1(void*, int32_t, double);
extern void* meth_jl_StringBuilder_insert_2(void*, int32_t, void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_3(void*, int32_t, void*);
extern void* meth_jl_StringBuilder_insert_4(void*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_5(void*, int32_t, void*);
extern void* meth_jl_StringBuilder_insert_6(void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_7(void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_delete(void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_deleteCharAt(void*, int32_t);
extern void* meth_jl_StringBuilder_insert_8(void*, int32_t, void*);
extern void* meth_jl_StringBuilder_substring(void*, int32_t, int32_t);
extern void meth_jl_StringBuilder_setLength(void*, int32_t);
extern void meth_jl_StringBuilder_getChars(void*, int32_t, int32_t, TeaVM_Array*, int32_t);
extern void* meth_jl_StringBuilder_subSequence(void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_9(void*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_append_11(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_10(void*, int32_t, void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_append_12(void*, void*, int32_t, int32_t);
extern int32_t meth_jl_StringBuilder_charAt(void*, int32_t);
extern int32_t meth_jl_StringBuilder_length(void*);
extern void* meth_jl_StringBuilder_toString(void*);
extern void meth_jl_StringBuilder_ensureCapacity(void*, int32_t);
extern void* meth_jl_StringBuilder_insert_11(void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_12(void*, int32_t, void*);
extern void* meth_jl_StringBuilder_insert_13(void*, int32_t, int32_t);
extern void* meth_jl_StringBuilder_insert_14(void*, int32_t, double);
extern void* meth_jl_StringBuilder_insert_15(void*, int32_t, float);
extern void* meth_jl_StringBuilder_insert_16(void*, int32_t, int64_t);
extern void* meth_jl_StringBuilder_insert_17(void*, int32_t, void*);
extern void* meth_jl_StringBuilder_append_13(void*, void*);
extern int32_t supertypeof_jl_StringBuilder(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_StringBuilder_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_insert_4)(void*, int32_t, void*); // 11
    void* (*virt_append)(void*, int32_t, int32_t); // 12
    void* (*virt_insert_5)(void*, int32_t, int32_t, int32_t); // 13
    void* (*virt_insert_6)(void*, int32_t, int32_t); // 14
    void* (*virt_insert_22)(void*, int32_t, double); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void* (*virt_subSequence)(void*, int32_t, int32_t); // 17
    void* (*virt_insert_20)(void*, int32_t, void*); // 18
    void* (*virt_insert_7)(void*, int32_t, int32_t); // 19
    void* (*virt_insert_8)(void*, int32_t, void*); // 20
    void* (*virt_insert_9)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 21
    void* (*virt_append_7)(void*, TeaVM_Array*, int32_t, int32_t); // 22
    void* (*virt_append_8)(void*, void*, int32_t, int32_t); // 23
    void* (*virt_insert_10)(void*, int32_t, float); // 24
    int32_t (*virt_length)(void*); // 25
    int32_t (*virt_charAt)(void*, int32_t); // 26
    void (*virt_ensureCapacity)(void*, int32_t); // 27
    void* (*virt_insert_11)(void*, int32_t, int64_t, int32_t); // 28
    void* (*virt_append_9)(void*, int32_t); // 29
    void* (*virt_append_10)(void*, int64_t); // 30
    void* (*virt_substring)(void*, int32_t, int32_t); // 31
    void* (*virt_append_11)(void*, float); // 32
    void* (*virt_append_12)(void*, double); // 33
    void* (*virt_insert_17)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 34
    void (*pad0)(); // 35
    void* (*virt_append_13)(void*, int32_t); // 36
    void* (*virt_insert_12)(void*, int32_t, double); // 37
    void* (*virt_append_14)(void*, void*); // 38
    void* (*virt_insert_13)(void*, int32_t, void*); // 39
    void* (*virt_insert_23)(void*, int32_t, float); // 40
    void* (*virt_deleteCharAt_0)(void*, int32_t); // 41
    void* (*virt_append_16)(void*, int32_t); // 42
    void* (*virt_append_17)(void*, void*); // 43
    void* (*virt_append_18)(void*, TeaVM_Array*); // 44
    void (*virt_getChars)(void*, int32_t, int32_t, TeaVM_Array*, int32_t); // 45
    void* (*virt_append_19)(void*, void*); // 46
    void* (*virt_insert_14)(void*, int32_t, int64_t); // 47
    void* (*virt_insert_15)(void*, int32_t, void*, int32_t, int32_t); // 48
    void* (*virt_append_20)(void*, void*); // 49
    void (*virt_setLength)(void*, int32_t); // 50
    void* (*virt_deleteCharAt)(void*, int32_t); // 51
    void* (*virt_delete)(void*, int32_t, int32_t); // 52
    void* (*virt_append_1)(void*, void*); // 53
    int32_t (*virt_indexOf_0)(void*, void*, int32_t); // 54
    void* (*virt_insert_24)(void*, int32_t, int64_t); // 55
    void* (*virt_append_53)(void*, void*, int32_t, int32_t); // 56
    void* (*virt_insert_21)(void*, int32_t, int32_t); // 57
    void* (*virt_insert_16)(void*, int32_t, void*); // 58
    void* (*virt_delete_1)(void*, int32_t, int32_t); // 59
    void* (*virt_append_54)(void*, double); // 60
    void* (*virt_insert_25)(void*, int32_t, void*); // 61
    void* (*virt_append_4)(void*, int32_t); // 62
    void* (*virt_append_0)(void*, void*); // 63
    void* (*virt_append_27)(void*, TeaVM_Array*); // 64
    void* (*virt_append_25)(void*, void*); // 65
    void* (*virt_insert_19)(void*, int32_t, int32_t); // 66
    void* (*virt_append_24)(void*, int32_t); // 67
    void* (*virt_insert_18)(void*, int32_t, void*, int32_t, int32_t); // 68
    void* (*virt_append_26)(void*, int64_t); // 69
    void* (*virt_append_28)(void*, int32_t); // 70
    void* (*virt_append_52)(void*, TeaVM_Array*, int32_t, int32_t); // 71
    void* (*virt_append_55)(void*, float); // 72
} jl_StringBuilder_VT;
extern jl_StringBuilder_VT jl_StringBuilder_Cls;
