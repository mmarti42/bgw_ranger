#include "Float.h"
#include "Number.h"
#include "../../../primitives/float.h"
#include "../../../strings.h"
#include "Object.h"

void* sfld_jl_Float_TYPE;
int32_t meth_jl_Float_isInfinite(float teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5729, teavm_initializeClass((TeaVM_Class*) &jl_Float_Cls, &initclass_jl_Float));
    teavm_local_2 = ((!((!isfinite(teavm_local_1)) && (!isnan(teavm_local_1)))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Float_compare(float teavm_local_1, float teavm_local_2) {
    int32_t teavm_local_3;
    float teavm_local_4;
    float teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5730, teavm_initializeClass((TeaVM_Class*) &jl_Float_Cls, &initclass_jl_Float));
    teavm_local_3 = (((!(teavm_local_1 > teavm_local_2)) ? INT32_C(0) : INT32_C(1)) - ((!(teavm_local_2 > teavm_local_1)) ? INT32_C(0) : INT32_C(1)));
    if ((!teavm_local_3)) {
        teavm_local_4 = (1.0f / teavm_local_1);
        teavm_local_5 = (1.0f / teavm_local_2);
        teavm_local_6 = (((!(teavm_local_4 > teavm_local_5)) ? INT32_C(0) : INT32_C(1)) - ((!(teavm_local_5 > teavm_local_4)) ? INT32_C(0) : INT32_C(1)));
        teavm_local_3 = ((teavm_local_6 + ((teavm_local_2 != teavm_local_2) ? INT32_C(0) : INT32_C(1))) - ((teavm_local_1 != teavm_local_1) ? INT32_C(0) : INT32_C(1)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Float_floatToIntBits(float teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5731, teavm_initializeClass((TeaVM_Class*) &jl_Float_Cls, &initclass_jl_Float));
    teavm_local_2 = ((!isnan(teavm_local_1)) ? teavm_reinterpretFloatToInt(teavm_local_1) : INT32_C(2143289344));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Float__clinit_() {
    sfld_jl_Float_TYPE = teavm_getClassObject((TeaVM_Class*) &F_Cls);
}
void initclass_jl_Float() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Float_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Float__clinit_();
    }
}
int32_t supertypeof_jl_Float(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1964 || tag >= 1966) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Float_VT jl_Float_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Float), sizeof(void*)),
        .flags = 0,
        .tag = 1964,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Float,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
static void** teavm_gc_localStaticRoots_jl_Float_Cls[1] = {
(void**) &sfld_jl_Float_TYPE
};
void sysinitclass_jl_Float() {
sfld_jl_Float_TYPE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Float_Cls, 1);
}
