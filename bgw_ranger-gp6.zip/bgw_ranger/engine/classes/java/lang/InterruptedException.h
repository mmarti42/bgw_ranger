#pragma once
#include "../../../runtime.h"
#include "Exception.h"
#include "InterruptedException.h"

extern void sysinitclass_jl_InterruptedException();
typedef struct cls_jl_InterruptedException {
    struct cls_jl_Exception parent;
} cls_jl_InterruptedException;
extern void meth_jl_InterruptedException__init_(void*);
extern int32_t supertypeof_jl_InterruptedException(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_InterruptedException_VT {
    jl_Exception_VT parent;
} jl_InterruptedException_VT;
extern jl_InterruptedException_VT jl_InterruptedException_Cls;
