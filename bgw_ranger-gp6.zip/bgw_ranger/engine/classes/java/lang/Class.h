#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Class.h"

extern void sysinitclass_jl_Class();
typedef struct cls_jl_Class {
    struct TeaVM_Object parent;
    int32_t fld_flags;
    void* fld_classInfo;
    void* fld_name;
    void* fld_simpleName;
    void* fld_canonicalName;
    TeaVM_Array* fld_enumConstantsCache;
} cls_jl_Class;
extern void meth_jl_Class__init_(void*, void*);
extern void* meth_jl_Class_createClass(void*);
extern void* meth_jl_Class_toString(void*);
extern void* meth_jl_Class_getClassInfo(void*);
extern int32_t meth_jl_Class_isInstance(void*, void*);
extern int32_t meth_jl_Class_isAssignableFrom(void*, void*);
extern void* meth_jl_Class_getName(void*);
extern void* meth_jl_Class_getSimpleName(void*);
extern void* meth_jl_Class_getCanonicalName(void*);
extern int32_t meth_jl_Class_isSynthetic(void*);
extern int32_t meth_jl_Class_isPrimitive(void*);
extern int32_t meth_jl_Class_isArray(void*);
extern int32_t meth_jl_Class_isEnum(void*);
extern int32_t meth_jl_Class_isInterface(void*);
extern void* meth_jl_Class_getComponentType(void*);
extern int32_t meth_jl_Class_desiredAssertionStatus(void*);
extern void* meth_jl_Class_getSuperclass(void*);
extern TeaVM_Array* meth_jl_Class_getEnumConstants(void*);
extern TeaVM_Array* meth_jl_Class_getEnumConstantsFast(void*);
extern void meth_jl_Class_initialize(void*);
extern void* meth_jl_Class_getDeclaringClass(void*);
extern void* meth_jl_Class_getEnclosingClass(void*);
extern int32_t supertypeof_jl_Class(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Class_VT {
    jl_Object_VT parent;
} jl_Class_VT;
extern jl_Class_VT jl_Class_Cls;
