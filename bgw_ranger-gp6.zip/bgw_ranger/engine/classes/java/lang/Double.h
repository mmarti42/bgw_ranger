#pragma once
#include "../../../runtime.h"
#include "Number.h"
#include "Double.h"

extern void sysinitclass_jl_Double();
typedef struct cls_jl_Double {
    struct cls_jl_Number parent;
    double fld_value;
} cls_jl_Double;
extern void* sfld_jl_Double_TYPE;
extern void meth_jl_Double__init_(void*, double);
extern double meth_jl_Double_doubleValue(void*);
extern int64_t meth_jl_Double_longValue(void*);
extern void* meth_jl_Double_valueOf_0(double);
extern void* meth_jl_Double_toString(double);
extern void* meth_jl_Double_valueOf(void*);
extern double meth_jl_Double_parseDouble(void*);
extern void* meth_jl_Double_toString_0(void*);
extern int32_t meth_jl_Double_equals(void*, void*);
extern int32_t meth_jl_Double_equals_0(double, double);
extern int32_t meth_jl_Double_equalsWithBits(double, double);
extern int32_t meth_jl_Double_hashCode(void*);
extern int32_t meth_jl_Double_hashCode_0(double);
extern int32_t meth_jl_Double_compare(double, double);
extern int32_t meth_jl_Double_compareTo(void*, void*);
extern int32_t meth_jl_Double_isInfinite(double);
extern int64_t meth_jl_Double_doubleToLongBits(double);
extern int32_t meth_jl_Double_compareTo_0(void*, void*);
extern void meth_jl_Double__clinit_();
extern void initclass_jl_Double();
extern int32_t supertypeof_jl_Double(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Double_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_intValue)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    int64_t (*virt_longValue)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    int32_t (*virt_compareTo_12)(void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    double (*virt_doubleValue)(void*); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*pad32)(); // 48
    void (*pad33)(); // 49
} jl_Double_VT;
extern jl_Double_VT jl_Double_Cls;
