#pragma once
#include "../../../runtime.h"
#include "Object@dNotifyListener.h"

extern void sysinitclass_jl_Object_NotifyListener();
extern int32_t supertypeof_jl_Object_NotifyListener(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Object_NotifyListener_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    int32_t (*virt_expired)(void*); // 12
    void (*pad1)(); // 13
    void (*pad2)(); // 14
    void (*pad3)(); // 15
    void (*pad4)(); // 16
    void (*pad5)(); // 17
    void (*pad6)(); // 18
    void (*pad7)(); // 19
    void (*pad8)(); // 20
    void (*pad9)(); // 21
    void (*pad10)(); // 22
    void (*pad11)(); // 23
    void (*pad12)(); // 24
    void (*pad13)(); // 25
    void (*pad14)(); // 26
    void (*pad15)(); // 27
    void (*virt_run_0)(void*); // 28
} jl_Object_NotifyListener_VT;
extern TeaVM_Class jl_Object_NotifyListener_Cls;
