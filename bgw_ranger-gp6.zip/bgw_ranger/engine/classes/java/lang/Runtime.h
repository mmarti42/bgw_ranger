#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Runtime.h"

extern void sysinitclass_jl_Runtime();
typedef struct cls_jl_Runtime {
    struct TeaVM_Object parent;
} cls_jl_Runtime;
extern void* sfld_jl_Runtime_instance;
extern void meth_jl_Runtime__init_(void*);
extern int64_t meth_jl_Runtime_freeMemory(void*);
extern int64_t meth_jl_Runtime_freeMemoryLowLevel(void*);
extern void* meth_jl_Runtime_getRuntime();
extern int64_t meth_jl_Runtime_totalMemory(void*);
extern int64_t meth_jl_Runtime_totalMemoryLowLevel(void*);
extern void meth_jl_Runtime__clinit_();
extern void initclass_jl_Runtime();
extern int32_t supertypeof_jl_Runtime(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Runtime_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int64_t (*virt_totalMemory)(void*); // 11
    int64_t (*virt_freeMemory)(void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void (*pad15)(); // 28
    void (*pad16)(); // 29
    void (*pad17)(); // 30
    void (*pad18)(); // 31
    void (*pad19)(); // 32
    void (*pad20)(); // 33
    void (*pad21)(); // 34
    void (*pad22)(); // 35
    void (*pad23)(); // 36
    void (*pad24)(); // 37
    void (*pad25)(); // 38
    void (*pad26)(); // 39
    void (*pad27)(); // 40
    void (*pad28)(); // 41
    void (*pad29)(); // 42
    void (*pad30)(); // 43
    void (*pad31)(); // 44
    void (*pad32)(); // 45
    void (*pad33)(); // 46
    void (*pad34)(); // 47
    void (*pad35)(); // 48
    void (*pad36)(); // 49
} jl_Runtime_VT;
extern jl_Runtime_VT jl_Runtime_Cls;
