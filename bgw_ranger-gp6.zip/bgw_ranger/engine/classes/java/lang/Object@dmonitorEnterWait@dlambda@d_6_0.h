#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Object@dmonitorEnterWait@dlambda@d_6_0.h"

extern void sysinitclass_jl_Object_monitorEnterWait_lambda__6_0();
typedef struct cls_jl_Object_monitorEnterWait_lambda__6_0 {
    struct TeaVM_Object parent;
    void* fld__0;
    void* fld__1;
    int32_t fld__2;
    void* fld__3;
} cls_jl_Object_monitorEnterWait_lambda__6_0;
extern void meth_jl_Object_monitorEnterWait_lambda__6_0__init_(void*, void*, void*, int32_t, void*);
extern void meth_jl_Object_monitorEnterWait_lambda__6_0_run(void*);
extern int32_t supertypeof_jl_Object_monitorEnterWait_lambda__6_0(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Object_monitorEnterWait_lambda__6_0_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*pad1)(); // 12
    void (*pad2)(); // 13
    void (*pad3)(); // 14
    void (*pad4)(); // 15
    void (*pad5)(); // 16
    void (*pad6)(); // 17
    void (*pad7)(); // 18
    void (*pad8)(); // 19
    void (*pad9)(); // 20
    void (*pad10)(); // 21
    void (*pad11)(); // 22
    void (*pad12)(); // 23
    void (*pad13)(); // 24
    void (*pad14)(); // 25
    void (*pad15)(); // 26
    void (*pad16)(); // 27
    void (*virt_run_0)(void*); // 28
    void (*pad17)(); // 29
    void (*pad18)(); // 30
    void (*pad19)(); // 31
    void (*pad20)(); // 32
    void (*pad21)(); // 33
    void (*pad22)(); // 34
    void (*pad23)(); // 35
    void (*pad24)(); // 36
    void (*pad25)(); // 37
    void (*pad26)(); // 38
    void (*pad27)(); // 39
    void (*pad28)(); // 40
    void (*pad29)(); // 41
    void (*pad30)(); // 42
    void (*pad31)(); // 43
    void (*pad32)(); // 44
    void (*pad33)(); // 45
    void (*pad34)(); // 46
    void (*pad35)(); // 47
    void (*pad36)(); // 48
    void (*pad37)(); // 49
} jl_Object_monitorEnterWait_lambda__6_0_VT;
extern jl_Object_monitorEnterWait_lambda__6_0_VT jl_Object_monitorEnterWait_lambda__6_0_Cls;
