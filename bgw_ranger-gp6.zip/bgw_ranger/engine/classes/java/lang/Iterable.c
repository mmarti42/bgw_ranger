#include "Iterable.h"
#include "../util/Iterator.h"
#include "../util/function/Consumer.h"
#include "../../../strings.h"

void meth_jl_Iterable_forEach(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10194, TEAVM_METHOD(teavm_this_, jl_Iterable_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10195, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(10196, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_1;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10197, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10198, teavm_nullCheck(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(10199, TEAVM_METHOD(teavm_local_1, juf_Consumer_VT, virt_accept)(teavm_local_1, teavm_local_3));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Iterable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1289 || tag >= 1579) return INT32_C(0);
    if (tag >= 1367 && tag < 1573) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jl_Iterable_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 1289,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jl_Iterable,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jl_Iterable() {
}
