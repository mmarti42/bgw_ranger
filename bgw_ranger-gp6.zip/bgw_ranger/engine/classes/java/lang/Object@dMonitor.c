#include "Object@dMonitor.h"
#include "Object.h"
#include "Thread.h"
#include "../../../strings.h"

void meth_jl_Object_Monitor__init_(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9411, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9412, meth_jl_Thread_currentThread());
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Object_Monitor, fld_owner) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Object_Monitor(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 385 || tag >= 387) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Object_Monitor_Cls[4];
alignas(8) jl_Object_Monitor_VT jl_Object_Monitor_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Object_Monitor), sizeof(void*)),
            .flags = 0,
            .tag = 385,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_Object_Monitor,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jl_Object_Monitor_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_jl_Object_Monitor_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_jl_Object_Monitor, fld_enteringThreads), (int16_t) offsetof(cls_jl_Object_Monitor, fld_notifyListeners), (int16_t) offsetof(cls_jl_Object_Monitor, fld_owner)
};
void sysinitclass_jl_Object_Monitor() {
}
