#include "StackTraceElement.h"
#include "Object.h"
#include "NullPointerException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "StringBuilder.h"
#include "../../../strings.h"

void meth_jl_StackTraceElement__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, void* teavm_local_3, int32_t teavm_local_4) {
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(12972, meth_jl_Object__init_(teavm_this_));
    if (((teavm_local_1 != NULL) && (teavm_local_2 != NULL))) {
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_declaringClass) = teavm_local_1;
        TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_methodName) = teavm_local_2;
        TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_fileName) = teavm_local_3;
        TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_lineNumber) = teavm_local_4;
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(12973, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(12974, meth_jl_NullPointerException__init_(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(12975, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void* meth_jl_StackTraceElement_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(12976, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(12977, meth_jl_StringBuilder__init_(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_declaringClass);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(12978, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_0)(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(12979, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(12980, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_28)(teavm_tmp_ptr_0, INT32_C(46))));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_methodName);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(12981, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(12982, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_3)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(12983, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(12984, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_28)(teavm_tmp_ptr_0, INT32_C(40))));
    if ((TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_fileName) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(12985, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_0)(teavm_local_1, TEAVM_GET_STRING(1308)));
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_fileName);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(12986, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_0)(teavm_local_1, teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(12987, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(12988, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_28)(teavm_tmp_ptr_0, INT32_C(58))));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_StackTraceElement, fld_lineNumber);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(12989, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(12990, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_24)(teavm_tmp_ptr_0, teavm_local_4)));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(12991, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_0)(teavm_local_1, TEAVM_GET_STRING(470)));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(12992, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_toString)(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jl_StackTraceElement(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 567 || tag >= 569) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_StackTraceElement_Cls[4];
alignas(8) jl_StackTraceElement_VT jl_StackTraceElement_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_StackTraceElement), sizeof(void*)),
            .flags = 0,
            .tag = 567,
            .modifiers = 17,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(1309),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_StackTraceElement,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jl_StackTraceElement_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_StackTraceElement_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_jl_StackTraceElement_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_jl_StackTraceElement, fld_declaringClass), (int16_t) offsetof(cls_jl_StackTraceElement, fld_methodName), (int16_t) offsetof(cls_jl_StackTraceElement, fld_fileName)
};
void sysinitclass_jl_StackTraceElement() {
}
