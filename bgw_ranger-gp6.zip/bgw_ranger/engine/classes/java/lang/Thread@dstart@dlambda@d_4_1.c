#include "Thread@dstart@dlambda@d_4_1.h"
#include "Object.h"
#include "Thread.h"
#include "../../../strings.h"

void meth_jl_Thread_start_lambda__4_1__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44624, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Thread_start_lambda__4_1, fld__0) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jl_Thread_start_lambda__4_1, fld__1) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_start_lambda__4_1_run(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Thread_start_lambda__4_1, fld__0);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Thread_start_lambda__4_1, fld__1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44625, meth_jl_Thread_lambda_start_0(TEAVM_WITH_CALL_SITE_ID(44626, teavm_nullCheck(teavm_local_1)), teavm_local_2));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Thread_start_lambda__4_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2245 || tag >= 2247) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Thread_start_lambda__4_1_Cls[2];
alignas(8) jl_Thread_start_lambda__4_1_VT jl_Thread_start_lambda__4_1_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Thread_start_lambda__4_1), sizeof(void*)),
        .flags = 0,
        .tag = 2245,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Thread_start_lambda__4_1,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Thread_start_lambda__4_1_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_run_0 = &meth_jl_Thread_start_lambda__4_1_run
};
static int16_t teavm_classLayouts_jl_Thread_start_lambda__4_1_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jl_Thread_start_lambda__4_1, fld__0)
};
void sysinitclass_jl_Thread_start_lambda__4_1() {
}
