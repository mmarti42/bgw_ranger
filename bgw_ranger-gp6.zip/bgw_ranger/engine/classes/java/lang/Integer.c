#include "Integer.h"
#include "Number.h"
#include "AbstractStringBuilder.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/classlib/impl/IntegerUtil.h"
#include "NumberFormatException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "String.h"
#include "CharSequence.h"
#include "StringBuilder.h"
#include "../../../arrayclass.h"
#include "../../../primitives/int.h"
#include "Object.h"

void* sfld_jl_Integer_TYPE;
TeaVM_Array* sfld_jl_Integer_integerCache;
void meth_jl_Integer__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(49, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    TEAVM_WITH_CALL_SITE_ID(50, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Integer_toString(int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(51, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((!((teavm_local_2 >= INT32_C(2)) && (teavm_local_2 <= INT32_C(36))))) {
        teavm_local_2 = INT32_C(10);
    }
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(52, meth_otr_Allocator_allocate(&jl_AbstractStringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(53, meth_jl_AbstractStringBuilder__init_(teavm_local_3, INT32_C(20)));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(54, TEAVM_METHOD(teavm_local_3, jl_AbstractStringBuilder_VT, virt_append)(teavm_local_3, teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(55, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(56, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_AbstractStringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Integer_hashCode(int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(57, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Integer_toHexString(int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(58, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(59, meth_otci_IntegerUtil_toUnsignedLogRadixString(teavm_local_1, INT32_C(4)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Integer_toString_0(int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(60, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(61, meth_jl_Integer_toString(teavm_local_1, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Integer_parseInt(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(62, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((teavm_local_1 == NULL)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(63, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(64, meth_jl_NumberFormatException__init_(teavm_local_3, TEAVM_GET_STRING(8)));
        TEAVM_WITH_CALL_SITE_ID(65, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(66, meth_jl_Integer_parseIntImpl(teavm_local_1, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(67, meth_jl_String_length(teavm_local_1)), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jl_Integer_parseIntImpl(void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_local_11;
    void* teavm_local_12;
    void* teavm_local_13;
    void* teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(68, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((teavm_local_2 != teavm_local_3)) {
        if (((teavm_local_4 >= INT32_C(2)) && (teavm_local_4 <= INT32_C(36)))) {
            teavm_local_5 = INT32_C(0);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(69, teavm_nullCheck(teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            switch (TEAVM_WITH_CALL_SITE_ID(70, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_2))) {
                case 43:
                    goto teavm_label_3;
                case 45:
                    goto teavm_label_2;
            }
            teavm_local_6 = teavm_local_2;
            goto teavm_label_1;
        teavm_label_3:;
            teavm_local_6 = (teavm_local_2 + INT32_C(1));
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_5 = INT32_C(1);
            teavm_local_6 = (teavm_local_2 + INT32_C(1));
        teavm_label_1:;
            teavm_local_7 = INT32_C(0);
            teavm_local_8 = (INT32_C(1) + (INT32_C(2147483647) / teavm_local_4));
            if ((teavm_local_6 != teavm_local_3)) {
                while (1) {
                    if ((teavm_local_6 >= teavm_local_3)) {
                        if (teavm_local_5) {
                            teavm_local_7 = (-teavm_local_7);
                        }
                        goto teavm_label_6;
                    }
                    teavm_local_9 = (teavm_local_6 + INT32_C(1));
                    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(71, meth_jl_Integer_decodeDigit(TEAVM_WITH_CALL_SITE_ID(72, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_6))));
                    if ((teavm_local_10 < INT32_C(0))) {
                        goto teavm_label_7;
                    }
                    if ((teavm_local_10 >= teavm_local_4)) {
                        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(73, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
                        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(74, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_subSequence)(teavm_local_1, teavm_local_2, teavm_local_3));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(75, meth_jl_String_valueOf(teavm_local_12));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(76, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_13);
                        TEAVM_WITH_CALL_SITE_ID(77, meth_jl_StringBuilder__init_(teavm_local_13));
                        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(78, meth_jl_StringBuilder_append(teavm_local_13, TEAVM_GET_STRING(9)));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(79, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(80, teavm_nullCheck(teavm_local_14)), teavm_local_4));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(81, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(82, teavm_nullCheck(teavm_local_14)), TEAVM_GET_STRING(10)));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                        TEAVM_WITH_CALL_SITE_ID(83, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(84, teavm_nullCheck(teavm_local_14)), teavm_local_12));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(85, meth_jl_StringBuilder_toString(teavm_local_13));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        TEAVM_WITH_CALL_SITE_ID(86, meth_jl_NumberFormatException__init_(teavm_local_11, teavm_local_12));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_WITH_CALL_SITE_ID(87, meth_otr_ExceptionHandling_throwException(teavm_local_11));
                        TEAVM_UNREACHABLE
                    }
                    if ((teavm_local_7 > teavm_local_8)) {
                        goto teavm_label_8;
                    }
                    teavm_local_7 = ((teavm_local_4 * teavm_local_7) + teavm_local_10);
                    if ((teavm_local_7 < INT32_C(0))) {
                        if ((teavm_local_9 != teavm_local_3)) {
                            goto teavm_label_5;
                        }
                        if ((teavm_local_7 != (int32_t) INT32_C(0x80000000))) {
                            goto teavm_label_5;
                        }
                        if ((!teavm_local_5)) {
                            goto teavm_label_5;
                        }
                        teavm_local_7 = (int32_t) INT32_C(0x80000000);
                        goto teavm_label_6;
                    }
                    teavm_local_6 = teavm_local_9;
                }
            teavm_label_8:;
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(88, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
                TEAVM_WITH_CALL_SITE_ID(89, meth_jl_NumberFormatException__init_(teavm_local_11, TEAVM_GET_STRING(11)));
                TEAVM_WITH_CALL_SITE_ID(90, meth_otr_ExceptionHandling_throwException(teavm_local_11));
                TEAVM_UNREACHABLE
            teavm_label_7:;
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(91, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(92, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_subSequence)(teavm_local_1, teavm_local_2, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(93, meth_jl_String_valueOf(teavm_local_12));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(94, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_12);
                TEAVM_WITH_CALL_SITE_ID(95, meth_jl_StringBuilder__init_(teavm_local_12));
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(96, meth_jl_StringBuilder_append(teavm_local_12, TEAVM_GET_STRING(12)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                TEAVM_WITH_CALL_SITE_ID(97, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(98, teavm_nullCheck(teavm_local_14)), teavm_local_13));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(99, meth_jl_StringBuilder_toString(teavm_local_12));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(100, meth_jl_NumberFormatException__init_(teavm_local_11, teavm_local_12));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(101, meth_otr_ExceptionHandling_throwException(teavm_local_11));
                TEAVM_UNREACHABLE
            teavm_label_6:;
                TEAVM_RELEASE_STACK;
                return teavm_local_7;
            teavm_label_5:;
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(102, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_11);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(103, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_subSequence)(teavm_local_1, teavm_local_2, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(104, meth_jl_String_valueOf(teavm_local_12));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(105, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_13);
                TEAVM_WITH_CALL_SITE_ID(106, meth_jl_StringBuilder__init_(teavm_local_13));
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(107, meth_jl_StringBuilder_append(teavm_local_13, TEAVM_GET_STRING(13)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                TEAVM_WITH_CALL_SITE_ID(108, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(109, teavm_nullCheck(teavm_local_14)), teavm_local_12));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(110, meth_jl_StringBuilder_toString(teavm_local_13));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(111, meth_jl_NumberFormatException__init_(teavm_local_11, teavm_local_12));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(112, meth_otr_ExceptionHandling_throwException(teavm_local_11));
                TEAVM_UNREACHABLE
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(113, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
            TEAVM_WITH_CALL_SITE_ID(114, meth_jl_NumberFormatException__init__0(teavm_local_11));
            TEAVM_WITH_CALL_SITE_ID(115, meth_otr_ExceptionHandling_throwException(teavm_local_11));
            TEAVM_UNREACHABLE
        }
        teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(116, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(117, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
        TEAVM_WITH_CALL_SITE_ID(118, meth_jl_StringBuilder__init_(teavm_local_12));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(119, meth_jl_StringBuilder_append(teavm_local_12, TEAVM_GET_STRING(14)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_13);
        TEAVM_WITH_CALL_SITE_ID(120, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(121, teavm_nullCheck(teavm_local_13)), teavm_local_4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(122, meth_jl_StringBuilder_toString(teavm_local_12));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
        TEAVM_WITH_CALL_SITE_ID(123, meth_jl_NumberFormatException__init_(teavm_local_11, teavm_local_12));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(124, meth_otr_ExceptionHandling_throwException(teavm_local_11));
        TEAVM_UNREACHABLE
    }
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(125, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(126, meth_jl_NumberFormatException__init_(teavm_local_11, TEAVM_GET_STRING(15)));
    TEAVM_WITH_CALL_SITE_ID(127, meth_otr_ExceptionHandling_throwException(teavm_local_11));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_Integer_parseInt_0(void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(128, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(129, meth_jl_Integer_parseInt(teavm_local_1, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Integer_valueOf(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(130, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(131, meth_jl_Integer_valueOf_0(TEAVM_WITH_CALL_SITE_ID(132, meth_jl_Integer_parseInt(teavm_local_1, teavm_local_2))));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_Integer_valueOf_1(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(133, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(134, meth_jl_Integer_valueOf(teavm_local_1, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Integer_valueOf_0(int32_t teavm_local_1) {
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(135, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((!((teavm_local_1 >= -INT32_C(128)) && (teavm_local_1 <= INT32_C(127))))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(136, meth_otr_Allocator_allocate(&jl_Integer_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(137, meth_jl_Integer__init_(teavm_local_2, teavm_local_1));
    } else {
        TEAVM_WITH_CALL_SITE_ID(138, meth_jl_Integer_ensureIntegerCache());
        teavm_local_3 = sfld_jl_Integer_integerCache;
        teavm_local_4 = (teavm_local_1 + INT32_C(128));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(139, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(140, teavm_checkBounds(teavm_local_4, teavm_local_3)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Integer_ensureIntegerCache() {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(141, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((sfld_jl_Integer_integerCache == NULL)) {
        sfld_jl_Integer_integerCache = TEAVM_WITH_CALL_SITE_ID(142, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Integer_Cls), INT32_C(256)));
        teavm_local_1 = INT32_C(0);
        while (1) {
            teavm_local_2 = sfld_jl_Integer_integerCache;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            if ((teavm_local_1 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(143, teavm_nullCheck(teavm_local_2))))) {
                goto teavm_label_1;
            }
            teavm_local_2 = sfld_jl_Integer_integerCache;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(144, meth_otr_Allocator_allocate(&jl_Integer_Cls));
            teavm_local_4 = (teavm_local_1 - INT32_C(128));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(145, meth_jl_Integer__init_(teavm_local_3, teavm_local_4));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(146, teavm_nullCheck(teavm_local_2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(147, teavm_checkBounds(teavm_local_1, teavm_local_2));
            teavm_gc_writeBarrier(teavm_local_2);
            TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1) = teavm_local_3;
            teavm_local_1 = (teavm_local_1 + INT32_C(1));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Integer_intValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value);
}
int64_t meth_jl_Integer_longValue(void* teavm_this_) {
    return ((int64_t) TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value));
}
double meth_jl_Integer_doubleValue(void* teavm_this_) {
    return ((double) TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value));
}
void* meth_jl_Integer_toString_1(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(148, meth_jl_Integer_toString_0(TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Integer_hashCode_0(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(149, meth_jl_Integer_hashCode(TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Integer_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if (teavm_instanceof(teavm_local_1, &jl_Integer_Cls, &supertypeof_jl_Integer)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(150, teavm_checkcast(teavm_local_1, &jl_Integer_Cls, &supertypeof_jl_Integer));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(151, teavm_nullCheck(teavm_local_3)), cls_jl_Integer, fld_value) == TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Integer_decodeDigit(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(152, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_2 = (((teavm_local_1 >= INT32_C(48)) && (teavm_local_1 <= INT32_C(57))) ? (teavm_local_1 - INT32_C(48)) : (((teavm_local_1 >= INT32_C(97)) && (teavm_local_1 <= INT32_C(122))) ? ((teavm_local_1 - INT32_C(97)) + INT32_C(10)) : ((!((teavm_local_1 >= INT32_C(65)) && (teavm_local_1 <= INT32_C(90)))) ? -INT32_C(1) : ((teavm_local_1 - INT32_C(65)) + INT32_C(10)))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Integer_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Integer, fld_value);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(153, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(154, meth_jl_Integer_compare(teavm_local_2, TEAVM_FIELD(teavm_local_1, cls_jl_Integer, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Integer_compare(int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(155, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_1 = teavm_compare_i32(teavm_local_1, teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Integer_numberOfLeadingZeros(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(156, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((!teavm_local_1)) {
        teavm_local_2 = INT32_C(32);
    } else {
        teavm_local_3 = INT32_C(0);
        teavm_local_2 = ((int32_t) ((uint32_t) teavm_local_1 >> INT32_C(16)));
        if (teavm_local_2) {
            teavm_local_3 = INT32_C(16);
        } else {
            teavm_local_2 = teavm_local_1;
        }
        teavm_local_4 = ((int32_t) ((uint32_t) teavm_local_2 >> INT32_C(8)));
        if ((!teavm_local_4)) {
            teavm_local_4 = teavm_local_2;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(8));
        }
        teavm_local_2 = ((int32_t) ((uint32_t) teavm_local_4 >> INT32_C(4)));
        if ((!teavm_local_2)) {
            teavm_local_2 = teavm_local_4;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(4));
        }
        teavm_local_4 = ((int32_t) ((uint32_t) teavm_local_2 >> INT32_C(2)));
        if ((!teavm_local_4)) {
            teavm_local_4 = teavm_local_2;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(2));
        }
        if (((int32_t) ((uint32_t) teavm_local_4 >> INT32_C(1)))) {
            teavm_local_3 = (teavm_local_3 | INT32_C(1));
        }
        teavm_local_2 = ((INT32_C(32) - teavm_local_3) - INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Integer_numberOfTrailingZeros(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(157, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    if ((!teavm_local_1)) {
        teavm_local_2 = INT32_C(32);
    } else {
        teavm_local_3 = INT32_C(0);
        teavm_local_2 = (teavm_local_1 << INT32_C(16));
        if (teavm_local_2) {
            teavm_local_3 = INT32_C(16);
        } else {
            teavm_local_2 = teavm_local_1;
        }
        teavm_local_4 = (teavm_local_2 << INT32_C(8));
        if ((!teavm_local_4)) {
            teavm_local_4 = teavm_local_2;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(8));
        }
        teavm_local_2 = (teavm_local_4 << INT32_C(4));
        if ((!teavm_local_2)) {
            teavm_local_2 = teavm_local_4;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(4));
        }
        teavm_local_4 = (teavm_local_2 << INT32_C(2));
        if ((!teavm_local_4)) {
            teavm_local_4 = teavm_local_2;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(2));
        }
        if ((teavm_local_4 << INT32_C(1))) {
            teavm_local_3 = (teavm_local_3 | INT32_C(1));
        }
        teavm_local_2 = ((INT32_C(32) - teavm_local_3) - INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Integer_rotateLeft(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(158, teavm_initializeClass((TeaVM_Class*) &jl_Integer_Cls, &initclass_jl_Integer));
    teavm_local_3 = (teavm_local_2 & INT32_C(31));
    teavm_local_4 = ((teavm_local_1 << teavm_local_3) | ((int32_t) ((uint32_t) teavm_local_1 >> (INT32_C(32) - teavm_local_3))));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jl_Integer_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(159, teavm_checkcast(teavm_local_1, &jl_Integer_Cls, &supertypeof_jl_Integer));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(160, TEAVM_METHOD(teavm_this_, jl_Integer_VT, virt_compareTo_1)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Integer__clinit_() {
    sfld_jl_Integer_TYPE = teavm_getClassObject((TeaVM_Class*) &I_Cls);
}
void initclass_jl_Integer() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Integer_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Integer__clinit_();
    }
}
int32_t supertypeof_jl_Integer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1962 || tag >= 1964) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Integer_VT jl_Integer_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Integer), sizeof(void*)),
        .flags = 0,
        .tag = 1962,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(16),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Integer,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Integer_hashCode_0,
    .virt_equals = &meth_jl_Integer_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Integer_toString_1,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_intValue = &meth_jl_Integer_intValue,
    .virt_compareTo = &meth_jl_Integer_compareTo_0,
    .virt_longValue = &meth_jl_Integer_longValue,
    .virt_compareTo_1 = &meth_jl_Integer_compareTo,
    .virt_doubleValue = &meth_jl_Integer_doubleValue
};
static void** teavm_gc_localStaticRoots_jl_Integer_Cls[2] = {
(void**) &sfld_jl_Integer_TYPE, (void**) &sfld_jl_Integer_integerCache
};
void sysinitclass_jl_Integer() {
sfld_jl_Integer_TYPE = NULL;
sfld_jl_Integer_integerCache = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Integer_Cls, 2);
}
