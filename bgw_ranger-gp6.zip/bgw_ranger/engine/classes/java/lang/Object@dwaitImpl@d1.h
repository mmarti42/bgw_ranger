#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Object@dwaitImpl@d1.h"

extern void sysinitclass_jl_Object_waitImpl_1();
typedef struct cls_jl_Object_waitImpl_1 {
    struct TeaVM_Object parent;
    void* fld_instance;
    int64_t fld_param0;
    int32_t fld_param1;
} cls_jl_Object_waitImpl_1;
extern void meth_jl_Object_waitImpl_1__init_(void*, void*, int64_t, int32_t);
extern void meth_jl_Object_waitImpl_1_run(void*, void*);
extern int32_t supertypeof_jl_Object_waitImpl_1(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Object_waitImpl_1_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*virt_run)(void*, void*); // 12
    void (*pad1)(); // 13
    void (*pad2)(); // 14
    void (*pad3)(); // 15
    void (*pad4)(); // 16
    void (*pad5)(); // 17
    void (*pad6)(); // 18
    void (*pad7)(); // 19
    void (*pad8)(); // 20
    void (*pad9)(); // 21
    void (*pad10)(); // 22
    void (*pad11)(); // 23
    void (*pad12)(); // 24
    void (*pad13)(); // 25
    void (*pad14)(); // 26
    void (*pad15)(); // 27
    void (*pad16)(); // 28
    void (*pad17)(); // 29
    void (*pad18)(); // 30
    void (*pad19)(); // 31
    void (*pad20)(); // 32
    void (*pad21)(); // 33
    void (*pad22)(); // 34
    void (*pad23)(); // 35
    void (*pad24)(); // 36
    void (*pad25)(); // 37
    void (*pad26)(); // 38
    void (*pad27)(); // 39
    void (*pad28)(); // 40
    void (*pad29)(); // 41
    void (*pad30)(); // 42
    void (*pad31)(); // 43
    void (*pad32)(); // 44
    void (*pad33)(); // 45
    void (*pad34)(); // 46
    void (*pad35)(); // 47
    void (*pad36)(); // 48
    void (*pad37)(); // 49
} jl_Object_waitImpl_1_VT;
extern jl_Object_waitImpl_1_VT jl_Object_waitImpl_1_Cls;
