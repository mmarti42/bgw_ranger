#pragma once
#include "../../../runtime.h"
#include "VirtualMachineError.h"
#include "OutOfMemoryError.h"

extern void sysinitclass_jl_OutOfMemoryError();
typedef struct cls_jl_OutOfMemoryError {
    struct cls_jl_VirtualMachineError parent;
} cls_jl_OutOfMemoryError;
extern void meth_jl_OutOfMemoryError__init_(void*, void*);
extern int32_t supertypeof_jl_OutOfMemoryError(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_OutOfMemoryError_VT {
    jl_VirtualMachineError_VT parent;
} jl_OutOfMemoryError_VT;
extern jl_OutOfMemoryError_VT jl_OutOfMemoryError_Cls;
