#pragma once
#include "../../../runtime.h"
#include "RuntimeException.h"
#include "IllegalMonitorStateException.h"

extern void sysinitclass_jl_IllegalMonitorStateException();
typedef struct cls_jl_IllegalMonitorStateException {
    struct cls_jl_RuntimeException parent;
} cls_jl_IllegalMonitorStateException;
extern void meth_jl_IllegalMonitorStateException__init_(void*);
extern int32_t supertypeof_jl_IllegalMonitorStateException(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_IllegalMonitorStateException_VT {
    jl_RuntimeException_VT parent;
} jl_IllegalMonitorStateException_VT;
extern jl_IllegalMonitorStateException_VT jl_IllegalMonitorStateException_Cls;
