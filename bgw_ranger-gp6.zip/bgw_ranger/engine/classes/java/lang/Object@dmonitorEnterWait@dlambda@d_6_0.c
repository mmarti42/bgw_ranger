#include "Object@dmonitorEnterWait@dlambda@d_6_0.h"
#include "Object.h"
#include "../../../strings.h"

void meth_jl_Object_monitorEnterWait_lambda__6_0__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(3533, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__0) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__1) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__2) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__3) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorEnterWait_lambda__6_0_run(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__0);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__1);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__2);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_lambda__6_0, fld__3);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(3534, meth_jl_Object_lambda_monitorEnterWait_0(teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Object_monitorEnterWait_lambda__6_0(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 175 || tag >= 177) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Object_monitorEnterWait_lambda__6_0_Cls[4];
alignas(8) jl_Object_monitorEnterWait_lambda__6_0_VT jl_Object_monitorEnterWait_lambda__6_0_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Object_monitorEnterWait_lambda__6_0), sizeof(void*)),
        .flags = 0,
        .tag = 175,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(436),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Object_monitorEnterWait_lambda__6_0,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Object_monitorEnterWait_lambda__6_0_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_run_0 = &meth_jl_Object_monitorEnterWait_lambda__6_0_run
};
static int16_t teavm_classLayouts_jl_Object_monitorEnterWait_lambda__6_0_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_jl_Object_monitorEnterWait_lambda__6_0, fld__0), (int16_t) offsetof(cls_jl_Object_monitorEnterWait_lambda__6_0, fld__1), (int16_t) offsetof(cls_jl_Object_monitorEnterWait_lambda__6_0, fld__3)
};
void sysinitclass_jl_Object_monitorEnterWait_lambda__6_0() {
}
