#include "Character.h"
#include "Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "String.h"
#include "../../../arrays/primitives/char.h"
#include "IndexOutOfBoundsException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../resources/org/teavm/platform/metadata/StringResource.h"
#include "../../org/teavm/classlib/impl/unicode/UnicodeHelper.h"
#include "../../org/teavm/classlib/impl/unicode/CharMapping.h"
#include "IllegalArgumentException.h"
#include "../../org/teavm/classlib/impl/unicode/UnicodeHelper@dRange.h"
#include "../../../primitives/char.h"
#include "../../../arrayclass.h"
#include "../../../strings.h"

void* sfld_jl_Character_TYPE;
TeaVM_Array* sfld_jl_Character_digitMapping;
void* sfld_jl_Character_upperCaseMapping;
void* sfld_jl_Character_lowerCaseMapping;
TeaVM_Array* sfld_jl_Character_classMapping;
TeaVM_Array* sfld_jl_Character_characterCache;
void* sfld_jl_Character___metadata__0;
void* sfld_jl_Character___metadata__1;
void* sfld_jl_Character___metadata__3;
void* sfld_jl_Character___metadata__4;
void meth_jl_Character__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28785, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    TEAVM_WITH_CALL_SITE_ID(28786, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Character, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Character_charValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Character, fld_value);
}
void* meth_jl_Character_valueOf(int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(28787, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = sfld_jl_Character_characterCache;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((teavm_local_1 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28788, teavm_nullCheck(teavm_local_2))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28789, meth_otr_Allocator_allocate(&jl_Character_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(28790, meth_jl_Character__init_(teavm_local_3, teavm_local_1));
    } else {
        teavm_local_2 = sfld_jl_Character_characterCache;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28791, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28792, teavm_checkBounds(teavm_local_1, teavm_local_2));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1);
        if ((teavm_local_3 == NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28793, meth_otr_Allocator_allocate(&jl_Character_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(28794, meth_jl_Character__init_(teavm_local_3, teavm_local_1));
            teavm_local_2 = sfld_jl_Character_characterCache;
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28795, teavm_nullCheck(teavm_local_2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28796, teavm_checkUpperBound(teavm_local_1, teavm_local_2));
            teavm_gc_writeBarrier(teavm_local_2);
            TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1) = teavm_local_3;
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_Character_toString_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28797, meth_jl_Character_toString(TEAVM_FIELD(teavm_this_, cls_jl_Character, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Character_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if (teavm_instanceof(teavm_local_1, &jl_Character_Cls, &supertypeof_jl_Character)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28798, teavm_checkcast(teavm_local_1, &jl_Character_Cls, &supertypeof_jl_Character));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(28799, teavm_nullCheck(teavm_local_3)), cls_jl_Character, fld_value) == TEAVM_FIELD(teavm_this_, cls_jl_Character, fld_value))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28800, meth_jl_Character_hashCode_0(TEAVM_FIELD(teavm_this_, cls_jl_Character, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Character_hashCode_0(int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28801, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Character_toString(int32_t teavm_local_1) {
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(28802, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28803, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28804, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(1)));
    TEAVM_ARRAY_AT(teavm_local_3, char16_t, INT32_C(0)) = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(28805, meth_jl_String__init__1(teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isValidCodePoint(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28806, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((!((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= INT32_C(1114111)))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isBmpCodePoint(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28807, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((!((teavm_local_1 > INT32_C(0)) && (teavm_local_1 <= INT32_C(65535)))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isSupplementaryCodePoint(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28808, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((!((teavm_local_1 >= INT32_C(65536)) && (teavm_local_1 <= INT32_C(1114111)))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isHighSurrogate(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28809, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = (((teavm_local_1 & INT32_C(64512)) != INT32_C(55296)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isLowSurrogate(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28810, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = (((teavm_local_1 & INT32_C(64512)) != INT32_C(56320)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isSurrogate(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28811, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((!((!TEAVM_WITH_CALL_SITE_ID(28812, meth_jl_Character_isHighSurrogate(teavm_local_1))) && (!TEAVM_WITH_CALL_SITE_ID(28813, meth_jl_Character_isLowSurrogate(teavm_local_1))))) ? INT32_C(1) : INT32_C(0));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isSurrogatePair(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28814, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_3 = ((!(TEAVM_WITH_CALL_SITE_ID(28815, meth_jl_Character_isHighSurrogate(teavm_local_1)) && TEAVM_WITH_CALL_SITE_ID(28816, meth_jl_Character_isLowSurrogate(teavm_local_2)))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_toCodePoint(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28817, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_3 = ((((teavm_local_1 & INT32_C(1023)) << INT32_C(10)) | (teavm_local_2 & INT32_C(1023))) + INT32_C(65536));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_codePointAt(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28818, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28819, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28820, meth_jl_Character_codePointAt_0(teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_codePointAt_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28821, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if (((teavm_local_2 < teavm_local_3) && (teavm_local_2 >= INT32_C(0)))) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28822, teavm_nullCheck(teavm_local_1));
        teavm_local_4 = teavm_local_1;
        if ((teavm_local_3 <= TEAVM_ARRAY_LENGTH(teavm_local_4))) {
            if ((teavm_local_2 < (teavm_local_3 - INT32_C(1)))) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28823, teavm_checkBounds(teavm_local_2, teavm_local_4));
                if (TEAVM_WITH_CALL_SITE_ID(28824, meth_jl_Character_isHighSurrogate(TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_2)))) {
                    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28825, teavm_checkBounds((teavm_local_2 + INT32_C(1)), teavm_local_4));
                    if (TEAVM_WITH_CALL_SITE_ID(28826, meth_jl_Character_isLowSurrogate(TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_5)))) {
                        goto teavm_label_2;
                    }
                }
            }
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28827, teavm_checkBounds(teavm_local_2, teavm_local_4));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_2);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_2);
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28828, meth_jl_Character_toCodePoint(teavm_local_6, teavm_local_5));
        teavm_label_1:;
            TEAVM_RELEASE_STACK;
            return teavm_local_6;
        }
    }
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28829, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(28830, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(28831, meth_otr_ExceptionHandling_throwException(teavm_local_7));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_Character_highSurrogate(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28832, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = (teavm_local_1 - INT32_C(65536));
    teavm_local_3 = TEAVM_TO_CHAR((INT32_C(55296) | ((teavm_local_2 >> INT32_C(10)) & INT32_C(1023))));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_lowSurrogate(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28833, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_TO_CHAR((INT32_C(56320) | (teavm_local_1 & INT32_C(1023))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_toLowerCase(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28834, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(28835, meth_jl_Character_toLowerCase_0(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_toLowerCase_0(int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28836, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28837, meth_jl_Character_getLowerCaseMapping());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28838, meth_jl_Character_mapChar(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_Character_getLowerCaseMapping() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28839, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character_lowerCaseMapping == NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28840, teavm_dereferenceNullable(TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(28841, meth_jl_Character_acquireLowerCaseMapping()), cls_otpm_StringResource, value)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28842, meth_otciu_UnicodeHelper_decodeCaseMapping(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        sfld_jl_Character_lowerCaseMapping = TEAVM_WITH_CALL_SITE_ID(28843, meth_otciu_UnicodeHelper_createCharMapping(teavm_local_2));
    }
    teavm_local_1 = sfld_jl_Character_lowerCaseMapping;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Character_acquireLowerCaseMapping() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28844, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character___metadata__0 == NULL)) {
        sfld_jl_Character___metadata__0 = TEAVM_WITH_CALL_SITE_ID(28845, meth_jl_Character_acquireLowerCaseMapping__create());
    }
    teavm_local_1 = sfld_jl_Character___metadata__0;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Character_toUpperCase(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28846, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_TO_CHAR(TEAVM_WITH_CALL_SITE_ID(28847, meth_jl_Character_toUpperCase_0(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_toUpperCase_0(int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28848, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28849, meth_jl_Character_getUpperCaseMapping());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28850, meth_jl_Character_mapChar(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_Character_getUpperCaseMapping() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28851, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character_upperCaseMapping == NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28852, teavm_dereferenceNullable(TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(28853, meth_jl_Character_acquireUpperCaseMapping()), cls_otpm_StringResource, value)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28854, meth_otciu_UnicodeHelper_decodeCaseMapping(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        sfld_jl_Character_upperCaseMapping = TEAVM_WITH_CALL_SITE_ID(28855, meth_otciu_UnicodeHelper_createCharMapping(teavm_local_2));
    }
    teavm_local_1 = sfld_jl_Character_upperCaseMapping;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Character_acquireUpperCaseMapping() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28856, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character___metadata__1 == NULL)) {
        sfld_jl_Character___metadata__1 = TEAVM_WITH_CALL_SITE_ID(28857, meth_jl_Character_acquireUpperCaseMapping__create());
    }
    teavm_local_1 = sfld_jl_Character___metadata__1;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Character_mapChar(void* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(28858, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28859, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_otciu_CharMapping, fld_fastTable);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(28860, teavm_nullCheck(teavm_local_3))))) {
        teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_otciu_CharMapping, fld_fastTable);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28861, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28862, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = (teavm_local_2 + TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2));
    } else {
        teavm_local_5 = TEAVM_FIELD(teavm_local_1, cls_otciu_CharMapping, fld_binarySearchTable);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(28863, meth_jl_Character_binarySearchTable(teavm_local_5, teavm_local_2));
        if ((teavm_local_6 >= INT32_C(0))) {
            teavm_local_4 = (teavm_local_6 * INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28864, teavm_nullCheck(teavm_local_5));
            teavm_local_3 = teavm_local_5;
            if ((teavm_local_4 < TEAVM_ARRAY_LENGTH(teavm_local_3))) {
                goto teavm_label_2;
            }
        }
        teavm_local_4 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_4 = (teavm_local_2 + TEAVM_ARRAY_AT(teavm_local_3, int32_t, TEAVM_WITH_CALL_SITE_ID(28865, teavm_checkBounds((teavm_local_4 + INT32_C(1)), teavm_local_3))));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_jl_Character_binarySearchTable(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28866, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_3 = INT32_C(0);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28867, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = ((TEAVM_ARRAY_LENGTH(teavm_local_4) / INT32_C(2)) - INT32_C(1));
    while (1) {
        teavm_local_6 = ((teavm_local_3 + teavm_local_5) / INT32_C(2));
        teavm_local_7 = (teavm_local_6 * INT32_C(2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, TEAVM_WITH_CALL_SITE_ID(28868, teavm_checkBounds(teavm_local_7, teavm_local_4)));
        teavm_local_9 = teavm_compare_i32(teavm_local_8, teavm_local_2);
        if ((!teavm_local_9)) {
            goto teavm_label_4;
        }
        if ((teavm_local_9 <= INT32_C(0))) {
            teavm_local_3 = (teavm_local_6 + INT32_C(1));
            if ((teavm_local_3 > teavm_local_5)) {
                goto teavm_label_2;
            }
        } else {
            teavm_local_6 = (teavm_local_6 - INT32_C(1));
            if ((teavm_local_6 < teavm_local_3)) {
                goto teavm_label_3;
            }
            teavm_local_5 = teavm_local_6;
        }
    }
teavm_label_4:;
    goto teavm_label_1;
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_jl_Character_digit(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28869, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28870, meth_jl_Character_digit_0(teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_digit_0(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28871, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((!((teavm_local_2 >= INT32_C(2)) && (teavm_local_2 <= INT32_C(36))))) {
        teavm_local_3 = -INT32_C(1);
    } else {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28872, meth_jl_Character_getNumericValue(teavm_local_1));
        if ((teavm_local_3 >= teavm_local_2)) {
            teavm_local_3 = -INT32_C(1);
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_getNumericValue(int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28873, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28874, meth_jl_Character_getDigitMapping());
    teavm_local_3 = INT32_C(0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28875, teavm_nullCheck(teavm_local_2));
    teavm_local_4 = teavm_local_2;
    teavm_local_5 = ((TEAVM_ARRAY_LENGTH(teavm_local_4) / INT32_C(2)) - INT32_C(1));
    while (1) {
        if (!(teavm_local_5 >= teavm_local_3)) break;
        teavm_local_6 = ((teavm_local_3 + teavm_local_5) / INT32_C(2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28876, teavm_checkBounds((teavm_local_6 * INT32_C(2)), teavm_local_4));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_7);
        teavm_local_9 = teavm_compare_i32(teavm_local_1, teavm_local_8);
        if ((teavm_local_9 > INT32_C(0))) {
            teavm_local_3 = (teavm_local_6 + INT32_C(1));
        } else {
            if ((teavm_local_9 >= INT32_C(0))) {
                goto teavm_label_2;
            }
            teavm_local_5 = (teavm_local_6 - INT32_C(1));
        }
    }
    teavm_local_9 = -INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, TEAVM_WITH_CALL_SITE_ID(28877, teavm_checkBounds((teavm_local_7 + INT32_C(1)), teavm_local_4)));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_9;
}
int32_t meth_jl_Character_forDigit(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28878, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_3 = ((!((teavm_local_2 >= INT32_C(2)) && ((teavm_local_2 <= INT32_C(36)) && ((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 < teavm_local_2))))) ? INT32_C(0) : ((teavm_local_1 < INT32_C(10)) ? TEAVM_TO_CHAR((INT32_C(48) + teavm_local_1)) : TEAVM_TO_CHAR(((INT32_C(97) + teavm_local_1) - INT32_C(10)))));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_isDigit(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28879, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28880, meth_jl_Character_isDigit_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isDigit_0(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28881, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(28882, meth_jl_Character_getType(teavm_local_1)) != INT32_C(9)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
TeaVM_Array* meth_jl_Character_getDigitMapping() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28883, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character_digitMapping == NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28884, teavm_dereferenceNullable(TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(28885, meth_jl_Character_obtainDigitMapping()), cls_otpm_StringResource, value)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        sfld_jl_Character_digitMapping = TEAVM_WITH_CALL_SITE_ID(28886, meth_otciu_UnicodeHelper_decodeIntPairsDiff(teavm_local_1));
    }
    teavm_local_2 = sfld_jl_Character_digitMapping;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Character_obtainDigitMapping() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28887, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character___metadata__3 == NULL)) {
        sfld_jl_Character___metadata__3 = TEAVM_WITH_CALL_SITE_ID(28888, meth_jl_Character_obtainDigitMapping__create());
    }
    teavm_local_1 = sfld_jl_Character___metadata__3;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jl_Character_getClasses() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28889, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character_classMapping == NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28890, teavm_dereferenceNullable(TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(28891, meth_jl_Character_obtainClasses()), cls_otpm_StringResource, value)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        sfld_jl_Character_classMapping = TEAVM_WITH_CALL_SITE_ID(28892, meth_otciu_UnicodeHelper_extractRle(teavm_local_1));
    }
    teavm_local_2 = sfld_jl_Character_classMapping;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Character_obtainClasses() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28893, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((sfld_jl_Character___metadata__4 == NULL)) {
        sfld_jl_Character___metadata__4 = TEAVM_WITH_CALL_SITE_ID(28894, meth_jl_Character_obtainClasses__create());
    }
    teavm_local_1 = sfld_jl_Character___metadata__4;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jl_Character_toChars(int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28895, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if (TEAVM_WITH_CALL_SITE_ID(28896, meth_jl_Character_isValidCodePoint(teavm_local_1))) {
        if ((teavm_local_1 < INT32_C(65536))) {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28897, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(1)));
            TEAVM_ARRAY_AT(teavm_local_2, char16_t, INT32_C(0)) = TEAVM_TO_CHAR(teavm_local_1);
        } else {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28898, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(2)));
            teavm_local_3 = teavm_local_2;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_ARRAY_AT(teavm_local_3, char16_t, INT32_C(0)) = TEAVM_WITH_CALL_SITE_ID(28899, meth_jl_Character_highSurrogate(teavm_local_1));
            TEAVM_ARRAY_AT(teavm_local_3, char16_t, INT32_C(1)) = TEAVM_WITH_CALL_SITE_ID(28900, meth_jl_Character_lowSurrogate(teavm_local_1));
        }
        TEAVM_RELEASE_STACK;
        return teavm_local_2;
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(28901, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(28902, meth_jl_IllegalArgumentException__init_(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(28903, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_Character_isISOControl(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28904, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((!((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= INT32_C(31))))) {
        if ((teavm_local_1 < INT32_C(127))) {
            goto teavm_label_2;
        }
        if ((teavm_local_1 > INT32_C(159))) {
            goto teavm_label_2;
        }
    }
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_getType_0(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28905, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28906, meth_jl_Character_getType(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_getType(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(28907, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if ((TEAVM_WITH_CALL_SITE_ID(28908, meth_jl_Character_isBmpCodePoint(teavm_local_1)) && TEAVM_WITH_CALL_SITE_ID(28909, meth_jl_Character_isSurrogate(TEAVM_TO_CHAR(teavm_local_1))))) {
        teavm_local_2 = INT32_C(19);
    } else {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28910, meth_jl_Character_getClasses());
        teavm_local_4 = INT32_C(0);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(28911, teavm_nullCheck(teavm_local_3));
        teavm_local_5 = teavm_local_3;
        teavm_local_6 = (TEAVM_ARRAY_LENGTH(teavm_local_5) - INT32_C(1));
        while (1) {
            if (!(teavm_local_4 <= teavm_local_6)) break;
            teavm_local_7 = ((teavm_local_4 + teavm_local_6) / INT32_C(2));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(28912, teavm_checkBounds(teavm_local_7, teavm_local_5));
            teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_7);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(28913, teavm_nullCheck(teavm_local_8));
            if ((teavm_local_1 >= TEAVM_FIELD(teavm_local_8, cls_otciu_UnicodeHelper_Range, fld_end))) {
                teavm_local_4 = (teavm_local_7 + INT32_C(1));
            } else {
                if ((teavm_local_1 >= TEAVM_FIELD(teavm_local_8, cls_otciu_UnicodeHelper_Range, fld_start))) {
                    goto teavm_label_2;
                }
                teavm_local_6 = (teavm_local_7 - INT32_C(1));
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_5 = TEAVM_FIELD(teavm_local_8, cls_otciu_UnicodeHelper_Range, fld_data);
        teavm_local_2 = (teavm_local_1 - TEAVM_FIELD(teavm_local_8, cls_otciu_UnicodeHelper_Range, fld_start));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(28914, teavm_nullCheck(teavm_local_5));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_5, int8_t, TEAVM_WITH_CALL_SITE_ID(28915, teavm_checkBounds(teavm_local_2, teavm_local_5)));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isLowerCase(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28916, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(28917, meth_jl_Character_getType(teavm_local_1)) != INT32_C(2)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isUpperCase(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28918, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(28919, meth_jl_Character_getType(teavm_local_1)) != INT32_C(1)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isTitleCase(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28920, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(28921, meth_jl_Character_getType(teavm_local_1)) != INT32_C(3)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isDefined(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28922, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = ((!TEAVM_WITH_CALL_SITE_ID(28923, meth_jl_Character_getType(teavm_local_1))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isLetter(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28924, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28925, meth_jl_Character_getType(teavm_local_1))) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            goto teavm_label_3;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isLetterOrDigit(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28926, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28927, meth_jl_Character_isLetterOrDigit_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isLetterOrDigit_0(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28928, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28929, meth_jl_Character_getType(teavm_local_1))) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 9:
            goto teavm_label_3;
        case 6:
        case 7:
        case 8:
            goto teavm_label_2;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isJavaIdentifierStart(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28930, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28931, meth_jl_Character_getType(teavm_local_1))) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 10:
        case 23:
        case 26:
            goto teavm_label_3;
        case 6:
        case 7:
        case 8:
        case 9:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
        case 16:
        case 17:
        case 18:
        case 19:
        case 20:
        case 21:
        case 22:
        case 24:
        case 25:
            goto teavm_label_2;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28932, meth_jl_Character_isIdentifierIgnorable(teavm_local_1));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isJavaIdentifierPart(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28933, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28934, meth_jl_Character_getType(teavm_local_1))) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 8:
        case 9:
        case 10:
        case 23:
        case 26:
            goto teavm_label_3;
        case 7:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
        case 16:
        case 17:
        case 18:
        case 19:
        case 20:
        case 21:
        case 22:
        case 24:
        case 25:
            goto teavm_label_2;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28935, meth_jl_Character_isIdentifierIgnorable(teavm_local_1));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isUnicodeIdentifierStart(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28936, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28937, meth_jl_Character_getType(teavm_local_1))) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 10:
            goto teavm_label_3;
        case 6:
        case 7:
        case 8:
        case 9:
            goto teavm_label_2;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28938, meth_jl_Character_isIdentifierIgnorable(teavm_local_1));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isUnicodeIdentifierPart(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28939, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28940, meth_jl_Character_getType(teavm_local_1))) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 8:
        case 9:
        case 10:
        case 23:
            goto teavm_label_3;
        case 7:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
        case 16:
        case 17:
        case 18:
        case 19:
        case 20:
        case 21:
        case 22:
            goto teavm_label_2;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28941, meth_jl_Character_isIdentifierIgnorable(teavm_local_1));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isIdentifierIgnorable(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28942, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    if (((!((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= INT32_C(8)))) && (!((teavm_local_1 >= INT32_C(14)) && (teavm_local_1 <= INT32_C(27)))))) {
        if ((teavm_local_1 < INT32_C(127))) {
            goto teavm_label_2;
        }
        if ((teavm_local_1 > INT32_C(159))) {
            goto teavm_label_2;
        }
    }
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(28943, meth_jl_Character_getType(teavm_local_1)) != INT32_C(16)) ? INT32_C(0) : INT32_C(1));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isSpaceChar(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28944, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (TEAVM_WITH_CALL_SITE_ID(28945, meth_jl_Character_getType(teavm_local_1))) {
        case 12:
        case 13:
        case 14:
            goto teavm_label_3;
        default:
            goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isWhitespace(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28946, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28947, meth_jl_Character_isWhitespace_0(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_isWhitespace_0(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28948, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    switch (teavm_local_1) {
        case 9:
        case 10:
        case 11:
        case 12:
        case 13:
        case 28:
        case 29:
        case 30:
        case 31:
            goto teavm_label_4;
        case 160:
        case 8199:
        case 8239:
            goto teavm_label_3;
        default:
            goto teavm_label_2;
    }
teavm_label_4:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_3:;
    teavm_local_2 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28949, meth_jl_Character_isSpaceChar(teavm_local_1));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Character, fld_value);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28950, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28951, meth_jl_Character_compare(teavm_local_2, TEAVM_FIELD(teavm_local_1, cls_jl_Character, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_compare(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28952, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_3 = (teavm_local_1 - teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Character_reverseBytes(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(28953, teavm_initializeClass((TeaVM_Class*) &jl_Character_Cls, &initclass_jl_Character));
    teavm_local_2 = TEAVM_TO_CHAR((((teavm_local_1 & INT32_C(65280)) >> INT32_C(8)) | (teavm_local_1 << INT32_C(8))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Character_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(28954, teavm_checkcast(teavm_local_1, &jl_Character_Cls, &supertypeof_jl_Character));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28955, TEAVM_METHOD(teavm_this_, jl_Character_VT, virt_compareTo_9)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Character__clinit_() {
    TEAVM_ALLOC_STACK(INT32_C(0));
    sfld_jl_Character_TYPE = teavm_getClassObject((TeaVM_Class*) &C_Cls);
    sfld_jl_Character_characterCache = TEAVM_WITH_CALL_SITE_ID(28956, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Character_Cls), INT32_C(128)));
    TEAVM_RELEASE_STACK;
}
static void* resource_meth_jl_Character_acquireLowerCaseMapping__create = &(cls_otpm_StringResource) {
    .value = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7363)
};
void* meth_jl_Character_acquireLowerCaseMapping__create() {
    return resource_meth_jl_Character_acquireLowerCaseMapping__create;
}
static void* resource_meth_jl_Character_acquireUpperCaseMapping__create = &(cls_otpm_StringResource) {
    .value = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7364)
};
void* meth_jl_Character_acquireUpperCaseMapping__create() {
    return resource_meth_jl_Character_acquireUpperCaseMapping__create;
}
static void* resource_meth_jl_Character_obtainDigitMapping__create = &(cls_otpm_StringResource) {
    .value = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7365)
};
void* meth_jl_Character_obtainDigitMapping__create() {
    return resource_meth_jl_Character_obtainDigitMapping__create;
}
static void* resource_meth_jl_Character_obtainClasses__create = &(cls_otpm_StringResource) {
    .value = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7366)
};
void* meth_jl_Character_obtainClasses__create() {
    return resource_meth_jl_Character_obtainClasses__create;
}
void initclass_jl_Character() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Character_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Character__clinit_();
    }
}
int32_t supertypeof_jl_Character(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1453 || tag >= 1455) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Character_VT jl_Character_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Character), sizeof(void*)),
        .flags = 0,
        .tag = 1453,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7367),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Character,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Character_hashCode,
    .virt_equals = &meth_jl_Character_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Character_toString_0,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_compareTo_9 = &meth_jl_Character_compareTo,
    .virt_compareTo = &meth_jl_Character_compareTo_0,
    .virt_charValue = &meth_jl_Character_charValue
};
static void** teavm_gc_localStaticRoots_jl_Character_Cls[6] = {
(void**) &sfld_jl_Character_TYPE, (void**) &sfld_jl_Character_digitMapping, (void**) &sfld_jl_Character_upperCaseMapping, (void**) &sfld_jl_Character_lowerCaseMapping, (void**) &sfld_jl_Character_classMapping, (void**) &sfld_jl_Character_characterCache
};
void sysinitclass_jl_Character() {
sfld_jl_Character_TYPE = NULL;
sfld_jl_Character_digitMapping = NULL;
sfld_jl_Character_upperCaseMapping = NULL;
sfld_jl_Character_lowerCaseMapping = NULL;
sfld_jl_Character_classMapping = NULL;
sfld_jl_Character_characterCache = NULL;
sfld_jl_Character___metadata__0 = NULL;
sfld_jl_Character___metadata__1 = NULL;
sfld_jl_Character___metadata__3 = NULL;
sfld_jl_Character___metadata__4 = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Character_Cls, 6);
}
