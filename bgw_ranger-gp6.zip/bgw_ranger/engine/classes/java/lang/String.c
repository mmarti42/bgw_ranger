#include "String.h"
#include "Object.h"
#include "../../../arrays/primitives/char.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "System.h"
#include "../util/Objects.h"
#include "Character.h"
#include "../util/Arrays.h"
#include "../nio/ByteBuffer.h"
#include "../nio/charset/Charset.h"
#include "../nio/CharBuffer.h"
#include "../nio/Buffer.h"
#include "StringIndexOutOfBoundsException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Math.h"
#include "CharSequence.h"
#include "StringBuilder.h"
#include "../../../strings.h"
#include "../../../arrays/primitives/byte.h"
#include "../../../arrays/primitives/int.h"
#include "../util/regex/Pattern.h"
#include "../util/Formatter.h"
#include "String@d@lclinit@g@dlambda@d_118_0.h"

TeaVM_Array* sfld_jl_String_EMPTY_CHARS;
void* sfld_jl_String_EMPTY;
void* sfld_jl_String_CASE_INSENSITIVE_ORDER;
void meth_jl_String__init__0(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8524, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    TEAVM_WITH_CALL_SITE_ID(8525, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = sfld_jl_String_EMPTY_CHARS;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, TeaVM_String, characters) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jl_String__init__1(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(8526, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    TEAVM_WITH_CALL_SITE_ID(8527, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8528, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8529, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(8530, meth_jl_System_fastArraycopy(teavm_local_1, INT32_C(0), teavm_local_3, INT32_C(0), teavm_local_2));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, TeaVM_String, characters) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void meth_jl_String__init_(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(8531, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    TEAVM_WITH_CALL_SITE_ID(8532, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8533, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(8534, meth_ju_Objects_checkFromIndexSize(teavm_local_2, teavm_local_3, teavm_local_4));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8535, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(8536, meth_jl_System_fastArraycopy(teavm_local_1, teavm_local_2, teavm_local_5, INT32_C(0), teavm_local_3));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, TeaVM_String, characters) = teavm_local_5;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_String_fromArray(TeaVM_Array* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8537, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8538, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8539, meth_jl_String__init__0(teavm_local_2));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_FIELD(teavm_local_2, TeaVM_String, characters) = teavm_local_1;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_String__init__2(void* teavm_this_, TeaVM_Array* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8540, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    TEAVM_WITH_CALL_SITE_ID(8541, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8542, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(8543, meth_jl_String_initWithBytes(teavm_this_, teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_jl_String__init__3(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(8544, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    TEAVM_WITH_CALL_SITE_ID(8545, meth_jl_Object__init_(teavm_this_));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8546, meth_otr_Allocator_allocateArray(&Arr_C_Cls, (teavm_local_3 * INT32_C(2))));
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_3)) break;
        teavm_local_7 = (teavm_local_2 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8547, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(8548, teavm_checkBounds(teavm_local_2, teavm_local_8)));
        if ((teavm_local_9 < INT32_C(65536))) {
            teavm_local_8 = teavm_local_4;
            teavm_local_10 = (teavm_local_5 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(8549, teavm_checkBounds(teavm_local_5, teavm_local_8))) = TEAVM_TO_CHAR(teavm_local_9);
        } else {
            teavm_local_8 = teavm_local_4;
            teavm_local_11 = (teavm_local_5 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(8550, teavm_checkBounds(teavm_local_5, teavm_local_8))) = TEAVM_WITH_CALL_SITE_ID(8551, meth_jl_Character_highSurrogate(teavm_local_9));
            teavm_local_10 = (teavm_local_11 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(8552, teavm_checkBounds(teavm_local_11, teavm_local_8))) = TEAVM_WITH_CALL_SITE_ID(8553, meth_jl_Character_lowSurrogate(teavm_local_9));
        }
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
        teavm_local_2 = teavm_local_7;
        teavm_local_5 = teavm_local_10;
    }
    if ((teavm_local_5 < TEAVM_ARRAY_LENGTH(teavm_local_4))) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8554, meth_ju_Arrays_copyOf_1(teavm_local_4, teavm_local_5));
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, TeaVM_String, characters) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
void meth_jl_String_initWithBytes(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    void* teavm_local_5;
    void* teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8555, meth_jn_ByteBuffer_wrap_0(teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8556, teavm_nullCheck(teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8557, meth_jnc_Charset_decode(teavm_local_4, teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8558, teavm_nullCheck(teavm_local_6));
    if ((TEAVM_WITH_CALL_SITE_ID(8559, meth_jn_CharBuffer_hasArray(teavm_local_6)) && ((!TEAVM_WITH_CALL_SITE_ID(8560, meth_jn_Buffer_position(teavm_local_6))) && (TEAVM_WITH_CALL_SITE_ID(8561, meth_jn_Buffer_limit(teavm_local_6)) == TEAVM_WITH_CALL_SITE_ID(8562, meth_jn_Buffer_capacity(teavm_local_6)))))) {
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8563, meth_jn_CharBuffer_array(teavm_local_6));
    } else {
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8564, meth_otr_Allocator_allocateArray(&Arr_C_Cls, TEAVM_WITH_CALL_SITE_ID(8565, meth_jn_Buffer_remaining(teavm_local_6))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(8566, TEAVM_METHOD(teavm_local_6, jn_CharBuffer_VT, virt_get_8)(teavm_local_6, teavm_local_7));
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, TeaVM_String, characters) = teavm_local_7;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_String_charAt(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((teavm_local_1 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8567, teavm_nullCheck(teavm_local_2))))) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8568, teavm_nullCheck(teavm_local_2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8569, teavm_checkBounds(teavm_local_1, teavm_local_2));
            teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_1);
            TEAVM_RELEASE_STACK;
            return teavm_local_3;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8570, meth_otr_Allocator_allocate(&jl_StringIndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(8571, meth_jl_StringIndexOutOfBoundsException__init_(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(8572, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_String_length(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8573, teavm_nullCheck(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_isEmpty(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8574, teavm_nullCheck(teavm_local_1))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8575, meth_jl_String_length(teavm_this_));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8576, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8577, meth_jl_Math_min(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(8578, meth_jl_String_length(teavm_local_1))));
        teavm_local_4 = INT32_C(0);
        while (1) {
            if ((teavm_local_4 >= teavm_local_3)) {
                goto teavm_label_2;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8579, teavm_nullCheck(teavm_local_5));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8580, teavm_checkBounds(teavm_local_4, teavm_local_5));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
            teavm_local_5 = TEAVM_FIELD(teavm_local_1, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8581, teavm_nullCheck(teavm_local_5));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8582, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
            teavm_local_2 = (teavm_local_6 - teavm_local_7);
            if (teavm_local_2) {
                goto teavm_label_3;
            }
            teavm_local_4 = (teavm_local_4 + INT32_C(1));
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = (TEAVM_WITH_CALL_SITE_ID(8583, meth_jl_String_length(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(8584, meth_jl_String_length(teavm_local_1)));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_startsWith_0(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8585, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if (((teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(8586, meth_jl_String_length(teavm_local_1))) > TEAVM_WITH_CALL_SITE_ID(8587, meth_jl_String_length(teavm_this_)))) {
        teavm_local_3 = INT32_C(0);
    } else {
        teavm_local_4 = INT32_C(0);
        while (1) {
            if (!(teavm_local_4 < TEAVM_WITH_CALL_SITE_ID(8588, meth_jl_String_length(teavm_local_1)))) break;
            teavm_local_5 = TEAVM_FIELD(teavm_local_1, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8589, teavm_nullCheck(teavm_local_5));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8590, teavm_checkBounds(teavm_local_4, teavm_local_5));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
            teavm_local_7 = (teavm_local_2 + INT32_C(1));
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8591, teavm_nullCheck(teavm_local_5));
            if ((teavm_local_6 != TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(8592, teavm_checkBounds(teavm_local_2, teavm_local_5))))) {
                goto teavm_label_2;
            }
            teavm_local_4 = (teavm_local_4 + INT32_C(1));
            teavm_local_2 = teavm_local_7;
        }
        teavm_local_3 = INT32_C(1);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_3 = INT32_C(0);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_String_startsWith(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = ((teavm_this_ == teavm_local_1) ? INT32_C(1) : TEAVM_WITH_CALL_SITE_ID(8593, meth_jl_String_startsWith_0(teavm_this_, teavm_local_1, INT32_C(0))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_regionMatches(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (((teavm_local_2 >= INT32_C(0)) && (teavm_local_4 >= INT32_C(0)))) {
        teavm_local_6 = (teavm_local_2 + teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((teavm_local_6 <= TEAVM_WITH_CALL_SITE_ID(8594, meth_jl_String_length(teavm_this_)))) {
            teavm_local_7 = (teavm_local_4 + teavm_local_5);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8595, teavm_nullCheck(teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((teavm_local_7 <= TEAVM_WITH_CALL_SITE_ID(8596, meth_jl_String_length(teavm_local_3)))) {
                goto teavm_label_2;
            }
        }
    }
    teavm_local_6 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_8 = INT32_C(0);
    while (1) {
        if (!(teavm_local_8 < teavm_local_5)) break;
        teavm_local_6 = (teavm_local_2 + INT32_C(1));
        teavm_local_9 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8597, teavm_nullCheck(teavm_local_9));
        teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_9, char16_t, TEAVM_WITH_CALL_SITE_ID(8598, teavm_checkBounds(teavm_local_2, teavm_local_9)));
        teavm_local_7 = (teavm_local_4 + INT32_C(1));
        teavm_local_9 = TEAVM_FIELD(teavm_local_3, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8599, teavm_nullCheck(teavm_local_9));
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_9, char16_t, TEAVM_WITH_CALL_SITE_ID(8600, teavm_checkBounds(teavm_local_4, teavm_local_9)));
        if (teavm_local_1) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8601, meth_jl_Character_toLowerCase(teavm_local_10));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(8602, meth_jl_Character_toLowerCase(teavm_local_11));
        }
        if ((teavm_local_10 != teavm_local_11)) {
            goto teavm_label_3;
        }
        teavm_local_8 = (teavm_local_8 + INT32_C(1));
        teavm_local_2 = teavm_local_6;
        teavm_local_4 = teavm_local_7;
    }
    teavm_local_6 = INT32_C(1);
    goto teavm_label_1;
teavm_label_3:;
    teavm_local_6 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_jl_String_regionMatches_0(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_3 >= INT32_C(0)))) {
        teavm_local_5 = (teavm_local_1 + teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((teavm_local_5 <= TEAVM_WITH_CALL_SITE_ID(8603, meth_jl_String_length(teavm_this_)))) {
            teavm_local_5 = (teavm_local_3 + teavm_local_4);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8604, teavm_nullCheck(teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            if ((teavm_local_5 <= TEAVM_WITH_CALL_SITE_ID(8605, meth_jl_String_length(teavm_local_2)))) {
                goto teavm_label_2;
            }
        }
    }
    teavm_local_5 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_4)) break;
        teavm_local_7 = (teavm_local_1 + INT32_C(1));
        teavm_local_8 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8606, teavm_nullCheck(teavm_local_8));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(8607, teavm_checkBounds(teavm_local_1, teavm_local_8)));
        teavm_local_9 = (teavm_local_3 + INT32_C(1));
        teavm_local_8 = TEAVM_FIELD(teavm_local_2, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8608, teavm_nullCheck(teavm_local_8));
        if ((teavm_local_5 != TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(8609, teavm_checkBounds(teavm_local_3, teavm_local_8))))) {
            goto teavm_label_3;
        }
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
        teavm_local_1 = teavm_local_7;
        teavm_local_3 = teavm_local_9;
    }
    teavm_local_5 = INT32_C(1);
    goto teavm_label_1;
teavm_label_3:;
    teavm_local_5 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t meth_jl_String_endsWith(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8610, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        if ((TEAVM_WITH_CALL_SITE_ID(8611, meth_jl_String_length(teavm_local_1)) > TEAVM_WITH_CALL_SITE_ID(8612, meth_jl_String_length(teavm_this_)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_3 = INT32_C(0);
            teavm_local_4 = (TEAVM_WITH_CALL_SITE_ID(8613, meth_jl_String_length(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(8614, meth_jl_String_length(teavm_local_1)));
            while (1) {
                if (!(teavm_local_4 < TEAVM_WITH_CALL_SITE_ID(8615, meth_jl_String_length(teavm_this_)))) break;
                teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8616, teavm_nullCheck(teavm_local_5));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8617, teavm_checkBounds(teavm_local_4, teavm_local_5));
                teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
                teavm_local_2 = (teavm_local_3 + INT32_C(1));
                teavm_local_5 = TEAVM_FIELD(teavm_local_1, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8618, teavm_nullCheck(teavm_local_5));
                if ((teavm_local_6 != TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(8619, teavm_checkBounds(teavm_local_3, teavm_local_5))))) {
                    goto teavm_label_2;
                }
                teavm_local_4 = (teavm_local_4 + INT32_C(1));
                teavm_local_3 = teavm_local_2;
            }
            teavm_local_2 = INT32_C(1);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(0);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_indexOf_0(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8620, meth_jl_Math_max(INT32_C(0), teavm_local_2));
    if ((teavm_local_1 < INT32_C(65536))) {
        teavm_local_4 = TEAVM_TO_CHAR(teavm_local_1);
        while (1) {
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8621, teavm_nullCheck(teavm_local_5))))) {
                goto teavm_label_2;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8622, teavm_nullCheck(teavm_local_5));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8623, teavm_checkBounds(teavm_local_3, teavm_local_5));
            if ((TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_3) == teavm_local_4)) {
                goto teavm_label_3;
            }
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_3 = -INT32_C(1);
    } else {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8624, meth_jl_Character_highSurrogate(teavm_local_1));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8625, meth_jl_Character_lowSurrogate(teavm_local_1));
        while (1) {
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            if ((teavm_local_3 >= (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8626, teavm_nullCheck(teavm_local_5))) - INT32_C(1)))) {
                goto teavm_label_4;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8627, teavm_nullCheck(teavm_local_5));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8628, teavm_checkBounds(teavm_local_3, teavm_local_5));
            if ((TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_3) == teavm_local_6)) {
                teavm_local_8 = (teavm_local_3 + INT32_C(1));
                teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8629, teavm_nullCheck(teavm_local_5));
                if ((TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(8630, teavm_checkBounds(teavm_local_8, teavm_local_5))) == teavm_local_7)) {
                    goto teavm_label_5;
                }
            }
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_5:;
        goto teavm_label_1;
    teavm_label_4:;
        teavm_local_3 = -INT32_C(1);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_String_indexOf(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8631, meth_jl_String_indexOf_0(teavm_this_, teavm_local_1, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_lastIndexOf_0(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8632, meth_jl_Math_min(teavm_local_2, (TEAVM_WITH_CALL_SITE_ID(8633, meth_jl_String_length(teavm_this_)) - INT32_C(1))));
    if ((teavm_local_1 < INT32_C(65536))) {
        teavm_local_4 = TEAVM_TO_CHAR(teavm_local_1);
        while (1) {
            if ((teavm_local_3 < INT32_C(0))) {
                goto teavm_label_2;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8634, teavm_nullCheck(teavm_local_5));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8635, teavm_checkBounds(teavm_local_3, teavm_local_5));
            if ((TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_3) == teavm_local_4)) {
                goto teavm_label_3;
            }
            teavm_local_3 = (teavm_local_3 + -INT32_C(1));
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_3 = -INT32_C(1);
    } else {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8636, meth_jl_Character_highSurrogate(teavm_local_1));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8637, meth_jl_Character_lowSurrogate(teavm_local_1));
        while (1) {
            if ((teavm_local_3 < INT32_C(1))) {
                goto teavm_label_4;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8638, teavm_nullCheck(teavm_local_5));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8639, teavm_checkUpperBound(teavm_local_3, teavm_local_5));
            if ((TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_8) == teavm_local_7)) {
                teavm_local_9 = (teavm_local_8 - INT32_C(1));
                teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8640, teavm_nullCheck(teavm_local_5));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8641, teavm_checkBounds(teavm_local_9, teavm_local_5));
                if ((TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_3) == teavm_local_6)) {
                    goto teavm_label_5;
                }
            }
            teavm_local_3 = (teavm_local_8 + -INT32_C(1));
        }
    teavm_label_5:;
        goto teavm_label_1;
    teavm_label_4:;
        teavm_local_3 = -INT32_C(1);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_String_lastIndexOf(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8642, meth_jl_String_lastIndexOf_0(teavm_this_, teavm_local_1, (TEAVM_WITH_CALL_SITE_ID(8643, meth_jl_String_length(teavm_this_)) - INT32_C(1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_indexOf_1(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8644, meth_jl_Math_max(INT32_C(0), teavm_local_2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8645, meth_jl_String_length(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8646, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_5 = (teavm_local_4 - TEAVM_WITH_CALL_SITE_ID(8647, meth_jl_String_length(teavm_local_1)));
    while (1) {
        if ((teavm_local_3 > teavm_local_5)) {
            goto teavm_label_2;
        }
        teavm_local_6 = INT32_C(0);
        while (1) {
            if ((teavm_local_6 >= TEAVM_WITH_CALL_SITE_ID(8648, meth_jl_String_length(teavm_local_1)))) {
                goto teavm_label_3;
            }
            teavm_local_4 = (teavm_local_3 + teavm_local_6);
            teavm_local_7 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8649, teavm_nullCheck(teavm_local_7));
            teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_7, char16_t, TEAVM_WITH_CALL_SITE_ID(8650, teavm_checkBounds(teavm_local_4, teavm_local_7)));
            teavm_local_7 = TEAVM_FIELD(teavm_local_1, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8651, teavm_nullCheck(teavm_local_7));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8652, teavm_checkBounds(teavm_local_6, teavm_local_7));
            if ((teavm_local_4 != TEAVM_ARRAY_AT(teavm_local_7, char16_t, teavm_local_6))) {
                goto teavm_label_4;
            }
            teavm_local_6 = (teavm_local_6 + INT32_C(1));
        }
    teavm_label_4:;
        teavm_local_3 = (teavm_local_3 + INT32_C(1));
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = -INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_String_indexOf_2(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8653, meth_jl_String_indexOf_1(teavm_this_, teavm_local_1, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_lastIndexOf_1(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8654, meth_jl_String_length(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8655, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8656, meth_jl_Math_min(teavm_local_2, (teavm_local_3 - TEAVM_WITH_CALL_SITE_ID(8657, meth_jl_String_length(teavm_local_1)))));
    while (1) {
        if ((teavm_local_4 < INT32_C(0))) {
            goto teavm_label_2;
        }
        teavm_local_5 = INT32_C(0);
        while (1) {
            if ((teavm_local_5 >= TEAVM_WITH_CALL_SITE_ID(8658, meth_jl_String_length(teavm_local_1)))) {
                goto teavm_label_3;
            }
            teavm_local_3 = (teavm_local_4 + teavm_local_5);
            teavm_local_6 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8659, teavm_nullCheck(teavm_local_6));
            teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(8660, teavm_checkBounds(teavm_local_3, teavm_local_6)));
            teavm_local_6 = TEAVM_FIELD(teavm_local_1, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8661, teavm_nullCheck(teavm_local_6));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8662, teavm_checkBounds(teavm_local_5, teavm_local_6));
            if ((teavm_local_3 != TEAVM_ARRAY_AT(teavm_local_6, char16_t, teavm_local_5))) {
                goto teavm_label_4;
            }
            teavm_local_5 = (teavm_local_5 + INT32_C(1));
        }
    teavm_label_4:;
        teavm_local_4 = (teavm_local_4 + -INT32_C(1));
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_4 = -INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_String_substring_0(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8663, teavm_nullCheck(teavm_local_3)));
    if ((teavm_local_1 == teavm_local_2)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(8664, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
        teavm_local_5 = sfld_jl_String_EMPTY;
    } else if (((!teavm_local_1) && (teavm_local_2 == teavm_local_4))) {
        teavm_local_5 = teavm_this_;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8665, meth_otr_Allocator_allocate(&jl_String_Cls));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        teavm_local_6 = (teavm_local_2 - teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(8666, meth_jl_String__init_(teavm_local_5, teavm_local_3, teavm_local_1, teavm_local_6));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jl_String_substring(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8667, meth_jl_String_substring_0(teavm_this_, teavm_local_1, TEAVM_WITH_CALL_SITE_ID(8668, meth_jl_String_length(teavm_this_))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_String_subSequence(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8669, meth_jl_String_substring_0(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_String_replace(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_1 != teavm_local_2)) {
        teavm_local_3 = INT32_C(0);
        while (1) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8670, teavm_nullCheck(teavm_local_4))))) {
                goto teavm_label_3;
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8671, teavm_nullCheck(teavm_local_4));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8672, teavm_checkBounds(teavm_local_3, teavm_local_4));
            if ((TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_3) == teavm_local_1)) {
                goto teavm_label_2;
            }
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8673, teavm_nullCheck(teavm_local_4)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8674, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_5));
        teavm_local_7 = INT32_C(0);
        while (1) {
            if (!(teavm_local_7 < teavm_local_3)) break;
            teavm_local_4 = teavm_local_6;
            teavm_local_8 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8675, teavm_nullCheck(teavm_local_8));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8676, teavm_checkBounds(teavm_local_7, teavm_local_8));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, teavm_local_7);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8677, teavm_checkUpperBound(teavm_local_7, teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_7) = teavm_local_5;
            teavm_local_7 = (teavm_local_7 + INT32_C(1));
        }
        teavm_local_4 = teavm_local_6;
        teavm_local_5 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8678, teavm_checkUpperBound(teavm_local_3, teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_3) = teavm_local_2;
        while (1) {
            if (!(teavm_local_5 < TEAVM_WITH_CALL_SITE_ID(8679, meth_jl_String_length(teavm_this_)))) break;
            teavm_local_8 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8680, teavm_nullCheck(teavm_local_8));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8681, teavm_checkBounds(teavm_local_5, teavm_local_8));
            teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, teavm_local_9);
            if ((teavm_local_10 == teavm_local_1)) {
                teavm_local_10 = teavm_local_2;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8682, teavm_checkUpperBound(teavm_local_9, teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_9) = teavm_local_10;
            teavm_local_5 = (teavm_local_9 + INT32_C(1));
        }
        teavm_this_ = TEAVM_WITH_CALL_SITE_ID(8683, meth_jl_String_fromArray(teavm_local_6));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
int32_t meth_jl_String_contains(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8684, meth_jl_String_length(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8685, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = (teavm_local_2 - TEAVM_WITH_CALL_SITE_ID(8686, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)));
    teavm_local_4 = INT32_C(0);
    while (1) {
        if (!(teavm_local_4 <= teavm_local_3)) break;
        teavm_local_5 = INT32_C(0);
        while (1) {
            if ((teavm_local_5 >= TEAVM_WITH_CALL_SITE_ID(8687, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)))) {
                goto teavm_label_2;
            }
            teavm_local_6 = (teavm_local_4 + teavm_local_5);
            teavm_local_7 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8688, teavm_nullCheck(teavm_local_7));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_7, char16_t, TEAVM_WITH_CALL_SITE_ID(8689, teavm_checkBounds(teavm_local_6, teavm_local_7)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if ((teavm_local_6 != TEAVM_WITH_CALL_SITE_ID(8690, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_5)))) {
                goto teavm_label_4;
            }
            teavm_local_5 = (teavm_local_5 + INT32_C(1));
        }
    teavm_label_4:;
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
    teavm_local_2 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_String_replace_0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((teavm_local_1 == teavm_local_2)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8691, teavm_checkcast(teavm_this_, &jl_String_Cls, &supertypeof_jl_String));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8692, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        if (TEAVM_WITH_CALL_SITE_ID(8693, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_isEmpty)(teavm_local_1))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8694, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(8695, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_5 = INT32_C(0);
            while (1) {
                if (!(teavm_local_5 < TEAVM_WITH_CALL_SITE_ID(8696, meth_jl_String_length(teavm_this_)))) break;
                TEAVM_WITH_CALL_SITE_ID(8697, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_1)(teavm_local_4, teavm_local_2));
                teavm_local_6 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8698, teavm_nullCheck(teavm_local_6));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8699, teavm_checkBounds(teavm_local_5, teavm_local_6));
                teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_6, char16_t, teavm_local_5);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(8700, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_28)(teavm_local_4, teavm_local_7));
                teavm_local_5 = (teavm_local_5 + INT32_C(1));
            }
            TEAVM_WITH_CALL_SITE_ID(8701, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_1)(teavm_local_4, teavm_local_2));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8702, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
        } else {
            if ((TEAVM_WITH_CALL_SITE_ID(8703, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)) == INT32_C(1))) {
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8704, teavm_nullCheck(teavm_local_2));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                if ((TEAVM_WITH_CALL_SITE_ID(8705, TEAVM_METHOD(teavm_local_2, jl_CharSequence_VT, virt_length)(teavm_local_2)) == INT32_C(1))) {
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8706, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, INT32_C(0)));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8707, TEAVM_METHOD(teavm_local_2, jl_CharSequence_VT, virt_charAt)(teavm_local_2, INT32_C(0)));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8708, meth_jl_String_replace(teavm_this_, teavm_local_8, teavm_local_7));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8709, teavm_checkcast(teavm_local_3, &jl_String_Cls, &supertypeof_jl_String));
                    goto teavm_label_1;
                }
            }
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8710, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(8711, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_9 = (TEAVM_WITH_CALL_SITE_ID(8712, meth_jl_String_length(teavm_this_)) - TEAVM_WITH_CALL_SITE_ID(8713, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)));
            teavm_local_5 = INT32_C(0);
            while (1) {
                if (!(teavm_local_5 <= teavm_local_9)) break;
                teavm_local_10 = INT32_C(0);
                while (1) {
                    if (!(teavm_local_10 < TEAVM_WITH_CALL_SITE_ID(8714, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)))) break;
                    teavm_local_8 = (teavm_local_5 + teavm_local_10);
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8715, teavm_nullCheck(teavm_local_6));
                    teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(8716, teavm_checkBounds(teavm_local_8, teavm_local_6)));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    if ((teavm_local_8 != TEAVM_WITH_CALL_SITE_ID(8717, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_10)))) {
                        goto teavm_label_5;
                    }
                    teavm_local_10 = (teavm_local_10 + INT32_C(1));
                }
                TEAVM_WITH_CALL_SITE_ID(8718, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_1)(teavm_local_4, teavm_local_2));
                teavm_local_5 = (teavm_local_5 + (TEAVM_WITH_CALL_SITE_ID(8719, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)) - INT32_C(1)));
                goto teavm_label_4;
            teavm_label_5:;
                teavm_local_6 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8720, teavm_nullCheck(teavm_local_6));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8721, teavm_checkBounds(teavm_local_5, teavm_local_6));
                teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_6, char16_t, teavm_local_5);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(8722, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_28)(teavm_local_4, teavm_local_8));
            teavm_label_4:;
                teavm_local_5 = (teavm_local_5 + INT32_C(1));
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8723, meth_jl_String_substring(teavm_this_, teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(8724, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_1)(teavm_local_4, teavm_local_3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8725, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_toString)(teavm_local_4));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_String_trim(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = (TEAVM_WITH_CALL_SITE_ID(8726, meth_jl_String_length(teavm_this_)) - INT32_C(1));
    while (1) {
        if (!(teavm_local_1 <= teavm_local_2)) break;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8727, teavm_nullCheck(teavm_local_3));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8728, teavm_checkBounds(teavm_local_1, teavm_local_3));
        if ((TEAVM_ARRAY_AT(teavm_local_3, char16_t, teavm_local_1) > INT32_C(32))) {
            goto teavm_label_2;
        }
        teavm_local_1 = (teavm_local_1 + INT32_C(1));
    }
    goto teavm_label_1;
teavm_label_2:;
teavm_label_1:;
    while (1) {
        if (!(teavm_local_1 <= teavm_local_2)) break;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8729, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8730, teavm_checkBounds(teavm_local_2, teavm_local_3));
        if ((TEAVM_ARRAY_AT(teavm_local_3, char16_t, teavm_local_2) > INT32_C(32))) {
            goto teavm_label_5;
        }
        teavm_local_2 = (teavm_local_2 + -INT32_C(1));
    }
    goto teavm_label_4;
teavm_label_5:;
teavm_label_4:;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8731, meth_jl_String_substring_0(teavm_this_, teavm_local_1, (teavm_local_2 + INT32_C(1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_String_toString(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8732, teavm_checkcast(teavm_this_, &jl_String_Cls, &supertypeof_jl_String));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jl_String_toCharArray(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8733, teavm_nullCheck(teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8734, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_1 = teavm_local_3;
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(teavm_local_1))) {
            goto teavm_label_1;
        }
        teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8735, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8736, teavm_checkBounds(teavm_local_4, teavm_local_5));
        TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_4) = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_String_valueOf(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8737, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_2 = ((teavm_local_1 == NULL) ? TEAVM_GET_STRING(498) : TEAVM_WITH_CALL_SITE_ID(8738, TEAVM_METHOD(teavm_local_1, jl_Object_VT, virt_toString)(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_String_valueOf_2(int32_t teavm_local_1) {
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(8739, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8740, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8741, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(1)));
    TEAVM_ARRAY_AT(teavm_local_3, char16_t, INT32_C(0)) = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(8742, meth_jl_String__init__1(teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_String_valueOf_0(int32_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8743, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8744, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8745, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8746, TEAVM_METHOD(teavm_local_2, jl_StringBuilder_VT, virt_append_24)(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8747, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(8748, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_String_valueOf_1(int64_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8749, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8750, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(8751, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8752, TEAVM_METHOD(teavm_local_2, jl_StringBuilder_VT, virt_append_26)(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8753, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(8754, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &jl_String_Cls, &supertypeof_jl_String))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8755, teavm_checkcast(teavm_local_1, &jl_String_Cls, &supertypeof_jl_String));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8756, teavm_nullCheck(teavm_local_3));
        if ((TEAVM_WITH_CALL_SITE_ID(8757, meth_jl_String_length(teavm_local_3)) != TEAVM_WITH_CALL_SITE_ID(8758, meth_jl_String_length(teavm_this_)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_4 = INT32_C(0);
            while (1) {
                if (!(teavm_local_4 < TEAVM_WITH_CALL_SITE_ID(8759, meth_jl_String_length(teavm_local_3)))) break;
                teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8760, teavm_nullCheck(teavm_local_5));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8761, teavm_checkBounds(teavm_local_4, teavm_local_5));
                teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
                teavm_local_5 = TEAVM_FIELD(teavm_local_3, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8762, teavm_nullCheck(teavm_local_5));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8763, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
                if ((teavm_local_2 != TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4))) {
                    goto teavm_label_2;
                }
                teavm_local_4 = (teavm_local_4 + INT32_C(1));
            }
            teavm_local_2 = INT32_C(1);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(0);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_String_equalsIgnoreCase(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((teavm_local_1 == NULL)) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if ((TEAVM_WITH_CALL_SITE_ID(8764, meth_jl_String_length(teavm_this_)) != TEAVM_WITH_CALL_SITE_ID(8765, meth_jl_String_length(teavm_local_1)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_3 = INT32_C(0);
            while (1) {
                if (!(teavm_local_3 < TEAVM_WITH_CALL_SITE_ID(8766, meth_jl_String_length(teavm_this_)))) break;
                teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8767, teavm_nullCheck(teavm_local_4));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8768, teavm_checkBounds(teavm_local_3, teavm_local_4));
                teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_3);
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8769, meth_jl_Character_toLowerCase(teavm_local_2));
                teavm_local_4 = TEAVM_FIELD(teavm_local_1, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8770, teavm_nullCheck(teavm_local_4));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8771, teavm_checkUpperBound(teavm_local_3, teavm_local_4));
                teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_3);
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(8772, meth_jl_Character_toLowerCase(teavm_local_5)))) {
                    goto teavm_label_2;
                }
                teavm_local_3 = (teavm_local_3 + INT32_C(1));
            }
            teavm_local_2 = INT32_C(1);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(0);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
TeaVM_Array* meth_jl_String_getBytes(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8773, meth_jn_CharBuffer_wrap_0(teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8774, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8775, meth_jnc_Charset_encode(teavm_local_1, teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8776, teavm_nullCheck(teavm_local_4));
    if ((TEAVM_WITH_CALL_SITE_ID(8777, meth_jn_ByteBuffer_hasArray(teavm_local_4)) && ((!TEAVM_WITH_CALL_SITE_ID(8778, meth_jn_Buffer_position(teavm_local_4))) && (TEAVM_WITH_CALL_SITE_ID(8779, meth_jn_Buffer_limit(teavm_local_4)) == TEAVM_WITH_CALL_SITE_ID(8780, meth_jn_Buffer_capacity(teavm_local_4)))))) {
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8781, meth_jn_ByteBuffer_array(teavm_local_4));
    } else {
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8782, meth_otr_Allocator_allocateArray(&Arr_B_Cls, TEAVM_WITH_CALL_SITE_ID(8783, meth_jn_Buffer_remaining(teavm_local_4))));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_WITH_CALL_SITE_ID(8784, TEAVM_METHOD(teavm_local_4, jn_ByteBuffer_VT, virt_get_9)(teavm_local_4, teavm_local_5));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t meth_jl_String_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!TEAVM_FIELD(teavm_this_, TeaVM_String, hashCode))) {
        teavm_local_1 = INT32_C(0);
        while (1) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            if ((teavm_local_1 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8785, teavm_nullCheck(teavm_local_2))))) {
                goto teavm_label_1;
            }
            teavm_local_3 = (INT32_C(31) * TEAVM_FIELD(teavm_this_, TeaVM_String, hashCode));
            teavm_local_2 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8786, teavm_nullCheck(teavm_local_2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8787, teavm_checkBounds(teavm_local_1, teavm_local_2));
            TEAVM_FIELD(teavm_this_, TeaVM_String, hashCode) = (teavm_local_3 + TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_1));
            teavm_local_1 = (teavm_local_1 + INT32_C(1));
        }
    }
teavm_label_1:;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, TeaVM_String, hashCode);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_String_toLowerCase(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((!TEAVM_WITH_CALL_SITE_ID(8788, meth_jl_String_isEmpty(teavm_this_)))) {
        teavm_local_1 = INT32_C(0);
        teavm_local_2 = INT32_C(0);
        teavm_local_3 = INT32_C(0);
        while (1) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8789, teavm_nullCheck(teavm_local_4))))) {
                goto teavm_label_3;
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8790, teavm_nullCheck(teavm_local_4));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8791, teavm_checkBounds(teavm_local_3, teavm_local_4));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if ((TEAVM_WITH_CALL_SITE_ID(8792, meth_jl_Character_toLowerCase(teavm_local_5)) != teavm_local_5)) {
                goto teavm_label_2;
            }
            if (TEAVM_WITH_CALL_SITE_ID(8793, meth_jl_Character_isSurrogate(teavm_local_5))) {
                teavm_local_2 = INT32_C(1);
            }
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_1 = INT32_C(1);
    teavm_label_1:;
        if (teavm_local_1) {
            if ((!teavm_local_2)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(8794, meth_jl_String_toLowerCaseChars(teavm_this_));
            } else {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(8795, meth_jl_String_toLowerCaseCodePoints(teavm_this_));
            }
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_String_toLowerCaseChars(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8796, teavm_nullCheck(teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8797, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8798, teavm_nullCheck(teavm_local_1))))) {
            goto teavm_label_1;
        }
        teavm_local_1 = teavm_local_3;
        teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8799, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8800, teavm_checkBounds(teavm_local_4, teavm_local_5));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8801, meth_jl_Character_toLowerCase(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8802, teavm_checkUpperBound(teavm_local_4, teavm_local_1));
        TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_4) = teavm_local_2;
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8803, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(8804, meth_jl_String__init__1(teavm_local_6, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void* meth_jl_String_toLowerCaseCodePoints(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8805, teavm_nullCheck(teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8806, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_2));
    teavm_local_4 = INT32_C(0);
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8807, teavm_nullCheck(teavm_local_1)));
    teavm_local_6 = INT32_C(0);
    while (1) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        if ((teavm_local_6 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8808, teavm_nullCheck(teavm_local_1))))) {
            goto teavm_label_1;
        }
        if ((teavm_local_6 != (teavm_local_5 - INT32_C(1)))) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8809, teavm_nullCheck(teavm_local_1));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8810, teavm_checkBounds(teavm_local_6, teavm_local_1));
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if (TEAVM_WITH_CALL_SITE_ID(8811, meth_jl_Character_isHighSurrogate(teavm_local_7))) {
                teavm_local_7 = (teavm_local_6 + INT32_C(1));
                teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8812, teavm_nullCheck(teavm_local_1));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8813, teavm_checkBounds(teavm_local_7, teavm_local_1));
                teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_7);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                if (TEAVM_WITH_CALL_SITE_ID(8814, meth_jl_Character_isLowSurrogate(teavm_local_8))) {
                    goto teavm_label_3;
                }
            }
        }
        teavm_local_9 = teavm_local_3;
        teavm_local_8 = (teavm_local_4 + INT32_C(1));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8815, teavm_nullCheck(teavm_local_1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8816, teavm_checkBounds(teavm_local_6, teavm_local_1));
        teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8817, meth_jl_Character_toLowerCase(teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_9, int32_t, TEAVM_WITH_CALL_SITE_ID(8818, teavm_checkBounds(teavm_local_4, teavm_local_9))) = teavm_local_2;
        goto teavm_label_2;
    teavm_label_3:;
        teavm_local_1 = teavm_local_3;
        teavm_local_8 = (teavm_local_4 + INT32_C(1));
        teavm_local_9 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8819, teavm_nullCheck(teavm_local_9));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8820, teavm_checkUpperBound(teavm_local_6, teavm_local_9));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_9, char16_t, teavm_local_6);
        teavm_local_9 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8821, teavm_nullCheck(teavm_local_9));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8822, teavm_checkUpperBound(teavm_local_7, teavm_local_9));
        teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_9, char16_t, teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8823, meth_jl_Character_toLowerCase_0(TEAVM_WITH_CALL_SITE_ID(8824, meth_jl_Character_toCodePoint(teavm_local_2, teavm_local_7))));
        TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(8825, teavm_checkBounds(teavm_local_4, teavm_local_1))) = teavm_local_2;
    teavm_label_2:;
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
        teavm_local_4 = teavm_local_8;
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8826, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(8827, meth_jl_String__init__3(teavm_local_10, teavm_local_3, INT32_C(0), teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_10;
}
void* meth_jl_String_toLowerCase_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8828, meth_jl_String_toLowerCase(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_String_toUpperCase(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((!TEAVM_WITH_CALL_SITE_ID(8829, meth_jl_String_isEmpty(teavm_this_)))) {
        teavm_local_1 = INT32_C(0);
        teavm_local_2 = INT32_C(0);
        teavm_local_3 = INT32_C(0);
        while (1) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8830, teavm_nullCheck(teavm_local_4))))) {
                goto teavm_label_3;
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8831, teavm_nullCheck(teavm_local_4));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8832, teavm_checkBounds(teavm_local_3, teavm_local_4));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if ((TEAVM_WITH_CALL_SITE_ID(8833, meth_jl_Character_toUpperCase(teavm_local_5)) != teavm_local_5)) {
                goto teavm_label_2;
            }
            if (TEAVM_WITH_CALL_SITE_ID(8834, meth_jl_Character_isSurrogate(teavm_local_5))) {
                teavm_local_2 = INT32_C(1);
            }
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_1 = INT32_C(1);
    teavm_label_1:;
        if (teavm_local_1) {
            if ((!teavm_local_2)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(8835, meth_jl_String_toUpperCaseChars(teavm_this_));
            } else {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_this_ = TEAVM_WITH_CALL_SITE_ID(8836, meth_jl_String_toUpperCaseCodePoints(teavm_this_));
            }
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_String_toUpperCaseChars(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8837, teavm_nullCheck(teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8838, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8839, teavm_nullCheck(teavm_local_1))))) {
            goto teavm_label_1;
        }
        teavm_local_1 = teavm_local_3;
        teavm_local_5 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8840, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8841, teavm_checkBounds(teavm_local_4, teavm_local_5));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8842, meth_jl_Character_toUpperCase(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8843, teavm_checkUpperBound(teavm_local_4, teavm_local_1));
        TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_4) = teavm_local_2;
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8844, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(8845, meth_jl_String__init__1(teavm_local_6, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
void* meth_jl_String_toUpperCaseCodePoints(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8846, teavm_nullCheck(teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8847, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_2));
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = INT32_C(0);
    while (1) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        if ((teavm_local_5 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8848, teavm_nullCheck(teavm_local_1))))) {
            goto teavm_label_1;
        }
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        if ((teavm_local_5 != (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(8849, teavm_nullCheck(teavm_local_1))) - INT32_C(1)))) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8850, teavm_nullCheck(teavm_local_1));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8851, teavm_checkBounds(teavm_local_5, teavm_local_1));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if (TEAVM_WITH_CALL_SITE_ID(8852, meth_jl_Character_isHighSurrogate(teavm_local_6))) {
                teavm_local_6 = (teavm_local_5 + INT32_C(1));
                teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8853, teavm_nullCheck(teavm_local_1));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(8854, teavm_checkBounds(teavm_local_6, teavm_local_1));
                teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                if (TEAVM_WITH_CALL_SITE_ID(8855, meth_jl_Character_isLowSurrogate(teavm_local_7))) {
                    goto teavm_label_3;
                }
            }
        }
        teavm_local_8 = teavm_local_3;
        teavm_local_9 = (teavm_local_4 + INT32_C(1));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8856, teavm_nullCheck(teavm_local_1));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8857, teavm_checkBounds(teavm_local_5, teavm_local_1));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8858, meth_jl_Character_toUpperCase(teavm_local_6));
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, TEAVM_WITH_CALL_SITE_ID(8859, teavm_checkBounds(teavm_local_4, teavm_local_8))) = teavm_local_2;
        goto teavm_label_2;
    teavm_label_3:;
        teavm_local_1 = teavm_local_3;
        teavm_local_9 = (teavm_local_4 + INT32_C(1));
        teavm_local_8 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8860, teavm_nullCheck(teavm_local_8));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8861, teavm_checkUpperBound(teavm_local_5, teavm_local_8));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, teavm_local_5);
        teavm_local_8 = TEAVM_FIELD(teavm_this_, TeaVM_String, characters);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8862, teavm_nullCheck(teavm_local_8));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8863, teavm_checkUpperBound(teavm_local_6, teavm_local_8));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8864, meth_jl_Character_toUpperCase_0(TEAVM_WITH_CALL_SITE_ID(8865, meth_jl_Character_toCodePoint(teavm_local_2, teavm_local_6))));
        TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(8866, teavm_checkBounds(teavm_local_4, teavm_local_1))) = teavm_local_2;
    teavm_label_2:;
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
        teavm_local_4 = teavm_local_9;
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8867, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(8868, meth_jl_String__init__3(teavm_local_10, teavm_local_3, INT32_C(0), teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_10;
}
void* meth_jl_String_toUpperCase_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8869, meth_jl_String_toUpperCase(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
TeaVM_Array* meth_jl_String_split(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8870, meth_jur_Pattern_compile(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8871, meth_jl_String_toString(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8872, meth_jur_Pattern_split(TEAVM_WITH_CALL_SITE_ID(8873, teavm_nullCheck(teavm_local_2)), teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_String_format(void* teavm_local_1, TeaVM_Array* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8874, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8875, meth_otr_Allocator_allocate(&ju_Formatter_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(8876, meth_ju_Formatter__init_(teavm_local_3));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8877, meth_ju_Formatter_format(teavm_local_3, teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(8878, meth_ju_Formatter_toString(TEAVM_WITH_CALL_SITE_ID(8879, teavm_nullCheck(teavm_local_3))));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_String_join(void* teavm_local_1, TeaVM_Array* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_local_12;
    int32_t teavm_local_13;
    TeaVM_Array* teavm_local_14;
    int32_t teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(8880, teavm_initializeClass((TeaVM_Class*) &jl_String_Cls, &initclass_jl_String));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8881, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = teavm_local_2;
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    if ((!teavm_local_4)) {
        teavm_local_5 = sfld_jl_String_EMPTY;
    } else {
        teavm_local_6 = INT32_C(0);
        teavm_local_7 = INT32_C(0);
        while (1) {
            if (!(teavm_local_7 < teavm_local_4)) break;
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8882, teavm_checkLowerBound(teavm_local_7));
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_8);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8883, teavm_nullCheck(teavm_local_9));
            teavm_local_6 = (teavm_local_6 + TEAVM_WITH_CALL_SITE_ID(8884, TEAVM_METHOD(teavm_local_9, jl_CharSequence_VT, virt_length)(teavm_local_9)));
            teavm_local_7 = (teavm_local_8 + INT32_C(1));
        }
        teavm_local_7 = (teavm_local_4 - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8885, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_8 = (teavm_local_6 + (teavm_local_7 * TEAVM_WITH_CALL_SITE_ID(8886, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1))));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8887, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_8));
        teavm_local_11 = INT32_C(0);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
        teavm_local_12 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(8888, teavm_checkUpperBound(INT32_C(0), teavm_local_3)));
        teavm_local_13 = INT32_C(0);
        while (1) {
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_12);
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(8889, teavm_nullCheck(teavm_local_12));
            if ((teavm_local_13 >= TEAVM_WITH_CALL_SITE_ID(8890, TEAVM_METHOD(teavm_local_12, jl_CharSequence_VT, virt_length)(teavm_local_12)))) {
                goto teavm_label_2;
            }
            teavm_local_14 = teavm_local_10;
            teavm_local_8 = (teavm_local_11 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_14, char16_t, TEAVM_WITH_CALL_SITE_ID(8891, teavm_checkBounds(teavm_local_11, teavm_local_14))) = TEAVM_WITH_CALL_SITE_ID(8892, TEAVM_METHOD(teavm_local_12, jl_CharSequence_VT, virt_charAt)(teavm_local_12, teavm_local_13));
            teavm_local_13 = (teavm_local_13 + INT32_C(1));
            teavm_local_11 = teavm_local_8;
        }
    teavm_label_2:;
        teavm_local_13 = INT32_C(1);
        while (1) {
            if (!(teavm_local_13 < teavm_local_4)) break;
            teavm_local_15 = INT32_C(0);
            while (1) {
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                if ((teavm_local_15 >= TEAVM_WITH_CALL_SITE_ID(8893, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1)))) {
                    goto teavm_label_4;
                }
                teavm_local_8 = (teavm_local_11 + INT32_C(1));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8894, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_15));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8895, teavm_nullCheck(teavm_local_10));
                teavm_local_14 = teavm_local_10;
                TEAVM_ARRAY_AT(teavm_local_14, char16_t, TEAVM_WITH_CALL_SITE_ID(8896, teavm_checkBounds(teavm_local_11, teavm_local_14))) = teavm_local_7;
                teavm_local_15 = (teavm_local_15 + INT32_C(1));
                teavm_local_11 = teavm_local_8;
            }
        teavm_label_4:;
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(8897, teavm_checkLowerBound(teavm_local_13));
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_13);
            teavm_local_15 = INT32_C(0);
            while (1) {
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_10);
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_9);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(8898, teavm_nullCheck(teavm_local_9));
                if ((teavm_local_15 >= TEAVM_WITH_CALL_SITE_ID(8899, TEAVM_METHOD(teavm_local_9, jl_CharSequence_VT, virt_length)(teavm_local_9)))) {
                    goto teavm_label_5;
                }
                teavm_local_8 = (teavm_local_11 + INT32_C(1));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8900, TEAVM_METHOD(teavm_local_9, jl_CharSequence_VT, virt_charAt)(teavm_local_9, teavm_local_15));
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(8901, teavm_nullCheck(teavm_local_10));
                teavm_local_14 = teavm_local_10;
                TEAVM_ARRAY_AT(teavm_local_14, char16_t, TEAVM_WITH_CALL_SITE_ID(8902, teavm_checkBounds(teavm_local_11, teavm_local_14))) = teavm_local_7;
                teavm_local_15 = (teavm_local_15 + INT32_C(1));
                teavm_local_11 = teavm_local_8;
            }
        teavm_label_5:;
            teavm_local_13 = (teavm_local_13 + INT32_C(1));
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(8903, meth_jl_String_fromArray(teavm_local_10));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
int32_t meth_jl_String_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8904, teavm_checkcast(teavm_local_1, &jl_String_Cls, &supertypeof_jl_String));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8905, meth_jl_String_compareTo(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_String__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jl_String_EMPTY_CHARS = TEAVM_WITH_CALL_SITE_ID(8906, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(0)));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8907, meth_otr_Allocator_allocate(&jl_String_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(8908, meth_jl_String__init__0(teavm_local_1));
    sfld_jl_String_EMPTY = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8909, meth_otr_Allocator_allocate(&jl_String__clinit__lambda__118_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(8910, meth_jl_String__clinit__lambda__118_0__init_(teavm_local_1));
    sfld_jl_String_CASE_INSENSITIVE_ORDER = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jl_String() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_String_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_String__clinit_();
    }
}
int32_t supertypeof_jl_String(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 333 || tag >= 335) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_String_Cls[2];
alignas(8) jl_String_VT jl_String_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(TeaVM_String), sizeof(void*)),
        .flags = 0,
        .tag = 333,
        .modifiers = 17,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(669),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_String,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_String_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_String_hashCode,
    .virt_equals = &meth_jl_String_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_String_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_compareTo = &meth_jl_String_compareTo_0,
    .virt_isEmpty = &meth_jl_String_isEmpty,
    .virt_subSequence = &meth_jl_String_subSequence,
    .virt_length = &meth_jl_String_length,
    .virt_charAt = &meth_jl_String_charAt
};
static void** teavm_gc_localStaticRoots_jl_String_Cls[3] = {
(void**) &sfld_jl_String_EMPTY_CHARS, (void**) &sfld_jl_String_EMPTY, (void**) &sfld_jl_String_CASE_INSENSITIVE_ORDER
};
static int16_t teavm_classLayouts_jl_String_Cls[2] = {
INT16_C(1), (int16_t) offsetof(TeaVM_String, characters)
};
void sysinitclass_jl_String() {
sfld_jl_String_EMPTY_CHARS = NULL;
sfld_jl_String_EMPTY = NULL;
sfld_jl_String_CASE_INSENSITIVE_ORDER = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_String_Cls, 3);
}
