#include "AbstractStringBuilder@dConstants.h"
#include "Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrays/primitives/long.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer@dResult.h"
#include "../../org/teavm/classlib/impl/text/FloatAnalyzer@dResult.h"
#include "../../../strings.h"

TeaVM_Array* sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen;
void* sfld_jl_AbstractStringBuilder_Constants_doubleAnalysisResult;
void* sfld_jl_AbstractStringBuilder_Constants_floatAnalysisResult;
void meth_jl_AbstractStringBuilder_Constants__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen = TEAVM_WITH_CALL_SITE_ID(20693, teavm_fillLongArray(meth_otr_Allocator_allocateArray(&Arr_J_Cls, 6), INT64_C(1), INT64_C(10), INT64_C(100), INT64_C(10000), INT64_C(100000000), INT64_C(10000000000000000)));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20694, meth_otr_Allocator_allocate(&otcit_DoubleAnalyzer_Result_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20695, meth_otcit_DoubleAnalyzer_Result__init_(teavm_local_1));
    sfld_jl_AbstractStringBuilder_Constants_doubleAnalysisResult = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20696, meth_otr_Allocator_allocate(&otcit_FloatAnalyzer_Result_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20697, meth_otcit_FloatAnalyzer_Result__init_(teavm_local_1));
    sfld_jl_AbstractStringBuilder_Constants_floatAnalysisResult = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jl_AbstractStringBuilder_Constants() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_AbstractStringBuilder_Constants_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_AbstractStringBuilder_Constants__clinit_();
    }
}
int32_t supertypeof_jl_AbstractStringBuilder_Constants(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1233 || tag >= 1235) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_AbstractStringBuilder_Constants_VT jl_AbstractStringBuilder_Constants_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_AbstractStringBuilder_Constants), sizeof(void*)),
            .flags = 0,
            .tag = 1233,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_AbstractStringBuilder_Constants,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jl_AbstractStringBuilder_Constants_Cls[3] = {
(void**) &sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen, (void**) &sfld_jl_AbstractStringBuilder_Constants_doubleAnalysisResult, (void**) &sfld_jl_AbstractStringBuilder_Constants_floatAnalysisResult
};
void sysinitclass_jl_AbstractStringBuilder_Constants() {
sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen = NULL;
sfld_jl_AbstractStringBuilder_Constants_doubleAnalysisResult = NULL;
sfld_jl_AbstractStringBuilder_Constants_floatAnalysisResult = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_AbstractStringBuilder_Constants_Cls, 3);
}
