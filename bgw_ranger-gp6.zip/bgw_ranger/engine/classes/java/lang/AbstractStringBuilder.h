#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "AbstractStringBuilder.h"

extern void sysinitclass_jl_AbstractStringBuilder();
typedef struct cls_jl_AbstractStringBuilder {
    struct TeaVM_Object parent;
    TeaVM_Array* fld_buffer;
    int32_t fld_length;
} cls_jl_AbstractStringBuilder;
extern void meth_jl_AbstractStringBuilder__init__0(void*);
extern void meth_jl_AbstractStringBuilder__init_(void*, int32_t);
extern void meth_jl_AbstractStringBuilder__init__1(void*, void*);
extern void meth_jl_AbstractStringBuilder__init__2(void*, void*);
extern void* meth_jl_AbstractStringBuilder_append(void*, void*);
extern void* meth_jl_AbstractStringBuilder_append_0(void*, void*);
extern void* meth_jl_AbstractStringBuilder_insert_3(void*, int32_t, void*);
extern void* meth_jl_AbstractStringBuilder_append_1(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_append_7(void*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_insert_4(void*, int32_t, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_append_8(void*, int64_t);
extern void* meth_jl_AbstractStringBuilder_insert_6(void*, int32_t, int64_t);
extern void* meth_jl_AbstractStringBuilder_insert_5(void*, int32_t, int64_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_append_9(void*, float);
extern void* meth_jl_AbstractStringBuilder_insert_7(void*, int32_t, float);
extern void* meth_jl_AbstractStringBuilder_append_10(void*, double);
extern void* meth_jl_AbstractStringBuilder_insert_8(void*, int32_t, double);
extern int32_t meth_jl_AbstractStringBuilder_trailingDecimalZeros(int32_t);
extern int32_t meth_jl_AbstractStringBuilder_trailingDecimalZeros_0(int64_t);
extern void* meth_jl_AbstractStringBuilder_append_2(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_insert_2(void*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_insert_1(void*, int32_t, void*);
extern void* meth_jl_AbstractStringBuilder_append_11(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_insert_9(void*, int32_t, int32_t);
extern void meth_jl_AbstractStringBuilder_ensureCapacity(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_toString(void*);
extern int32_t meth_jl_AbstractStringBuilder_length(void*);
extern int32_t meth_jl_AbstractStringBuilder_charAt(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_append_5(void*, void*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_insert(void*, int32_t, void*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_append_6(void*, void*);
extern void* meth_jl_AbstractStringBuilder_insert_10(void*, int32_t, void*);
extern void* meth_jl_AbstractStringBuilder_append_3(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_insert_0(void*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_append_4(void*, TeaVM_Array*);
extern void* meth_jl_AbstractStringBuilder_subSequence(void*, int32_t, int32_t);
extern void meth_jl_AbstractStringBuilder_getChars(void*, int32_t, int32_t, TeaVM_Array*, int32_t);
extern void meth_jl_AbstractStringBuilder_setLength(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_deleteCharAt(void*, int32_t);
extern void* meth_jl_AbstractStringBuilder_delete(void*, int32_t, int32_t);
extern void meth_jl_AbstractStringBuilder_insertSpace(void*, int32_t, int32_t);
extern void* meth_jl_AbstractStringBuilder_substring(void*, int32_t, int32_t);
extern int32_t supertypeof_jl_AbstractStringBuilder(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_AbstractStringBuilder_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_insert_4)(void*, int32_t, void*); // 11
    void* (*virt_append)(void*, int32_t, int32_t); // 12
    void* (*virt_insert_5)(void*, int32_t, int32_t, int32_t); // 13
    void* (*virt_insert_6)(void*, int32_t, int32_t); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void* (*virt_subSequence)(void*, int32_t, int32_t); // 17
    void (*pad1)(); // 18
    void* (*virt_insert_7)(void*, int32_t, int32_t); // 19
    void* (*virt_insert_8)(void*, int32_t, void*); // 20
    void* (*virt_insert_9)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 21
    void* (*virt_append_7)(void*, TeaVM_Array*, int32_t, int32_t); // 22
    void* (*virt_append_8)(void*, void*, int32_t, int32_t); // 23
    void* (*virt_insert_10)(void*, int32_t, float); // 24
    int32_t (*virt_length)(void*); // 25
    int32_t (*virt_charAt)(void*, int32_t); // 26
    void (*virt_ensureCapacity)(void*, int32_t); // 27
    void* (*virt_insert_11)(void*, int32_t, int64_t, int32_t); // 28
    void* (*virt_append_9)(void*, int32_t); // 29
    void* (*virt_append_10)(void*, int64_t); // 30
    void* (*virt_substring)(void*, int32_t, int32_t); // 31
    void* (*virt_append_11)(void*, float); // 32
    void* (*virt_append_12)(void*, double); // 33
    void (*pad2)(); // 34
    void (*pad3)(); // 35
    void* (*virt_append_13)(void*, int32_t); // 36
    void* (*virt_insert_12)(void*, int32_t, double); // 37
    void* (*virt_append_14)(void*, void*); // 38
    void* (*virt_insert_13)(void*, int32_t, void*); // 39
    void (*pad4)(); // 40
    void (*pad5)(); // 41
    void* (*virt_append_16)(void*, int32_t); // 42
    void* (*virt_append_17)(void*, void*); // 43
    void* (*virt_append_18)(void*, TeaVM_Array*); // 44
    void (*virt_getChars)(void*, int32_t, int32_t, TeaVM_Array*, int32_t); // 45
    void (*pad6)(); // 46
    void* (*virt_insert_14)(void*, int32_t, int64_t); // 47
    void* (*virt_insert_15)(void*, int32_t, void*, int32_t, int32_t); // 48
    void* (*virt_append_20)(void*, void*); // 49
    void (*virt_setLength)(void*, int32_t); // 50
    void* (*virt_deleteCharAt)(void*, int32_t); // 51
    void* (*virt_delete)(void*, int32_t, int32_t); // 52
} jl_AbstractStringBuilder_VT;
extern jl_AbstractStringBuilder_VT jl_AbstractStringBuilder_Cls;
