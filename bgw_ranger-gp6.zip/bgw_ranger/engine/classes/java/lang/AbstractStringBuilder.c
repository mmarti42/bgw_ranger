#include "AbstractStringBuilder.h"
#include "Object.h"
#include "../../../arrays/primitives/char.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "CharSequence.h"
#include "../../../strings.h"
#include "String.h"
#include "StringIndexOutOfBoundsException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Character.h"
#include "Float.h"
#include "AbstractStringBuilder@dConstants.h"
#include "../../org/teavm/classlib/impl/text/FloatAnalyzer.h"
#include "../../org/teavm/classlib/impl/text/FloatAnalyzer@dResult.h"
#include "Math.h"
#include "Double.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer.h"
#include "../../org/teavm/classlib/impl/text/DoubleAnalyzer@dResult.h"
#include "../util/Arrays.h"
#include "IndexOutOfBoundsException.h"

void meth_jl_AbstractStringBuilder__init__0(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(4945, meth_jl_AbstractStringBuilder__init_(teavm_this_, INT32_C(16)));
    TEAVM_RELEASE_STACK;
}
void meth_jl_AbstractStringBuilder__init_(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(4946, meth_jl_Object__init_(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4947, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jl_AbstractStringBuilder__init__1(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(4948, meth_jl_AbstractStringBuilder__init__2(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_AbstractStringBuilder__init__2(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(4949, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(4950, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4951, meth_otr_Allocator_allocateArray(&Arr_C_Cls, TEAVM_WITH_CALL_SITE_ID(4952, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1))));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer) = teavm_local_2;
    teavm_local_3 = INT32_C(0);
    while (1) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(4953, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_1;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(4954, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4955, teavm_nullCheck(teavm_local_2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4956, teavm_checkBounds(teavm_local_3, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_3) = teavm_local_4;
        teavm_local_3 = (teavm_local_3 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) = TEAVM_WITH_CALL_SITE_ID(4957, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_AbstractStringBuilder_append(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4958, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_8)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_append_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4959, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_4)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_3(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length)))) {
        if ((teavm_local_2 == NULL)) {
            teavm_local_2 = TEAVM_GET_STRING(498);
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if (TEAVM_WITH_CALL_SITE_ID(4960, meth_jl_String_isEmpty(teavm_local_2))) {
                goto teavm_label_1;
            }
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(4961, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_ensureCapacity)(teavm_this_, (teavm_local_3 + TEAVM_WITH_CALL_SITE_ID(4962, meth_jl_String_length(teavm_local_2)))));
        teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) - INT32_C(1));
        while (1) {
            if (!(teavm_local_4 >= teavm_local_1)) break;
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_6 = (teavm_local_4 + TEAVM_WITH_CALL_SITE_ID(4963, meth_jl_String_length(teavm_local_2)));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(4964, teavm_nullCheck(teavm_local_7));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(4965, teavm_checkBounds(teavm_local_4, teavm_local_7));
            teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_7, char16_t, teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4966, teavm_nullCheck(teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(4967, teavm_checkBounds(teavm_local_6, teavm_local_5))) = teavm_local_3;
            teavm_local_4 = (teavm_local_4 + -INT32_C(1));
        }
        TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) + TEAVM_WITH_CALL_SITE_ID(4968, meth_jl_String_length(teavm_local_2)));
        teavm_local_4 = INT32_C(0);
        while (1) {
            if (!(teavm_local_4 < TEAVM_WITH_CALL_SITE_ID(4969, meth_jl_String_length(teavm_local_2)))) break;
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_6 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4970, meth_jl_String_charAt(teavm_local_2, teavm_local_4));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4971, teavm_nullCheck(teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(4972, teavm_checkBounds(teavm_local_1, teavm_local_5))) = teavm_local_3;
            teavm_local_4 = (teavm_local_4 + INT32_C(1));
            teavm_local_1 = teavm_local_6;
        }
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_this_;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(4973, meth_otr_Allocator_allocate(&jl_StringIndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(4974, meth_jl_StringIndexOutOfBoundsException__init_(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(4975, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
void* meth_jl_AbstractStringBuilder_append_1(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4976, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_append)(teavm_this_, teavm_local_1, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_append_7(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4977, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_5)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_AbstractStringBuilder_insert_4(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_4 = INT32_C(1);
    if ((teavm_local_2 < INT32_C(0))) {
        teavm_local_4 = INT32_C(0);
        teavm_local_2 = (-teavm_local_2);
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((TEAVM_WITH_CALL_SITE_ID(4978, teavm_compare_u32(teavm_local_2, teavm_local_3)) < INT32_C(0))) {
        if (teavm_local_4) {
            TEAVM_WITH_CALL_SITE_ID(4979, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(1))));
        } else {
            TEAVM_WITH_CALL_SITE_ID(4980, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(2))));
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_6 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4981, teavm_nullCheck(teavm_local_5));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(4982, teavm_checkBounds(teavm_local_1, teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_1) = INT32_C(45);
            teavm_local_1 = teavm_local_6;
        }
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(4983, meth_jl_Character_forDigit(teavm_local_2, teavm_local_3));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4984, teavm_nullCheck(teavm_local_5));
        TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(4985, teavm_checkBounds(teavm_local_1, teavm_local_5))) = teavm_local_6;
    } else {
        teavm_local_7 = INT32_C(1);
        teavm_local_8 = INT32_C(1);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(4986, ((int32_t) ((uint32_t) -INT32_C(1) / (uint32_t) teavm_local_3)));
        while (1) {
            teavm_local_10 = (teavm_local_7 * teavm_local_3);
            if ((TEAVM_WITH_CALL_SITE_ID(4987, teavm_compare_u32(teavm_local_10, teavm_local_2)) > INT32_C(0))) {
                goto teavm_label_3;
            }
            teavm_local_8 = (teavm_local_8 + INT32_C(1));
            if ((TEAVM_WITH_CALL_SITE_ID(4988, teavm_compare_u32(teavm_local_10, teavm_local_9)) > INT32_C(0))) {
                goto teavm_label_4;
            }
            teavm_local_7 = teavm_local_10;
        }
    teavm_label_4:;
        goto teavm_label_2;
    teavm_label_3:;
        teavm_local_10 = teavm_local_7;
    teavm_label_2:;
        if ((!teavm_local_4)) {
            teavm_local_8 = (teavm_local_8 + INT32_C(1));
        }
        TEAVM_WITH_CALL_SITE_ID(4989, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + teavm_local_8)));
        if (teavm_local_4) {
            teavm_local_11 = teavm_local_1;
        } else {
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_11 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4990, teavm_nullCheck(teavm_local_5));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(4991, teavm_checkBounds(teavm_local_1, teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, char16_t, teavm_local_1) = INT32_C(45);
        }
        while (1) {
            if ((!teavm_local_10)) {
                goto teavm_label_1;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_12 = (teavm_local_11 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(4992, meth_jl_Character_forDigit(TEAVM_WITH_CALL_SITE_ID(4993, ((int32_t) ((uint32_t) teavm_local_2 / (uint32_t) teavm_local_10))), teavm_local_3));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4994, teavm_nullCheck(teavm_local_5));
            TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(4995, teavm_checkBounds(teavm_local_11, teavm_local_5))) = teavm_local_13;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4996, ((int32_t) ((uint32_t) teavm_local_2 % (uint32_t) teavm_local_10)));
            teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(4997, ((int32_t) ((uint32_t) teavm_local_10 / (uint32_t) teavm_local_3)));
            teavm_local_11 = teavm_local_12;
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_AbstractStringBuilder_append_8(void* teavm_this_, int64_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4998, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_14)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_6(void* teavm_this_, int32_t teavm_local_1, int64_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4999, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_11)(teavm_this_, teavm_local_1, teavm_local_2, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_AbstractStringBuilder_insert_5(void* teavm_this_, int32_t teavm_local_1, int64_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    int64_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int64_t teavm_local_9;
    int64_t teavm_local_10;
    int64_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_4 = INT32_C(1);
    if ((teavm_local_2 < INT64_C(0))) {
        teavm_local_4 = INT32_C(0);
        teavm_local_2 = (-teavm_local_2);
    }
    teavm_local_5 = ((int64_t) teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((TEAVM_WITH_CALL_SITE_ID(5000, teavm_compare_u64(teavm_local_2, teavm_local_5)) < INT32_C(0))) {
        if (teavm_local_4) {
            TEAVM_WITH_CALL_SITE_ID(5001, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(1))));
        } else {
            TEAVM_WITH_CALL_SITE_ID(5002, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(2))));
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_7 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5003, teavm_nullCheck(teavm_local_6));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5004, teavm_checkBounds(teavm_local_1, teavm_local_6));
            TEAVM_ARRAY_AT(teavm_local_6, char16_t, teavm_local_1) = INT32_C(45);
            teavm_local_1 = teavm_local_7;
        }
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_7 = ((int32_t) teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5005, meth_jl_Character_forDigit(teavm_local_7, teavm_local_3));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5006, teavm_nullCheck(teavm_local_6));
        TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(5007, teavm_checkBounds(teavm_local_1, teavm_local_6))) = teavm_local_7;
    } else {
        teavm_local_8 = INT32_C(1);
        teavm_local_9 = INT64_C(1);
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(5008, ((int64_t) ((uint64_t) -INT64_C(1) / (uint64_t) teavm_local_5)));
        while (1) {
            teavm_local_11 = (teavm_local_9 * teavm_local_5);
            if ((TEAVM_WITH_CALL_SITE_ID(5009, teavm_compare_u64(teavm_local_11, teavm_local_2)) > INT32_C(0))) {
                goto teavm_label_3;
            }
            teavm_local_8 = (teavm_local_8 + INT32_C(1));
            if ((TEAVM_WITH_CALL_SITE_ID(5010, teavm_compare_u64(teavm_local_11, teavm_local_10)) > INT32_C(0))) {
                goto teavm_label_4;
            }
            teavm_local_9 = teavm_local_11;
        }
    teavm_label_4:;
        goto teavm_label_2;
    teavm_label_3:;
        teavm_local_11 = teavm_local_9;
    teavm_label_2:;
        if ((!teavm_local_4)) {
            teavm_local_8 = (teavm_local_8 + INT32_C(1));
        }
        TEAVM_WITH_CALL_SITE_ID(5011, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + teavm_local_8)));
        if (teavm_local_4) {
            teavm_local_12 = teavm_local_1;
        } else {
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_12 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5012, teavm_nullCheck(teavm_local_6));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5013, teavm_checkBounds(teavm_local_1, teavm_local_6));
            TEAVM_ARRAY_AT(teavm_local_6, char16_t, teavm_local_1) = INT32_C(45);
        }
        while (1) {
            if ((teavm_local_11 == INT64_C(0))) {
                goto teavm_label_1;
            }
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_13 = (teavm_local_12 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(5014, meth_jl_Character_forDigit(((int32_t) TEAVM_WITH_CALL_SITE_ID(5015, ((int64_t) ((uint64_t) teavm_local_2 / (uint64_t) teavm_local_11)))), teavm_local_3));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5016, teavm_nullCheck(teavm_local_6));
            TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(5017, teavm_checkBounds(teavm_local_12, teavm_local_6))) = teavm_local_14;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5018, ((int64_t) ((uint64_t) teavm_local_2 % (uint64_t) teavm_local_11)));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(5019, ((int64_t) ((uint64_t) teavm_local_11 / (uint64_t) teavm_local_5)));
            teavm_local_12 = teavm_local_13;
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_AbstractStringBuilder_append_9(void* teavm_this_, float teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5020, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_10)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_7(void* teavm_this_, int32_t teavm_local_1, float teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = teavm_compare_float_less(teavm_local_2, 0.0f);
    if ((!teavm_local_3)) {
        if (((1.0f / teavm_local_2) == INFINITY)) {
            teavm_local_3 = (teavm_local_1 + INT32_C(3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(5021, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5022, teavm_nullCheck(teavm_local_4));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5023, teavm_checkBounds(teavm_local_1, teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(48);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5024, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5025, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(46);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5026, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5027, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(48);
        } else {
            teavm_local_3 = (teavm_local_1 + INT32_C(4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(5028, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5029, teavm_nullCheck(teavm_local_4));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5030, teavm_checkBounds(teavm_local_1, teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(45);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5031, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5032, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(48);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5033, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5034, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(46);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5035, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5036, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(48);
        }
    } else if (isnan(teavm_local_2)) {
        teavm_local_3 = (teavm_local_1 + INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(5037, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_3 = (teavm_local_1 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5038, teavm_nullCheck(teavm_local_4));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5039, teavm_checkBounds(teavm_local_1, teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(78);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_5 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5040, teavm_nullCheck(teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5041, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(97);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5042, teavm_nullCheck(teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5043, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(78);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if (TEAVM_WITH_CALL_SITE_ID(5044, meth_jl_Float_isInfinite(teavm_local_2))) {
            if ((teavm_local_3 > INT32_C(0))) {
                TEAVM_WITH_CALL_SITE_ID(5045, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(8))));
                teavm_local_3 = teavm_local_1;
            } else {
                TEAVM_WITH_CALL_SITE_ID(5046, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(9))));
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_3 = (teavm_local_1 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5047, teavm_nullCheck(teavm_local_4));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5048, teavm_checkBounds(teavm_local_1, teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(45);
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5049, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5050, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(73);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5051, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5052, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(110);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5053, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5054, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(102);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5055, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5056, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(105);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5057, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5058, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(110);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5059, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5060, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(105);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5061, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5062, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(116);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5063, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5064, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(121);
        } else {
            TEAVM_WITH_CALL_SITE_ID(5065, teavm_initializeClass((TeaVM_Class*) &jl_AbstractStringBuilder_Constants_Cls, &initclass_jl_AbstractStringBuilder_Constants));
            teavm_local_6 = sfld_jl_AbstractStringBuilder_Constants_floatAnalysisResult;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(5066, meth_otcit_FloatAnalyzer_analyze(teavm_local_2, teavm_local_6));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5067, teavm_nullCheck(teavm_local_6));
            teavm_local_7 = TEAVM_FIELD(teavm_local_6, cls_otcit_FloatAnalyzer_Result, fld_mantissa);
            teavm_local_8 = TEAVM_FIELD(teavm_local_6, cls_otcit_FloatAnalyzer_Result, fld_exponent);
            teavm_local_9 = TEAVM_FIELD(teavm_local_6, cls_otcit_FloatAnalyzer_Result, fld_sign);
            teavm_local_10 = INT32_C(1);
            teavm_local_11 = INT32_C(1);
            if (teavm_local_9) {
                teavm_local_11 = INT32_C(2);
            }
            teavm_local_12 = INT32_C(9);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(5068, meth_jl_AbstractStringBuilder_trailingDecimalZeros(teavm_local_7));
            if ((teavm_local_13 > INT32_C(0))) {
                teavm_local_12 = (teavm_local_12 - teavm_local_13);
            }
            teavm_local_14 = INT32_C(0);
            teavm_local_15 = INT32_C(0);
            if (((teavm_local_8 < INT32_C(7)) && (teavm_local_8 >= -INT32_C(3)))) {
                if ((teavm_local_8 >= INT32_C(0))) {
                    teavm_local_10 = (teavm_local_8 + INT32_C(1));
                    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(5069, meth_jl_Math_max(teavm_local_12, (teavm_local_10 + INT32_C(1))));
                    teavm_local_8 = INT32_C(0);
                } else {
                    teavm_local_10 = INT32_C(0);
                    teavm_local_14 = ((-teavm_local_8) - INT32_C(1));
                    teavm_local_15 = INT32_C(1);
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                    teavm_local_8 = INT32_C(0);
                }
            }
            if (teavm_local_8) {
                teavm_local_11 = (teavm_local_11 + INT32_C(2));
                if ((!((teavm_local_8 > -INT32_C(10)) && (teavm_local_8 < INT32_C(10))))) {
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                }
                if ((teavm_local_8 < INT32_C(0))) {
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                }
            }
            if ((teavm_local_8 && (teavm_local_12 == teavm_local_10))) {
                teavm_local_12 = (teavm_local_12 + INT32_C(1));
            }
            teavm_local_3 = (teavm_local_11 + (teavm_local_12 + teavm_local_14));
            TEAVM_WITH_CALL_SITE_ID(5070, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + teavm_local_3)));
            if ((!teavm_local_9)) {
                teavm_local_3 = teavm_local_1;
            } else {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_3 = (teavm_local_1 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5071, teavm_nullCheck(teavm_local_4));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5072, teavm_checkBounds(teavm_local_1, teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(45);
            }
            teavm_local_16 = INT32_C(100000000);
            if (teavm_local_15) {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_5 = (teavm_local_3 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5073, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5074, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(48);
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_3 = (teavm_local_5 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5075, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5076, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(46);
                while (1) {
                    teavm_local_5 = (teavm_local_14 + -INT32_C(1));
                    if ((teavm_local_14 <= INT32_C(0))) {
                        goto teavm_label_1;
                    }
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_17 = (teavm_local_3 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5077, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5078, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(48);
                    teavm_local_14 = teavm_local_5;
                    teavm_local_3 = teavm_local_17;
                }
            teavm_label_1:;
            }
            teavm_local_18 = INT32_C(0);
            while (1) {
                if (!(teavm_local_18 < teavm_local_12)) break;
                if ((teavm_local_16 <= INT32_C(0))) {
                    teavm_local_19 = INT32_C(0);
                } else {
                    teavm_local_19 = (teavm_local_7 / teavm_local_16);
                    teavm_local_7 = (teavm_local_7 % teavm_local_16);
                }
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_5 = (teavm_local_3 + INT32_C(1));
                teavm_local_17 = TEAVM_TO_CHAR((INT32_C(48) + teavm_local_19));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5079, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5080, teavm_checkBounds(teavm_local_3, teavm_local_4))) = teavm_local_17;
                teavm_local_10 = (teavm_local_10 + -INT32_C(1));
                if (teavm_local_10) {
                    teavm_local_3 = teavm_local_5;
                } else {
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_3 = (teavm_local_5 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5081, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5082, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(46);
                }
                teavm_local_16 = (teavm_local_16 / INT32_C(10));
                teavm_local_18 = (teavm_local_18 + INT32_C(1));
            }
            if (teavm_local_8) {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_5 = (teavm_local_3 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5083, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5084, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(69);
                if ((teavm_local_8 >= INT32_C(0))) {
                    teavm_local_3 = teavm_local_5;
                } else {
                    teavm_local_8 = (-teavm_local_8);
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_3 = (teavm_local_5 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5085, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5086, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(45);
                }
                if ((teavm_local_8 < INT32_C(10))) {
                    teavm_local_5 = teavm_local_3;
                } else {
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_5 = (teavm_local_3 + INT32_C(1));
                    teavm_local_17 = TEAVM_TO_CHAR((INT32_C(48) + (teavm_local_8 / INT32_C(10))));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5087, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5088, teavm_checkBounds(teavm_local_3, teavm_local_4))) = teavm_local_17;
                }
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_3 = TEAVM_TO_CHAR((INT32_C(48) + (teavm_local_8 % INT32_C(10))));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5089, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5090, teavm_checkBounds(teavm_local_5, teavm_local_4))) = teavm_local_3;
            }
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_AbstractStringBuilder_append_10(void* teavm_this_, double teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5091, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_12)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_8(void* teavm_this_, int32_t teavm_local_1, double teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int64_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int64_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    int32_t teavm_local_20;
    int32_t teavm_local_21;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = teavm_compare_double_less(teavm_local_2, 0.0);
    if ((!teavm_local_3)) {
        if (((1.0 / teavm_local_2) == INFINITY)) {
            teavm_local_3 = (teavm_local_1 + INT32_C(3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(5092, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5093, teavm_nullCheck(teavm_local_4));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5094, teavm_checkBounds(teavm_local_1, teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(48);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5095, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5096, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(46);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5097, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5098, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(48);
        } else {
            teavm_local_3 = (teavm_local_1 + INT32_C(4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(5099, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5100, teavm_nullCheck(teavm_local_4));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5101, teavm_checkBounds(teavm_local_1, teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(45);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5102, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5103, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(48);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5104, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5105, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(46);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5106, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5107, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(48);
        }
    } else if (isnan(teavm_local_2)) {
        teavm_local_3 = (teavm_local_1 + INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(5108, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_3 = (teavm_local_1 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5109, teavm_nullCheck(teavm_local_4));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5110, teavm_checkBounds(teavm_local_1, teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(78);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_5 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5111, teavm_nullCheck(teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5112, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(97);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5113, teavm_nullCheck(teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5114, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(78);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if (TEAVM_WITH_CALL_SITE_ID(5115, meth_jl_Double_isInfinite(teavm_local_2))) {
            if ((teavm_local_3 > INT32_C(0))) {
                TEAVM_WITH_CALL_SITE_ID(5116, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(8))));
                teavm_local_3 = teavm_local_1;
            } else {
                TEAVM_WITH_CALL_SITE_ID(5117, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + INT32_C(9))));
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_3 = (teavm_local_1 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5118, teavm_nullCheck(teavm_local_4));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5119, teavm_checkBounds(teavm_local_1, teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(45);
            }
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5120, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5121, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(73);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5122, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5123, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(110);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5124, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5125, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(102);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5126, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5127, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(105);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5128, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5129, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(110);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = (teavm_local_5 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5130, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5131, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(105);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5132, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5133, teavm_checkBounds(teavm_local_3, teavm_local_4))) = INT32_C(116);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5134, teavm_nullCheck(teavm_local_4));
            TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5135, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(121);
        } else {
            TEAVM_WITH_CALL_SITE_ID(5136, teavm_initializeClass((TeaVM_Class*) &jl_AbstractStringBuilder_Constants_Cls, &initclass_jl_AbstractStringBuilder_Constants));
            teavm_local_6 = sfld_jl_AbstractStringBuilder_Constants_doubleAnalysisResult;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(5137, meth_otcit_DoubleAnalyzer_analyze(teavm_local_2, teavm_local_6));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5138, teavm_nullCheck(teavm_local_6));
            teavm_local_7 = TEAVM_FIELD(teavm_local_6, cls_otcit_DoubleAnalyzer_Result, fld_mantissa);
            teavm_local_8 = TEAVM_FIELD(teavm_local_6, cls_otcit_DoubleAnalyzer_Result, fld_exponent);
            teavm_local_9 = TEAVM_FIELD(teavm_local_6, cls_otcit_DoubleAnalyzer_Result, fld_sign);
            teavm_local_10 = INT32_C(1);
            teavm_local_11 = INT32_C(1);
            if (teavm_local_9) {
                teavm_local_11 = INT32_C(2);
            }
            teavm_local_12 = INT32_C(18);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(5139, meth_jl_AbstractStringBuilder_trailingDecimalZeros_0(teavm_local_7));
            if ((teavm_local_13 > INT32_C(0))) {
                teavm_local_12 = (teavm_local_12 - teavm_local_13);
            }
            teavm_local_14 = INT32_C(0);
            teavm_local_15 = INT32_C(0);
            if (((teavm_local_8 < INT32_C(7)) && (teavm_local_8 >= -INT32_C(3)))) {
                if ((teavm_local_8 >= INT32_C(0))) {
                    teavm_local_10 = (teavm_local_8 + INT32_C(1));
                    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(5140, meth_jl_Math_max(teavm_local_12, (teavm_local_10 + INT32_C(1))));
                    teavm_local_8 = INT32_C(0);
                } else {
                    teavm_local_10 = INT32_C(0);
                    teavm_local_14 = ((-teavm_local_8) - INT32_C(1));
                    teavm_local_15 = INT32_C(1);
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                    teavm_local_8 = INT32_C(0);
                }
            }
            if (teavm_local_8) {
                teavm_local_11 = (teavm_local_11 + INT32_C(2));
                if ((!((teavm_local_8 > -INT32_C(10)) && (teavm_local_8 < INT32_C(10))))) {
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                }
                if ((!((teavm_local_8 > -INT32_C(100)) && (teavm_local_8 < INT32_C(100))))) {
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                }
                if ((teavm_local_8 < INT32_C(0))) {
                    teavm_local_11 = (teavm_local_11 + INT32_C(1));
                }
            }
            if ((teavm_local_8 && (teavm_local_12 == teavm_local_10))) {
                teavm_local_12 = (teavm_local_12 + INT32_C(1));
            }
            teavm_local_3 = (teavm_local_11 + (teavm_local_12 + teavm_local_14));
            TEAVM_WITH_CALL_SITE_ID(5141, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, (teavm_local_1 + teavm_local_3)));
            if ((!teavm_local_9)) {
                teavm_local_16 = teavm_local_1;
            } else {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_16 = (teavm_local_1 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5142, teavm_nullCheck(teavm_local_4));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5143, teavm_checkBounds(teavm_local_1, teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = INT32_C(45);
            }
            teavm_local_17 = INT64_C(100000000000000000);
            if (teavm_local_15) {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_5 = (teavm_local_16 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5144, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5145, teavm_checkBounds(teavm_local_16, teavm_local_4))) = INT32_C(48);
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_16 = (teavm_local_5 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5146, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5147, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(46);
                while (1) {
                    teavm_local_5 = (teavm_local_14 + -INT32_C(1));
                    if ((teavm_local_14 <= INT32_C(0))) {
                        goto teavm_label_1;
                    }
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_18 = (teavm_local_16 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5148, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5149, teavm_checkBounds(teavm_local_16, teavm_local_4))) = INT32_C(48);
                    teavm_local_14 = teavm_local_5;
                    teavm_local_16 = teavm_local_18;
                }
            teavm_label_1:;
            }
            teavm_local_19 = INT32_C(0);
            while (1) {
                if (!(teavm_local_19 < teavm_local_12)) break;
                if ((teavm_local_17 <= INT64_C(0))) {
                    teavm_local_20 = INT32_C(0);
                } else {
                    teavm_local_20 = ((int32_t) (teavm_local_7 / teavm_local_17));
                    teavm_local_7 = (teavm_local_7 % teavm_local_17);
                }
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_5 = (teavm_local_16 + INT32_C(1));
                teavm_local_18 = TEAVM_TO_CHAR((INT32_C(48) + teavm_local_20));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5150, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5151, teavm_checkBounds(teavm_local_16, teavm_local_4))) = teavm_local_18;
                teavm_local_10 = (teavm_local_10 + -INT32_C(1));
                if (teavm_local_10) {
                    teavm_local_16 = teavm_local_5;
                } else {
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_16 = (teavm_local_5 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5152, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5153, teavm_checkBounds(teavm_local_5, teavm_local_4))) = INT32_C(46);
                }
                teavm_local_17 = (teavm_local_17 / INT64_C(10));
                teavm_local_19 = (teavm_local_19 + INT32_C(1));
            }
            if (teavm_local_8) {
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_21 = (teavm_local_16 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5154, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5155, teavm_checkBounds(teavm_local_16, teavm_local_4))) = INT32_C(69);
                if ((teavm_local_8 >= INT32_C(0))) {
                    teavm_local_18 = teavm_local_21;
                } else {
                    teavm_local_8 = (-teavm_local_8);
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_18 = (teavm_local_21 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5156, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5157, teavm_checkBounds(teavm_local_21, teavm_local_4))) = INT32_C(45);
                }
                if ((teavm_local_8 >= INT32_C(100))) {
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_16 = (teavm_local_18 + INT32_C(1));
                    teavm_local_5 = TEAVM_TO_CHAR((INT32_C(48) + (teavm_local_8 / INT32_C(100))));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5158, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5159, teavm_checkBounds(teavm_local_18, teavm_local_4))) = teavm_local_5;
                    teavm_local_8 = (teavm_local_8 % INT32_C(100));
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_5 = (teavm_local_16 + INT32_C(1));
                    teavm_local_18 = TEAVM_TO_CHAR((INT32_C(48) + (teavm_local_8 / INT32_C(10))));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5160, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5161, teavm_checkBounds(teavm_local_16, teavm_local_4))) = teavm_local_18;
                } else if ((teavm_local_8 < INT32_C(10))) {
                    teavm_local_5 = teavm_local_18;
                } else {
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_5 = (teavm_local_18 + INT32_C(1));
                    teavm_local_16 = TEAVM_TO_CHAR((INT32_C(48) + (teavm_local_8 / INT32_C(10))));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5162, teavm_nullCheck(teavm_local_4));
                    TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5163, teavm_checkBounds(teavm_local_18, teavm_local_4))) = teavm_local_16;
                }
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_3 = TEAVM_TO_CHAR((INT32_C(48) + (teavm_local_8 % INT32_C(10))));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5164, teavm_nullCheck(teavm_local_4));
                TEAVM_ARRAY_AT(teavm_local_4, char16_t, TEAVM_WITH_CALL_SITE_ID(5165, teavm_checkBounds(teavm_local_5, teavm_local_4))) = teavm_local_3;
            }
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
int32_t meth_jl_AbstractStringBuilder_trailingDecimalZeros(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    if ((teavm_local_1 % INT32_C(1000000000))) {
        teavm_local_2 = INT32_C(0);
        teavm_local_3 = INT32_C(1);
        if ((!(teavm_local_1 % INT32_C(100000000)))) {
            teavm_local_2 = INT32_C(8);
            teavm_local_3 = INT32_C(100000000);
        }
        teavm_local_4 = (teavm_local_3 * INT32_C(10000));
        if ((teavm_local_1 % teavm_local_4)) {
            teavm_local_4 = teavm_local_3;
        } else {
            teavm_local_2 = (teavm_local_2 | INT32_C(4));
        }
        teavm_local_5 = (teavm_local_4 * INT32_C(100));
        if ((teavm_local_1 % teavm_local_5)) {
            teavm_local_5 = teavm_local_4;
        } else {
            teavm_local_2 = (teavm_local_2 | INT32_C(2));
        }
        if ((!(teavm_local_1 % (teavm_local_5 * INT32_C(10))))) {
            teavm_local_2 = (teavm_local_2 | INT32_C(1));
        }
        return teavm_local_2;
    }
    return INT32_C(9);
}
int32_t meth_jl_AbstractStringBuilder_trailingDecimalZeros_0(int64_t teavm_local_1) {
    int64_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = INT64_C(1);
    teavm_local_3 = INT32_C(0);
    teavm_local_4 = INT32_C(16);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5166, teavm_initializeClass((TeaVM_Class*) &jl_AbstractStringBuilder_Constants_Cls, &initclass_jl_AbstractStringBuilder_Constants));
    teavm_local_5 = sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_6 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5167, teavm_nullCheck(teavm_local_5))) - INT32_C(1));
    while (1) {
        if (!(teavm_local_6 >= INT32_C(0))) break;
        teavm_local_5 = sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5168, teavm_nullCheck(teavm_local_5));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5169, teavm_checkBounds(teavm_local_6, teavm_local_5));
        if (((teavm_local_1 % (teavm_local_2 * TEAVM_ARRAY_AT(teavm_local_5, int64_t, teavm_local_6))) == INT64_C(0))) {
            teavm_local_3 = (teavm_local_3 | teavm_local_4);
            teavm_local_5 = sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5170, teavm_nullCheck(teavm_local_5));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5171, teavm_checkUpperBound(teavm_local_6, teavm_local_5));
            teavm_local_2 = (teavm_local_2 * TEAVM_ARRAY_AT(teavm_local_5, int64_t, teavm_local_6));
        }
        teavm_local_4 = ((int32_t) ((uint32_t) teavm_local_4 >> INT32_C(1)));
        teavm_local_6 = (teavm_local_6 + -INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_AbstractStringBuilder_append_2(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5172, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_7)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_2(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = (teavm_local_1 + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5173, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_3));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5174, teavm_nullCheck(teavm_local_4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5175, teavm_checkBounds(teavm_local_1, teavm_local_4));
    TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_1) = teavm_local_2;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_AbstractStringBuilder_insert_1(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 == NULL)) {
        teavm_local_3 = TEAVM_GET_STRING(498);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5176, TEAVM_METHOD(teavm_local_2, jl_Object_VT, virt_toString)(teavm_local_2));
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5177, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_4)(teavm_this_, teavm_local_1, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_AbstractStringBuilder_append_11(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5178, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_6)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_9(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = ((!teavm_local_2) ? TEAVM_GET_STRING(30) : TEAVM_GET_STRING(29));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5179, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_4)(teavm_this_, teavm_local_1, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jl_AbstractStringBuilder_ensureCapacity(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5180, teavm_nullCheck(teavm_local_2))) < teavm_local_1)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5181, teavm_nullCheck(teavm_local_2))) >= INT32_C(1073741823))) {
            teavm_local_3 = INT32_C(2147483647);
        } else {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_4 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5182, teavm_nullCheck(teavm_local_2))) * INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5183, meth_jl_Math_max(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(5184, meth_jl_Math_max(teavm_local_4, INT32_C(5)))));
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5185, meth_ju_Arrays_copyOf_1(teavm_local_2, teavm_local_3));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer) = teavm_local_2;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jl_AbstractStringBuilder_toString(void* teavm_this_) {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5186, meth_otr_Allocator_allocate(&jl_String_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5187, meth_jl_String__init_(teavm_local_1, teavm_local_2, INT32_C(0), teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_AbstractStringBuilder_length(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length);
}
int32_t meth_jl_AbstractStringBuilder_charAt(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length)))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5188, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5189, teavm_checkBounds(teavm_local_1, teavm_local_2));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_1);
        TEAVM_RELEASE_STACK;
        return teavm_local_3;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5190, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(5191, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(5192, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
void* meth_jl_AbstractStringBuilder_append_5(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5193, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_15)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_AbstractStringBuilder_insert(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_3 <= teavm_local_4)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5194, teavm_nullCheck(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if (((teavm_local_4 <= TEAVM_WITH_CALL_SITE_ID(5195, TEAVM_METHOD(teavm_local_2, jl_CharSequence_VT, virt_length)(teavm_local_2))) && (teavm_local_3 >= INT32_C(0)))) {
            TEAVM_WITH_CALL_SITE_ID(5196, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, ((teavm_local_1 + teavm_local_4) - teavm_local_3)));
            while (1) {
                if (!(teavm_local_3 < teavm_local_4)) break;
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                teavm_local_6 = (teavm_local_1 + INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5197, TEAVM_METHOD(teavm_local_2, jl_CharSequence_VT, virt_charAt)(teavm_local_2, teavm_local_3));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5198, teavm_nullCheck(teavm_local_5));
                TEAVM_ARRAY_AT(teavm_local_5, char16_t, TEAVM_WITH_CALL_SITE_ID(5199, teavm_checkBounds(teavm_local_1, teavm_local_5))) = teavm_local_7;
                teavm_local_3 = (teavm_local_3 + INT32_C(1));
                teavm_local_1 = teavm_local_6;
            }
            TEAVM_RELEASE_STACK;
            return teavm_this_;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5200, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(5201, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(5202, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
void* meth_jl_AbstractStringBuilder_append_6(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5203, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5204, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_append_8)(teavm_this_, teavm_local_1, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(5205, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_length)(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_AbstractStringBuilder_insert_10(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5206, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5207, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_15)(teavm_this_, teavm_local_1, teavm_local_2, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(5208, TEAVM_METHOD(teavm_local_2, jl_CharSequence_VT, virt_length)(teavm_local_2))));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_AbstractStringBuilder_append_3(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5209, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_insert_9)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length), teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_AbstractStringBuilder_insert_0(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_5 = (teavm_local_1 + teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(5210, meth_jl_AbstractStringBuilder_insertSpace(teavm_this_, teavm_local_1, teavm_local_5));
    teavm_local_6 = (teavm_local_4 + teavm_local_3);
    while (1) {
        if (!(teavm_local_3 < teavm_local_6)) break;
        teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_8 = (teavm_local_1 + INT32_C(1));
        teavm_local_5 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5211, teavm_nullCheck(teavm_local_2));
        teavm_local_9 = teavm_local_2;
        teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_9, char16_t, TEAVM_WITH_CALL_SITE_ID(5212, teavm_checkBounds(teavm_local_3, teavm_local_9)));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(5213, teavm_nullCheck(teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_9, char16_t, TEAVM_WITH_CALL_SITE_ID(5214, teavm_checkBounds(teavm_local_1, teavm_local_9))) = teavm_local_10;
        teavm_local_1 = teavm_local_8;
        teavm_local_3 = teavm_local_5;
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_AbstractStringBuilder_append_4(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5215, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5216, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_append_7)(teavm_this_, teavm_local_1, INT32_C(0), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_AbstractStringBuilder_subSequence(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5217, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_substring)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jl_AbstractStringBuilder_getChars(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_1 <= teavm_local_2)) {
        while (1) {
            if (!(teavm_local_1 < teavm_local_2)) break;
            teavm_local_5 = (teavm_local_4 + INT32_C(1));
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_7 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5218, teavm_nullCheck(teavm_local_6));
            teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(5219, teavm_checkBounds(teavm_local_1, teavm_local_6)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5220, teavm_nullCheck(teavm_local_3));
            teavm_local_6 = teavm_local_3;
            TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(5221, teavm_checkBounds(teavm_local_4, teavm_local_6))) = teavm_local_8;
            teavm_local_4 = teavm_local_5;
            teavm_local_1 = teavm_local_7;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(5222, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(5223, meth_jl_IndexOutOfBoundsException__init_(teavm_local_9, TEAVM_GET_STRING(499)));
    TEAVM_WITH_CALL_SITE_ID(5224, meth_otr_ExceptionHandling_throwException(teavm_local_9));
    TEAVM_UNREACHABLE
}
void meth_jl_AbstractStringBuilder_setLength(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) = teavm_local_1;
}
void* meth_jl_AbstractStringBuilder_deleteCharAt(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length)))) {
        TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) - INT32_C(1));
        while (1) {
            if (!(teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length))) break;
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
            teavm_local_4 = (teavm_local_1 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5225, teavm_nullCheck(teavm_local_3));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5226, teavm_checkBounds(teavm_local_4, teavm_local_3));
            teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, char16_t, teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5227, teavm_nullCheck(teavm_local_2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5228, teavm_checkBounds(teavm_local_1, teavm_local_2));
            TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_1) = teavm_local_4;
            teavm_local_1 = teavm_local_5;
        }
        TEAVM_RELEASE_STACK;
        return teavm_this_;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5229, meth_otr_Allocator_allocate(&jl_StringIndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(5230, meth_jl_StringIndexOutOfBoundsException__init_(teavm_local_6));
    TEAVM_WITH_CALL_SITE_ID(5231, meth_otr_ExceptionHandling_throwException(teavm_local_6));
    TEAVM_UNREACHABLE
}
void* meth_jl_AbstractStringBuilder_delete(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_3 = teavm_compare_i32(teavm_local_1, teavm_local_2);
        if (((teavm_local_3 <= INT32_C(0)) && (teavm_local_1 <= TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length)))) {
            if (teavm_local_3) {
                if ((teavm_local_2 > TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length))) {
                    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length);
                }
                teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) - teavm_local_2);
                TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) - (teavm_local_2 - teavm_local_1));
                teavm_local_5 = INT32_C(0);
                while (1) {
                    if (!(teavm_local_5 < teavm_local_4)) break;
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_7 = (teavm_local_1 + INT32_C(1));
                    teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
                    teavm_local_3 = (teavm_local_2 + INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5232, teavm_nullCheck(teavm_local_8));
                    teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(5233, teavm_checkBounds(teavm_local_2, teavm_local_8)));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5234, teavm_nullCheck(teavm_local_6));
                    TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(5235, teavm_checkBounds(teavm_local_1, teavm_local_8))) = teavm_local_9;
                    teavm_local_5 = (teavm_local_5 + INT32_C(1));
                    teavm_local_1 = teavm_local_7;
                    teavm_local_2 = teavm_local_3;
                }
            }
            TEAVM_RELEASE_STACK;
            return teavm_this_;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(5236, meth_otr_Allocator_allocate(&jl_StringIndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(5237, meth_jl_StringIndexOutOfBoundsException__init_(teavm_local_10));
    TEAVM_WITH_CALL_SITE_ID(5238, meth_otr_ExceptionHandling_throwException(teavm_local_10));
    TEAVM_UNREACHABLE
}
void meth_jl_AbstractStringBuilder_insertSpace(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) - teavm_local_1);
    teavm_local_4 = ((TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) + teavm_local_2) - teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(5239, TEAVM_METHOD(teavm_this_, jl_AbstractStringBuilder_VT, virt_ensureCapacity)(teavm_this_, teavm_local_4));
    teavm_local_5 = (teavm_local_3 - INT32_C(1));
    while (1) {
        if (!(teavm_local_5 >= INT32_C(0))) break;
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_7 = (teavm_local_2 + teavm_local_5);
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_4 = (teavm_local_1 + teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5240, teavm_nullCheck(teavm_local_8));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(5241, teavm_checkBounds(teavm_local_4, teavm_local_8)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5242, teavm_nullCheck(teavm_local_6));
        TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(5243, teavm_checkBounds(teavm_local_7, teavm_local_8))) = teavm_local_4;
        teavm_local_5 = (teavm_local_5 + -INT32_C(1));
    }
    TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) = (TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length) + (teavm_local_2 - teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_AbstractStringBuilder_substring(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (((teavm_local_1 <= teavm_local_2) && ((teavm_local_1 >= INT32_C(0)) && (teavm_local_2 <= TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_length))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5244, meth_otr_Allocator_allocate(&jl_String_Cls));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_AbstractStringBuilder, fld_buffer);
        teavm_local_5 = (teavm_local_2 - teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(5245, meth_jl_String__init_(teavm_local_3, teavm_local_4, teavm_local_1, teavm_local_5));
        TEAVM_RELEASE_STACK;
        return teavm_local_3;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5246, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(5247, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(5248, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_jl_AbstractStringBuilder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 233 || tag >= 239) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_AbstractStringBuilder_Cls[2];
alignas(8) jl_AbstractStringBuilder_VT jl_AbstractStringBuilder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_AbstractStringBuilder), sizeof(void*)),
        .flags = 0,
        .tag = 233,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_AbstractStringBuilder,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_AbstractStringBuilder_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_AbstractStringBuilder_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_insert_4 = &meth_jl_AbstractStringBuilder_insert_3,
    .virt_append = &meth_jl_AbstractStringBuilder_append_7,
    .virt_insert_5 = &meth_jl_AbstractStringBuilder_insert_4,
    .virt_insert_6 = &meth_jl_AbstractStringBuilder_insert_9,
    .virt_subSequence = &meth_jl_AbstractStringBuilder_subSequence,
    .virt_insert_7 = &meth_jl_AbstractStringBuilder_insert_2,
    .virt_insert_8 = &meth_jl_AbstractStringBuilder_insert_1,
    .virt_insert_9 = &meth_jl_AbstractStringBuilder_insert_0,
    .virt_append_7 = &meth_jl_AbstractStringBuilder_append_3,
    .virt_append_8 = &meth_jl_AbstractStringBuilder_append_5,
    .virt_insert_10 = &meth_jl_AbstractStringBuilder_insert_7,
    .virt_length = &meth_jl_AbstractStringBuilder_length,
    .virt_charAt = &meth_jl_AbstractStringBuilder_charAt,
    .virt_ensureCapacity = &meth_jl_AbstractStringBuilder_ensureCapacity,
    .virt_insert_11 = &meth_jl_AbstractStringBuilder_insert_5,
    .virt_append_9 = &meth_jl_AbstractStringBuilder_append_1,
    .virt_append_10 = &meth_jl_AbstractStringBuilder_append_8,
    .virt_substring = &meth_jl_AbstractStringBuilder_substring,
    .virt_append_11 = &meth_jl_AbstractStringBuilder_append_9,
    .virt_append_12 = &meth_jl_AbstractStringBuilder_append_10,
    .virt_append_13 = &meth_jl_AbstractStringBuilder_append_2,
    .virt_insert_12 = &meth_jl_AbstractStringBuilder_insert_8,
    .virt_append_14 = &meth_jl_AbstractStringBuilder_append,
    .virt_insert_13 = &meth_jl_AbstractStringBuilder_insert_10,
    .virt_append_16 = &meth_jl_AbstractStringBuilder_append_11,
    .virt_append_17 = &meth_jl_AbstractStringBuilder_append_6,
    .virt_append_18 = &meth_jl_AbstractStringBuilder_append_4,
    .virt_getChars = &meth_jl_AbstractStringBuilder_getChars,
    .virt_insert_14 = &meth_jl_AbstractStringBuilder_insert_6,
    .virt_insert_15 = &meth_jl_AbstractStringBuilder_insert,
    .virt_append_20 = &meth_jl_AbstractStringBuilder_append_0,
    .virt_setLength = &meth_jl_AbstractStringBuilder_setLength,
    .virt_deleteCharAt = &meth_jl_AbstractStringBuilder_deleteCharAt,
    .virt_delete = &meth_jl_AbstractStringBuilder_delete
};
static int16_t teavm_classLayouts_jl_AbstractStringBuilder_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jl_AbstractStringBuilder, fld_buffer)
};
void sysinitclass_jl_AbstractStringBuilder() {
}
