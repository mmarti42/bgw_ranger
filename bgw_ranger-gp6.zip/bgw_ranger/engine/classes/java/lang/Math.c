#include "Math.h"
#include "Object.h"
#include "ArithmeticException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"

int32_t meth_jl_Math_round(float teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = ((int32_t) (teavm_local_1 + (TEAVM_WITH_CALL_SITE_ID(30990, meth_jl_Math_signum(teavm_local_1)) * 0x1.0p-1f)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Math_toIntExact(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_1 <= INT64_C(2147483647)) && (teavm_local_1 >= -INT64_C(2147483648)))) {
        teavm_local_2 = ((int32_t) teavm_local_1);
        TEAVM_RELEASE_STACK;
        return teavm_local_2;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30991, meth_otr_Allocator_allocate(&jl_ArithmeticException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(30992, meth_jl_ArithmeticException__init__0(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(30993, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_Math_min(int32_t teavm_local_1, int32_t teavm_local_2) {
    if ((teavm_local_1 < teavm_local_2)) {
        teavm_local_2 = teavm_local_1;
    }
    return teavm_local_2;
}
int32_t meth_jl_Math_max(int32_t teavm_local_1, int32_t teavm_local_2) {
    if ((teavm_local_1 > teavm_local_2)) {
        teavm_local_2 = teavm_local_1;
    }
    return teavm_local_2;
}
int64_t meth_jl_Math_max_0(int64_t teavm_local_1, int64_t teavm_local_2) {
    if ((teavm_local_1 > teavm_local_2)) {
        teavm_local_2 = teavm_local_1;
    }
    return teavm_local_2;
}
int32_t meth_jl_Math_abs_0(int32_t teavm_local_1) {
    if ((teavm_local_1 < INT32_C(0))) {
        teavm_local_1 = (-teavm_local_1);
    }
    return teavm_local_1;
}
int64_t meth_jl_Math_abs(int64_t teavm_local_1) {
    if ((teavm_local_1 < INT64_C(0))) {
        teavm_local_1 = (-teavm_local_1);
    }
    return teavm_local_1;
}
double meth_jl_Math_abs_1(double teavm_local_1) {
    double teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30994, fabs(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
float meth_jl_Math_signum(float teavm_local_1) {
    if ((!isnan(((double) teavm_local_1)))) {
        if ((teavm_local_1 < 0.0f)) {
            teavm_local_1 = -1.0f;
        } else if ((teavm_local_1 > 0.0f)) {
            teavm_local_1 = 1.0f;
        }
        return teavm_local_1;
    }
    return teavm_local_1;
}
int32_t supertypeof_jl_Math(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1571 || tag >= 1573) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Math_VT jl_Math_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Math), sizeof(void*)),
            .flags = 0,
            .tag = 1571,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_Math,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_jl_Math() {
}
