#pragma once
#include "../../../runtime.h"
#include "Iterable.h"

extern void sysinitclass_jl_Iterable();
extern void meth_jl_Iterable_forEach(void*, void*);
extern int32_t supertypeof_jl_Iterable(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Iterable_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_forEach)(void*, void*); // 11
    void* (*virt_iterator)(void*); // 12
} jl_Iterable_VT;
extern TeaVM_Class jl_Iterable_Cls;
