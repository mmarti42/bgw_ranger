#include "AutoCloseable.h"
#include "../../../strings.h"

int32_t supertypeof_jl_AutoCloseable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 381 || tag >= 2257) return INT32_C(0);
    if (tag >= 383 && tag < 481) return INT32_C(0);
    if (tag >= 491 && tag < 569) return INT32_C(0);
    if (tag >= 571 && tag < 829) return INT32_C(0);
    if (tag >= 831 && tag < 1033) return INT32_C(0);
    if (tag >= 1035 && tag < 1496) return INT32_C(0);
    if (tag >= 1498 && tag < 1593) return INT32_C(0);
    if (tag >= 1597 && tag < 1603) return INT32_C(0);
    if (tag >= 1605 && tag < 1807) return INT32_C(0);
    if (tag >= 1829 && tag < 1909) return INT32_C(0);
    if (tag >= 1913 && tag < 1951) return INT32_C(0);
    if (tag >= 1953 && tag < 2255) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jl_AutoCloseable_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 381,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jl_AutoCloseable,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jl_AutoCloseable() {
}
