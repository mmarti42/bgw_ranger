#include "Thread@dlambda@dstart@d0@dlambda@d_39_0.h"
#include "Object.h"
#include "../../org/teavm/runtime/Fiber.h"
#include "Thread.h"
#include "../../../strings.h"

void meth_jl_Thread_lambda_start_0_lambda__39_0__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8293, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Thread_lambda_start_0_lambda__39_0, fld__0) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_lambda_start_0_lambda__39_0_run(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_1)) {
        switch (meth_otr_Fiber_popInt(teavm_local_1)) {
            case 0:
                goto teavm_label_3;
            default:
                goto teavm_label_2;
        }
    teavm_label_3:;
        teavm_local_2 = meth_otr_Fiber_popObject(teavm_local_1);
        goto teavm_label_1;
    }
teavm_label_2:;
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Thread_lambda_start_0_lambda__39_0, fld__0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(8294, teavm_nullCheck(teavm_local_2));
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(8295, meth_jl_Thread_runThread(teavm_local_2));
    if (meth_otr_Fiber_isSuspending(teavm_local_1)) {
        TEAVM_WITH_CALL_SITE_ID(8296, meth_otr_Fiber_push(teavm_local_1, teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(8297, meth_otr_Fiber_push_0(teavm_local_1, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Thread_lambda_start_0_lambda__39_0(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 325 || tag >= 327) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Thread_lambda_start_0_lambda__39_0_Cls[2];
alignas(8) jl_Thread_lambda_start_0_lambda__39_0_VT jl_Thread_lambda_start_0_lambda__39_0_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Thread_lambda_start_0_lambda__39_0), sizeof(void*)),
        .flags = 0,
        .tag = 325,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Thread_lambda_start_0_lambda__39_0,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Thread_lambda_start_0_lambda__39_0_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_run_0 = &meth_jl_Thread_lambda_start_0_lambda__39_0_run
};
static int16_t teavm_classLayouts_jl_Thread_lambda_start_0_lambda__39_0_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jl_Thread_lambda_start_0_lambda__39_0, fld__0)
};
void sysinitclass_jl_Thread_lambda_start_0_lambda__39_0() {
}
