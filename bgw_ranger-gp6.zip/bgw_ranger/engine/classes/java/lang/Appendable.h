#pragma once
#include "../../../runtime.h"
#include "Appendable.h"

extern void sysinitclass_jl_Appendable();
extern int32_t supertypeof_jl_Appendable(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Appendable_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*pad1)(); // 12
    void (*pad2)(); // 13
    void (*pad3)(); // 14
    void (*pad4)(); // 15
    void (*pad5)(); // 16
    void (*pad6)(); // 17
    void (*pad7)(); // 18
    void (*pad8)(); // 19
    void (*pad9)(); // 20
    void (*pad10)(); // 21
    void (*pad11)(); // 22
    void (*pad12)(); // 23
    void (*pad13)(); // 24
    void (*pad14)(); // 25
    void (*pad15)(); // 26
    void (*pad16)(); // 27
    void (*pad17)(); // 28
    void (*pad18)(); // 29
    void (*pad19)(); // 30
    void (*pad20)(); // 31
    void (*pad21)(); // 32
    void (*pad22)(); // 33
    void (*pad23)(); // 34
    void (*pad24)(); // 35
    void (*pad25)(); // 36
    void (*pad26)(); // 37
    void (*pad27)(); // 38
    void (*pad28)(); // 39
    void (*pad29)(); // 40
    void (*pad30)(); // 41
    void (*pad31)(); // 42
    void (*pad32)(); // 43
    void (*pad33)(); // 44
    void (*pad34)(); // 45
    void* (*virt_append_19)(void*, void*); // 46
} jl_Appendable_VT;
extern TeaVM_Class jl_Appendable_Cls;
