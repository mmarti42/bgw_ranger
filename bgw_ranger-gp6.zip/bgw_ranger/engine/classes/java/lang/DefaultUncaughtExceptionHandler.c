#include "DefaultUncaughtExceptionHandler.h"
#include "Object.h"
#include "Throwable.h"
#include "../../../strings.h"

void meth_jl_DefaultUncaughtExceptionHandler__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13697, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jl_DefaultUncaughtExceptionHandler_uncaughtException(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13698, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(13699, TEAVM_METHOD(teavm_local_2, jl_Throwable_VT, virt_printStackTrace)(teavm_local_2));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_DefaultUncaughtExceptionHandler(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 619 || tag >= 621) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_DefaultUncaughtExceptionHandler_VT jl_DefaultUncaughtExceptionHandler_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_DefaultUncaughtExceptionHandler), sizeof(void*)),
        .flags = 0,
        .tag = 619,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_DefaultUncaughtExceptionHandler,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_uncaughtException = &meth_jl_DefaultUncaughtExceptionHandler_uncaughtException
};
void sysinitclass_jl_DefaultUncaughtExceptionHandler() {
}
