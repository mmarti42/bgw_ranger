#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "AbstractStringBuilder@dConstants.h"

extern void sysinitclass_jl_AbstractStringBuilder_Constants();
typedef struct cls_jl_AbstractStringBuilder_Constants {
    struct TeaVM_Object parent;
} cls_jl_AbstractStringBuilder_Constants;
extern TeaVM_Array* sfld_jl_AbstractStringBuilder_Constants_longLogPowersOfTen;
extern void* sfld_jl_AbstractStringBuilder_Constants_doubleAnalysisResult;
extern void* sfld_jl_AbstractStringBuilder_Constants_floatAnalysisResult;
extern void meth_jl_AbstractStringBuilder_Constants__clinit_();
extern void initclass_jl_AbstractStringBuilder_Constants();
extern int32_t supertypeof_jl_AbstractStringBuilder_Constants(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_AbstractStringBuilder_Constants_VT {
    jl_Object_VT parent;
} jl_AbstractStringBuilder_Constants_VT;
extern jl_AbstractStringBuilder_Constants_VT jl_AbstractStringBuilder_Constants_Cls;
