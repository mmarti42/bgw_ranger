#include "Object.h"
#include "../../org/teavm/runtime/RuntimeObject.h"
#include "Thread.h"
#include "Object@dMonitor.h"
#include "IllegalStateException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "IllegalMonitorStateException.h"
#include "../../org/teavm/runtime/Fiber.h"
#include "Object@dmonitorEnterWait@d0.h"
#include "../../org/teavm/interop/AsyncCallback.h"
#include "../util/ArrayDeque.h"
#include "Object@dmonitorEnterWait@dlambda@d_6_0.h"
#include "../util/Queue.h"
#include "Object@dmonitorExit@dlambda@d_8_0.h"
#include "../../org/teavm/runtime/EventQueue.h"
#include "../../org/teavm/platform/PlatformRunnable.h"
#include "../../../core.h"
#include "Class.h"
#include "Integer.h"
#include "StringBuilder.h"
#include "../../org/teavm/runtime/RuntimeClass.h"
#include "../../org/teavm/runtime/RuntimeArray.h"
#include <string.h>
#include "Object@dNotifyListener.h"
#include "InterruptedException.h"
#include "Object@dwaitImpl@d1.h"
#include "Object@dNotifyListenerImpl.h"
#include "System.h"

void meth_jl_Object_monitorEnterSync(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    int32_t teavm_tmp_int_2;
    int32_t teavm_tmp_int_3;
    int32_t teavm_tmp_int_4;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    if ((TEAVM_WITH_CALL_SITE_ID(39099, meth_jl_Thread_currentThread()) != NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39100, teavm_nullCheck(teavm_local_1));
        if (((teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0)) == NULL)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(39101, meth_jl_Object_createMonitor(teavm_local_1));
        }
        teavm_local_2 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39102, teavm_nullCheck(teavm_local_2)), cls_jl_Object_Monitor, fld_owner) == NULL)) {
            teavm_local_2 = (teavm_tmp_int_2 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_2));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39103, meth_jl_Thread_currentThread());
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39104, teavm_nullCheck(teavm_local_2));
            teavm_gc_writeBarrier(teavm_local_2);
            TEAVM_FIELD(teavm_local_2, cls_jl_Object_Monitor, fld_owner) = teavm_local_3;
        } else {
            teavm_local_2 = (teavm_tmp_int_3 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_3));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39105, teavm_nullCheck(teavm_local_2)), cls_jl_Object_Monitor, fld_owner);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            if ((teavm_local_3 != TEAVM_WITH_CALL_SITE_ID(39106, meth_jl_Thread_currentThread()))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39107, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_WITH_CALL_SITE_ID(39108, meth_jl_IllegalStateException__init_(teavm_local_3, TEAVM_GET_STRING(7972)));
                TEAVM_WITH_CALL_SITE_ID(39109, meth_otr_ExceptionHandling_throwException(teavm_local_3));
                TEAVM_UNREACHABLE
            }
        }
        teavm_local_2 = (teavm_tmp_int_4 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39110, teavm_nullCheck(teavm_local_2));
        TEAVM_FIELD(teavm_local_2, cls_jl_Object_Monitor, fld_count) = (TEAVM_FIELD(teavm_local_2, cls_jl_Object_Monitor, fld_count) + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorExitSync(void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    int32_t teavm_tmp_int_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((TEAVM_WITH_CALL_SITE_ID(39111, meth_jl_Thread_currentThread()) != NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39112, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        if ((!TEAVM_WITH_CALL_SITE_ID(39113, meth_jl_Object_isEmptyMonitor(teavm_local_1)))) {
            teavm_local_2 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39114, teavm_nullCheck(teavm_local_2)), cls_jl_Object_Monitor, fld_owner);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            if ((teavm_local_2 == TEAVM_WITH_CALL_SITE_ID(39115, meth_jl_Thread_currentThread()))) {
                teavm_local_2 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39116, teavm_nullCheck(teavm_local_2));
                teavm_local_3 = (TEAVM_FIELD(teavm_local_2, cls_jl_Object_Monitor, fld_count) - INT32_C(1));
                TEAVM_FIELD(teavm_local_2, cls_jl_Object_Monitor, fld_count) = teavm_local_3;
                if ((!teavm_local_3)) {
                    teavm_local_2 = (teavm_tmp_int_2 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_2));
                    teavm_local_4 = NULL;
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                    TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39117, teavm_nullCheck(teavm_local_2)), cls_jl_Object_Monitor, fld_owner) = teavm_local_4;
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(39118, meth_jl_Object_isEmptyMonitor(teavm_local_1));
                goto teavm_label_1;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39119, meth_otr_Allocator_allocate(&jl_IllegalMonitorStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(39120, meth_jl_IllegalMonitorStateException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(39121, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorEnter(void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_2)) {
        switch (meth_otr_Fiber_popInt(teavm_local_2)) {
            case 0:
                goto teavm_label_2;
            default:
                goto teavm_label_3;
        }
    }
teavm_label_3:;
    teavm_local_3 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = meth_otr_Fiber_popInt(teavm_local_2);
    teavm_local_1 = meth_otr_Fiber_popObject(teavm_local_2);
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(39122, meth_jl_Object_monitorEnter_0(teavm_local_1, teavm_local_3));
    if (meth_otr_Fiber_isSuspending(teavm_local_2)) {
        TEAVM_WITH_CALL_SITE_ID(39123, meth_otr_Fiber_push(teavm_local_2, teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(39124, meth_otr_Fiber_push_0(teavm_local_2, teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(39125, meth_otr_Fiber_push_0(teavm_local_2, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorEnter_0(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    int32_t teavm_tmp_int_2;
    int32_t teavm_tmp_int_3;
    int32_t teavm_tmp_int_4;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_3 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_3)) {
        switch (meth_otr_Fiber_popInt(teavm_local_3)) {
            case 0:
                goto teavm_label_6;
            default:
                goto teavm_label_5;
        }
    teavm_label_6:;
        teavm_local_1 = meth_otr_Fiber_popObject(teavm_local_3);
        teavm_local_2 = meth_otr_Fiber_popInt(teavm_local_3);
        goto teavm_label_4;
    }
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39126, teavm_nullCheck(teavm_local_1));
    if (((teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0)) == NULL)) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(39127, meth_jl_Object_createMonitor(teavm_local_1));
    }
    teavm_local_4 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39128, teavm_nullCheck(teavm_local_4)), cls_jl_Object_Monitor, fld_owner) == NULL)) {
        teavm_local_4 = (teavm_tmp_int_2 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_2));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39129, meth_jl_Thread_currentThread());
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39130, teavm_nullCheck(teavm_local_4));
        teavm_gc_writeBarrier(teavm_local_4);
        TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_owner) = teavm_local_5;
    }
    teavm_local_4 = (teavm_tmp_int_3 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_5 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39131, teavm_nullCheck(teavm_local_4)), cls_jl_Object_Monitor, fld_owner);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    if ((teavm_local_5 == TEAVM_WITH_CALL_SITE_ID(39132, meth_jl_Thread_currentThread()))) {
        teavm_local_3 = (teavm_tmp_int_4 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39133, teavm_nullCheck(teavm_local_3));
        TEAVM_FIELD(teavm_local_3, cls_jl_Object_Monitor, fld_count) = (TEAVM_FIELD(teavm_local_3, cls_jl_Object_Monitor, fld_count) + teavm_local_2);
        goto teavm_label_3;
    }
teavm_label_4:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(39134, meth_jl_Object_monitorEnterWait_0(teavm_local_1, teavm_local_2));
    if (meth_otr_Fiber_isSuspending(teavm_local_3)) {
        goto teavm_label_2;
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_WITH_CALL_SITE_ID(39135, meth_otr_Fiber_push_0(teavm_local_3, teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(39136, meth_otr_Fiber_push(teavm_local_3, teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(39137, meth_otr_Fiber_push_0(teavm_local_3, INT32_C(0)));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_createMonitor(void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_tmp_int_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = meth_jl_Object_hashCodeLowLevel(teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39138, meth_otr_Allocator_allocate(&jl_Object_Monitor_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(39139, meth_jl_Object_Monitor__init_(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39140, teavm_nullCheck(teavm_local_1));
    teavm_gc_writeBarrier(teavm_local_1);
    TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash) = TEAVM_PACK_MONITOR(teavm_local_3);
    teavm_local_3 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39141, teavm_nullCheck(teavm_local_3)), cls_jl_Object_Monitor, fld_id) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorEnterWait_0(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_3)) {
        switch (meth_otr_Fiber_popInt(teavm_local_3)) {
            case 0:
                goto teavm_label_3;
            default:
                goto teavm_label_2;
        }
    teavm_label_3:;
        teavm_local_4 = meth_otr_Fiber_popObject(teavm_local_3);
        goto teavm_label_1;
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39142, meth_otr_Allocator_allocate(&jl_Object_monitorEnterWait_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(39143, meth_jl_Object_monitorEnterWait_0__init_(teavm_local_4, teavm_local_1, teavm_local_2));
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(39144, meth_otr_Fiber_suspend(teavm_local_4));
    if (meth_otr_Fiber_isSuspending(teavm_local_3)) {
        TEAVM_WITH_CALL_SITE_ID(39145, meth_otr_Fiber_push(teavm_local_3, teavm_local_4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(39146, meth_otr_Fiber_push_0(teavm_local_3, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorEnterWait(void* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    int32_t teavm_tmp_int_2;
    int32_t teavm_tmp_int_3;
    int32_t teavm_tmp_int_4;
    int32_t teavm_tmp_int_5;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39147, meth_jl_Thread_currentThread());
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39148, teavm_nullCheck(teavm_local_1));
    if (((teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0)) == NULL)) {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(39149, meth_jl_Object_createMonitor(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(39150, meth_jl_Thread_setCurrentThread(teavm_local_4));
        teavm_local_5 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39151, teavm_nullCheck(teavm_local_5));
        TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_count) = (TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_count) + teavm_local_2);
        teavm_local_5 = NULL;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39152, teavm_nullCheck(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(39153, TEAVM_METHOD(teavm_local_3, oti_AsyncCallback_VT, virt_complete_0)(teavm_local_3, teavm_local_5));
    } else {
        teavm_local_5 = (teavm_tmp_int_2 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39154, teavm_nullCheck(teavm_local_5)), cls_jl_Object_Monitor, fld_owner) == NULL)) {
            teavm_local_5 = (teavm_tmp_int_3 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_3));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39155, teavm_nullCheck(teavm_local_5));
            teavm_gc_writeBarrier(teavm_local_5);
            TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_owner) = teavm_local_4;
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_WITH_CALL_SITE_ID(39156, meth_jl_Thread_setCurrentThread(teavm_local_4));
            teavm_local_5 = (teavm_tmp_int_4 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_4));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39157, teavm_nullCheck(teavm_local_5));
            TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_count) = (TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_count) + teavm_local_2);
            teavm_local_5 = NULL;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39158, teavm_nullCheck(teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(39159, TEAVM_METHOD(teavm_local_3, oti_AsyncCallback_VT, virt_complete_0)(teavm_local_3, teavm_local_5));
        } else {
            teavm_local_6 = (teavm_tmp_int_5 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_5));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(39160, teavm_nullCheck(teavm_local_6));
            if ((TEAVM_FIELD(teavm_local_6, cls_jl_Object_Monitor, fld_enteringThreads) == NULL)) {
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39161, meth_otr_Allocator_allocate(&ju_ArrayDeque_Cls));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
                TEAVM_WITH_CALL_SITE_ID(39162, meth_ju_ArrayDeque__init_(teavm_local_5));
                teavm_gc_writeBarrier(teavm_local_6);
                TEAVM_FIELD(teavm_local_6, cls_jl_Object_Monitor, fld_enteringThreads) = teavm_local_5;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_local_6, cls_jl_Object_Monitor, fld_enteringThreads);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(39163, meth_otr_Allocator_allocate(&jl_Object_monitorEnterWait_lambda__6_0_Cls));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(39164, meth_jl_Object_monitorEnterWait_lambda__6_0__init_(teavm_local_7, teavm_local_4, teavm_local_1, teavm_local_2, teavm_local_3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(39165, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(39166, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Queue_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_7)));
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorExit(void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(39167, meth_jl_Object_monitorExit_0(teavm_local_1, INT32_C(1)));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_monitorExit_0(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39168, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!TEAVM_WITH_CALL_SITE_ID(39169, meth_jl_Object_isEmptyMonitor(teavm_local_1)))) {
        teavm_local_3 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39170, teavm_nullCheck(teavm_local_3)), cls_jl_Object_Monitor, fld_owner);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(39171, meth_jl_Thread_currentThread()))) {
            teavm_local_4 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39172, teavm_nullCheck(teavm_local_4));
            TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_count) = (TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_count) - teavm_local_2);
            if ((TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_count) <= INT32_C(0))) {
                TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_owner) = NULL;
                if ((TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_enteringThreads) != NULL)) {
                    teavm_local_3 = TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_enteringThreads);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                    if ((!TEAVM_WITH_CALL_SITE_ID(39173, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(39174, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Queue_VT, virt_isEmpty)(teavm_tmp_ptr_0))))) {
                        goto teavm_label_2;
                    }
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(39175, meth_jl_Object_isEmptyMonitor(teavm_local_1));
                goto teavm_label_1;
            teavm_label_2:;
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39176, meth_otr_Allocator_allocate(&jl_Object_monitorExit_lambda__8_0_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                TEAVM_WITH_CALL_SITE_ID(39177, meth_jl_Object_monitorExit_lambda__8_0__init_(teavm_local_3, teavm_local_1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(39178, meth_otr_EventQueue_offer(teavm_local_3));
            teavm_label_1:;
            }
            TEAVM_RELEASE_STACK;
            return;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39179, meth_otr_Allocator_allocate(&jl_IllegalMonitorStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(39180, meth_jl_IllegalMonitorStateException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(39181, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void meth_jl_Object_waitForOtherThreads(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39182, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!TEAVM_WITH_CALL_SITE_ID(39183, meth_jl_Object_isEmptyMonitor(teavm_local_1)))) {
        teavm_local_2 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39184, teavm_nullCheck(teavm_local_2)), cls_jl_Object_Monitor, fld_owner) == NULL)) {
            goto teavm_label_2;
        }
    }
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39185, teavm_nullCheck(teavm_local_3));
    if ((TEAVM_FIELD(teavm_local_3, cls_jl_Object_Monitor, fld_enteringThreads) != NULL)) {
        teavm_local_2 = TEAVM_FIELD(teavm_local_3, cls_jl_Object_Monitor, fld_enteringThreads);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        if ((!TEAVM_WITH_CALL_SITE_ID(39186, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(39187, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Queue_VT, virt_isEmpty)(teavm_tmp_ptr_0))))) {
            teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jl_Object_Monitor, fld_enteringThreads);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39188, teavm_nullCheck(teavm_local_4));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39189, TEAVM_METHOD(teavm_local_4, ju_Queue_VT, virt_remove_3)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39190, teavm_checkcast(teavm_local_2, &otp_PlatformRunnable_Cls, &supertypeof_otp_PlatformRunnable));
            TEAVM_FIELD(teavm_local_3, cls_jl_Object_Monitor, fld_enteringThreads) = NULL;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39191, teavm_nullCheck(teavm_local_5));
            TEAVM_WITH_CALL_SITE_ID(39192, TEAVM_METHOD(teavm_local_5, otp_PlatformRunnable_VT, virt_run_0)(teavm_local_5));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Object_isEmptyMonitor(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_tmp_int_0;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_this_, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if ((TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_owner) == NULL)) {
            if ((TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_enteringThreads) != NULL)) {
                teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_enteringThreads);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                if ((!TEAVM_WITH_CALL_SITE_ID(39193, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(39194, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Queue_VT, virt_isEmpty)(teavm_tmp_ptr_0))))) {
                    goto teavm_label_3;
                }
            }
            if ((TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_notifyListeners) == NULL)) {
                goto teavm_label_2;
            }
            teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_notifyListeners);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if (TEAVM_WITH_CALL_SITE_ID(39195, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(39196, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Queue_VT, virt_isEmpty)(teavm_tmp_ptr_0)))) {
                goto teavm_label_2;
            }
        }
    teavm_label_3:;
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(39197, meth_jl_Object_deleteMonitor(teavm_this_));
        teavm_local_2 = INT32_C(1);
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Object_deleteMonitor(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_tmp_int_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_this_, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39198, teavm_nullCheck(teavm_local_1)), cls_jl_Object_Monitor, fld_id);
    meth_jl_Object_setHashCodeLowLevel(teavm_this_, teavm_local_2);
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Object_holdsLock(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39199, teavm_nullCheck(teavm_local_1));
    if (((teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0)) != NULL)) {
        teavm_local_2 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39200, teavm_nullCheck(teavm_local_2)), cls_jl_Object_Monitor, fld_owner);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((teavm_local_3 == TEAVM_WITH_CALL_SITE_ID(39201, meth_jl_Thread_currentThread()))) {
            goto teavm_label_2;
        }
    }
    teavm_local_4 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_4 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void meth_jl_Object__init_(void* teavm_this_) {
    return;
}
void* meth_jl_Object_getClass(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39202, teavm_getClassObject((TeaVM_Class*) TEAVM_WITH_CALL_SITE_ID(39203, TEAVM_CLASS_OF(teavm_this_))));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39204, teavm_checkcast(teavm_local_1, &jl_Class_Cls, &supertypeof_jl_Class));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Object_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39205, meth_jl_Object_identity(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Object_equals(void* teavm_this_, void* teavm_local_1) {
    return ((teavm_this_ != teavm_local_1) ? INT32_C(0) : INT32_C(1));
}
void* meth_jl_Object_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39206, meth_jl_Object_getClass(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39207, meth_jl_Class_getName(TEAVM_WITH_CALL_SITE_ID(39208, teavm_nullCheck(teavm_local_1))));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39209, meth_jl_Integer_toHexString(TEAVM_WITH_CALL_SITE_ID(39210, meth_jl_Object_identity(teavm_this_))));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39211, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(39212, meth_jl_StringBuilder__init_(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39213, meth_jl_StringBuilder_append(teavm_local_3, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39214, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(39215, teavm_nullCheck(teavm_local_1)), INT32_C(64)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(39216, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(39217, teavm_nullCheck(teavm_local_1)), teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39218, meth_jl_StringBuilder_toString(teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Object_identity(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_tmp_int_0;
    teavm_local_1 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_this_, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = meth_jl_Object_hashCodeLowLevel(teavm_this_);
        if ((!teavm_local_2)) {
            teavm_local_2 = meth_jl_Object_identityLowLevel();
            meth_jl_Object_setHashCodeLowLevel(teavm_this_, teavm_local_2);
        }
        return teavm_local_2;
    }
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_id);
    if ((!teavm_local_2)) {
        teavm_local_2 = meth_jl_Object_identityLowLevel();
        TEAVM_FIELD(teavm_local_1, cls_jl_Object_Monitor, fld_id) = teavm_local_2;
    }
    return teavm_local_2;
}
int32_t meth_jl_Object_hashCodeLowLevel(void* teavm_local_1) {
    return meth_jl_Object_hashCodeLowLevelImpl(teavm_local_1);
}
int32_t meth_jl_Object_hashCodeLowLevelImpl(void* teavm_local_1) {
    return TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash);
}
void meth_jl_Object_setHashCodeLowLevel(void* teavm_local_1, int32_t teavm_local_2) {
    meth_jl_Object_setHashCodeLowLevelImpl(teavm_local_1, teavm_local_2);
}
void meth_jl_Object_setHashCodeLowLevelImpl(void* teavm_local_1, int32_t teavm_local_2) {
    TEAVM_FIELD(teavm_local_1, TeaVM_Object, hash) = teavm_local_2;
}
int32_t meth_jl_Object_identityLowLevel() {
    int32_t teavm_local_1;
    teavm_local_1 = sfld_otr_RuntimeObject_nextId;
    sfld_otr_RuntimeObject_nextId = (teavm_local_1 + INT32_C(1));
    if ((!teavm_local_1)) {
        teavm_local_1 = sfld_otr_RuntimeObject_nextId;
        sfld_otr_RuntimeObject_nextId = (teavm_local_1 + INT32_C(1));
        if ((teavm_local_1 == (int32_t) INT32_C(0x80000000))) {
            teavm_local_1 = INT32_C(1);
        }
    }
    return teavm_local_1;
}
void* meth_jl_Object_clone(void* teavm_this_) {
    return meth_jl_Object_cloneLowLevel(teavm_this_);
}
void* meth_jl_Object_cloneLowLevel(void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = meth_otr_RuntimeClass_getClass(teavm_local_1);
    teavm_local_3 = sizeof(TeaVM_Object);
    if ((TEAVM_FIELD(teavm_local_2, TeaVM_Class, itemType) == NULL)) {
        teavm_local_4 = meth_otr_Allocator_allocate(teavm_local_2);
        teavm_local_5 = TEAVM_FIELD(teavm_local_2, TeaVM_Class, size);
    } else {
        teavm_local_6 = teavm_local_1;
        teavm_local_4 = meth_otr_Allocator_allocateArray(teavm_local_2, TEAVM_FIELD(teavm_local_6, TeaVM_Array, size));
        teavm_local_7 = ((!meth_otr_RuntimeClass_isPrimitive(teavm_local_2)) ? sizeof(void*) : TEAVM_FIELD(TEAVM_FIELD(teavm_local_2, TeaVM_Class, itemType), TeaVM_Class, size));
        teavm_local_8 = TEAVM_ALIGN(((void*) (intptr_t) sizeof(TeaVM_Array)), teavm_local_7);
        teavm_local_5 = ((teavm_local_7 * TEAVM_FIELD(teavm_local_6, TeaVM_Array, size)) + ((int32_t) (intptr_t) teavm_local_8));
    }
    if ((teavm_local_5 > teavm_local_3)) {
        memmove(TEAVM_ADDRESS_ADD(teavm_local_4, teavm_local_3), TEAVM_ADDRESS_ADD(teavm_local_1, teavm_local_3), (teavm_local_5 - teavm_local_3));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void meth_jl_Object_notifyAll(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if (TEAVM_WITH_CALL_SITE_ID(39219, meth_jl_Object_holdsLock(teavm_this_))) {
        teavm_local_1 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_this_, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39220, teavm_nullCheck(teavm_local_1)), cls_jl_Object_Monitor, fld_notifyListeners);
        if ((teavm_local_2 != NULL)) {
            while (1) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                if (TEAVM_WITH_CALL_SITE_ID(39221, TEAVM_METHOD(teavm_local_2, ju_Queue_VT, virt_isEmpty)(teavm_local_2))) {
                    goto teavm_label_1;
                }
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39222, TEAVM_METHOD(teavm_local_2, ju_Queue_VT, virt_remove_3)(teavm_local_2));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39223, teavm_checkcast(teavm_local_1, &jl_Object_NotifyListener_Cls, &supertypeof_jl_Object_NotifyListener));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39224, teavm_nullCheck(teavm_local_3));
                if ((!TEAVM_WITH_CALL_SITE_ID(39225, TEAVM_METHOD(teavm_local_3, jl_Object_NotifyListener_VT, virt_expired)(teavm_local_3)))) {
                    TEAVM_WITH_CALL_SITE_ID(39226, meth_otr_EventQueue_offer(teavm_local_3));
                }
            }
        teavm_label_1:;
            teavm_local_4 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_this_, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
            teavm_local_1 = NULL;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(39227, teavm_nullCheck(teavm_local_4)), cls_jl_Object_Monitor, fld_notifyListeners) = teavm_local_1;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39228, meth_otr_Allocator_allocate(&jl_IllegalMonitorStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(39229, meth_jl_IllegalMonitorStateException__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(39230, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void meth_jl_Object_wait(void* teavm_this_, int64_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    volatile int32_t teavm_spill_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_2)) {
        switch (meth_otr_Fiber_popInt(teavm_local_2)) {
            case 0:
                goto teavm_label_4;
            default:
                goto teavm_label_3;
        }
    teavm_label_4:;
        teavm_local_3 = meth_otr_Fiber_popInt(teavm_local_2);
        teavm_local_1 = meth_otr_Fiber_popLong(teavm_local_2);
        teavm_this_ = meth_otr_Fiber_popObject(teavm_local_2);
        goto teavm_label_2;
    }
teavm_label_3:;
    TEAVM_TRY
        teavm_spill_3 = teavm_local_3;
        teavm_local_3 = INT32_C(0);
        teavm_spill_3 = teavm_local_3;
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_2;
    TEAVM_CATCH
        // CATCH java.lang.InterruptedException
        case 1: {
            teavm_local_3 = teavm_spill_3;
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_2:;
    TEAVM_TRY
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_this_);
        TEAVM_WITH_CALL_SITE_ID(39231, meth_jl_Object_wait_1(teavm_this_, teavm_local_1, teavm_local_3));
        if ((!meth_otr_Fiber_isSuspending(teavm_local_2))) {
            TEAVM_RESTORE_JUMP_BUFFER;
            goto teavm_label_6;
        }
    TEAVM_CATCH
        // CATCH java.lang.InterruptedException
        case 1: {
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
    TEAVM_WITH_CALL_SITE_ID(39232, meth_otr_Fiber_push(teavm_local_2, teavm_this_));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(39233, meth_otr_Fiber_push_1(teavm_local_2, teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(39234, meth_otr_Fiber_push_0(teavm_local_2, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(39235, meth_otr_Fiber_push_0(teavm_local_2, INT32_C(0)));
    goto teavm_label_5;
teavm_label_6:;
    TEAVM_TRY
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_5;
    TEAVM_CATCH
        // CATCH java.lang.InterruptedException
        case 1: {
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_5:;
    TEAVM_RELEASE_STACK;
    return;
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39236, meth_otr_Allocator_allocate(&jl_InterruptedException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(39237, meth_jl_InterruptedException__init_(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(39238, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void meth_jl_Object_wait_1(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_3)) {
        switch (meth_otr_Fiber_popInt(teavm_local_3)) {
            case 0:
                goto teavm_label_3;
            default:
                goto teavm_label_2;
        }
    teavm_label_3:;
        teavm_local_2 = meth_otr_Fiber_popInt(teavm_local_3);
        teavm_local_1 = meth_otr_Fiber_popLong(teavm_local_3);
        teavm_this_ = meth_otr_Fiber_popObject(teavm_local_3);
        goto teavm_label_1;
    }
teavm_label_2:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((!TEAVM_WITH_CALL_SITE_ID(39239, meth_jl_Object_holdsLock(teavm_this_)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(39240, meth_otr_Allocator_allocate(&jl_IllegalMonitorStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(39241, meth_jl_IllegalMonitorStateException__init_(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(39242, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_this_);
    TEAVM_WITH_CALL_SITE_ID(39243, meth_jl_Object_waitImpl_0(teavm_this_, teavm_local_1, teavm_local_2));
    if (meth_otr_Fiber_isSuspending(teavm_local_3)) {
        TEAVM_WITH_CALL_SITE_ID(39244, meth_otr_Fiber_push(teavm_local_3, teavm_this_));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(39245, meth_otr_Fiber_push_1(teavm_local_3, teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(39246, meth_otr_Fiber_push_0(teavm_local_3, teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(39247, meth_otr_Fiber_push_0(teavm_local_3, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_waitImpl_0(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_3 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_3)) {
        switch (meth_otr_Fiber_popInt(teavm_local_3)) {
            case 0:
                goto teavm_label_3;
            default:
                goto teavm_label_2;
        }
    teavm_label_3:;
        teavm_local_4 = meth_otr_Fiber_popObject(teavm_local_3);
        goto teavm_label_1;
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39248, meth_otr_Allocator_allocate(&jl_Object_waitImpl_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(39249, meth_jl_Object_waitImpl_1__init_(teavm_local_4, teavm_this_, teavm_local_1, teavm_local_2));
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(39250, meth_otr_Fiber_suspend(teavm_local_4));
    if (meth_otr_Fiber_isSuspending(teavm_local_3)) {
        TEAVM_WITH_CALL_SITE_ID(39251, meth_otr_Fiber_push(teavm_local_3, teavm_local_4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(39252, meth_otr_Fiber_push_0(teavm_local_3, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_waitImpl(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2, void* teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    int64_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_tmp_int_0;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_4 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_this_, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39253, meth_otr_Allocator_allocate(&jl_Object_NotifyListenerImpl_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39254, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(39255, meth_jl_Object_NotifyListenerImpl__init_(teavm_local_5, teavm_this_, teavm_local_3, TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_count)));
    if ((TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_notifyListeners) == NULL)) {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(39256, meth_otr_Allocator_allocate(&ju_ArrayDeque_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(39257, meth_ju_ArrayDeque__init_(teavm_local_6));
        teavm_gc_writeBarrier(teavm_local_4);
        TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_notifyListeners) = teavm_local_6;
    }
    teavm_local_6 = TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_notifyListeners);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(39258, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(39259, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Queue_VT, virt_add_2)(teavm_tmp_ptr_0, teavm_local_5)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(39260, meth_jl_Thread_currentThread());
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(39261, teavm_nullCheck(teavm_local_6));
    teavm_gc_writeBarrier(teavm_local_6);
    TEAVM_FIELD(teavm_local_6, cls_jl_Thread, fld_interruptHandler) = teavm_local_5;
    if ((!((teavm_local_1 <= INT64_C(0)) && (teavm_local_2 <= INT32_C(0))))) {
        teavm_local_7 = ((teavm_local_1 < INT64_C(2147483647)) ? ((int32_t) teavm_local_1) : INT32_C(2147483647));
        teavm_local_8 = ((int64_t) teavm_local_7);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(39262, meth_otr_EventQueue_offer_0(teavm_local_5, (teavm_local_8 + TEAVM_WITH_CALL_SITE_ID(39263, meth_jl_System_currentTimeMillis()))));
        TEAVM_FIELD(teavm_local_5, cls_jl_Object_NotifyListenerImpl, fld_timerId) = teavm_local_9;
    }
    teavm_local_9 = TEAVM_FIELD(teavm_local_4, cls_jl_Object_Monitor, fld_count);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(39264, meth_jl_Object_monitorExit_0(teavm_this_, teavm_local_9));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_wait_0(void* teavm_this_) {
    void* teavm_local_1;
    int64_t teavm_local_2;
    volatile int64_t teavm_spill_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_1)) {
        switch (meth_otr_Fiber_popInt(teavm_local_1)) {
            case 0:
                goto teavm_label_4;
            default:
                goto teavm_label_3;
        }
    teavm_label_4:;
        teavm_local_2 = meth_otr_Fiber_popLong(teavm_local_1);
        teavm_this_ = meth_otr_Fiber_popObject(teavm_local_1);
        goto teavm_label_2;
    }
teavm_label_3:;
    TEAVM_TRY
        teavm_spill_2 = teavm_local_2;
        teavm_local_2 = INT64_C(0);
        teavm_spill_2 = teavm_local_2;
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_2;
    TEAVM_CATCH
        // CATCH java.lang.InterruptedException
        case 1: {
            teavm_local_2 = teavm_spill_2;
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_2:;
    TEAVM_TRY
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_this_);
        TEAVM_WITH_CALL_SITE_ID(39265, meth_jl_Object_wait(teavm_this_, teavm_local_2));
        if ((!meth_otr_Fiber_isSuspending(teavm_local_1))) {
            TEAVM_RESTORE_JUMP_BUFFER;
            goto teavm_label_6;
        }
    TEAVM_CATCH
        // CATCH java.lang.InterruptedException
        case 1: {
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
    TEAVM_WITH_CALL_SITE_ID(39266, meth_otr_Fiber_push(teavm_local_1, teavm_this_));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(39267, meth_otr_Fiber_push_1(teavm_local_1, teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(39268, meth_otr_Fiber_push_0(teavm_local_1, INT32_C(0)));
    goto teavm_label_5;
teavm_label_6:;
    TEAVM_TRY
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_5;
    TEAVM_CATCH
        // CATCH java.lang.InterruptedException
        case 1: {
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_5:;
    TEAVM_RELEASE_STACK;
    return;
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(39269, meth_otr_Allocator_allocate(&jl_InterruptedException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(39270, meth_jl_InterruptedException__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(39271, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void meth_jl_Object_lambda_monitorExit_1(void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(39272, meth_jl_Object_waitForOtherThreads(teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Object_lambda_monitorEnterWait_0(void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    void* teavm_local_5;
    int32_t teavm_tmp_int_0;
    int32_t teavm_tmp_int_1;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(39273, meth_jl_Thread_setCurrentThread(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(39274, teavm_nullCheck(teavm_local_2));
    teavm_local_5 = (teavm_tmp_int_0 = TEAVM_FIELD(teavm_local_2, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_0));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39275, teavm_nullCheck(teavm_local_5));
    teavm_gc_writeBarrier(teavm_local_5);
    TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_owner) = teavm_local_1;
    teavm_local_5 = (teavm_tmp_int_1 = TEAVM_FIELD(teavm_local_2, TeaVM_Object, hash), TEAVM_UNPACK_MONITOR(teavm_tmp_int_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(39276, teavm_nullCheck(teavm_local_5));
    TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_count) = (TEAVM_FIELD(teavm_local_5, cls_jl_Object_Monitor, fld_count) + teavm_local_3);
    teavm_local_5 = NULL;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(39277, teavm_nullCheck(teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(39278, TEAVM_METHOD(teavm_local_4, oti_AsyncCallback_VT, virt_complete_0)(teavm_local_4, teavm_local_5));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Object(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 0 || tag >= 2302) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Object_VT jl_Object_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(TeaVM_Object), sizeof(void*)),
        .flags = 0,
        .tag = 1148,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7973),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Object,
        .superclass = NULL,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
void sysinitclass_jl_Object() {
}
