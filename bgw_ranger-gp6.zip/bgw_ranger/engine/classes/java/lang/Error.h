#pragma once
#include "../../../runtime.h"
#include "Throwable.h"
#include "Error.h"

extern void sysinitclass_jl_Error();
typedef struct cls_jl_Error {
    struct cls_jl_Throwable parent;
} cls_jl_Error;
extern void meth_jl_Error__init_(void*);
extern void meth_jl_Error__init__0(void*, void*, void*);
extern void meth_jl_Error__init__1(void*, void*);
extern void meth_jl_Error__init__2(void*, void*);
extern int32_t supertypeof_jl_Error(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Error_VT {
    jl_Throwable_VT parent;
} jl_Error_VT;
extern jl_Error_VT jl_Error_Cls;
