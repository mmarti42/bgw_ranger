#include "Class.h"
#include "Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"
#include "StringBuilder.h"
#include "../../../core.h"
#include "String.h"
#include "../../../arrayclass.h"

void meth_jl_Class__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5494, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Class_createClass(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5495, meth_otr_Allocator_allocate(&jl_Class_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5496, meth_jl_Class__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Class_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = (TEAVM_WITH_CALL_SITE_ID(5497, meth_jl_Class_isInterface(teavm_this_)) ? TEAVM_GET_STRING(511) : ((!TEAVM_WITH_CALL_SITE_ID(5498, meth_jl_Class_isPrimitive(teavm_this_))) ? TEAVM_GET_STRING(512) : TEAVM_GET_STRING(34)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5499, meth_jl_Class_getName(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5500, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(5501, meth_jl_StringBuilder__init_(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5502, meth_jl_StringBuilder_append(teavm_local_3, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(5503, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(5504, teavm_nullCheck(teavm_local_1)), teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5505, meth_jl_StringBuilder_toString(teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Class_getClassInfo(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo);
}
int32_t meth_jl_Class_isInstance(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 != NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5506, meth_jl_Object_getClass(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if (TEAVM_WITH_CALL_SITE_ID(5507, meth_jl_Class_isAssignableFrom(teavm_this_, TEAVM_WITH_CALL_SITE_ID(5508, teavm_checkcast(teavm_local_2, &jl_Class_Cls, &supertypeof_jl_Class))))) {
            goto teavm_label_2;
        }
    }
    teavm_local_3 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Class_isAssignableFrom(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5509, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = teavm_isSupertypeOf((TeaVM_Class*) teavm_local_2, (TeaVM_Class*) TEAVM_FIELD(teavm_local_1, cls_jl_Class, fld_classInfo));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_Class_getName(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((!(TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) & INT32_C(1)))) {
        TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) = (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) | INT32_C(1));
        teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->name);
        teavm_local_2 = ((teavm_local_1 == NULL) ? NULL : *((TeaVM_String**) teavm_local_1));
        if ((teavm_local_2 == NULL)) {
            teavm_local_3 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType);
            if ((teavm_local_3 != NULL)) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5510, teavm_getClassObject((TeaVM_Class*) teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5511, meth_jl_Class_getName(TEAVM_WITH_CALL_SITE_ID(5512, teavm_nullCheck(teavm_local_4))));
                if ((teavm_local_5 != NULL)) {
                    if (((((TeaVM_Class*) (teavm_local_3))->itemType) != NULL)) {
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5513, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                        TEAVM_WITH_CALL_SITE_ID(5514, meth_jl_StringBuilder__init_(teavm_local_4));
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5515, meth_jl_StringBuilder_append_1(teavm_local_4, INT32_C(91)));
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                        TEAVM_WITH_CALL_SITE_ID(5516, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(5517, teavm_nullCheck(teavm_local_6)), teavm_local_5));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5518, meth_jl_StringBuilder_toString(teavm_local_4));
                    } else {
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5519, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                        TEAVM_WITH_CALL_SITE_ID(5520, meth_jl_StringBuilder__init_(teavm_local_4));
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5521, meth_jl_StringBuilder_append(teavm_local_4, TEAVM_GET_STRING(513)));
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5522, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(5523, teavm_nullCheck(teavm_local_6)), teavm_local_5));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        TEAVM_WITH_CALL_SITE_ID(5524, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(5525, teavm_nullCheck(teavm_local_6)), INT32_C(59)));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5526, meth_jl_StringBuilder_toString(teavm_local_4));
                    }
                }
            }
        }
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_name) = teavm_local_2;
    }
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_name);
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_Class_getSimpleName(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((!(TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) & INT32_C(2)))) {
        TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) = (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) | INT32_C(2));
        teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->simpleName);
        teavm_local_2 = ((teavm_local_1 == NULL) ? NULL : *((TeaVM_String**) teavm_local_1));
        if ((teavm_local_2 == NULL)) {
            if (((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType) != NULL)) {
                teavm_local_3 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType);
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5527, teavm_getClassObject((TeaVM_Class*) teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5528, meth_jl_Class_getSimpleName(TEAVM_WITH_CALL_SITE_ID(5529, teavm_nullCheck(teavm_local_3))));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5530, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                TEAVM_WITH_CALL_SITE_ID(5531, meth_jl_StringBuilder__init_(teavm_local_4));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5532, meth_jl_StringBuilder_append(teavm_local_4, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_WITH_CALL_SITE_ID(5533, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(5534, teavm_nullCheck(teavm_local_3)), TEAVM_GET_STRING(514)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5535, meth_jl_StringBuilder_toString(teavm_local_4));
            } else {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                if ((TEAVM_WITH_CALL_SITE_ID(5536, meth_jl_Class_getEnclosingClass(teavm_this_)) == NULL)) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5537, meth_jl_Class_getName(teavm_this_));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5538, teavm_nullCheck(teavm_local_5));
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5539, meth_jl_String_lastIndexOf(teavm_local_2, INT32_C(36)));
                    if ((teavm_local_6 == -INT32_C(1))) {
                        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5540, meth_jl_String_lastIndexOf(teavm_local_2, INT32_C(46)));
                        if ((teavm_local_7 != -INT32_C(1))) {
                            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5541, meth_jl_String_substring(teavm_local_2, (teavm_local_7 + INT32_C(1))));
                        }
                    } else {
                        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5542, meth_jl_String_substring(teavm_local_2, (teavm_local_6 + INT32_C(1))));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5543, teavm_nullCheck(teavm_local_3));
                        if (((TEAVM_WITH_CALL_SITE_ID(5544, meth_jl_String_charAt(teavm_local_2, INT32_C(0))) >= INT32_C(48)) && (TEAVM_WITH_CALL_SITE_ID(5545, meth_jl_String_charAt(teavm_local_2, INT32_C(0))) <= INT32_C(57)))) {
                            teavm_local_2 = TEAVM_GET_STRING(34);
                        }
                    }
                } else if ((teavm_local_2 == NULL)) {
                    teavm_local_2 = TEAVM_GET_STRING(34);
                }
            }
        }
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_simpleName) = teavm_local_2;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_simpleName);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_Class_getCanonicalName(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((!(TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) & INT32_C(4)))) {
        TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) = (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_flags) | INT32_C(4));
        if (((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType) != NULL)) {
            teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5546, teavm_getClassObject((TeaVM_Class*) teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5547, meth_jl_Class_getCanonicalName(TEAVM_WITH_CALL_SITE_ID(5548, teavm_nullCheck(teavm_local_1))));
            if ((teavm_local_2 != NULL)) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5549, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                TEAVM_WITH_CALL_SITE_ID(5550, meth_jl_StringBuilder__init_(teavm_local_1));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5551, meth_jl_StringBuilder_append(teavm_local_1, teavm_local_2));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_WITH_CALL_SITE_ID(5552, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(5553, teavm_nullCheck(teavm_local_3)), TEAVM_GET_STRING(514)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5554, meth_jl_StringBuilder_toString(teavm_local_1));
                teavm_gc_writeBarrier(teavm_this_);
                TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_canonicalName) = teavm_local_1;
            }
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((TEAVM_WITH_CALL_SITE_ID(5555, meth_jl_Class_getEnclosingClass(teavm_this_)) == NULL)) {
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5556, meth_jl_Class_getName(teavm_this_));
                teavm_gc_writeBarrier(teavm_this_);
                TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_canonicalName) = teavm_local_1;
            } else if (((TEAVM_WITH_CALL_SITE_ID(5557, meth_jl_Class_getDeclaringClass(teavm_this_)) != NULL) && (!TEAVM_WITH_CALL_SITE_ID(5558, meth_jl_Class_isSynthetic(teavm_this_))))) {
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5559, meth_jl_Class_getDeclaringClass(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5560, meth_jl_Class_getCanonicalName(TEAVM_WITH_CALL_SITE_ID(5561, teavm_nullCheck(teavm_local_1))));
                if ((teavm_local_4 != NULL)) {
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5562, meth_jl_Class_getSimpleName(teavm_this_));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5563, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
                    TEAVM_WITH_CALL_SITE_ID(5564, meth_jl_StringBuilder__init_(teavm_local_3));
                    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5565, meth_jl_StringBuilder_append(teavm_local_3, teavm_local_4));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5566, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(5567, teavm_nullCheck(teavm_local_5)), INT32_C(46)));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                    TEAVM_WITH_CALL_SITE_ID(5568, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(5569, teavm_nullCheck(teavm_local_5)), teavm_local_1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5570, meth_jl_StringBuilder_toString(teavm_local_3));
                    teavm_gc_writeBarrier(teavm_this_);
                    TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_canonicalName) = teavm_local_1;
                }
            }
        }
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_canonicalName);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Class_isSynthetic(void* teavm_this_) {
    return ((!((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->modifiers) & INT32_C(32768))) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jl_Class_isPrimitive(void* teavm_this_) {
    return ((!teavm_primitiveKind((TeaVM_Class*) TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo))) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jl_Class_isArray(void* teavm_this_) {
    return (((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType) == NULL) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jl_Class_isEnum(void* teavm_this_) {
    return ((!((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->modifiers) & INT32_C(65536))) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jl_Class_isInterface(void* teavm_this_) {
    return ((!((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->modifiers) & INT32_C(512))) ? INT32_C(0) : INT32_C(1));
}
void* meth_jl_Class_getComponentType(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->itemType);
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = NULL;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5571, teavm_getClassObject((TeaVM_Class*) teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5572, teavm_checkcast(teavm_local_2, &jl_Class_Cls, &supertypeof_jl_Class));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Class_desiredAssertionStatus(void* teavm_this_) {
    return INT32_C(1);
}
void* meth_jl_Class_getSuperclass(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->superclass) == NULL)) {
        teavm_local_1 = NULL;
    } else {
        teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->superclass);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5573, teavm_getClassObject((TeaVM_Class*) teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5574, teavm_checkcast(teavm_local_1, &jl_Class_Cls, &supertypeof_jl_Class));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jl_Class_getEnumConstants(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5575, meth_jl_Class_getEnumConstantsFast(teavm_this_));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = NULL;
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5576, TEAVM_METHOD(teavm_local_1, jl_Object_VT, virt_clone)(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5577, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), &teavm_isSupertypeOfArray));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
TeaVM_Array* meth_jl_Class_getEnumConstantsFast(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((!TEAVM_WITH_CALL_SITE_ID(5578, meth_jl_Class_isEnum(teavm_this_)))) {
        teavm_local_1 = NULL;
    } else {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_enumConstantsCache);
        if ((teavm_local_1 == NULL)) {
            TEAVM_WITH_CALL_SITE_ID(5579, meth_jl_Class_initialize(teavm_this_));
            teavm_local_2 = teavm_enumConstantCount((TeaVM_Class*) TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5580, meth_otr_Allocator_allocateArray(teavm_getArrayClass(TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)), teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5581, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), &teavm_isSupertypeOfArray));
            teavm_local_4 = INT32_C(0);
            while (1) {
                if (!(teavm_local_4 < teavm_local_2)) break;
                teavm_local_3 = teavm_enumConstant((TeaVM_Class*) TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo), teavm_local_4);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5582, teavm_nullCheck(teavm_local_1));
                teavm_local_5 = teavm_local_1;
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5583, teavm_checkBounds(teavm_local_4, teavm_local_5));
                teavm_gc_writeBarrier(teavm_local_5);
                TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4) = teavm_local_3;
                teavm_local_4 = (teavm_local_4 + INT32_C(1));
            }
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_enumConstantsCache) = teavm_local_1;
        }
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jl_Class_initialize(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5584, teavm_initializeClassDefault((TeaVM_Class*) TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Class_getDeclaringClass(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->declaringClass);
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = NULL;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5585, teavm_getClassObject((TeaVM_Class*) teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5586, teavm_checkcast(teavm_local_2, &jl_Class_Cls, &supertypeof_jl_Class));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Class_getEnclosingClass(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = (((TeaVM_Class*) (TEAVM_FIELD(teavm_this_, cls_jl_Class, fld_classInfo)))->enclosingClass);
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = NULL;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5587, teavm_getClassObject((TeaVM_Class*) teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5588, teavm_checkcast(teavm_local_2, &jl_Class_Cls, &supertypeof_jl_Class));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jl_Class(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 257 || tag >= 259) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Class_Cls[5];
alignas(8) jl_Class_VT jl_Class_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Class), sizeof(void*)),
            .flags = 0,
            .tag = 257,
            .modifiers = 17,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(515),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_Class,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jl_Class_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Class_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static int16_t teavm_classLayouts_jl_Class_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jl_Class, fld_name), (int16_t) offsetof(cls_jl_Class, fld_simpleName), (int16_t) offsetof(cls_jl_Class, fld_canonicalName), (int16_t) offsetof(cls_jl_Class, fld_enumConstantsCache)
};
void sysinitclass_jl_Class() {
}
