#pragma once
#include "../../../../runtime.h"
#include "../Object.h"
#include "Reference.h"

extern void sysinitclass_jlr_Reference();
typedef struct cls_jlr_Reference {
    struct TeaVM_Object parent;
} cls_jlr_Reference;
extern void meth_jlr_Reference__init_(void*);
extern int32_t supertypeof_jlr_Reference(TeaVM_Class*, TeaVM_Class*);
typedef struct jlr_Reference_VT {
    jl_Object_VT parent;
} jlr_Reference_VT;
extern jlr_Reference_VT jlr_Reference_Cls;
