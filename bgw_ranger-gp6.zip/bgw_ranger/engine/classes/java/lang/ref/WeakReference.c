#include "WeakReference.h"
#include "Reference.h"
#include "../../../../strings.h"
#include "../Object.h"

void meth_jlr_WeakReference__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    meth_jlr_Reference__init_(teavm_this_);
    teavm_reference_init((TeaVM_Reference*) teavm_this_, teavm_local_1, teavm_local_2);
}
void* meth_jlr_WeakReference_get(void* teavm_this_) {
    return teavm_reference_get((TeaVM_Reference*) teavm_this_);
}
int32_t supertypeof_jlr_WeakReference(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 624 || tag >= 628) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlr_WeakReference_VT jlr_WeakReference_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(TeaVM_Reference), sizeof(void*)),
        .flags = 2,
        .tag = 624,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jlr_WeakReference,
        .superclass = (TeaVM_Class*) &jlr_Reference_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_get_4 = &meth_jlr_WeakReference_get
};
void sysinitclass_jlr_WeakReference() {
}
