#include "ReferenceQueue.h"
#include "../Object.h"
#include "../../../../strings.h"

void meth_jlr_ReferenceQueue__init_(void* teavm_this_) {
    meth_jl_Object__init_(teavm_this_);
}
void* meth_jlr_ReferenceQueue_poll(void* teavm_this_) {
    return teavm_reference_poll((TeaVM_ReferenceQueue*) teavm_this_);
}
int32_t supertypeof_jlr_ReferenceQueue(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1953 || tag >= 1955) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlr_ReferenceQueue_VT jlr_ReferenceQueue_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(TeaVM_ReferenceQueue), sizeof(void*)),
        .flags = 4,
        .tag = 1953,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jlr_ReferenceQueue,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_poll = &meth_jlr_ReferenceQueue_poll
};
void sysinitclass_jlr_ReferenceQueue() {
}
