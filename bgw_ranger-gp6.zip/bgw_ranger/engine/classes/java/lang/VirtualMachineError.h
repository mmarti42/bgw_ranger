#pragma once
#include "../../../runtime.h"
#include "Error.h"
#include "VirtualMachineError.h"

extern void sysinitclass_jl_VirtualMachineError();
typedef struct cls_jl_VirtualMachineError {
    struct cls_jl_Error parent;
} cls_jl_VirtualMachineError;
extern void meth_jl_VirtualMachineError__init_(void*, void*);
extern int32_t supertypeof_jl_VirtualMachineError(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_VirtualMachineError_VT {
    jl_Error_VT parent;
} jl_VirtualMachineError_VT;
extern jl_VirtualMachineError_VT jl_VirtualMachineError_Cls;
