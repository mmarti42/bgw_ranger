#include "Thread.h"
#include "Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/Fiber.h"
#include "Thread@dstart@dlambda@d_4_1.h"
#include "../../org/teavm/runtime/EventQueue.h"
#include "../../lab/ranger/translation/teavm/ThreadAccounting.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Thread@dUncaughtExceptionHandler.h"
#include "System.h"
#include "Thread@dswitchContext@d0.h"
#include "Thread@dswitchContext@dlambda@d_19_0.h"
#include "ThreadInterruptHandler.h"
#include "../../org/teavm/interop/AsyncCallback.h"
#include "Thread@dlambda@dstart@d0@dlambda@d_39_0.h"
#include "../../../strings.h"
#include "DefaultUncaughtExceptionHandler.h"

void* sfld_jl_Thread_mainThread;
void* sfld_jl_Thread_currentThread;
int32_t sfld_jl_Thread_nextId;
int32_t sfld_jl_Thread_activeCount;
void* sfld_jl_Thread_defaultUncaughtExceptionHandler;
void meth_jl_Thread__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20732, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    TEAVM_WITH_CALL_SITE_ID(20733, meth_jl_Thread__init__0(teavm_this_, NULL, NULL));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread__init__1(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20734, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    TEAVM_WITH_CALL_SITE_ID(20735, meth_jl_Thread__init__0(teavm_this_, NULL, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread__init__0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20736, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    TEAVM_WITH_CALL_SITE_ID(20737, meth_jl_Object__init_(teavm_this_));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20738, meth_otr_Allocator_allocate(&jl_Object_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(20739, meth_jl_Object__init_(teavm_local_3));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_finishedLock) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_alive) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_name) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_target) = teavm_local_1;
    teavm_local_4 = sfld_jl_Thread_nextId;
    sfld_jl_Thread_nextId = (teavm_local_4 + INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_id) = ((int64_t) teavm_local_4);
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_start(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_daemon);
    if ((!teavm_local_1)) {
        sfld_otr_Fiber_userThreadCount = (sfld_otr_Fiber_userThreadCount + INT32_C(1));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20740, meth_otr_Allocator_allocate(&jl_Thread_start_lambda__4_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20741, meth_jl_Thread_start_lambda__4_1__init_(teavm_local_2, teavm_this_, teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(20742, meth_otr_EventQueue_offer(teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20743, meth_lrtt_ThreadAccounting_threadScheduled(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_runThread(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void * volatile teavm_spill_2;
    void* teavm_local_3;
    void * volatile teavm_spill_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_1 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_1)) {
        switch (meth_otr_Fiber_popInt(teavm_local_1)) {
            case 0:
                goto teavm_label_7;
            default:
                goto teavm_label_6;
        }
    teavm_label_7:;
        teavm_this_ = meth_otr_Fiber_popObject(teavm_local_1);
        goto teavm_label_5;
    }
teavm_label_6:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(20744, meth_lrtt_ThreadAccounting_threadRunning(teavm_this_));
    TEAVM_TRY
        teavm_spill_2 = teavm_local_2;
        teavm_spill_3 = teavm_local_3;
        teavm_local_2 = teavm_this_;
        teavm_spill_2 = teavm_local_2;
        teavm_local_3 = teavm_this_;
        teavm_spill_3 = teavm_local_3;
        TEAVM_WITH_CALL_SITE_ID(20745, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
        sfld_jl_Thread_activeCount = (sfld_jl_Thread_activeCount + INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(20746, meth_jl_Thread_setCurrentThread(teavm_this_));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20747, meth_otr_Allocator_allocate(&jl_Object_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(20748, meth_jl_Object__init_(teavm_local_4));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_key) = teavm_local_4;
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_5;
    TEAVM_CATCH
        // CATCH java.lang.Throwable
        case 2: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_3 = teavm_spill_3;
            teavm_local_5 = teavm_catchException();
            goto teavm_label_4;
            break;
        }
        // CATCH any
        case 1: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_3 = teavm_spill_3;
            teavm_local_4 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_5:;
    TEAVM_TRY
        teavm_spill_2 = teavm_local_2;
        teavm_spill_3 = teavm_local_3;
        teavm_local_3 = teavm_this_;
        teavm_spill_3 = teavm_local_3;
        teavm_local_2 = teavm_this_;
        teavm_spill_2 = teavm_local_2;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(2), teavm_this_);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(20749, TEAVM_METHOD(teavm_this_, jl_Thread_VT, virt_run_0)(teavm_this_));
        if ((!meth_otr_Fiber_isSuspending(teavm_local_1))) {
            TEAVM_RESTORE_JUMP_BUFFER;
            goto teavm_label_8;
        }
    TEAVM_CATCH
        // CATCH java.lang.Throwable
        case 2: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_3 = teavm_spill_3;
            teavm_local_5 = teavm_catchException();
            goto teavm_label_4;
            break;
        }
        // CATCH any
        case 1: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_4 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
    TEAVM_WITH_CALL_SITE_ID(20750, meth_otr_Fiber_push(teavm_local_1, teavm_this_));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20751, meth_otr_Fiber_push_0(teavm_local_1, INT32_C(0)));
    goto teavm_label_2;
teavm_label_8:;
    TEAVM_TRY
        teavm_spill_2 = teavm_local_2;
        teavm_spill_3 = teavm_local_3;
        teavm_local_2 = teavm_this_;
        teavm_spill_2 = teavm_local_2;
        teavm_local_3 = teavm_this_;
        teavm_spill_3 = teavm_local_3;
    TEAVM_CATCH
        // CATCH java.lang.Throwable
        case 2: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_3 = teavm_spill_3;
            teavm_local_5 = teavm_catchException();
            goto teavm_label_4;
            break;
        }
        // CATCH any
        case 1: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_4 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_finishedLock);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20752, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(20753, meth_jl_Object_monitorEnter(teavm_local_1));
    TEAVM_TRY
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_finishedLock);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(20754, meth_jl_Object_notifyAll(TEAVM_WITH_CALL_SITE_ID(20755, teavm_nullCheck(teavm_local_4))));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(20756, meth_jl_Object_monitorExit(teavm_local_1));
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_9;
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_4 = teavm_catchException();
            break;
        }
    TEAVM_END_TRY
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20757, meth_jl_Object_monitorExit(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20758, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
teavm_label_9:;
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_alive) = INT32_C(0);
    sfld_jl_Thread_activeCount = (sfld_jl_Thread_activeCount - INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_key) = NULL;
    teavm_local_4 = sfld_jl_Thread_mainThread;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20759, meth_jl_Thread_setCurrentThread(teavm_local_4));
    goto teavm_label_3;
teavm_label_4:;
    TEAVM_TRY
        teavm_spill_2 = teavm_local_2;
        teavm_local_2 = teavm_local_3;
        teavm_spill_2 = teavm_local_2;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20760, TEAVM_METHOD(teavm_local_3, jl_Thread_VT, virt_getUncaughtExceptionHandler)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(20761, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20762, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Thread_UncaughtExceptionHandler_VT, virt_uncaughtException)(teavm_tmp_ptr_0, teavm_local_3, teavm_local_5)));
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_2 = teavm_spill_2;
            teavm_local_4 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
    teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jl_Thread, fld_finishedLock);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20763, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(20764, meth_jl_Object_monitorEnter(teavm_local_1));
    TEAVM_TRY
        teavm_local_4 = TEAVM_FIELD(teavm_local_3, cls_jl_Thread, fld_finishedLock);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(20765, meth_jl_Object_notifyAll(TEAVM_WITH_CALL_SITE_ID(20766, teavm_nullCheck(teavm_local_4))));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(20767, meth_jl_Object_monitorExit(teavm_local_1));
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_10;
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_4 = teavm_catchException();
            break;
        }
    TEAVM_END_TRY
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20768, meth_jl_Object_monitorExit(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20769, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
teavm_label_10:;
    TEAVM_FIELD(teavm_local_3, cls_jl_Thread, fld_alive) = INT32_C(0);
    sfld_jl_Thread_activeCount = (sfld_jl_Thread_activeCount - INT32_C(1));
    TEAVM_FIELD(teavm_local_3, cls_jl_Thread, fld_key) = NULL;
    teavm_local_4 = sfld_jl_Thread_mainThread;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20770, meth_jl_Thread_setCurrentThread(teavm_local_4));
teavm_label_3:;
teavm_label_2:;
    TEAVM_RELEASE_STACK;
    return;
teavm_label_1:;
    teavm_local_1 = TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_finishedLock);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(20771, teavm_nullCheck(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(20772, meth_jl_Object_monitorEnter(teavm_local_6));
    TEAVM_TRY
        teavm_local_1 = TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_finishedLock);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(20773, meth_jl_Object_notifyAll(TEAVM_WITH_CALL_SITE_ID(20774, teavm_nullCheck(teavm_local_1))));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(20775, meth_jl_Object_monitorExit(teavm_local_6));
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_11;
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_4 = teavm_catchException();
            break;
        }
    TEAVM_END_TRY
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(20776, meth_jl_Object_monitorExit(teavm_local_6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(20777, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
teavm_label_11:;
    TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_alive) = INT32_C(0);
    sfld_jl_Thread_activeCount = (sfld_jl_Thread_activeCount - INT32_C(1));
    TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_key) = NULL;
    teavm_local_1 = sfld_jl_Thread_mainThread;
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(20778, meth_jl_Thread_setCurrentThread(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(20779, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
void meth_jl_Thread_setCurrentThread(void* teavm_local_1) {
    void* teavm_local_2;
    int64_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20780, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    if ((sfld_jl_Thread_currentThread != teavm_local_1)) {
        sfld_jl_Thread_currentThread = teavm_local_1;
    }
    teavm_local_2 = sfld_jl_Thread_currentThread;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20781, meth_jl_System_currentTimeMillis());
    TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(20782, teavm_nullCheck(teavm_local_2)), cls_jl_Thread, fld_timeSliceStart) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Thread_getMainThread() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20783, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    teavm_local_1 = sfld_jl_Thread_mainThread;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Thread_currentThread() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20784, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    teavm_local_1 = sfld_jl_Thread_currentThread;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Thread_getName(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_name);
}
void meth_jl_Thread_setDaemon(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_daemon) = teavm_local_1;
}
void meth_jl_Thread_join(void* teavm_this_, int64_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    void * volatile teavm_spill_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void * volatile teavm_spill_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_3 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_3)) {
        switch (meth_otr_Fiber_popInt(teavm_local_3)) {
            case 0:
                goto teavm_label_5;
            default:
                goto teavm_label_4;
        }
    teavm_label_5:;
        teavm_local_4 = meth_otr_Fiber_popObject(teavm_local_3);
        teavm_local_5 = meth_otr_Fiber_popObject(teavm_local_3);
        teavm_local_2 = meth_otr_Fiber_popInt(teavm_local_3);
        teavm_local_1 = meth_otr_Fiber_popLong(teavm_local_3);
        goto teavm_label_3;
    }
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    if ((!((TEAVM_WITH_CALL_SITE_ID(20785, meth_jl_Thread_currentThread()) != teavm_this_) && TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_alive)))) {
        goto teavm_label_2;
    }
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_finishedLock);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(20786, teavm_nullCheck(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(20787, meth_jl_Object_monitorEnter(teavm_local_5));
    TEAVM_TRY
        teavm_spill_4 = teavm_local_4;
        teavm_spill_6 = teavm_local_6;
        teavm_local_6 = teavm_local_5;
        teavm_spill_6 = teavm_local_6;
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_finishedLock);
        teavm_spill_4 = teavm_local_4;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20788, teavm_nullCheck(teavm_local_4));
        teavm_spill_4 = teavm_local_4;
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_3;
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_4 = teavm_spill_4;
            teavm_local_6 = teavm_spill_6;
            teavm_local_5 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_3:;
    TEAVM_TRY
        teavm_spill_6 = teavm_local_6;
        teavm_local_6 = teavm_local_5;
        teavm_spill_6 = teavm_local_6;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(20789, meth_jl_Object_wait_1(teavm_local_4, teavm_local_1, teavm_local_2));
        if ((!meth_otr_Fiber_isSuspending(teavm_local_3))) {
            TEAVM_RESTORE_JUMP_BUFFER;
            goto teavm_label_6;
        }
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_6 = teavm_spill_6;
            teavm_local_5 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
    TEAVM_WITH_CALL_SITE_ID(20790, meth_otr_Fiber_push_1(teavm_local_3, teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(20791, meth_otr_Fiber_push_0(teavm_local_3, teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(20792, meth_otr_Fiber_push(teavm_local_3, teavm_local_5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(20793, meth_otr_Fiber_push(teavm_local_3, teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20794, meth_otr_Fiber_push_0(teavm_local_3, INT32_C(0)));
    goto teavm_label_2;
teavm_label_6:;
    TEAVM_TRY
        teavm_spill_6 = teavm_local_6;
        teavm_local_6 = teavm_local_5;
        teavm_spill_6 = teavm_local_6;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(20795, meth_jl_Object_monitorExit(teavm_local_5));
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_2;
    TEAVM_CATCH
        // CATCH any
        case 1: {
            teavm_local_6 = teavm_spill_6;
            teavm_local_5 = teavm_catchException();
            goto teavm_label_1;
            break;
        }
    TEAVM_END_TRY
teavm_label_2:;
    TEAVM_RELEASE_STACK;
    return;
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20796, meth_jl_Object_monitorExit(teavm_local_6));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(20797, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void meth_jl_Thread_join_1(void* teavm_this_, int64_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_2)) {
        switch (meth_otr_Fiber_popInt(teavm_local_2)) {
            case 0:
                goto teavm_label_2;
            default:
                goto teavm_label_3;
        }
    }
teavm_label_3:;
    teavm_local_3 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = meth_otr_Fiber_popInt(teavm_local_2);
    teavm_local_1 = meth_otr_Fiber_popLong(teavm_local_2);
    teavm_this_ = meth_otr_Fiber_popObject(teavm_local_2);
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_this_);
    TEAVM_WITH_CALL_SITE_ID(20798, meth_jl_Thread_join(teavm_this_, teavm_local_1, teavm_local_3));
    if (meth_otr_Fiber_isSuspending(teavm_local_2)) {
        TEAVM_WITH_CALL_SITE_ID(20799, meth_otr_Fiber_push(teavm_local_2, teavm_this_));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(20800, meth_otr_Fiber_push_1(teavm_local_2, teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(20801, meth_otr_Fiber_push_0(teavm_local_2, teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(20802, meth_otr_Fiber_push_0(teavm_local_2, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_join_0(void* teavm_this_) {
    void* teavm_local_1;
    int64_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_1)) {
        switch (meth_otr_Fiber_popInt(teavm_local_1)) {
            case 0:
                goto teavm_label_2;
            default:
                goto teavm_label_3;
        }
    }
teavm_label_3:;
    teavm_local_2 = INT64_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = meth_otr_Fiber_popLong(teavm_local_1);
    teavm_this_ = meth_otr_Fiber_popObject(teavm_local_1);
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_this_);
    TEAVM_WITH_CALL_SITE_ID(20803, meth_jl_Thread_join_1(teavm_this_, teavm_local_2));
    if (meth_otr_Fiber_isSuspending(teavm_local_1)) {
        TEAVM_WITH_CALL_SITE_ID(20804, meth_otr_Fiber_push(teavm_local_1, teavm_this_));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(20805, meth_otr_Fiber_push_1(teavm_local_1, teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(20806, meth_otr_Fiber_push_0(teavm_local_1, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_yield() {
    void* teavm_local_1;
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int64_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_1)) {
        switch (meth_otr_Fiber_popInt(teavm_local_1)) {
            case 0:
                goto teavm_label_6;
            default:
                goto teavm_label_5;
        }
    teavm_label_6:;
        teavm_local_2 = meth_otr_Fiber_popObject(teavm_local_1);
        goto teavm_label_4;
    }
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20807, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20808, meth_jl_Thread_currentThread());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20809, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = (TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_yieldCount) + INT32_C(1));
    TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_yieldCount) = teavm_local_3;
    if ((teavm_local_3 < INT32_C(30))) {
        goto teavm_label_1;
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20810, meth_jl_Thread_currentThread());
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(20811, teavm_nullCheck(teavm_local_4)), cls_jl_Thread, fld_yieldCount) = INT32_C(0);
    teavm_local_5 = (TEAVM_FIELD(teavm_local_2, cls_jl_Thread, fld_timeSliceStart) + INT64_C(100));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((teavm_local_5 >= TEAVM_WITH_CALL_SITE_ID(20812, meth_jl_System_currentTimeMillis()))) {
        goto teavm_label_3;
    }
teavm_label_4:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20813, meth_jl_Thread_switchContext(teavm_local_2));
    if (meth_otr_Fiber_isSuspending(teavm_local_1)) {
        goto teavm_label_2;
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_WITH_CALL_SITE_ID(20814, meth_otr_Fiber_push(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20815, meth_otr_Fiber_push_0(teavm_local_1, INT32_C(0)));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_switchContext(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = meth_otr_Fiber_current();
    if (meth_otr_Fiber_isResuming(teavm_local_2)) {
        switch (meth_otr_Fiber_popInt(teavm_local_2)) {
            case 0:
                goto teavm_label_3;
            default:
                goto teavm_label_2;
        }
    teavm_label_3:;
        teavm_local_3 = meth_otr_Fiber_popObject(teavm_local_2);
        goto teavm_label_1;
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20816, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20817, meth_otr_Allocator_allocate(&jl_Thread_switchContext_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(20818, meth_jl_Thread_switchContext_0__init_(teavm_local_3, teavm_local_1));
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20819, meth_otr_Fiber_suspend(teavm_local_3));
    if (meth_otr_Fiber_isSuspending(teavm_local_2)) {
        TEAVM_WITH_CALL_SITE_ID(20820, meth_otr_Fiber_push(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(20821, meth_otr_Fiber_push_0(teavm_local_2, INT32_C(0)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_switchContext_0(void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20822, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20823, meth_otr_Allocator_allocate(&jl_Thread_switchContext_lambda__19_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(20824, meth_jl_Thread_switchContext_lambda__19_0__init_(teavm_local_3, teavm_local_1, teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(20825, meth_otr_EventQueue_offer(teavm_local_3));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_interrupt(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_interruptedFlag) = INT32_C(1);
    if ((TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_interruptHandler) != NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_interruptHandler);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(20826, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20827, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_ThreadInterruptHandler_VT, virt_interrupted)(teavm_tmp_ptr_0)));
        TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_interruptHandler) = NULL;
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Thread_interrupted() {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20828, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20829, meth_jl_Thread_currentThread());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20830, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_jl_Thread, fld_interruptedFlag);
    TEAVM_FIELD(teavm_local_1, cls_jl_Thread, fld_interruptedFlag) = INT32_C(0);
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Thread_isAlive(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_alive);
}
int64_t meth_jl_Thread_getId(void* teavm_this_) {
    return (TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_id) + INT64_C(1));
}
void* meth_jl_Thread_getUncaughtExceptionHandler(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_uncaughtExceptionHandler) != NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Thread, fld_uncaughtExceptionHandler);
    } else {
        TEAVM_WITH_CALL_SITE_ID(20831, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
        teavm_local_1 = sfld_jl_Thread_defaultUncaughtExceptionHandler;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jl_Thread_lambda_switchContext_1(void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20832, teavm_initializeClass((TeaVM_Class*) &jl_Thread_Cls, &initclass_jl_Thread));
    TEAVM_WITH_CALL_SITE_ID(20833, meth_jl_Thread_setCurrentThread(teavm_local_1));
    teavm_local_3 = NULL;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20834, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20835, TEAVM_METHOD(teavm_local_2, oti_AsyncCallback_VT, virt_complete_0)(teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread_lambda_start_0(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20836, meth_otr_Allocator_allocate(&jl_Thread_lambda_start_0_lambda__39_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20837, meth_jl_Thread_lambda_start_0_lambda__39_0__init_(teavm_local_2, teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(20838, meth_otr_Fiber_start(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Thread__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20839, meth_otr_Allocator_allocate(&jl_Thread_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20840, meth_jl_Thread__init__1(teavm_local_1, TEAVM_GET_STRING(2832)));
    sfld_jl_Thread_mainThread = teavm_local_1;
    sfld_jl_Thread_currentThread = sfld_jl_Thread_mainThread;
    sfld_jl_Thread_nextId = INT32_C(1);
    sfld_jl_Thread_activeCount = INT32_C(1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20841, meth_otr_Allocator_allocate(&jl_DefaultUncaughtExceptionHandler_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20842, meth_jl_DefaultUncaughtExceptionHandler__init_(teavm_local_1));
    sfld_jl_Thread_defaultUncaughtExceptionHandler = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jl_Thread() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Thread_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Thread__clinit_();
    }
}
int32_t supertypeof_jl_Thread(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1237 || tag >= 1245) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Thread_Cls[7];
alignas(8) jl_Thread_VT jl_Thread_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Thread), sizeof(void*)),
        .flags = 0,
        .tag = 1237,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(2833),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Thread,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Thread_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_isAlive = &meth_jl_Thread_isAlive,
    .virt_getId_0 = &meth_jl_Thread_getId,
    .virt_getUncaughtExceptionHandler = &meth_jl_Thread_getUncaughtExceptionHandler,
    .virt_getName = &meth_jl_Thread_getName,
    .virt_setDaemon = &meth_jl_Thread_setDaemon,
    .virt_start_1 = &meth_jl_Thread_start,
    .virt_join = &meth_jl_Thread_join,
    .virt_interrupt = &meth_jl_Thread_interrupt,
    .virt_join_0 = &meth_jl_Thread_join_0,
    .virt_join_1 = &meth_jl_Thread_join_1
};
static void** teavm_gc_localStaticRoots_jl_Thread_Cls[3] = {
(void**) &sfld_jl_Thread_mainThread, (void**) &sfld_jl_Thread_currentThread, (void**) &sfld_jl_Thread_defaultUncaughtExceptionHandler
};
static int16_t teavm_classLayouts_jl_Thread_Cls[7] = {
INT16_C(6), (int16_t) offsetof(cls_jl_Thread, fld_uncaughtExceptionHandler), (int16_t) offsetof(cls_jl_Thread, fld_finishedLock), (int16_t) offsetof(cls_jl_Thread, fld_interruptHandler), (int16_t) offsetof(cls_jl_Thread, fld_key), (int16_t) offsetof(cls_jl_Thread, fld_name), (int16_t) offsetof(cls_jl_Thread, fld_target)
};
void sysinitclass_jl_Thread() {
sfld_jl_Thread_mainThread = NULL;
sfld_jl_Thread_currentThread = NULL;
sfld_jl_Thread_nextId = INT32_C(0);
sfld_jl_Thread_activeCount = INT32_C(0);
sfld_jl_Thread_defaultUncaughtExceptionHandler = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Thread_Cls, 3);
}
