#pragma once
#include "../../../runtime.h"
#include "RuntimeException.h"
#include "SecurityException.h"

extern void sysinitclass_jl_SecurityException();
typedef struct cls_jl_SecurityException {
    struct cls_jl_RuntimeException parent;
} cls_jl_SecurityException;
extern int32_t supertypeof_jl_SecurityException(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_SecurityException_VT {
    jl_RuntimeException_VT parent;
} jl_SecurityException_VT;
extern jl_SecurityException_VT jl_SecurityException_Cls;
