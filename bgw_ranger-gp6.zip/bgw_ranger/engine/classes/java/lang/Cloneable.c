#include "Cloneable.h"
#include "../../../strings.h"

int32_t supertypeof_jl_Cloneable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 53 || tag >= 1866) return INT32_C(0);
    if (tag >= 55 && tag < 101) return INT32_C(0);
    if (tag >= 105 && tag < 259) return INT32_C(0);
    if (tag >= 261 && tag < 321) return INT32_C(0);
    if (tag >= 323 && tag < 369) return INT32_C(0);
    if (tag >= 371 && tag < 613) return INT32_C(0);
    if (tag >= 615 && tag < 710) return INT32_C(0);
    if (tag >= 712 && tag < 834) return INT32_C(0);
    if (tag >= 838 && tag < 1215) return INT32_C(0);
    if (tag >= 1229 && tag < 1292) return INT32_C(0);
    if (tag >= 1294 && tag < 1295) return INT32_C(0);
    if (tag >= 1297 && tag < 1299) return INT32_C(0);
    if (tag >= 1303 && tag < 1303) return INT32_C(0);
    if (tag >= 1307 && tag < 1343) return INT32_C(0);
    if (tag >= 1347 && tag < 1359) return INT32_C(0);
    if (tag >= 1361 && tag < 1447) return INT32_C(0);
    if (tag >= 1451 && tag < 1645) return INT32_C(0);
    if (tag >= 1647 && tag < 1741) return INT32_C(0);
    if (tag >= 1745 && tag < 1751) return INT32_C(0);
    if (tag >= 1761 && tag < 1838) return INT32_C(0);
    if (tag >= 1840 && tag < 1850) return INT32_C(0);
    if (tag >= 1852 && tag < 1852) return INT32_C(0);
    if (tag >= 1862 && tag < 1864) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jl_Cloneable_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 53,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jl_Cloneable,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jl_Cloneable() {
}
