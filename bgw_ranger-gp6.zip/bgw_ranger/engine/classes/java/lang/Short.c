#include "Short.h"
#include "Number.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrayclass.h"
#include "StringBuilder.h"
#include "Integer.h"
#include "NumberFormatException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../primitives/short.h"
#include "../../../strings.h"
#include "Object.h"

void* sfld_jl_Short_TYPE;
TeaVM_Array* sfld_jl_Short_shortCache;
void meth_jl_Short__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13560, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    TEAVM_WITH_CALL_SITE_ID(13561, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Short, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Short_valueOf(int32_t teavm_local_1) {
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13562, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    if ((!((teavm_local_1 >= -INT32_C(128)) && (teavm_local_1 <= INT32_C(127))))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13563, meth_otr_Allocator_allocate(&jl_Short_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(13564, meth_jl_Short__init_(teavm_local_2, teavm_local_1));
    } else {
        TEAVM_WITH_CALL_SITE_ID(13565, meth_jl_Short_ensureShortCache());
        teavm_local_3 = sfld_jl_Short_shortCache;
        teavm_local_4 = (teavm_local_1 + INT32_C(128));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13566, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(13567, teavm_checkBounds(teavm_local_4, teavm_local_3)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Short_ensureShortCache() {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(13568, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    if ((sfld_jl_Short_shortCache == NULL)) {
        sfld_jl_Short_shortCache = TEAVM_WITH_CALL_SITE_ID(13569, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Short_Cls), INT32_C(256)));
        teavm_local_1 = INT32_C(0);
        while (1) {
            teavm_local_2 = sfld_jl_Short_shortCache;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            if ((teavm_local_1 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(13570, teavm_nullCheck(teavm_local_2))))) {
                goto teavm_label_1;
            }
            teavm_local_2 = sfld_jl_Short_shortCache;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13571, meth_otr_Allocator_allocate(&jl_Short_Cls));
            teavm_local_4 = TEAVM_TO_SHORT((teavm_local_1 - INT32_C(128)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(13572, meth_jl_Short__init_(teavm_local_3, teavm_local_4));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13573, teavm_nullCheck(teavm_local_2));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13574, teavm_checkBounds(teavm_local_1, teavm_local_2));
            teavm_gc_writeBarrier(teavm_local_2);
            TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1) = teavm_local_3;
            teavm_local_1 = (teavm_local_1 + INT32_C(1));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Short_toString(int32_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13575, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13576, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(13577, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13578, TEAVM_METHOD(teavm_local_2, jl_StringBuilder_VT, virt_append_24)(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13579, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13580, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Short_toString_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13581, meth_jl_Short_toString(TEAVM_FIELD(teavm_this_, cls_jl_Short, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Short_equals(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (teavm_instanceof(teavm_local_1, &jl_Short_Cls, &supertypeof_jl_Short)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13582, teavm_checkcast(teavm_local_1, &jl_Short_Cls, &supertypeof_jl_Short));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(13583, teavm_nullCheck(teavm_local_2)), cls_jl_Short, fld_value) == TEAVM_FIELD(teavm_this_, cls_jl_Short, fld_value))) {
            goto teavm_label_2;
        }
    }
    teavm_local_3 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Short_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13584, meth_jl_Short_hashCode_0(TEAVM_FIELD(teavm_this_, cls_jl_Short, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Short_hashCode_0(int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13585, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Short_compare(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13586, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    teavm_local_3 = (teavm_local_1 - teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Short_parseShort(void* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13587, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13588, meth_jl_Integer_parseInt(teavm_local_1, teavm_local_2));
    if (((teavm_local_3 >= -INT32_C(32768)) && (teavm_local_3 <= INT32_C(32767)))) {
        teavm_local_4 = TEAVM_TO_SHORT(teavm_local_3);
        TEAVM_RELEASE_STACK;
        return teavm_local_4;
    }
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13589, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(13590, meth_jl_NumberFormatException__init__0(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(13591, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_Short_parseShort_0(void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13592, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13593, meth_jl_Short_parseShort(teavm_local_1, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Short_valueOf_0(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13594, teavm_initializeClass((TeaVM_Class*) &jl_Short_Cls, &initclass_jl_Short));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13595, meth_jl_Short_valueOf(TEAVM_WITH_CALL_SITE_ID(13596, meth_jl_Short_parseShort_0(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Short__clinit_() {
    sfld_jl_Short_TYPE = teavm_getClassObject((TeaVM_Class*) &S_Cls);
}
void initclass_jl_Short() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Short_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Short__clinit_();
    }
}
int32_t supertypeof_jl_Short(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1970 || tag >= 1972) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Short_VT jl_Short_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Short), sizeof(void*)),
        .flags = 0,
        .tag = 1970,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(1354),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Short,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Short_hashCode,
    .virt_equals = &meth_jl_Short_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Short_toString_0,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
static void** teavm_gc_localStaticRoots_jl_Short_Cls[2] = {
(void**) &sfld_jl_Short_TYPE, (void**) &sfld_jl_Short_shortCache
};
void sysinitclass_jl_Short() {
sfld_jl_Short_TYPE = NULL;
sfld_jl_Short_shortCache = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Short_Cls, 2);
}
