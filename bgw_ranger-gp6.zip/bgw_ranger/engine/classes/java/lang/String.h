#pragma once
#include "../../../runtime.h"
#include "String.h"

extern void sysinitclass_jl_String();
extern TeaVM_Array* sfld_jl_String_EMPTY_CHARS;
extern void* sfld_jl_String_EMPTY;
extern void* sfld_jl_String_CASE_INSENSITIVE_ORDER;
extern void meth_jl_String__init__0(void*);
extern void meth_jl_String__init__1(void*, TeaVM_Array*);
extern void meth_jl_String__init_(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jl_String_fromArray(TeaVM_Array*);
extern void meth_jl_String__init__2(void*, TeaVM_Array*, void*);
extern void meth_jl_String__init__3(void*, TeaVM_Array*, int32_t, int32_t);
extern void meth_jl_String_initWithBytes(void*, TeaVM_Array*, int32_t, int32_t, void*);
extern int32_t meth_jl_String_charAt(void*, int32_t);
extern int32_t meth_jl_String_length(void*);
extern int32_t meth_jl_String_isEmpty(void*);
extern int32_t meth_jl_String_compareTo(void*, void*);
extern int32_t meth_jl_String_startsWith_0(void*, void*, int32_t);
extern int32_t meth_jl_String_startsWith(void*, void*);
extern int32_t meth_jl_String_regionMatches(void*, int32_t, int32_t, void*, int32_t, int32_t);
extern int32_t meth_jl_String_regionMatches_0(void*, int32_t, void*, int32_t, int32_t);
extern int32_t meth_jl_String_endsWith(void*, void*);
extern int32_t meth_jl_String_indexOf_0(void*, int32_t, int32_t);
extern int32_t meth_jl_String_indexOf(void*, int32_t);
extern int32_t meth_jl_String_lastIndexOf_0(void*, int32_t, int32_t);
extern int32_t meth_jl_String_lastIndexOf(void*, int32_t);
extern int32_t meth_jl_String_indexOf_1(void*, void*, int32_t);
extern int32_t meth_jl_String_indexOf_2(void*, void*);
extern int32_t meth_jl_String_lastIndexOf_1(void*, void*, int32_t);
extern void* meth_jl_String_substring_0(void*, int32_t, int32_t);
extern void* meth_jl_String_substring(void*, int32_t);
extern void* meth_jl_String_subSequence(void*, int32_t, int32_t);
extern void* meth_jl_String_replace(void*, int32_t, int32_t);
extern int32_t meth_jl_String_contains(void*, void*);
extern void* meth_jl_String_replace_0(void*, void*, void*);
extern void* meth_jl_String_trim(void*);
extern void* meth_jl_String_toString(void*);
extern TeaVM_Array* meth_jl_String_toCharArray(void*);
extern void* meth_jl_String_valueOf(void*);
extern void* meth_jl_String_valueOf_2(int32_t);
extern void* meth_jl_String_valueOf_0(int32_t);
extern void* meth_jl_String_valueOf_1(int64_t);
extern int32_t meth_jl_String_equals(void*, void*);
extern int32_t meth_jl_String_equalsIgnoreCase(void*, void*);
extern TeaVM_Array* meth_jl_String_getBytes(void*, void*);
extern int32_t meth_jl_String_hashCode(void*);
extern void* meth_jl_String_toLowerCase(void*);
extern void* meth_jl_String_toLowerCaseChars(void*);
extern void* meth_jl_String_toLowerCaseCodePoints(void*);
extern void* meth_jl_String_toLowerCase_0(void*, void*);
extern void* meth_jl_String_toUpperCase(void*);
extern void* meth_jl_String_toUpperCaseChars(void*);
extern void* meth_jl_String_toUpperCaseCodePoints(void*);
extern void* meth_jl_String_toUpperCase_0(void*, void*);
extern TeaVM_Array* meth_jl_String_split(void*, void*);
extern void* meth_jl_String_format(void*, TeaVM_Array*);
extern void* meth_jl_String_join(void*, TeaVM_Array*);
extern int32_t meth_jl_String_compareTo_0(void*, void*);
extern void meth_jl_String__clinit_();
extern void initclass_jl_String();
extern int32_t supertypeof_jl_String(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_String_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad1)(); // 13
    void (*pad2)(); // 14
    void (*pad3)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void* (*virt_subSequence)(void*, int32_t, int32_t); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void (*pad8)(); // 22
    void (*pad9)(); // 23
    void (*pad10)(); // 24
    int32_t (*virt_length)(void*); // 25
    int32_t (*virt_charAt)(void*, int32_t); // 26
    void (*pad11)(); // 27
    void (*pad12)(); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*pad32)(); // 48
    void (*pad33)(); // 49
} jl_String_VT;
extern jl_String_VT jl_String_Cls;
