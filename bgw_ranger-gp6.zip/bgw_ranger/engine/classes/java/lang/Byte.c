#include "Byte.h"
#include "Number.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../primitives/byte.h"
#include "../../../strings.h"
#include "Object.h"

void* sfld_jl_Byte_TYPE;
TeaVM_Array* sfld_jl_Byte_byteCache;
void meth_jl_Byte__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18424, teavm_initializeClass((TeaVM_Class*) &jl_Byte_Cls, &initclass_jl_Byte));
    TEAVM_WITH_CALL_SITE_ID(18425, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Byte, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
TeaVM_Array* meth_jl_Byte_ensureByteCache() {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(18426, teavm_initializeClass((TeaVM_Class*) &jl_Byte_Cls, &initclass_jl_Byte));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18427, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Byte_Cls), INT32_C(256)));
    teavm_local_2 = INT32_C(0);
    while (1) {
        teavm_local_3 = teavm_local_1;
        if ((teavm_local_2 >= TEAVM_ARRAY_LENGTH(teavm_local_3))) {
            goto teavm_label_1;
        }
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18428, meth_otr_Allocator_allocate(&jl_Byte_Cls));
        teavm_local_5 = TEAVM_TO_BYTE((teavm_local_2 - INT32_C(128)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(18429, meth_jl_Byte__init_(teavm_local_4, teavm_local_5));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18430, teavm_checkLowerBound(teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_3);
        TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_4;
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Byte_compare(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18431, teavm_initializeClass((TeaVM_Class*) &jl_Byte_Cls, &initclass_jl_Byte));
    teavm_local_3 = (teavm_local_1 - teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jl_Byte__clinit_() {
    TEAVM_ALLOC_STACK(INT32_C(0));
    sfld_jl_Byte_TYPE = teavm_getClassObject((TeaVM_Class*) &B_Cls);
    sfld_jl_Byte_byteCache = TEAVM_WITH_CALL_SITE_ID(18432, meth_jl_Byte_ensureByteCache());
    TEAVM_RELEASE_STACK;
}
void initclass_jl_Byte() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Byte_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Byte__clinit_();
    }
}
int32_t supertypeof_jl_Byte(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1972 || tag >= 1974) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Byte_VT jl_Byte_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Byte), sizeof(void*)),
        .flags = 0,
        .tag = 1972,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Byte,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
static void** teavm_gc_localStaticRoots_jl_Byte_Cls[2] = {
(void**) &sfld_jl_Byte_TYPE, (void**) &sfld_jl_Byte_byteCache
};
void sysinitclass_jl_Byte() {
sfld_jl_Byte_TYPE = NULL;
sfld_jl_Byte_byteCache = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Byte_Cls, 2);
}
