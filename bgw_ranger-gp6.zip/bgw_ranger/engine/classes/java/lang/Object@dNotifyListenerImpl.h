#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Object@dNotifyListenerImpl.h"

extern void sysinitclass_jl_Object_NotifyListenerImpl();
typedef struct cls_jl_Object_NotifyListenerImpl {
    struct TeaVM_Object parent;
    void* fld_obj;
    void* fld_callback;
    void* fld_currentThread;
    int32_t fld_timerId;
    int8_t fld_expired;
    int8_t fld_performed;
    int32_t fld_lockCount;
} cls_jl_Object_NotifyListenerImpl;
extern void meth_jl_Object_NotifyListenerImpl__init_(void*, void*, void*, int32_t);
extern int32_t meth_jl_Object_NotifyListenerImpl_expired(void*);
extern void meth_jl_Object_NotifyListenerImpl_run(void*);
extern void meth_jl_Object_NotifyListenerImpl_interrupted(void*);
extern void meth_jl_Object_NotifyListenerImpl_lambda_interrupted_2(void*);
extern int32_t supertypeof_jl_Object_NotifyListenerImpl(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Object_NotifyListenerImpl_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_interrupted)(void*); // 11
    int32_t (*virt_expired)(void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void (*virt_run_0)(void*); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} jl_Object_NotifyListenerImpl_VT;
extern jl_Object_NotifyListenerImpl_VT jl_Object_NotifyListenerImpl_Cls;
