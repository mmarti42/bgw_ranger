#include "ThreadLocal.h"
#include "Object.h"
#include "Thread.h"
#include "../util/Map.h"
#include "../util/WeakHashMap.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "ThreadLocal@d1.h"
#include "../../../strings.h"

void* sfld_jl_ThreadLocal_NULL;
void meth_jl_ThreadLocal__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(36865, teavm_initializeClass((TeaVM_Class*) &jl_ThreadLocal_Cls, &initclass_jl_ThreadLocal));
    TEAVM_WITH_CALL_SITE_ID(36866, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_ThreadLocal_get(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    if (TEAVM_WITH_CALL_SITE_ID(36867, meth_jl_ThreadLocal_isInMainThread())) {
        if ((!TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_initialized))) {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36868, TEAVM_METHOD(teavm_this_, jl_ThreadLocal_VT, virt_initialValue)(teavm_this_));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_value) = teavm_local_1;
            TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_initialized) = INT32_C(1);
        }
        TEAVM_WITH_CALL_SITE_ID(36869, meth_jl_ThreadLocal_cleanupMap(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_value);
    } else {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36870, meth_jl_Thread_currentThread());
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(36871, teavm_nullCheck(teavm_local_1)), cls_jl_Thread, fld_key);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(36872, meth_jl_ThreadLocal_initMap(teavm_this_));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36873, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(36874, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_get_3)(teavm_tmp_ptr_0, teavm_local_3)));
        if ((teavm_local_2 == NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36875, TEAVM_METHOD(teavm_this_, jl_ThreadLocal_VT, virt_initialValue)(teavm_this_));
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map);
            teavm_local_4 = ((teavm_local_2 != NULL) ? teavm_local_2 : sfld_jl_ThreadLocal_NULL);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(36876, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(36877, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_put)(teavm_tmp_ptr_0, teavm_local_3, teavm_local_4)));
        } else if ((teavm_local_2 == sfld_jl_ThreadLocal_NULL)) {
            teavm_local_2 = NULL;
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(36878, meth_jl_ThreadLocal_cleanupMap(teavm_this_));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_ThreadLocal_initMap(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36879, meth_otr_Allocator_allocate(&ju_WeakHashMap_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(36880, meth_ju_WeakHashMap__init_(teavm_local_1));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map) = teavm_local_1;
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_ThreadLocal_cleanupMap(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map) != NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        if (TEAVM_WITH_CALL_SITE_ID(36881, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(36882, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_isEmpty)(teavm_tmp_ptr_0)))) {
            TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal, fld_map) = NULL;
        }
    }
    TEAVM_RELEASE_STACK;
}
void* meth_jl_ThreadLocal_withInitial(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(36883, teavm_initializeClass((TeaVM_Class*) &jl_ThreadLocal_Cls, &initclass_jl_ThreadLocal));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36884, meth_otr_Allocator_allocate(&jl_ThreadLocal_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(36885, meth_jl_ThreadLocal_1__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_ThreadLocal_isInMainThread() {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(36886, teavm_initializeClass((TeaVM_Class*) &jl_ThreadLocal_Cls, &initclass_jl_ThreadLocal));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36887, meth_jl_Thread_currentThread());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = ((teavm_local_1 != TEAVM_WITH_CALL_SITE_ID(36888, meth_jl_Thread_getMainThread())) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_ThreadLocal__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36889, meth_otr_Allocator_allocate(&jl_Object_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(36890, meth_jl_Object__init_(teavm_local_1));
    sfld_jl_ThreadLocal_NULL = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jl_ThreadLocal() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_ThreadLocal_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_ThreadLocal__clinit_();
    }
}
int32_t supertypeof_jl_ThreadLocal(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1731 || tag >= 1737) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_ThreadLocal_Cls[3];
alignas(8) jl_ThreadLocal_VT jl_ThreadLocal_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_ThreadLocal), sizeof(void*)),
        .flags = 0,
        .tag = 1731,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_ThreadLocal,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_ThreadLocal_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_get_4 = &meth_jl_ThreadLocal_get
};
static void** teavm_gc_localStaticRoots_jl_ThreadLocal_Cls[1] = {
(void**) &sfld_jl_ThreadLocal_NULL
};
static int16_t teavm_classLayouts_jl_ThreadLocal_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jl_ThreadLocal, fld_map), (int16_t) offsetof(cls_jl_ThreadLocal, fld_value)
};
void sysinitclass_jl_ThreadLocal() {
sfld_jl_ThreadLocal_NULL = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_ThreadLocal_Cls, 1);
}
