#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Object@dMonitor.h"

extern void sysinitclass_jl_Object_Monitor();
typedef struct cls_jl_Object_Monitor {
    struct TeaVM_Object parent;
    void* fld_enteringThreads;
    void* fld_notifyListeners;
    void* fld_owner;
    int32_t fld_count;
    int32_t fld_id;
} cls_jl_Object_Monitor;
extern void meth_jl_Object_Monitor__init_(void*);
extern int32_t supertypeof_jl_Object_Monitor(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Object_Monitor_VT {
    jl_Object_VT parent;
} jl_Object_Monitor_VT;
extern jl_Object_Monitor_VT jl_Object_Monitor_Cls;
