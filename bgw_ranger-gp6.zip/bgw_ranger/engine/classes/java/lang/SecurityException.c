#include "SecurityException.h"
#include "RuntimeException.h"
#include "../../../strings.h"
#include "Object.h"
#include "Throwable.h"

int32_t supertypeof_jl_SecurityException(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 920 || tag >= 922) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_SecurityException_VT jl_SecurityException_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_SecurityException), sizeof(void*)),
                    .flags = 0,
                    .tag = 920,
                    .modifiers = 1,
                    .name = NULL,
                    .simpleName = NULL,
                    .arrayType = NULL,
                    .itemType = NULL,
                    .isSupertypeOf = &supertypeof_jl_SecurityException,
                    .superclass = (TeaVM_Class*) &jl_RuntimeException_Cls,
                    .layout = NULL,
                    .enumValues = NULL,
                    .declaringClass = NULL,
                    .enclosingClass = NULL,
                    .init = NULL
                },
                .virt_hashCode = &meth_jl_Object_hashCode,
                .virt_equals = &meth_jl_Object_equals,
                .virt_clone = &meth_jl_Object_clone,
                .virt_toString = &meth_jl_Throwable_toString,
                .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                .virt_getClass = &meth_jl_Object_getClass,
                .virt_identity = &meth_jl_Object_identity,
                .virt_notifyAll = &meth_jl_Object_notifyAll,
                .virt_wait = &meth_jl_Object_wait,
                .virt_waitImpl = &meth_jl_Object_waitImpl,
                .virt_wait_0 = &meth_jl_Object_wait_0,
                .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
                .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
                .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
                .virt_getMessage = &meth_jl_Throwable_getMessage,
                .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
                .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
            }
        }
    }
};
void sysinitclass_jl_SecurityException() {
}
