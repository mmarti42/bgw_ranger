#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Enum.h"

extern void sysinitclass_jl_Enum();
typedef struct cls_jl_Enum {
    struct TeaVM_Object parent;
    void* fld_name;
    int32_t fld_ordinal;
} cls_jl_Enum;
extern void meth_jl_Enum__init_(void*, void*, int32_t);
extern void* meth_jl_Enum_name(void*);
extern int32_t meth_jl_Enum_ordinal(void*);
extern void* meth_jl_Enum_toString(void*);
extern int32_t meth_jl_Enum_equals(void*, void*);
extern int32_t meth_jl_Enum_hashCode(void*);
extern void* meth_jl_Enum_getDeclaringClass(void*);
extern int32_t meth_jl_Enum_compareTo_0(void*, void*);
extern void* meth_jl_Enum_valueOf(void*, void*);
extern int32_t meth_jl_Enum_compareTo(void*, void*);
extern int32_t supertypeof_jl_Enum(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Enum_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_name)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_getDeclaringClass)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    int32_t (*virt_compareTo_0)(void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    int32_t (*virt_ordinal)(void*); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*pad32)(); // 48
    void (*pad33)(); // 49
} jl_Enum_VT;
extern jl_Enum_VT jl_Enum_Cls;
