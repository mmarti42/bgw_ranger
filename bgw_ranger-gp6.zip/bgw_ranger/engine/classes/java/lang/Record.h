#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Record.h"

extern void sysinitclass_jl_Record();
typedef struct cls_jl_Record {
    struct TeaVM_Object parent;
} cls_jl_Record;
extern void meth_jl_Record__init_(void*);
extern int32_t supertypeof_jl_Record(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Record_VT {
    jl_Object_VT parent;
} jl_Record_VT;
extern jl_Record_VT jl_Record_Cls;
