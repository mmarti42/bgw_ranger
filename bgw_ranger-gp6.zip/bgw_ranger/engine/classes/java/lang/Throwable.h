#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Throwable.h"

extern void sysinitclass_jl_Throwable();
typedef struct cls_jl_Throwable {
    struct TeaVM_Object parent;
    void* fld_message;
    void* fld_cause;
    int8_t fld_suppressionEnabled;
    int8_t fld_writableStackTrace;
    TeaVM_Array* fld_suppressed;
    TeaVM_Array* fld_stackTrace;
} cls_jl_Throwable;
extern void meth_jl_Throwable__init_(void*);
extern void meth_jl_Throwable__init__1(void*, void*);
extern void meth_jl_Throwable__init__0(void*, void*, void*);
extern void meth_jl_Throwable__init__2(void*, void*);
extern void* meth_jl_Throwable_fillInStackTrace(void*);
extern void meth_jl_Throwable_initNativeException(void*);
extern void meth_jl_Throwable_ensureStackTrace(void*);
extern void* meth_jl_Throwable_getMessage(void*);
extern void* meth_jl_Throwable_getLocalizedMessage(void*);
extern void* meth_jl_Throwable_toString(void*);
extern void meth_jl_Throwable_printStackTrace(void*);
extern void meth_jl_Throwable_printStackTrace_0(void*, void*);
extern void meth_jl_Throwable_addSuppressed(void*, void*);
extern int32_t supertypeof_jl_Throwable(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Throwable_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_fillInStackTrace)(void*); // 11
    void (*virt_printStackTrace)(void*); // 12
    void (*pad0)(); // 13
    void (*virt_printStackTrace_0)(void*, void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_getMessage)(void*); // 21
    void (*virt_addSuppressed)(void*, void*); // 22
    void (*pad7)(); // 23
    void (*pad8)(); // 24
    void (*pad9)(); // 25
    void (*pad10)(); // 26
    void (*pad11)(); // 27
    void* (*virt_getLocalizedMessage)(void*); // 28
    void (*pad12)(); // 29
    void (*pad13)(); // 30
    void (*pad14)(); // 31
    void (*pad15)(); // 32
    void (*pad16)(); // 33
    void (*pad17)(); // 34
    void (*pad18)(); // 35
    void (*pad19)(); // 36
    void (*pad20)(); // 37
    void (*pad21)(); // 38
    void (*pad22)(); // 39
    void (*pad23)(); // 40
    void (*pad24)(); // 41
    void (*pad25)(); // 42
    void (*pad26)(); // 43
    void (*pad27)(); // 44
    void (*pad28)(); // 45
    void (*pad29)(); // 46
    void (*pad30)(); // 47
    void (*pad31)(); // 48
    void (*pad32)(); // 49
} jl_Throwable_VT;
extern jl_Throwable_VT jl_Throwable_Cls;
