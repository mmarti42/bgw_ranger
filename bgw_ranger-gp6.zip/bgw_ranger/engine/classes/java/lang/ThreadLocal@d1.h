#pragma once
#include "../../../runtime.h"
#include "ThreadLocal.h"
#include "ThreadLocal@d1.h"

extern void sysinitclass_jl_ThreadLocal_1();
typedef struct cls_jl_ThreadLocal_1 {
    struct cls_jl_ThreadLocal parent;
    void* fld_val_supplier;
} cls_jl_ThreadLocal_1;
extern void meth_jl_ThreadLocal_1__init_(void*, void*);
extern void* meth_jl_ThreadLocal_1_initialValue(void*);
extern int32_t supertypeof_jl_ThreadLocal_1(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_ThreadLocal_1_VT {
    jl_ThreadLocal_VT parent;
} jl_ThreadLocal_1_VT;
extern jl_ThreadLocal_1_VT jl_ThreadLocal_1_Cls;
