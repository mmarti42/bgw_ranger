#include "ThreadInterruptHandler.h"
#include "../../../strings.h"

int32_t supertypeof_jl_ThreadInterruptHandler(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 523 || tag >= 525) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jl_ThreadInterruptHandler_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 523,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jl_ThreadInterruptHandler,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jl_ThreadInterruptHandler() {
}
