#include "Double.h"
#include "Number.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "StringBuilder.h"
#include "String.h"
#include "../../../strings.h"
#include "../../../core.h"
#include "NumberFormatException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../org/teavm/classlib/impl/text/DoubleSynthesizer.h"
#include "../../../primitives/double.h"
#include "Object.h"

void* sfld_jl_Double_TYPE;
void meth_jl_Double__init_(void* teavm_this_, double teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41615, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    TEAVM_WITH_CALL_SITE_ID(41616, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
double meth_jl_Double_doubleValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value);
}
int64_t meth_jl_Double_longValue(void* teavm_this_) {
    return ((int64_t) TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value));
}
void* meth_jl_Double_valueOf_0(double teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41617, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41618, meth_otr_Allocator_allocate(&jl_Double_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(41619, meth_jl_Double__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Double_toString(double teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41620, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41621, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(41622, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41623, TEAVM_METHOD(teavm_local_2, jl_StringBuilder_VT, virt_append_54)(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41624, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41625, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Double_valueOf(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41626, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41627, meth_jl_Double_valueOf_0(TEAVM_WITH_CALL_SITE_ID(41628, meth_jl_Double_parseDouble(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
double meth_jl_Double_parseDouble(void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int64_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int64_t teavm_local_11;
    double teavm_local_12;
    void* teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41629, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41630, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!TEAVM_WITH_CALL_SITE_ID(41631, meth_jl_String_isEmpty(teavm_local_1)))) {
        teavm_local_2 = INT32_C(0);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41632, meth_jl_String_length(teavm_local_1));
        while (1) {
            if ((TEAVM_WITH_CALL_SITE_ID(41633, meth_jl_String_charAt(teavm_local_1, teavm_local_2)) > INT32_C(32))) {
                while (1) {
                    teavm_local_4 = (teavm_local_3 - INT32_C(1));
                    if ((TEAVM_WITH_CALL_SITE_ID(41634, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) > INT32_C(32))) {
                        goto teavm_label_2;
                    }
                    teavm_local_3 = (teavm_local_3 + -INT32_C(1));
                }
            teavm_label_2:;
                teavm_local_5 = (((TEAVM_WITH_CALL_SITE_ID(41635, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) != INT32_C(102)) && ((TEAVM_WITH_CALL_SITE_ID(41636, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) != INT32_C(70)) && ((TEAVM_WITH_CALL_SITE_ID(41637, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) != INT32_C(100)) && (TEAVM_WITH_CALL_SITE_ID(41638, meth_jl_String_charAt(teavm_local_1, teavm_local_4)) != INT32_C(68))))) ? teavm_local_3 : (teavm_local_3 + -INT32_C(1)));
                teavm_local_6 = INT32_C(0);
                if ((TEAVM_WITH_CALL_SITE_ID(41639, meth_jl_String_charAt(teavm_local_1, teavm_local_2)) == INT32_C(45))) {
                    teavm_local_2 = (teavm_local_2 + INT32_C(1));
                    teavm_local_6 = INT32_C(1);
                } else if ((TEAVM_WITH_CALL_SITE_ID(41640, meth_jl_String_charAt(teavm_local_1, teavm_local_2)) == INT32_C(43))) {
                    teavm_local_2 = (teavm_local_2 + INT32_C(1));
                }
                if ((teavm_local_2 != teavm_local_5)) {
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(41641, meth_jl_String_charAt(teavm_local_1, teavm_local_2));
                    teavm_local_8 = INT64_C(0);
                    teavm_local_9 = -INT32_C(1);
                    teavm_local_10 = INT32_C(0);
                    teavm_local_11 = INT64_C(1000000000000000000);
                    if ((teavm_local_7 != INT32_C(46))) {
                        teavm_local_10 = INT32_C(1);
                        if (((teavm_local_7 >= INT32_C(48)) && (teavm_local_7 <= INT32_C(57)))) {
                            while (1) {
                                if (!(teavm_local_2 < teavm_local_5)) break;
                                if ((TEAVM_WITH_CALL_SITE_ID(41642, meth_jl_String_charAt(teavm_local_1, teavm_local_2)) != INT32_C(48))) {
                                    goto teavm_label_6;
                                }
                                teavm_local_2 = (teavm_local_2 + INT32_C(1));
                            }
                            goto teavm_label_5;
                        teavm_label_6:;
                        teavm_label_5:;
                            while (1) {
                                if (!(teavm_local_2 < teavm_local_5)) break;
                                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41643, meth_jl_String_charAt(teavm_local_1, teavm_local_2));
                                if ((teavm_local_4 < INT32_C(48))) {
                                    goto teavm_label_8;
                                }
                                if ((teavm_local_4 > INT32_C(57))) {
                                    goto teavm_label_9;
                                }
                                if ((teavm_local_11 > INT64_C(0))) {
                                    teavm_local_8 = (teavm_local_8 + (teavm_local_11 * ((int64_t) (teavm_local_4 - INT32_C(48)))));
                                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41644, ((int64_t) ((uint64_t) teavm_local_11 / (uint64_t) INT64_C(10))));
                                }
                                teavm_local_9 = (teavm_local_9 + INT32_C(1));
                                teavm_local_2 = (teavm_local_2 + INT32_C(1));
                            }
                            goto teavm_label_4;
                        teavm_label_9:;
                            goto teavm_label_4;
                        teavm_label_8:;
                        } else {
                            if (((teavm_local_7 == INT32_C(73)) && (((teavm_local_3 - teavm_local_2) == INT32_C(8)) && TEAVM_WITH_CALL_SITE_ID(41645, meth_jl_String_regionMatches(teavm_local_1, INT32_C(0), teavm_local_2, TEAVM_GET_STRING(1317), INT32_C(0), INT32_C(8)))))) {
                                teavm_local_12 = ((!teavm_local_6) ? INFINITY : -INFINITY);
                                goto teavm_label_3;
                            }
                            if (((teavm_local_7 == INT32_C(78)) && (((teavm_local_3 - teavm_local_2) == INT32_C(3)) && TEAVM_WITH_CALL_SITE_ID(41646, meth_jl_String_regionMatches(teavm_local_1, INT32_C(0), teavm_local_2, TEAVM_GET_STRING(1318), INT32_C(0), INT32_C(3)))))) {
                                teavm_local_12 = teavm_reinterpretLongToDouble(INT64_C(9221120237041090560));
                                goto teavm_label_3;
                            }
                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41647, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                            TEAVM_WITH_CALL_SITE_ID(41648, meth_jl_NumberFormatException__init__0(teavm_local_13));
                            TEAVM_WITH_CALL_SITE_ID(41649, meth_otr_ExceptionHandling_throwException(teavm_local_13));
                            TEAVM_UNREACHABLE
                        }
                    }
                teavm_label_4:;
                    if (((teavm_local_2 < teavm_local_5) && (TEAVM_WITH_CALL_SITE_ID(41650, meth_jl_String_charAt(teavm_local_1, teavm_local_2)) == INT32_C(46)))) {
                        teavm_local_2 = (teavm_local_2 + INT32_C(1));
                        while (1) {
                            if ((teavm_local_2 >= teavm_local_5)) {
                                goto teavm_label_11;
                            }
                            teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(41651, meth_jl_String_charAt(teavm_local_1, teavm_local_2));
                            teavm_local_4 = teavm_compare_i32(teavm_local_14, INT32_C(48));
                            if ((teavm_local_4 < INT32_C(0))) {
                                goto teavm_label_11;
                            }
                            if ((teavm_local_14 > INT32_C(57))) {
                                goto teavm_label_12;
                            }
                            if (((teavm_local_8 == INT64_C(0)) && (!teavm_local_4))) {
                                teavm_local_9 = (teavm_local_9 + -INT32_C(1));
                            } else if ((teavm_local_11 > INT64_C(0))) {
                                teavm_local_8 = (teavm_local_8 + (teavm_local_11 * ((int64_t) (teavm_local_14 - INT32_C(48)))));
                                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(41652, ((int64_t) ((uint64_t) teavm_local_11 / (uint64_t) INT64_C(10))));
                            }
                            teavm_local_2 = (teavm_local_2 + INT32_C(1));
                            teavm_local_10 = INT32_C(1);
                        }
                    teavm_label_12:;
                    teavm_label_11:;
                        if ((!teavm_local_10)) {
                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41653, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                            TEAVM_WITH_CALL_SITE_ID(41654, meth_jl_NumberFormatException__init__0(teavm_local_13));
                            TEAVM_WITH_CALL_SITE_ID(41655, meth_otr_ExceptionHandling_throwException(teavm_local_13));
                            TEAVM_UNREACHABLE
                        }
                    }
                    if ((teavm_local_2 < teavm_local_5)) {
                        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(41656, meth_jl_String_charAt(teavm_local_1, teavm_local_2));
                        if (((teavm_local_14 != INT32_C(101)) && (teavm_local_14 != INT32_C(69)))) {
                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41657, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                            TEAVM_WITH_CALL_SITE_ID(41658, meth_jl_NumberFormatException__init__0(teavm_local_13));
                            TEAVM_WITH_CALL_SITE_ID(41659, meth_otr_ExceptionHandling_throwException(teavm_local_13));
                            TEAVM_UNREACHABLE
                        }
                        teavm_local_15 = (teavm_local_2 + INT32_C(1));
                        teavm_local_16 = INT32_C(0);
                        if ((teavm_local_15 != teavm_local_5)) {
                            if ((TEAVM_WITH_CALL_SITE_ID(41660, meth_jl_String_charAt(teavm_local_1, teavm_local_15)) == INT32_C(45))) {
                                teavm_local_15 = (teavm_local_15 + INT32_C(1));
                                teavm_local_16 = INT32_C(1);
                            } else if ((TEAVM_WITH_CALL_SITE_ID(41661, meth_jl_String_charAt(teavm_local_1, teavm_local_15)) == INT32_C(43))) {
                                teavm_local_15 = (teavm_local_15 + INT32_C(1));
                            }
                            teavm_local_17 = INT32_C(0);
                            teavm_local_4 = INT32_C(0);
                            while (1) {
                                if ((teavm_local_15 >= teavm_local_5)) {
                                    goto teavm_label_14;
                                }
                                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(41662, meth_jl_String_charAt(teavm_local_1, teavm_local_15));
                                if ((teavm_local_14 < INT32_C(48))) {
                                    goto teavm_label_14;
                                }
                                if ((teavm_local_14 > INT32_C(57))) {
                                    goto teavm_label_15;
                                }
                                teavm_local_17 = ((INT32_C(10) * teavm_local_17) + (teavm_local_14 - INT32_C(48)));
                                teavm_local_4 = INT32_C(1);
                                teavm_local_15 = (teavm_local_15 + INT32_C(1));
                            }
                        teavm_label_15:;
                        teavm_label_14:;
                            if (teavm_local_4) {
                                if (teavm_local_16) {
                                    teavm_local_17 = (-teavm_local_17);
                                }
                                teavm_local_9 = (teavm_local_9 + teavm_local_17);
                                goto teavm_label_13;
                            }
                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41663, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                            TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                            TEAVM_WITH_CALL_SITE_ID(41664, meth_jl_NumberFormatException__init__0(teavm_local_13));
                            TEAVM_WITH_CALL_SITE_ID(41665, meth_otr_ExceptionHandling_throwException(teavm_local_13));
                            TEAVM_UNREACHABLE
                        }
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41666, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                        TEAVM_WITH_CALL_SITE_ID(41667, meth_jl_NumberFormatException__init__0(teavm_local_13));
                        TEAVM_WITH_CALL_SITE_ID(41668, meth_otr_ExceptionHandling_throwException(teavm_local_13));
                        TEAVM_UNREACHABLE
                    }
                teavm_label_13:;
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(41669, meth_otcit_DoubleSynthesizer_synthesizeDouble(teavm_local_8, teavm_local_9, teavm_local_6));
                teavm_label_3:;
                    TEAVM_RELEASE_STACK;
                    return teavm_local_12;
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41670, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                TEAVM_WITH_CALL_SITE_ID(41671, meth_jl_NumberFormatException__init__0(teavm_local_13));
                TEAVM_WITH_CALL_SITE_ID(41672, meth_otr_ExceptionHandling_throwException(teavm_local_13));
                TEAVM_UNREACHABLE
            }
            teavm_local_2 = (teavm_local_2 + INT32_C(1));
            if ((teavm_local_2 == teavm_local_3)) {
                goto teavm_label_1;
            }
        }
    teavm_label_1:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41673, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
        TEAVM_WITH_CALL_SITE_ID(41674, meth_jl_NumberFormatException__init__0(teavm_local_13));
        TEAVM_WITH_CALL_SITE_ID(41675, meth_otr_ExceptionHandling_throwException(teavm_local_13));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(41676, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
    TEAVM_WITH_CALL_SITE_ID(41677, meth_jl_NumberFormatException__init__0(teavm_local_13));
    TEAVM_WITH_CALL_SITE_ID(41678, meth_otr_ExceptionHandling_throwException(teavm_local_13));
    TEAVM_UNREACHABLE
}
void* meth_jl_Double_toString_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41679, meth_jl_Double_toString(TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Double_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    double teavm_local_3;
    void* teavm_local_4;
    double teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if (teavm_instanceof(teavm_local_1, &jl_Double_Cls, &supertypeof_jl_Double)) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(41680, teavm_checkcast(teavm_local_1, &jl_Double_Cls, &supertypeof_jl_Double));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_5 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41681, teavm_nullCheck(teavm_local_4)), cls_jl_Double, fld_value);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if (TEAVM_WITH_CALL_SITE_ID(41682, meth_jl_Double_equals_0(teavm_local_3, teavm_local_5))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Double_equals_0(double teavm_local_1, double teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41683, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41684, meth_jl_Double_equalsWithBits(teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Double_equalsWithBits(double teavm_local_1, double teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41685, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_3 = ((teavm_local_1 != teavm_local_1) ? ((teavm_local_2 == teavm_local_2) ? INT32_C(0) : INT32_C(1)) : ((teavm_reinterpretDoubleToLong(teavm_local_1) != teavm_reinterpretDoubleToLong(teavm_local_2)) ? INT32_C(0) : INT32_C(1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Double_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41686, meth_jl_Double_hashCode_0(TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Double_hashCode_0(double teavm_local_1) {
    int64_t teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41687, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41688, meth_jl_Double_doubleToLongBits(teavm_local_1));
    teavm_local_3 = (((int32_t) ((int64_t) ((uint64_t) teavm_local_2 >> INT32_C(32)))) ^ ((int32_t) teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Double_compare(double teavm_local_1, double teavm_local_2) {
    int32_t teavm_local_3;
    double teavm_local_4;
    double teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41689, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_3 = (((!(teavm_local_1 > teavm_local_2)) ? INT32_C(0) : INT32_C(1)) - ((!(teavm_local_2 > teavm_local_1)) ? INT32_C(0) : INT32_C(1)));
    if ((!teavm_local_3)) {
        teavm_local_4 = (1.0 / teavm_local_1);
        teavm_local_5 = (1.0 / teavm_local_2);
        teavm_local_6 = (((!(teavm_local_4 > teavm_local_5)) ? INT32_C(0) : INT32_C(1)) - ((!(teavm_local_5 > teavm_local_4)) ? INT32_C(0) : INT32_C(1)));
        teavm_local_3 = ((teavm_local_6 + ((teavm_local_2 != teavm_local_2) ? INT32_C(0) : INT32_C(1))) - ((teavm_local_1 != teavm_local_1) ? INT32_C(0) : INT32_C(1)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Double_compareTo(void* teavm_this_, void* teavm_local_1) {
    double teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Double, fld_value);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41690, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41691, meth_jl_Double_compare(teavm_local_2, TEAVM_FIELD(teavm_local_1, cls_jl_Double, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Double_isInfinite(double teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41692, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_2 = ((!((!isfinite(teavm_local_1)) && (!isnan(teavm_local_1)))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int64_t meth_jl_Double_doubleToLongBits(double teavm_local_1) {
    int64_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41693, teavm_initializeClass((TeaVM_Class*) &jl_Double_Cls, &initclass_jl_Double));
    teavm_local_2 = ((!isnan(teavm_local_1)) ? teavm_reinterpretDoubleToLong(teavm_local_1) : INT64_C(9221120237041090560));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Double_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41694, teavm_checkcast(teavm_local_1, &jl_Double_Cls, &supertypeof_jl_Double));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41695, TEAVM_METHOD(teavm_this_, jl_Double_VT, virt_compareTo_12)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Double__clinit_() {
    sfld_jl_Double_TYPE = teavm_getClassObject((TeaVM_Class*) &D_Cls);
}
void initclass_jl_Double() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Double_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Double__clinit_();
    }
}
int32_t supertypeof_jl_Double(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1980 || tag >= 1982) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Double_VT jl_Double_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Double), sizeof(void*)),
        .flags = 0,
        .tag = 1980,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(8068),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Double,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Double_hashCode,
    .virt_equals = &meth_jl_Double_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Double_toString_0,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_compareTo = &meth_jl_Double_compareTo_0,
    .virt_longValue = &meth_jl_Double_longValue,
    .virt_compareTo_12 = &meth_jl_Double_compareTo,
    .virt_doubleValue = &meth_jl_Double_doubleValue
};
static void** teavm_gc_localStaticRoots_jl_Double_Cls[1] = {
(void**) &sfld_jl_Double_TYPE
};
void sysinitclass_jl_Double() {
sfld_jl_Double_TYPE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Double_Cls, 1);
}
