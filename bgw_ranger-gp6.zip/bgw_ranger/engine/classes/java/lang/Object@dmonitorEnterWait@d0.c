#include "Object@dmonitorEnterWait@d0.h"
#include "Object.h"
#include "../../../strings.h"

void meth_jl_Object_monitorEnterWait_0__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_0, fld_param0) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_0, fld_param1) = teavm_local_2;
}
void meth_jl_Object_monitorEnterWait_0_run(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_0, fld_param0);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Object_monitorEnterWait_0, fld_param1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(582, meth_jl_Object_monitorEnterWait(teavm_local_2, teavm_local_3, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Object_monitorEnterWait_0(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 55 || tag >= 57) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Object_monitorEnterWait_0_Cls[2];
alignas(8) jl_Object_monitorEnterWait_0_VT jl_Object_monitorEnterWait_0_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Object_monitorEnterWait_0), sizeof(void*)),
        .flags = 0,
        .tag = 55,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Object_monitorEnterWait_0,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Object_monitorEnterWait_0_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_run = &meth_jl_Object_monitorEnterWait_0_run
};
static int16_t teavm_classLayouts_jl_Object_monitorEnterWait_0_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jl_Object_monitorEnterWait_0, fld_param0)
};
void sysinitclass_jl_Object_monitorEnterWait_0() {
}
