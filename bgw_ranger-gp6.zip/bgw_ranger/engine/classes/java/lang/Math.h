#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Math.h"

extern void sysinitclass_jl_Math();
typedef struct cls_jl_Math {
    struct TeaVM_Object parent;
} cls_jl_Math;
extern int32_t meth_jl_Math_round(float);
extern int32_t meth_jl_Math_toIntExact(int64_t);
extern int32_t meth_jl_Math_min(int32_t, int32_t);
extern int32_t meth_jl_Math_max(int32_t, int32_t);
extern int64_t meth_jl_Math_max_0(int64_t, int64_t);
extern int32_t meth_jl_Math_abs_0(int32_t);
extern int64_t meth_jl_Math_abs(int64_t);
extern double meth_jl_Math_abs_1(double);
extern float meth_jl_Math_signum(float);
extern int32_t supertypeof_jl_Math(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Math_VT {
    jl_Object_VT parent;
} jl_Math_VT;
extern jl_Math_VT jl_Math_Cls;
