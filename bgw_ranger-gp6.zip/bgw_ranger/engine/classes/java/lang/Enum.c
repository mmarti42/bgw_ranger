#include "Enum.h"
#include "Object.h"
#include "String.h"
#include "Class.h"
#include "IllegalArgumentException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "StringBuilder.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Integer.h"
#include "../../../arrayclass.h"

void meth_jl_Enum__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44261, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Enum, fld_name) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jl_Enum, fld_ordinal) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Enum_name(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Enum, fld_name);
}
int32_t meth_jl_Enum_ordinal(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Enum, fld_ordinal);
}
void* meth_jl_Enum_toString(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_Enum, fld_name);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44262, meth_jl_String_toString(TEAVM_WITH_CALL_SITE_ID(44263, teavm_nullCheck(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Enum_equals(void* teavm_this_, void* teavm_local_1) {
    return ((teavm_this_ != teavm_local_1) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jl_Enum_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44264, meth_jl_Object_hashCode(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Enum_getDeclaringClass(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44265, meth_jl_Object_getClass(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44266, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44267, meth_jl_Class_getSuperclass(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    if ((!TEAVM_WITH_CALL_SITE_ID(44268, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(44269, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_equals)(teavm_tmp_ptr_0, teavm_getClassObject((TeaVM_Class*) &jl_Enum_Cls)))))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44270, meth_jl_Class_getSuperclass(teavm_local_1));
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44271, teavm_checkcast(teavm_local_1, &jl_Class_Cls, &supertypeof_jl_Class));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Enum_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44272, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44273, meth_jl_Enum_getDeclaringClass(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(44274, meth_jl_Enum_getDeclaringClass(teavm_this_)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44275, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44276, meth_jl_Enum_getDeclaringClass(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44277, meth_jl_String_valueOf(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(44278, meth_jl_Enum_getDeclaringClass(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(44279, meth_jl_String_valueOf(teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(44280, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
        TEAVM_WITH_CALL_SITE_ID(44281, meth_jl_StringBuilder__init_(teavm_local_5));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(44282, meth_jl_StringBuilder_append(teavm_local_5, TEAVM_GET_STRING(8157)));
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_6);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44283, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44284, teavm_nullCheck(teavm_local_6)), teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44285, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44286, teavm_nullCheck(teavm_local_3)), TEAVM_GET_STRING(1397)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(44287, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44288, teavm_nullCheck(teavm_local_3)), teavm_local_4));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44289, meth_jl_StringBuilder_toString(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(44290, meth_jl_IllegalArgumentException__init__0(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(44291, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_jl_Enum, fld_ordinal);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44292, meth_jl_Enum_ordinal(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44293, meth_jl_Integer_compare(teavm_local_7, teavm_local_8));
    TEAVM_RELEASE_STACK;
    return teavm_local_7;
}
void* meth_jl_Enum_valueOf(void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    void* teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44294, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(44295, meth_jl_Class_getEnumConstants(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(44296, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_Enum_Cls), &teavm_isSupertypeOfArray));
    if ((teavm_local_4 != NULL)) {
        teavm_local_3 = teavm_local_4;
        teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_3);
        teavm_local_6 = INT32_C(0);
        while (1) {
            if ((teavm_local_6 >= teavm_local_5)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44297, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44298, meth_jl_String_valueOf(teavm_local_1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(44299, meth_jl_String_valueOf(teavm_local_2));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(44300, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_10);
                TEAVM_WITH_CALL_SITE_ID(44301, meth_jl_StringBuilder__init_(teavm_local_10));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(44302, meth_jl_StringBuilder_append(teavm_local_10, TEAVM_GET_STRING(8158)));
                TEAVM_GC_ROOT(INT32_C(4), teavm_local_11);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44303, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44304, teavm_nullCheck(teavm_local_11)), teavm_local_8));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(4));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44305, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44306, teavm_nullCheck(teavm_local_8)), TEAVM_GET_STRING(8159)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44307, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44308, teavm_nullCheck(teavm_local_8)), teavm_local_9));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(44309, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(44310, teavm_nullCheck(teavm_local_8)), TEAVM_GET_STRING(8160)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(44311, meth_jl_StringBuilder_toString(teavm_local_10));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                TEAVM_WITH_CALL_SITE_ID(44312, meth_jl_IllegalArgumentException__init__0(teavm_local_7, teavm_local_8));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(44313, meth_otr_ExceptionHandling_throwException(teavm_local_7));
                TEAVM_UNREACHABLE
            }
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(44314, teavm_checkLowerBound(teavm_local_6));
            teavm_local_13 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_12);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_13);
            teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(44315, teavm_nullCheck(teavm_local_13));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44316, meth_jl_Enum_name(teavm_local_13));
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_7);
            if (TEAVM_WITH_CALL_SITE_ID(44317, meth_jl_String_equals(TEAVM_WITH_CALL_SITE_ID(44318, teavm_nullCheck(teavm_local_7)), teavm_local_2))) {
                goto teavm_label_1;
            }
            teavm_local_6 = (teavm_local_12 + INT32_C(1));
        }
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_13;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(44319, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(44320, meth_jl_IllegalArgumentException__init__0(teavm_local_7, TEAVM_GET_STRING(8161)));
    TEAVM_WITH_CALL_SITE_ID(44321, meth_otr_ExceptionHandling_throwException(teavm_local_7));
    TEAVM_UNREACHABLE
}
int32_t meth_jl_Enum_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44322, teavm_checkcast(teavm_local_1, &jl_Enum_Cls, &supertypeof_jl_Enum));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44323, meth_jl_Enum_compareTo_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jl_Enum(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2165 || tag >= 2205) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Enum_Cls[2];
alignas(8) jl_Enum_VT jl_Enum_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Enum), sizeof(void*)),
        .flags = 0,
        .tag = 2165,
        .modifiers = 1025,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(8162),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Enum,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Enum_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Enum_hashCode,
    .virt_equals = &meth_jl_Enum_equals,
    .virt_toString = &meth_jl_Enum_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_name = &meth_jl_Enum_name,
    .virt_compareTo = &meth_jl_Enum_compareTo,
    .virt_getDeclaringClass = &meth_jl_Enum_getDeclaringClass,
    .virt_compareTo_0 = &meth_jl_Enum_compareTo_0,
    .virt_ordinal = &meth_jl_Enum_ordinal
};
static int16_t teavm_classLayouts_jl_Enum_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jl_Enum, fld_name)
};
void sysinitclass_jl_Enum() {
}
