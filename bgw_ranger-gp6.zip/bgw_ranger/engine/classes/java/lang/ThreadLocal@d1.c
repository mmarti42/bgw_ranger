#include "ThreadLocal@d1.h"
#include "ThreadLocal.h"
#include "../util/function/Supplier.h"
#include "../../../strings.h"
#include "Object.h"

void meth_jl_ThreadLocal_1__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal_1, fld_val_supplier) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(8521, meth_jl_ThreadLocal__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_ThreadLocal_1_initialValue(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jl_ThreadLocal_1, fld_val_supplier);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8522, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(8523, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, juf_Supplier_VT, virt_get_4)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_jl_ThreadLocal_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1732 || tag >= 1734) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_ThreadLocal_1_Cls[2];
alignas(8) jl_ThreadLocal_1_VT jl_ThreadLocal_1_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_ThreadLocal_1), sizeof(void*)),
            .flags = 0,
            .tag = 1732,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jl_ThreadLocal_1,
            .superclass = (TeaVM_Class*) &jl_ThreadLocal_Cls,
            .layout = teavm_classLayouts_jl_ThreadLocal_1_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_get_4 = &meth_jl_ThreadLocal_get,
        .virt_initialValue = &meth_jl_ThreadLocal_1_initialValue
    }
};
static int16_t teavm_classLayouts_jl_ThreadLocal_1_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jl_ThreadLocal_1, fld_val_supplier)
};
void sysinitclass_jl_ThreadLocal_1() {
}
