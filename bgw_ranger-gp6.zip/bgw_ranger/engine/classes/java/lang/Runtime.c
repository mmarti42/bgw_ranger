#include "Runtime.h"
#include "Object.h"
#include "../../org/teavm/runtime/GC.h"
#include "../../../heaptrace.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"

void* sfld_jl_Runtime_instance;
void meth_jl_Runtime__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(6450, teavm_initializeClass((TeaVM_Class*) &jl_Runtime_Cls, &initclass_jl_Runtime));
    TEAVM_WITH_CALL_SITE_ID(6451, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int64_t meth_jl_Runtime_freeMemory(void* teavm_this_) {
    return meth_jl_Runtime_freeMemoryLowLevel(teavm_this_);
}
int64_t meth_jl_Runtime_freeMemoryLowLevel(void* teavm_this_) {
    return ((int64_t) meth_otr_GC_getFreeMemory());
}
void* meth_jl_Runtime_getRuntime() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(6452, teavm_initializeClass((TeaVM_Class*) &jl_Runtime_Cls, &initclass_jl_Runtime));
    teavm_local_1 = sfld_jl_Runtime_instance;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int64_t meth_jl_Runtime_totalMemory(void* teavm_this_) {
    return meth_jl_Runtime_totalMemoryLowLevel(teavm_this_);
}
int64_t meth_jl_Runtime_totalMemoryLowLevel(void* teavm_this_) {
    return teavm_gc_availableBytes;
}
void meth_jl_Runtime__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(6453, meth_otr_Allocator_allocate(&jl_Runtime_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(6454, meth_jl_Runtime__init_(teavm_local_1));
    sfld_jl_Runtime_instance = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jl_Runtime() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Runtime_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Runtime__clinit_();
    }
}
int32_t supertypeof_jl_Runtime(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 297 || tag >= 299) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Runtime_VT jl_Runtime_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Runtime), sizeof(void*)),
        .flags = 0,
        .tag = 297,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Runtime,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_totalMemory = &meth_jl_Runtime_totalMemory,
    .virt_freeMemory = &meth_jl_Runtime_freeMemory
};
static void** teavm_gc_localStaticRoots_jl_Runtime_Cls[1] = {
(void**) &sfld_jl_Runtime_instance
};
void sysinitclass_jl_Runtime() {
sfld_jl_Runtime_instance = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Runtime_Cls, 1);
}
