#include "StringBuilder.h"
#include "AbstractStringBuilder.h"
#include "../../../strings.h"
#include "Object.h"

void meth_jl_StringBuilder__init__0(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34232, meth_jl_AbstractStringBuilder__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_StringBuilder__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34233, meth_jl_AbstractStringBuilder__init__0(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jl_StringBuilder__init__1(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34234, meth_jl_AbstractStringBuilder__init__1(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_StringBuilder_append(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34235, meth_jl_AbstractStringBuilder_append(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_4(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34236, meth_jl_AbstractStringBuilder_append_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_0(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34237, meth_jl_AbstractStringBuilder_append_1(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_5(void* teavm_this_, int64_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34238, meth_jl_AbstractStringBuilder_append_8(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_3(void* teavm_this_, float teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34239, meth_jl_AbstractStringBuilder_append_9(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_6(void* teavm_this_, double teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34240, meth_jl_AbstractStringBuilder_append_10(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_1(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34241, meth_jl_AbstractStringBuilder_append_2(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_7(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34242, meth_jl_AbstractStringBuilder_append_3(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_8(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34243, meth_jl_AbstractStringBuilder_append_4(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_9(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34244, meth_jl_AbstractStringBuilder_append_5(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_10(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34245, meth_jl_AbstractStringBuilder_append_6(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_append_2(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34246, meth_jl_AbstractStringBuilder_append_11(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert(void* teavm_this_, int32_t teavm_local_1, int64_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34247, meth_jl_AbstractStringBuilder_insert_6(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_0(void* teavm_this_, int32_t teavm_local_1, float teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34248, meth_jl_AbstractStringBuilder_insert_7(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_1(void* teavm_this_, int32_t teavm_local_1, double teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34249, meth_jl_AbstractStringBuilder_insert_8(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_2(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34250, meth_jl_AbstractStringBuilder_insert(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_3(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34251, meth_jl_AbstractStringBuilder_insert_10(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_4(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34252, meth_jl_AbstractStringBuilder_insert_0(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_5(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34253, meth_jl_AbstractStringBuilder_insert_1(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_6(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34254, meth_jl_AbstractStringBuilder_insert_9(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_7(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34255, meth_jl_AbstractStringBuilder_insert_2(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_delete(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34256, meth_jl_AbstractStringBuilder_delete(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_deleteCharAt(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34257, meth_jl_AbstractStringBuilder_deleteCharAt(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_insert_8(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34258, meth_jl_AbstractStringBuilder_insert_3(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuilder_substring(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34259, meth_jl_AbstractStringBuilder_substring(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jl_StringBuilder_setLength(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34260, meth_jl_AbstractStringBuilder_setLength(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_StringBuilder_getChars(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34261, meth_jl_AbstractStringBuilder_getChars(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_StringBuilder_subSequence(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34262, meth_jl_AbstractStringBuilder_subSequence(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuilder_insert_9(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(34263, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_17)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jl_StringBuilder_append_11(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(34264, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_append_52)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_StringBuilder_insert_10(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34265, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_18)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_StringBuilder_append_12(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34266, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_append_53)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_StringBuilder_charAt(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34267, meth_jl_AbstractStringBuilder_charAt(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_StringBuilder_length(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34268, meth_jl_AbstractStringBuilder_length(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_StringBuilder_toString(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34269, meth_jl_AbstractStringBuilder_toString(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jl_StringBuilder_ensureCapacity(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34270, meth_jl_AbstractStringBuilder_ensureCapacity(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_StringBuilder_insert_11(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34271, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_19)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuilder_insert_12(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34272, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_20)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_StringBuilder_insert_13(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34273, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_21)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuilder_insert_14(void* teavm_this_, int32_t teavm_local_1, double teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34274, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_22)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuilder_insert_15(void* teavm_this_, int32_t teavm_local_1, float teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34275, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_23)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuilder_insert_16(void* teavm_this_, int32_t teavm_local_1, int64_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34276, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_24)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuilder_insert_17(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34277, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_insert_25)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_StringBuilder_append_13(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34278, TEAVM_METHOD(teavm_this_, jl_StringBuilder_VT, virt_append_25)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_jl_StringBuilder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 236 || tag >= 238) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_StringBuilder_VT jl_StringBuilder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_StringBuilder), sizeof(void*)),
        .flags = 0,
        .tag = 236,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7682),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_StringBuilder,
        .superclass = (TeaVM_Class*) &jl_AbstractStringBuilder_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_StringBuilder_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_insert_4 = &meth_jl_StringBuilder_insert_17,
    .virt_append = &meth_jl_AbstractStringBuilder_append_7,
    .virt_insert_5 = &meth_jl_AbstractStringBuilder_insert_4,
    .virt_insert_6 = &meth_jl_StringBuilder_insert_11,
    .virt_insert_22 = &meth_jl_StringBuilder_insert_1,
    .virt_subSequence = &meth_jl_StringBuilder_subSequence,
    .virt_insert_20 = &meth_jl_StringBuilder_insert_5,
    .virt_insert_7 = &meth_jl_StringBuilder_insert_13,
    .virt_insert_8 = &meth_jl_StringBuilder_insert_12,
    .virt_insert_9 = &meth_jl_StringBuilder_insert_9,
    .virt_append_7 = &meth_jl_StringBuilder_append_11,
    .virt_append_8 = &meth_jl_StringBuilder_append_12,
    .virt_insert_10 = &meth_jl_StringBuilder_insert_15,
    .virt_length = &meth_jl_StringBuilder_length,
    .virt_charAt = &meth_jl_StringBuilder_charAt,
    .virt_ensureCapacity = &meth_jl_StringBuilder_ensureCapacity,
    .virt_insert_11 = &meth_jl_AbstractStringBuilder_insert_5,
    .virt_substring = &meth_jl_StringBuilder_substring,
    .virt_insert_17 = &meth_jl_StringBuilder_insert_4,
    .virt_insert_12 = &meth_jl_StringBuilder_insert_14,
    .virt_insert_23 = &meth_jl_StringBuilder_insert_0,
    .virt_deleteCharAt_0 = &meth_jl_StringBuilder_deleteCharAt,
    .virt_getChars = &meth_jl_StringBuilder_getChars,
    .virt_append_19 = &meth_jl_StringBuilder_append_13,
    .virt_insert_14 = &meth_jl_StringBuilder_insert_16,
    .virt_insert_15 = &meth_jl_StringBuilder_insert_10,
    .virt_setLength = &meth_jl_StringBuilder_setLength,
    .virt_append_1 = &meth_jl_StringBuilder_append,
    .virt_insert_24 = &meth_jl_StringBuilder_insert,
    .virt_append_53 = &meth_jl_StringBuilder_append_9,
    .virt_insert_21 = &meth_jl_StringBuilder_insert_7,
    .virt_insert_16 = &meth_jl_StringBuilder_insert_3,
    .virt_delete_1 = &meth_jl_StringBuilder_delete,
    .virt_append_54 = &meth_jl_StringBuilder_append_6,
    .virt_insert_25 = &meth_jl_StringBuilder_insert_8,
    .virt_append_4 = &meth_jl_StringBuilder_append_2,
    .virt_append_0 = &meth_jl_StringBuilder_append_4,
    .virt_append_27 = &meth_jl_StringBuilder_append_8,
    .virt_append_25 = &meth_jl_StringBuilder_append_10,
    .virt_insert_19 = &meth_jl_StringBuilder_insert_6,
    .virt_append_24 = &meth_jl_StringBuilder_append_0,
    .virt_insert_18 = &meth_jl_StringBuilder_insert_2,
    .virt_append_26 = &meth_jl_StringBuilder_append_5,
    .virt_append_28 = &meth_jl_StringBuilder_append_1,
    .virt_append_52 = &meth_jl_StringBuilder_append_7,
    .virt_append_55 = &meth_jl_StringBuilder_append_3
};
void sysinitclass_jl_StringBuilder() {
}
