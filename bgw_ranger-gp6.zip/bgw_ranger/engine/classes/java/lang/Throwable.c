#include "Throwable.h"
#include "Object.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "StackTraceElement.h"
#include "Class.h"
#include "../../../strings.h"
#include "StringBuilder.h"
#include "System.h"
#include "../io/PrintStream.h"
#include "../util/Arrays.h"

void meth_jl_Throwable__init_(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17164, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Throwable_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(17165, meth_jl_Throwable_initNativeException(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressionEnabled) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_writableStackTrace) = INT32_C(1);
    TEAVM_WITH_CALL_SITE_ID(17166, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_fillInStackTrace)(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Throwable__init__1(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17167, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Throwable_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed) = teavm_local_2;
    TEAVM_WITH_CALL_SITE_ID(17168, meth_jl_Throwable_initNativeException(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressionEnabled) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_writableStackTrace) = INT32_C(1);
    TEAVM_WITH_CALL_SITE_ID(17169, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_fillInStackTrace)(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_message) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Throwable__init__0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17170, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Throwable_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed) = teavm_local_3;
    TEAVM_WITH_CALL_SITE_ID(17171, meth_jl_Throwable_initNativeException(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressionEnabled) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_writableStackTrace) = INT32_C(1);
    TEAVM_WITH_CALL_SITE_ID(17172, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_fillInStackTrace)(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_message) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_cause) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_jl_Throwable__init__2(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17173, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Throwable_Cls), INT32_C(0)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed) = teavm_local_2;
    TEAVM_WITH_CALL_SITE_ID(17174, meth_jl_Throwable_initNativeException(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressionEnabled) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_writableStackTrace) = INT32_C(1);
    TEAVM_WITH_CALL_SITE_ID(17175, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_fillInStackTrace)(teavm_this_));
    teavm_local_3 = ((teavm_local_1 == NULL) ? NULL : TEAVM_WITH_CALL_SITE_ID(17176, TEAVM_METHOD(teavm_local_1, jl_Throwable_VT, virt_toString)(teavm_local_1)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_message) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_cause) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Throwable_fillInStackTrace(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17177, meth_otr_ExceptionHandling_fillStackTrace());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17178, teavm_checkcast(teavm_local_1, teavm_getArrayClass((TeaVM_Class*) &jl_StackTraceElement_Cls), &teavm_isSupertypeOfArray));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_stackTrace) = teavm_local_1;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jl_Throwable_initNativeException(void* teavm_this_) {
    return;
}
void meth_jl_Throwable_ensureStackTrace(void* teavm_this_) {
    return;
}
void* meth_jl_Throwable_getMessage(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_message);
}
void* meth_jl_Throwable_getLocalizedMessage(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17179, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_getMessage)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_Throwable_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17180, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_getLocalizedMessage)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17181, meth_jl_Object_getClass(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17182, meth_jl_Class_getName(TEAVM_WITH_CALL_SITE_ID(17183, teavm_nullCheck(teavm_local_2))));
    if ((teavm_local_1 == NULL)) {
        teavm_local_3 = TEAVM_GET_STRING(34);
    } else {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17184, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(17185, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17186, meth_jl_StringBuilder_append(teavm_local_3, TEAVM_GET_STRING(10)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(17187, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(17188, teavm_nullCheck(teavm_local_4)), teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17189, meth_jl_StringBuilder_toString(teavm_local_3));
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17190, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(17191, meth_jl_StringBuilder__init_(teavm_local_4));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17192, meth_jl_StringBuilder_append(teavm_local_4, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(17193, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(17194, teavm_nullCheck(teavm_local_2)), teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17195, meth_jl_StringBuilder_toString(teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Throwable_printStackTrace(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17196, meth_jl_System_err());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(17197, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_printStackTrace_0)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_Throwable_printStackTrace_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17198, meth_jl_Object_getClass(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17199, meth_jl_Class_getName(TEAVM_WITH_CALL_SITE_ID(17200, teavm_nullCheck(teavm_local_2))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17201, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(17202, TEAVM_METHOD(teavm_local_1, ji_PrintStream_VT, virt_print_1)(teavm_local_1, teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17203, TEAVM_METHOD(teavm_this_, jl_Throwable_VT, virt_getLocalizedMessage)(teavm_this_));
    if ((teavm_local_3 != NULL)) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17204, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(17205, meth_jl_StringBuilder__init_(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17206, meth_jl_StringBuilder_append(teavm_local_2, TEAVM_GET_STRING(10)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(17207, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(17208, teavm_nullCheck(teavm_local_4)), teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17209, meth_jl_StringBuilder_toString(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_WITH_CALL_SITE_ID(17210, TEAVM_METHOD(teavm_local_1, ji_PrintStream_VT, virt_print_1)(teavm_local_1, teavm_local_2));
    }
    TEAVM_WITH_CALL_SITE_ID(17211, TEAVM_METHOD(teavm_local_1, ji_PrintStream_VT, virt_println_0)(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(17212, meth_jl_Throwable_ensureStackTrace(teavm_this_));
    if ((TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_stackTrace) != NULL)) {
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_stackTrace);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(17213, teavm_nullCheck(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_LENGTH(teavm_local_5);
        teavm_local_7 = INT32_C(0);
        while (1) {
            if ((teavm_local_7 >= teavm_local_6)) {
                goto teavm_label_1;
            }
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(17214, teavm_checkLowerBound(teavm_local_7));
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_8);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
            TEAVM_WITH_CALL_SITE_ID(17215, TEAVM_METHOD(teavm_local_1, ji_PrintStream_VT, virt_print_1)(teavm_local_1, TEAVM_GET_STRING(1579)));
            TEAVM_WITH_CALL_SITE_ID(17216, TEAVM_METHOD(teavm_local_1, ji_PrintStream_VT, virt_println_1)(teavm_local_1, teavm_local_9));
            teavm_local_7 = (teavm_local_8 + INT32_C(1));
        }
    }
teavm_label_1:;
    if (((TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_cause) != NULL) && (TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_cause) != teavm_this_))) {
        TEAVM_WITH_CALL_SITE_ID(17217, TEAVM_METHOD(teavm_local_1, ji_PrintStream_VT, virt_print_1)(teavm_local_1, TEAVM_GET_STRING(1580)));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_cause);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(17218, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17219, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Throwable_VT, virt_printStackTrace_0)(teavm_tmp_ptr_0, teavm_local_1)));
    }
    TEAVM_RELEASE_STACK;
}
void meth_jl_Throwable_addSuppressed(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressionEnabled)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(17220, teavm_nullCheck(teavm_local_3))) + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17221, meth_ju_Arrays_copyOf(teavm_local_2, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17222, teavm_checkcast(teavm_local_2, teavm_getArrayClass((TeaVM_Class*) &jl_Throwable_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed) = teavm_local_2;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jl_Throwable, fld_suppressed);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(17223, teavm_nullCheck(teavm_local_3))) - INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17224, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17225, teavm_checkBounds(teavm_local_4, teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_4) = teavm_local_1;
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_Throwable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 841 || tag >= 949) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jl_Throwable_Cls[5];
alignas(8) jl_Throwable_VT jl_Throwable_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Throwable), sizeof(void*)),
        .flags = 0,
        .tag = 841,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Throwable,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jl_Throwable_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Throwable_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
    .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
    .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
    .virt_getMessage = &meth_jl_Throwable_getMessage,
    .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
    .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
};
static int16_t teavm_classLayouts_jl_Throwable_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jl_Throwable, fld_message), (int16_t) offsetof(cls_jl_Throwable, fld_cause), (int16_t) offsetof(cls_jl_Throwable, fld_suppressed), (int16_t) offsetof(cls_jl_Throwable, fld_stackTrace)
};
void sysinitclass_jl_Throwable() {
}
