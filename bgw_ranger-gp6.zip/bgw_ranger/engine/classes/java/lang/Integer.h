#pragma once
#include "../../../runtime.h"
#include "Number.h"
#include "Integer.h"

extern void sysinitclass_jl_Integer();
typedef struct cls_jl_Integer {
    struct cls_jl_Number parent;
    int32_t fld_value;
} cls_jl_Integer;
extern void* sfld_jl_Integer_TYPE;
extern TeaVM_Array* sfld_jl_Integer_integerCache;
extern void meth_jl_Integer__init_(void*, int32_t);
extern void* meth_jl_Integer_toString(int32_t, int32_t);
extern int32_t meth_jl_Integer_hashCode(int32_t);
extern void* meth_jl_Integer_toHexString(int32_t);
extern void* meth_jl_Integer_toString_0(int32_t);
extern int32_t meth_jl_Integer_parseInt(void*, int32_t);
extern int32_t meth_jl_Integer_parseIntImpl(void*, int32_t, int32_t, int32_t);
extern int32_t meth_jl_Integer_parseInt_0(void*);
extern void* meth_jl_Integer_valueOf(void*, int32_t);
extern void* meth_jl_Integer_valueOf_1(void*);
extern void* meth_jl_Integer_valueOf_0(int32_t);
extern void meth_jl_Integer_ensureIntegerCache();
extern int32_t meth_jl_Integer_intValue(void*);
extern int64_t meth_jl_Integer_longValue(void*);
extern double meth_jl_Integer_doubleValue(void*);
extern void* meth_jl_Integer_toString_1(void*);
extern int32_t meth_jl_Integer_hashCode_0(void*);
extern int32_t meth_jl_Integer_equals(void*, void*);
extern int32_t meth_jl_Integer_decodeDigit(int32_t);
extern int32_t meth_jl_Integer_compareTo(void*, void*);
extern int32_t meth_jl_Integer_compare(int32_t, int32_t);
extern int32_t meth_jl_Integer_numberOfLeadingZeros(int32_t);
extern int32_t meth_jl_Integer_numberOfTrailingZeros(int32_t);
extern int32_t meth_jl_Integer_rotateLeft(int32_t, int32_t);
extern int32_t meth_jl_Integer_compareTo_0(void*, void*);
extern void meth_jl_Integer__clinit_();
extern void initclass_jl_Integer();
extern int32_t supertypeof_jl_Integer(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Integer_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_intValue)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    int64_t (*virt_longValue)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    int32_t (*virt_compareTo_1)(void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    double (*virt_doubleValue)(void*); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*pad32)(); // 48
    void (*pad33)(); // 49
} jl_Integer_VT;
extern jl_Integer_VT jl_Integer_Cls;
