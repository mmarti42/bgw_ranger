#include "StringBuffer.h"
#include "AbstractStringBuilder.h"
#include "../../../strings.h"
#include "Object.h"

void meth_jl_StringBuffer__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1404, meth_jl_AbstractStringBuilder__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_StringBuffer__init__0(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1405, meth_jl_AbstractStringBuilder__init__0(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_StringBuffer_append(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1406, meth_jl_AbstractStringBuilder_append(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_0(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1407, meth_jl_AbstractStringBuilder_append_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_1(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1408, meth_jl_AbstractStringBuilder_append_1(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_2(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1409, meth_jl_AbstractStringBuilder_append_2(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_3(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1410, meth_jl_AbstractStringBuilder_append_3(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_4(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1411, meth_jl_AbstractStringBuilder_append_4(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_5(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1412, meth_jl_AbstractStringBuilder_append_5(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_append_6(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1413, meth_jl_AbstractStringBuilder_append_6(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_insert(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1414, meth_jl_AbstractStringBuilder_insert(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_insert_0(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1415, meth_jl_AbstractStringBuilder_insert_0(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_insert_1(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1416, meth_jl_AbstractStringBuilder_insert_1(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_insert_2(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1417, meth_jl_AbstractStringBuilder_insert_2(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jl_StringBuffer_insert_3(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1418, meth_jl_AbstractStringBuilder_insert_3(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jl_StringBuffer_setLength(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1419, meth_jl_AbstractStringBuilder_setLength(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_StringBuffer_insert_4(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1420, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_insert)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jl_StringBuffer_append_7(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1421, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_append_5)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jl_StringBuffer_insert_5(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1422, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_insert_0)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_StringBuffer_append_8(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1423, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_append_6)(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_StringBuffer_charAt(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1424, meth_jl_AbstractStringBuilder_charAt(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_StringBuffer_length(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1425, meth_jl_AbstractStringBuilder_length(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jl_StringBuffer_toString(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1426, meth_jl_AbstractStringBuilder_toString(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jl_StringBuffer_ensureCapacity(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1427, meth_jl_AbstractStringBuilder_ensureCapacity(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jl_StringBuffer_insert_6(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1428, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_insert_1)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_StringBuffer_insert_7(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1429, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_insert_2)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jl_StringBuffer_insert_8(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1430, TEAVM_METHOD(teavm_this_, jl_StringBuffer_VT, virt_insert_3)(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jl_StringBuffer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 234 || tag >= 236) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_StringBuffer_VT jl_StringBuffer_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_StringBuffer), sizeof(void*)),
        .flags = 0,
        .tag = 234,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(104),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_StringBuffer,
        .superclass = (TeaVM_Class*) &jl_AbstractStringBuilder_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_StringBuffer_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_insert_4 = &meth_jl_StringBuffer_insert_8,
    .virt_append = &meth_jl_AbstractStringBuilder_append_7,
    .virt_insert_5 = &meth_jl_AbstractStringBuilder_insert_4,
    .virt_insert_7 = &meth_jl_StringBuffer_insert_7,
    .virt_insert_8 = &meth_jl_StringBuffer_insert_6,
    .virt_insert_9 = &meth_jl_StringBuffer_insert_4,
    .virt_append_7 = &meth_jl_StringBuffer_append_7,
    .virt_append_8 = &meth_jl_StringBuffer_append_8,
    .virt_length = &meth_jl_StringBuffer_length,
    .virt_charAt = &meth_jl_StringBuffer_charAt,
    .virt_ensureCapacity = &meth_jl_StringBuffer_ensureCapacity,
    .virt_insert_11 = &meth_jl_AbstractStringBuilder_insert_5,
    .virt_append_2 = &meth_jl_StringBuffer_append_1,
    .virt_append_15 = &meth_jl_StringBuffer_append_6,
    .virt_insert_15 = &meth_jl_StringBuffer_insert_5,
    .virt_setLength = &meth_jl_StringBuffer_setLength,
    .virt_append_21 = &meth_jl_StringBuffer_append,
    .virt_insert_3 = &meth_jl_StringBuffer_insert_3,
    .virt_insert_2 = &meth_jl_StringBuffer_insert_2,
    .virt_append_3 = &meth_jl_StringBuffer_append_2,
    .virt_insert_1 = &meth_jl_StringBuffer_insert_1,
    .virt_append_22 = &meth_jl_StringBuffer_append_0,
    .virt_append_23 = &meth_jl_StringBuffer_append_4,
    .virt_append_5 = &meth_jl_StringBuffer_append_3,
    .virt_insert = &meth_jl_StringBuffer_insert_0,
    .virt_append_6 = &meth_jl_StringBuffer_append_5,
    .virt_insert_0 = &meth_jl_StringBuffer_insert
};
void sysinitclass_jl_StringBuffer() {
}
