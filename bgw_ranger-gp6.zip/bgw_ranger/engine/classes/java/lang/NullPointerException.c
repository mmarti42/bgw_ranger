#include "NullPointerException.h"
#include "RuntimeException.h"
#include "../../../strings.h"
#include "Object.h"
#include "Throwable.h"

void meth_jl_NullPointerException__init__0(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30736, meth_jl_RuntimeException__init__0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_jl_NullPointerException__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30737, meth_jl_RuntimeException__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jl_NullPointerException(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 926 || tag >= 928) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_NullPointerException_VT jl_NullPointerException_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_NullPointerException), sizeof(void*)),
                    .flags = 0,
                    .tag = 926,
                    .modifiers = 1,
                    .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7513),
                    .simpleName = NULL,
                    .arrayType = NULL,
                    .itemType = NULL,
                    .isSupertypeOf = &supertypeof_jl_NullPointerException,
                    .superclass = (TeaVM_Class*) &jl_RuntimeException_Cls,
                    .layout = NULL,
                    .enumValues = NULL,
                    .declaringClass = NULL,
                    .enclosingClass = NULL,
                    .init = NULL
                },
                .virt_hashCode = &meth_jl_Object_hashCode,
                .virt_equals = &meth_jl_Object_equals,
                .virt_clone = &meth_jl_Object_clone,
                .virt_toString = &meth_jl_Throwable_toString,
                .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                .virt_getClass = &meth_jl_Object_getClass,
                .virt_identity = &meth_jl_Object_identity,
                .virt_notifyAll = &meth_jl_Object_notifyAll,
                .virt_wait = &meth_jl_Object_wait,
                .virt_waitImpl = &meth_jl_Object_waitImpl,
                .virt_wait_0 = &meth_jl_Object_wait_0,
                .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
                .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
                .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
                .virt_getMessage = &meth_jl_Throwable_getMessage,
                .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
                .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
            }
        }
    }
};
void sysinitclass_jl_NullPointerException() {
}
