#pragma once
#include "../../../runtime.h"
#include "Object.h"
#include "Boolean.h"

extern void sysinitclass_jl_Boolean();
typedef struct cls_jl_Boolean {
    struct TeaVM_Object parent;
    int8_t fld_value;
} cls_jl_Boolean;
extern void* sfld_jl_Boolean_TRUE;
extern void* sfld_jl_Boolean_FALSE;
extern void* sfld_jl_Boolean_TYPE;
extern void meth_jl_Boolean__init_(void*, int32_t);
extern int32_t meth_jl_Boolean_compareTo(void*, void*);
extern int32_t meth_jl_Boolean_compare(int32_t, int32_t);
extern int32_t meth_jl_Boolean_parseBoolean(void*);
extern int32_t meth_jl_Boolean_booleanValue(void*);
extern void* meth_jl_Boolean_valueOf(int32_t);
extern void* meth_jl_Boolean_valueOf_0(void*);
extern void* meth_jl_Boolean_toString(int32_t);
extern void* meth_jl_Boolean_toString_0(void*);
extern int32_t meth_jl_Boolean_hashCode(void*);
extern int32_t meth_jl_Boolean_hashCode_0(int32_t);
extern int32_t meth_jl_Boolean_equals(void*, void*);
extern int32_t meth_jl_Boolean_compareTo_0(void*, void*);
extern void meth_jl_Boolean__clinit_();
extern void initclass_jl_Boolean();
extern int32_t supertypeof_jl_Boolean(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_Boolean_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_booleanValue)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*pad1)(); // 14
    void (*pad2)(); // 15
    void (*pad3)(); // 16
    void (*pad4)(); // 17
    void (*pad5)(); // 18
    void (*pad6)(); // 19
    void (*pad7)(); // 20
    void (*pad8)(); // 21
    void (*pad9)(); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    int32_t (*virt_compareTo_7)(void*, void*); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} jl_Boolean_VT;
extern jl_Boolean_VT jl_Boolean_Cls;
