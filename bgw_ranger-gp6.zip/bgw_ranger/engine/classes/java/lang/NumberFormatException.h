#pragma once
#include "../../../runtime.h"
#include "IllegalArgumentException.h"
#include "NumberFormatException.h"

extern void sysinitclass_jl_NumberFormatException();
typedef struct cls_jl_NumberFormatException {
    struct cls_jl_IllegalArgumentException parent;
} cls_jl_NumberFormatException;
extern void meth_jl_NumberFormatException__init__0(void*);
extern void meth_jl_NumberFormatException__init_(void*, void*);
extern int32_t supertypeof_jl_NumberFormatException(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_NumberFormatException_VT {
    jl_IllegalArgumentException_VT parent;
} jl_NumberFormatException_VT;
extern jl_NumberFormatException_VT jl_NumberFormatException_Cls;
