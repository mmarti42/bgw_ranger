#pragma once
#include "../../../runtime.h"
#include "Exception.h"
#include "CloneNotSupportedException.h"

extern void sysinitclass_jl_CloneNotSupportedException();
typedef struct cls_jl_CloneNotSupportedException {
    struct cls_jl_Exception parent;
} cls_jl_CloneNotSupportedException;
extern int32_t supertypeof_jl_CloneNotSupportedException(TeaVM_Class*, TeaVM_Class*);
typedef struct jl_CloneNotSupportedException_VT {
    jl_Exception_VT parent;
} jl_CloneNotSupportedException_VT;
extern jl_CloneNotSupportedException_VT jl_CloneNotSupportedException_Cls;
