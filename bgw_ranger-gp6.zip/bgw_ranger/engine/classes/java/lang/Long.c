#include "Long.h"
#include "Number.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "NumberFormatException.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "String.h"
#include "CharSequence.h"
#include "StringBuilder.h"
#include "../../../primitives/long.h"
#include "Object.h"

void* sfld_jl_Long_TYPE;
void meth_jl_Long__init_(void* teavm_this_, int64_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33910, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    TEAVM_WITH_CALL_SITE_ID(33911, meth_jl_Number__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jl_Long_valueOf(int64_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33912, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33913, meth_otr_Allocator_allocate(&jl_Long_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(33914, meth_jl_Long__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int64_t meth_jl_Long_parseLong(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    int64_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33915, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    if ((teavm_local_1 == NULL)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33916, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(33917, meth_jl_NumberFormatException__init_(teavm_local_3, TEAVM_GET_STRING(8)));
        TEAVM_WITH_CALL_SITE_ID(33918, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(33919, meth_jl_Long_parseLongImpl(teavm_local_1, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(33920, meth_jl_String_length(teavm_local_1)), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int64_t meth_jl_Long_parseLongImpl(void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int64_t teavm_local_7;
    int64_t teavm_local_8;
    int64_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_local_12;
    void* teavm_local_13;
    void* teavm_local_14;
    void* teavm_local_15;
    void* teavm_local_16;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(33921, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    if (((teavm_local_4 >= INT32_C(2)) && (teavm_local_4 <= INT32_C(36)))) {
        if ((teavm_local_2 != teavm_local_3)) {
            teavm_local_5 = INT32_C(0);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33922, teavm_nullCheck(teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            switch (TEAVM_WITH_CALL_SITE_ID(33923, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_2))) {
                case 43:
                    goto teavm_label_3;
                case 45:
                    goto teavm_label_2;
            }
            teavm_local_6 = teavm_local_2;
            goto teavm_label_1;
        teavm_label_3:;
            teavm_local_6 = (teavm_local_2 + INT32_C(1));
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_5 = INT32_C(1);
            teavm_local_6 = (teavm_local_2 + INT32_C(1));
        teavm_label_1:;
            teavm_local_7 = INT64_C(0);
            teavm_local_8 = ((int64_t) teavm_local_4);
            teavm_local_9 = (INT64_C(1) + (INT64_C(9223372036854775807) / teavm_local_8));
            if ((teavm_local_6 != teavm_local_3)) {
                while (1) {
                    if ((teavm_local_6 >= teavm_local_3)) {
                        if (teavm_local_5) {
                            teavm_local_7 = (-teavm_local_7);
                        }
                        goto teavm_label_6;
                    }
                    teavm_local_10 = (teavm_local_6 + INT32_C(1));
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(33924, meth_jl_Long_decodeDigit(TEAVM_WITH_CALL_SITE_ID(33925, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_charAt)(teavm_local_1, teavm_local_6))));
                    if ((teavm_local_11 < INT32_C(0))) {
                        goto teavm_label_7;
                    }
                    if ((teavm_local_11 >= teavm_local_4)) {
                        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33926, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33927, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_subSequence)(teavm_local_1, teavm_local_2, teavm_local_3));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(33928, meth_jl_String_valueOf(teavm_local_13));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_14);
                        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(33929, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                        TEAVM_GC_ROOT(INT32_C(2), teavm_local_15);
                        TEAVM_WITH_CALL_SITE_ID(33930, meth_jl_StringBuilder__init_(teavm_local_15));
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33931, meth_jl_StringBuilder_append(teavm_local_15, TEAVM_GET_STRING(9)));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_13);
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33932, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(33933, teavm_nullCheck(teavm_local_13)), teavm_local_4));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_13);
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33934, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(33935, teavm_nullCheck(teavm_local_13)), TEAVM_GET_STRING(10)));
                        TEAVM_GC_ROOT(INT32_C(3), teavm_local_13);
                        TEAVM_WITH_CALL_SITE_ID(33936, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(33937, teavm_nullCheck(teavm_local_13)), teavm_local_14));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33938, meth_jl_StringBuilder_toString(teavm_local_15));
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                        TEAVM_WITH_CALL_SITE_ID(33939, meth_jl_NumberFormatException__init_(teavm_local_12, teavm_local_13));
                        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                        TEAVM_WITH_CALL_SITE_ID(33940, meth_otr_ExceptionHandling_throwException(teavm_local_12));
                        TEAVM_UNREACHABLE
                    }
                    if ((teavm_local_7 > teavm_local_9)) {
                        goto teavm_label_8;
                    }
                    teavm_local_7 = ((teavm_local_8 * teavm_local_7) + ((int64_t) teavm_local_11));
                    if ((teavm_local_7 < INT64_C(0))) {
                        if ((teavm_local_10 != teavm_local_3)) {
                            goto teavm_label_5;
                        }
                        if ((teavm_local_7 != (int64_t) INT64_C(0x8000000000000000))) {
                            goto teavm_label_5;
                        }
                        if ((!teavm_local_5)) {
                            goto teavm_label_5;
                        }
                        teavm_local_7 = (int64_t) INT64_C(0x8000000000000000);
                        goto teavm_label_6;
                    }
                    teavm_local_6 = teavm_local_10;
                }
            teavm_label_8:;
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33941, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
                TEAVM_WITH_CALL_SITE_ID(33942, meth_jl_NumberFormatException__init_(teavm_local_12, TEAVM_GET_STRING(7673)));
                TEAVM_WITH_CALL_SITE_ID(33943, meth_otr_ExceptionHandling_throwException(teavm_local_12));
                TEAVM_UNREACHABLE
            teavm_label_7:;
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33944, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33945, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_subSequence)(teavm_local_1, teavm_local_2, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33946, meth_jl_String_valueOf(teavm_local_13));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(33947, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_16);
                TEAVM_WITH_CALL_SITE_ID(33948, meth_jl_StringBuilder__init_(teavm_local_16));
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(33949, meth_jl_StringBuilder_append(teavm_local_16, TEAVM_GET_STRING(12)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                TEAVM_WITH_CALL_SITE_ID(33950, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(33951, teavm_nullCheck(teavm_local_14)), teavm_local_13));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33952, meth_jl_StringBuilder_toString(teavm_local_16));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(33953, meth_jl_NumberFormatException__init_(teavm_local_12, teavm_local_13));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(33954, meth_otr_ExceptionHandling_throwException(teavm_local_12));
                TEAVM_UNREACHABLE
            teavm_label_6:;
                TEAVM_RELEASE_STACK;
                return teavm_local_7;
            teavm_label_5:;
                teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33955, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_12);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33956, TEAVM_METHOD(teavm_local_1, jl_CharSequence_VT, virt_subSequence)(teavm_local_1, teavm_local_2, teavm_local_3));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33957, meth_jl_String_valueOf(teavm_local_13));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(33958, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_16);
                TEAVM_WITH_CALL_SITE_ID(33959, meth_jl_StringBuilder__init_(teavm_local_16));
                teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(33960, meth_jl_StringBuilder_append(teavm_local_16, TEAVM_GET_STRING(7674)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_14);
                TEAVM_WITH_CALL_SITE_ID(33961, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(33962, teavm_nullCheck(teavm_local_14)), teavm_local_13));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33963, meth_jl_StringBuilder_toString(teavm_local_16));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_13);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                TEAVM_WITH_CALL_SITE_ID(33964, meth_jl_NumberFormatException__init_(teavm_local_12, teavm_local_13));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(33965, meth_otr_ExceptionHandling_throwException(teavm_local_12));
                TEAVM_UNREACHABLE
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33966, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
            TEAVM_WITH_CALL_SITE_ID(33967, meth_jl_NumberFormatException__init__0(teavm_local_12));
            TEAVM_WITH_CALL_SITE_ID(33968, meth_otr_ExceptionHandling_throwException(teavm_local_12));
            TEAVM_UNREACHABLE
        }
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33969, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
        TEAVM_WITH_CALL_SITE_ID(33970, meth_jl_NumberFormatException__init_(teavm_local_12, TEAVM_GET_STRING(15)));
        TEAVM_WITH_CALL_SITE_ID(33971, meth_otr_ExceptionHandling_throwException(teavm_local_12));
        TEAVM_UNREACHABLE
    }
    teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(33972, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_12);
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33973, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_13);
    TEAVM_WITH_CALL_SITE_ID(33974, meth_jl_StringBuilder__init_(teavm_local_13));
    teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(33975, meth_jl_StringBuilder_append(teavm_local_13, TEAVM_GET_STRING(14)));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_16);
    TEAVM_WITH_CALL_SITE_ID(33976, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(33977, teavm_nullCheck(teavm_local_16)), teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(33978, meth_jl_StringBuilder_toString(teavm_local_13));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_13);
    TEAVM_WITH_CALL_SITE_ID(33979, meth_jl_NumberFormatException__init_(teavm_local_12, teavm_local_13));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(33980, meth_otr_ExceptionHandling_throwException(teavm_local_12));
    TEAVM_UNREACHABLE
}
int64_t meth_jl_Long_parseLong_0(void* teavm_local_1) {
    int64_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33981, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33982, meth_jl_Long_parseLong(teavm_local_1, INT32_C(10)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Long_valueOf_0(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33983, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33984, meth_jl_Long_valueOf(TEAVM_WITH_CALL_SITE_ID(33985, meth_jl_Long_parseLong_0(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Long_decodeDigit(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33986, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = (((teavm_local_1 >= INT32_C(48)) && (teavm_local_1 <= INT32_C(57))) ? (teavm_local_1 - INT32_C(48)) : (((teavm_local_1 >= INT32_C(97)) && (teavm_local_1 <= INT32_C(122))) ? ((teavm_local_1 - INT32_C(97)) + INT32_C(10)) : ((!((teavm_local_1 >= INT32_C(65)) && (teavm_local_1 <= INT32_C(90)))) ? -INT32_C(1) : ((teavm_local_1 - INT32_C(65)) + INT32_C(10)))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int64_t meth_jl_Long_longValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value);
}
double meth_jl_Long_doubleValue(void* teavm_this_) {
    return ((double) TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value));
}
void* meth_jl_Long_toString(int64_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33987, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33988, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(33989, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33990, TEAVM_METHOD(teavm_local_2, jl_StringBuilder_VT, virt_append_26)(teavm_local_2, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33991, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(33992, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Long_toString_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33993, meth_jl_Long_toString(TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Long_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33994, meth_jl_Long_hashCode_0(TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Long_hashCode_0(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33995, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = (((int32_t) teavm_local_1) ^ ((int32_t) ((int64_t) ((uint64_t) teavm_local_1 >> INT32_C(32)))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Long_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if (teavm_instanceof(teavm_local_1, &jl_Long_Cls, &supertypeof_jl_Long)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33996, teavm_checkcast(teavm_local_1, &jl_Long_Cls, &supertypeof_jl_Long));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(33997, teavm_nullCheck(teavm_local_3)), cls_jl_Long, fld_value) == TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Long_compare(int64_t teavm_local_1, int64_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33998, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_3 = teavm_compare_i64(teavm_local_1, teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Long_compareTo(void* teavm_this_, void* teavm_local_1) {
    int64_t teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Long, fld_value);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(33999, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(34000, meth_jl_Long_compare(teavm_local_2, TEAVM_FIELD(teavm_local_1, cls_jl_Long, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Long_numberOfLeadingZeros(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int64_t teavm_local_4;
    int64_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34001, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    if ((teavm_local_1 == INT64_C(0))) {
        teavm_local_2 = INT32_C(64);
    } else {
        teavm_local_3 = INT32_C(0);
        teavm_local_4 = ((int64_t) ((uint64_t) teavm_local_1 >> INT32_C(32)));
        if ((teavm_local_4 != INT64_C(0))) {
            teavm_local_3 = INT32_C(32);
        } else {
            teavm_local_4 = teavm_local_1;
        }
        teavm_local_5 = ((int64_t) ((uint64_t) teavm_local_4 >> INT32_C(16)));
        if ((teavm_local_5 == INT64_C(0))) {
            teavm_local_5 = teavm_local_4;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(16));
        }
        teavm_local_4 = ((int64_t) ((uint64_t) teavm_local_5 >> INT32_C(8)));
        if ((teavm_local_4 == INT64_C(0))) {
            teavm_local_4 = teavm_local_5;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(8));
        }
        teavm_local_5 = ((int64_t) ((uint64_t) teavm_local_4 >> INT32_C(4)));
        if ((teavm_local_5 == INT64_C(0))) {
            teavm_local_5 = teavm_local_4;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(4));
        }
        teavm_local_4 = ((int64_t) ((uint64_t) teavm_local_5 >> INT32_C(2)));
        if ((teavm_local_4 == INT64_C(0))) {
            teavm_local_4 = teavm_local_5;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(2));
        }
        if ((((int64_t) ((uint64_t) teavm_local_4 >> INT32_C(1))) != INT64_C(0))) {
            teavm_local_3 = (teavm_local_3 | INT32_C(1));
        }
        teavm_local_2 = ((INT32_C(64) - teavm_local_3) - INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Long_numberOfTrailingZeros(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int64_t teavm_local_4;
    int64_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34002, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    if ((teavm_local_1 == INT64_C(0))) {
        teavm_local_2 = INT32_C(64);
    } else {
        teavm_local_3 = INT32_C(0);
        teavm_local_4 = (teavm_local_1 << INT32_C(32));
        if ((teavm_local_4 != INT64_C(0))) {
            teavm_local_3 = INT32_C(32);
        } else {
            teavm_local_4 = teavm_local_1;
        }
        teavm_local_5 = (teavm_local_4 << INT32_C(16));
        if ((teavm_local_5 == INT64_C(0))) {
            teavm_local_5 = teavm_local_4;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(16));
        }
        teavm_local_4 = (teavm_local_5 << INT32_C(8));
        if ((teavm_local_4 == INT64_C(0))) {
            teavm_local_4 = teavm_local_5;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(8));
        }
        teavm_local_5 = (teavm_local_4 << INT32_C(4));
        if ((teavm_local_5 == INT64_C(0))) {
            teavm_local_5 = teavm_local_4;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(4));
        }
        teavm_local_4 = (teavm_local_5 << INT32_C(2));
        if ((teavm_local_4 == INT64_C(0))) {
            teavm_local_4 = teavm_local_5;
        } else {
            teavm_local_3 = (teavm_local_3 | INT32_C(2));
        }
        if (((teavm_local_4 << INT32_C(1)) != INT64_C(0))) {
            teavm_local_3 = (teavm_local_3 | INT32_C(1));
        }
        teavm_local_2 = ((INT32_C(64) - teavm_local_3) - INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Long_signum(int64_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34003, teavm_initializeClass((TeaVM_Class*) &jl_Long_Cls, &initclass_jl_Long));
    teavm_local_2 = ((int32_t) ((teavm_local_1 >> INT32_C(63)) | ((int64_t) ((uint64_t) (-teavm_local_1) >> INT32_C(63)))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Long_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34004, teavm_checkcast(teavm_local_1, &jl_Long_Cls, &supertypeof_jl_Long));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34005, TEAVM_METHOD(teavm_this_, jl_Long_VT, virt_compareTo_10)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Long__clinit_() {
    sfld_jl_Long_TYPE = teavm_getClassObject((TeaVM_Class*) &J_Cls);
}
void initclass_jl_Long() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Long_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Long__clinit_();
    }
}
int32_t supertypeof_jl_Long(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1978 || tag >= 1980) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Long_VT jl_Long_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Long), sizeof(void*)),
        .flags = 0,
        .tag = 1978,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7675),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Long,
        .superclass = (TeaVM_Class*) &jl_Number_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Long_hashCode,
    .virt_equals = &meth_jl_Long_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Long_toString_0,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_compareTo = &meth_jl_Long_compareTo_0,
    .virt_longValue = &meth_jl_Long_longValue,
    .virt_compareTo_10 = &meth_jl_Long_compareTo,
    .virt_doubleValue = &meth_jl_Long_doubleValue
};
static void** teavm_gc_localStaticRoots_jl_Long_Cls[1] = {
(void**) &sfld_jl_Long_TYPE
};
void sysinitclass_jl_Long() {
sfld_jl_Long_TYPE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Long_Cls, 1);
}
