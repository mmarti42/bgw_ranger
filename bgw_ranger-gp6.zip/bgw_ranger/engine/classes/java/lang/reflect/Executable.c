#include "Executable.h"
#include "AccessibleObject.h"
#include "../../../../strings.h"
#include "../Object.h"

int32_t supertypeof_jlr_Executable(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 498 || tag >= 502) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlr_Executable_VT jlr_Executable_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jlr_Executable), sizeof(void*)),
                .flags = 0,
                .tag = 498,
                .modifiers = 1025,
                .name = NULL,
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_jlr_Executable,
                .superclass = (TeaVM_Class*) &jlr_AccessibleObject_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_hashCode = &meth_jl_Object_hashCode,
            .virt_equals = &meth_jl_Object_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_jl_Object_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0
        }
    }
};
void sysinitclass_jlr_Executable() {
}
