#include "Array.h"
#include "../Object.h"
#include "../Class.h"
#include "../../../../core.h"
#include "../IllegalArgumentException.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../../primitives/void.h"
#include "../../../../arrayclass.h"
#include "../NegativeArraySizeException.h"
#include "../NullPointerException.h"
#include "../../../../strings.h"

int32_t meth_jlr_Array_getLength(void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3083, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3084, meth_jl_Object_getClass(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3085, meth_jl_Class_getClassInfo(TEAVM_WITH_CALL_SITE_ID(3086, teavm_nullCheck(TEAVM_WITH_CALL_SITE_ID(3087, teavm_checkcast(teavm_local_2, &jl_Class_Cls, &supertypeof_jl_Class))))));
    if (((((TeaVM_Class*) (teavm_local_3))->itemType) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3088, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(3089, meth_jl_IllegalArgumentException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(3090, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jlr_Array_newInstance(void* teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 != NULL)) {
        if ((teavm_local_1 != teavm_getClassObject((TeaVM_Class*) &V_Cls))) {
            if ((teavm_local_2 >= INT32_C(0))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3091, teavm_checkcast(teavm_local_1, &jl_Class_Cls, &supertypeof_jl_Class));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3092, meth_jl_Class_getClassInfo(TEAVM_WITH_CALL_SITE_ID(3093, teavm_nullCheck(teavm_local_3))));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3094, meth_otr_Allocator_allocateArray(teavm_getArrayClass(teavm_local_4), teavm_local_2));
                TEAVM_RELEASE_STACK;
                return teavm_local_3;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3095, meth_otr_Allocator_allocate(&jl_NegativeArraySizeException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(3096, meth_jl_NegativeArraySizeException__init_(teavm_local_3));
            TEAVM_WITH_CALL_SITE_ID(3097, meth_otr_ExceptionHandling_throwException(teavm_local_3));
            TEAVM_UNREACHABLE
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3098, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(3099, meth_jl_IllegalArgumentException__init_(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(3100, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3101, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(3102, meth_jl_NullPointerException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(3103, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_jlr_Array(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 143 || tag >= 145) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlr_Array_VT jlr_Array_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jlr_Array), sizeof(void*)),
            .flags = 0,
            .tag = 143,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jlr_Array,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_jlr_Array() {
}
