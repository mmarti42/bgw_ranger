#pragma once
#include "../../../../runtime.h"
#include "Executable.h"
#include "Method.h"

extern void sysinitclass_jlr_Method();
typedef struct cls_jlr_Method {
    struct cls_jlr_Executable parent;
} cls_jlr_Method;
extern int32_t supertypeof_jlr_Method(TeaVM_Class*, TeaVM_Class*);
typedef struct jlr_Method_VT {
    jlr_Executable_VT parent;
} jlr_Method_VT;
extern jlr_Method_VT jlr_Method_Cls;
