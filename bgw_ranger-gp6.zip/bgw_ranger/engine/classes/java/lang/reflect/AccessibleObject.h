#pragma once
#include "../../../../runtime.h"
#include "../Object.h"
#include "AccessibleObject.h"

extern void sysinitclass_jlr_AccessibleObject();
typedef struct cls_jlr_AccessibleObject {
    struct TeaVM_Object parent;
} cls_jlr_AccessibleObject;
extern int32_t supertypeof_jlr_AccessibleObject(TeaVM_Class*, TeaVM_Class*);
typedef struct jlr_AccessibleObject_VT {
    jl_Object_VT parent;
} jlr_AccessibleObject_VT;
extern jlr_AccessibleObject_VT jlr_AccessibleObject_Cls;
