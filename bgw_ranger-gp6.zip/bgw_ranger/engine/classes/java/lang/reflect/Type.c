#include "Type.h"
#include "../../../../strings.h"

int32_t supertypeof_jlr_Type(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 257 || tag >= 259) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jlr_Type_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 257,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jlr_Type,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jlr_Type() {
}
