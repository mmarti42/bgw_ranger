#pragma once
#include "../../../../runtime.h"
#include "AccessibleObject.h"
#include "Field.h"

extern void sysinitclass_jlr_Field();
typedef struct cls_jlr_Field {
    struct cls_jlr_AccessibleObject parent;
} cls_jlr_Field;
extern int32_t supertypeof_jlr_Field(TeaVM_Class*, TeaVM_Class*);
typedef struct jlr_Field_VT {
    jlr_AccessibleObject_VT parent;
} jlr_Field_VT;
extern jlr_Field_VT jlr_Field_Cls;
