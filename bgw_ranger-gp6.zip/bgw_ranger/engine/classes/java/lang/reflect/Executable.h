#pragma once
#include "../../../../runtime.h"
#include "AccessibleObject.h"
#include "Executable.h"

extern void sysinitclass_jlr_Executable();
typedef struct cls_jlr_Executable {
    struct cls_jlr_AccessibleObject parent;
} cls_jlr_Executable;
extern int32_t supertypeof_jlr_Executable(TeaVM_Class*, TeaVM_Class*);
typedef struct jlr_Executable_VT {
    jlr_AccessibleObject_VT parent;
} jlr_Executable_VT;
extern jlr_Executable_VT jlr_Executable_Cls;
