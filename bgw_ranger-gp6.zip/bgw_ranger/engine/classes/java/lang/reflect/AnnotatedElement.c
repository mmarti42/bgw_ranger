#include "AnnotatedElement.h"
#include "../../../../strings.h"

int32_t supertypeof_jlr_AnnotatedElement(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 257 || tag >= 503) return INT32_C(0);
    if (tag >= 259 && tag < 495) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class jlr_AnnotatedElement_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 257,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_jlr_AnnotatedElement,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_jlr_AnnotatedElement() {
}
