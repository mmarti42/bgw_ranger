#include "Field.h"
#include "AccessibleObject.h"
#include "../../../../strings.h"
#include "../Object.h"

int32_t supertypeof_jlr_Field(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 496 || tag >= 498) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jlr_Field_VT jlr_Field_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jlr_Field), sizeof(void*)),
                .flags = 0,
                .tag = 496,
                .modifiers = 1,
                .name = NULL,
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_jlr_Field,
                .superclass = (TeaVM_Class*) &jlr_AccessibleObject_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_hashCode = &meth_jl_Object_hashCode,
            .virt_equals = &meth_jl_Object_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0
        }
    }
};
void sysinitclass_jlr_Field() {
}
