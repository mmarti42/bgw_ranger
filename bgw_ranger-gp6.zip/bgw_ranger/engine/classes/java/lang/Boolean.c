#include "Boolean.h"
#include "Object.h"
#include "String.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../primitives/boolean.h"

void* sfld_jl_Boolean_TRUE;
void* sfld_jl_Boolean_FALSE;
void* sfld_jl_Boolean_TYPE;
void meth_jl_Boolean__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24503, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    TEAVM_WITH_CALL_SITE_ID(24504, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jl_Boolean, fld_value) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jl_Boolean_compareTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jl_Boolean, fld_value);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24505, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24506, meth_jl_Boolean_compare(teavm_local_2, TEAVM_FIELD(teavm_local_1, cls_jl_Boolean, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Boolean_compare(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24507, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    teavm_local_3 = ((teavm_local_1 == teavm_local_2) ? INT32_C(0) : ((!teavm_local_1) ? -INT32_C(1) : INT32_C(1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Boolean_parseBoolean(void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24508, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    if ((teavm_local_1 != NULL)) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24509, meth_jl_String_toLowerCase(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if (TEAVM_WITH_CALL_SITE_ID(24510, meth_jl_String_equals(TEAVM_WITH_CALL_SITE_ID(24511, teavm_nullCheck(teavm_local_2)), TEAVM_GET_STRING(29)))) {
            goto teavm_label_2;
        }
    }
    teavm_local_3 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jl_Boolean_booleanValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jl_Boolean, fld_value);
}
void* meth_jl_Boolean_valueOf(int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24512, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    teavm_local_2 = ((!teavm_local_1) ? sfld_jl_Boolean_FALSE : sfld_jl_Boolean_TRUE);
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Boolean_valueOf_0(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24513, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24514, meth_jl_Boolean_valueOf(TEAVM_WITH_CALL_SITE_ID(24515, meth_jl_Boolean_parseBoolean(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Boolean_toString(int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24516, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    teavm_local_2 = ((!teavm_local_1) ? TEAVM_GET_STRING(30) : TEAVM_GET_STRING(29));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jl_Boolean_toString_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24517, meth_jl_Boolean_toString(TEAVM_FIELD(teavm_this_, cls_jl_Boolean, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Boolean_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24518, meth_jl_Boolean_hashCode_0(TEAVM_FIELD(teavm_this_, cls_jl_Boolean, fld_value)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jl_Boolean_hashCode_0(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24519, teavm_initializeClass((TeaVM_Class*) &jl_Boolean_Cls, &initclass_jl_Boolean));
    teavm_local_2 = ((!teavm_local_1) ? INT32_C(1237) : INT32_C(1231));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Boolean_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else {
        if (teavm_instanceof(teavm_local_1, &jl_Boolean_Cls, &supertypeof_jl_Boolean)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(24520, teavm_checkcast(teavm_local_1, &jl_Boolean_Cls, &supertypeof_jl_Boolean));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(24521, teavm_nullCheck(teavm_local_3)), cls_jl_Boolean, fld_value) == TEAVM_FIELD(teavm_this_, cls_jl_Boolean, fld_value))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jl_Boolean_compareTo_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24522, teavm_checkcast(teavm_local_1, &jl_Boolean_Cls, &supertypeof_jl_Boolean));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24523, TEAVM_METHOD(teavm_this_, jl_Boolean_VT, virt_compareTo_7)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jl_Boolean__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24524, meth_otr_Allocator_allocate(&jl_Boolean_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(24525, meth_jl_Boolean__init_(teavm_local_1, INT32_C(1)));
    sfld_jl_Boolean_TRUE = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24526, meth_otr_Allocator_allocate(&jl_Boolean_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(24527, meth_jl_Boolean__init_(teavm_local_1, INT32_C(0)));
    sfld_jl_Boolean_FALSE = teavm_local_1;
    sfld_jl_Boolean_TYPE = teavm_getClassObject((TeaVM_Class*) &Z_Cls);
    TEAVM_RELEASE_STACK;
}
void initclass_jl_Boolean() {
    TeaVM_Class* cls = (TeaVM_Class*) &jl_Boolean_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jl_Boolean__clinit_();
    }
}
int32_t supertypeof_jl_Boolean(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1407 || tag >= 1409) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jl_Boolean_VT jl_Boolean_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jl_Boolean), sizeof(void*)),
        .flags = 0,
        .tag = 1407,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7117),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jl_Boolean,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Boolean_hashCode,
    .virt_equals = &meth_jl_Boolean_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Boolean_toString_0,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_booleanValue = &meth_jl_Boolean_booleanValue,
    .virt_compareTo = &meth_jl_Boolean_compareTo_0,
    .virt_compareTo_7 = &meth_jl_Boolean_compareTo
};
static void** teavm_gc_localStaticRoots_jl_Boolean_Cls[3] = {
(void**) &sfld_jl_Boolean_TRUE, (void**) &sfld_jl_Boolean_FALSE, (void**) &sfld_jl_Boolean_TYPE
};
void sysinitclass_jl_Boolean() {
sfld_jl_Boolean_TRUE = NULL;
sfld_jl_Boolean_FALSE = NULL;
sfld_jl_Boolean_TYPE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jl_Boolean_Cls, 3);
}
