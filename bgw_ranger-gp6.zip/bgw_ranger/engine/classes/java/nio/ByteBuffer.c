#include "ByteBuffer.h"
#include "Buffer.h"
#include "ByteOrder.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../arrays/primitives/byte.h"
#include "ByteBufferNative.h"
#include "../util/Objects.h"
#include "BufferUnderflowException.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "BufferOverflowException.h"
#include "ReadOnlyBufferException.h"
#include "../lang/Object.h"

void meth_jn_ByteBuffer__init_(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18307, meth_jn_Buffer__init_(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(18308, teavm_initializeClass((TeaVM_Class*) &jn_ByteOrder_Cls, &initclass_jn_ByteOrder));
    teavm_local_1 = sfld_jn_ByteOrder_BIG_ENDIAN;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBuffer, fld_order) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jn_ByteBuffer_allocate(int32_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    void* teavm_local_7;
    int32_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_local_1 < INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18309, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18310, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(18311, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18312, meth_jl_StringBuilder_append(teavm_local_3, TEAVM_GET_STRING(709)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(18313, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(18314, teavm_nullCheck(teavm_local_4)), teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18315, meth_jl_StringBuilder_toString(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(18316, meth_jl_IllegalArgumentException__init__0(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(18317, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18318, meth_otr_Allocator_allocateArray(&Arr_B_Cls, teavm_local_1));
    teavm_local_6 = teavm_local_5;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(18319, meth_otr_Allocator_allocate(&jn_ByteBufferNative_Cls));
    teavm_local_2 = NULL;
    teavm_local_3 = TEAVM_ARRAY_DATA(teavm_local_5, int32_t);
    teavm_local_8 = TEAVM_ARRAY_LENGTH(teavm_local_6);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(18320, meth_jn_ByteBufferNative__init_(teavm_local_7, teavm_local_2, teavm_local_5, INT32_C(0), teavm_local_5, teavm_local_3, teavm_local_8, INT32_C(0)));
    TEAVM_FIELD(teavm_local_7, cls_jn_Buffer, fld_limit) = teavm_local_1;
    TEAVM_RELEASE_STACK;
    return teavm_local_7;
}
void* meth_jn_ByteBuffer_wrap_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18321, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(18322, meth_ju_Objects_checkFromIndexSize(teavm_local_2, teavm_local_3, teavm_local_4));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18323, meth_otr_Allocator_allocate(&jn_ByteBufferNative_Cls));
    teavm_local_6 = NULL;
    teavm_local_7 = TEAVM_ARRAY_DATA(teavm_local_1, int32_t);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(18324, meth_jn_ByteBufferNative__init_(teavm_local_5, teavm_local_6, teavm_local_1, INT32_C(0), teavm_local_1, teavm_local_7, teavm_local_4, INT32_C(0)));
    TEAVM_FIELD(teavm_local_5, cls_jn_Buffer, fld_position) = teavm_local_2;
    TEAVM_FIELD(teavm_local_5, cls_jn_Buffer, fld_limit) = (teavm_local_2 + teavm_local_3);
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jn_ByteBuffer_wrap(TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18325, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18326, meth_jn_ByteBuffer_wrap_0(teavm_local_1, INT32_C(0), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jn_ByteBuffer_get_0(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_3 >= INT32_C(0)) && (teavm_local_2 >= INT32_C(0)))) {
        teavm_local_4 = (teavm_local_2 + teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18327, teavm_nullCheck(teavm_local_1));
        if ((teavm_local_4 <= TEAVM_ARRAY_LENGTH(teavm_local_1))) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            if ((teavm_local_3 <= TEAVM_WITH_CALL_SITE_ID(18328, meth_jn_Buffer_remaining(teavm_this_)))) {
                TEAVM_WITH_CALL_SITE_ID(18329, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_getImpl_0)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position), teavm_local_1, teavm_local_2, teavm_local_3));
                TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = (TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) + teavm_local_3);
                TEAVM_RELEASE_STACK;
                return teavm_this_;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18330, meth_otr_Allocator_allocate(&jn_BufferUnderflowException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_WITH_CALL_SITE_ID(18331, meth_jn_BufferUnderflowException__init_(teavm_local_5));
            TEAVM_WITH_CALL_SITE_ID(18332, meth_otr_ExceptionHandling_throwException(teavm_local_5));
            TEAVM_UNREACHABLE
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18333, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(18334, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(18335, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void* meth_jn_ByteBuffer_get(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18336, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18337, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_get_14)(teavm_this_, teavm_local_1, INT32_C(0), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jn_ByteBuffer_put_0(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (teavm_local_3) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if ((!TEAVM_WITH_CALL_SITE_ID(18338, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_isReadOnly)(teavm_this_)))) {
            if (((teavm_local_3 >= INT32_C(0)) && (teavm_local_2 >= INT32_C(0)))) {
                teavm_local_4 = (teavm_local_2 + teavm_local_3);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18339, teavm_nullCheck(teavm_local_1));
                if ((teavm_local_4 <= TEAVM_ARRAY_LENGTH(teavm_local_1))) {
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                    if ((teavm_local_3 <= TEAVM_WITH_CALL_SITE_ID(18340, meth_jn_Buffer_remaining(teavm_this_)))) {
                        TEAVM_WITH_CALL_SITE_ID(18341, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_putImpl_2)(teavm_this_, teavm_local_1, teavm_local_2, TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position), teavm_local_3));
                        TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = (TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) + teavm_local_3);
                        goto teavm_label_1;
                    }
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18342, meth_otr_Allocator_allocate(&jn_BufferOverflowException_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                    TEAVM_WITH_CALL_SITE_ID(18343, meth_jn_BufferOverflowException__init_(teavm_local_5));
                    TEAVM_WITH_CALL_SITE_ID(18344, meth_otr_ExceptionHandling_throwException(teavm_local_5));
                    TEAVM_UNREACHABLE
                }
            }
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18345, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_WITH_CALL_SITE_ID(18346, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_5));
            TEAVM_WITH_CALL_SITE_ID(18347, meth_otr_ExceptionHandling_throwException(teavm_local_5));
            TEAVM_UNREACHABLE
        }
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18348, meth_otr_Allocator_allocate(&jn_ReadOnlyBufferException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_WITH_CALL_SITE_ID(18349, meth_jn_ReadOnlyBufferException__init_(teavm_local_5));
        TEAVM_WITH_CALL_SITE_ID(18350, meth_otr_ExceptionHandling_throwException(teavm_local_5));
        TEAVM_UNREACHABLE
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jn_ByteBuffer_put(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18351, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18352, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_put_4)(teavm_this_, teavm_local_1, INT32_C(0), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_jn_ByteBuffer_hasArray(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18353, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_hasArrayImpl)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jn_ByteBuffer_array(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18354, TEAVM_METHOD(teavm_this_, jn_ByteBuffer_VT, virt_arrayImpl)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jn_ByteBuffer_clear(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18355, meth_jn_Buffer_clear(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jn_ByteBuffer_flip(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18356, meth_jn_Buffer_flip(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jn_ByteBuffer_position(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18357, meth_jn_Buffer_position_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
int32_t supertypeof_jn_ByteBuffer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 122 || tag >= 126) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jn_ByteBuffer_Cls[2];
alignas(8) jn_ByteBuffer_VT jn_ByteBuffer_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_ByteBuffer), sizeof(void*)),
        .flags = 0,
        .tag = 122,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jn_ByteBuffer,
        .superclass = (TeaVM_Class*) &jn_Buffer_Cls,
        .layout = teavm_classLayouts_jn_ByteBuffer_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_get_9 = &meth_jn_ByteBuffer_get,
    .virt_clear_3 = &meth_jn_ByteBuffer_clear,
    .virt_hasArray = &meth_jn_ByteBuffer_hasArray,
    .virt_get_14 = &meth_jn_ByteBuffer_get_0,
    .virt_put_5 = &meth_jn_ByteBuffer_put,
    .virt_position = &meth_jn_Buffer_position,
    .virt_array_0 = &meth_jn_ByteBuffer_array,
    .virt_limit_0 = &meth_jn_Buffer_limit,
    .virt_put_4 = &meth_jn_ByteBuffer_put_0,
    .virt_remaining = &meth_jn_Buffer_remaining,
    .virt_hasRemaining = &meth_jn_Buffer_hasRemaining,
    .virt_flip_1 = &meth_jn_ByteBuffer_flip,
    .virt_position_2 = &meth_jn_ByteBuffer_position,
    .virt_capacity = &meth_jn_Buffer_capacity
};
static int16_t teavm_classLayouts_jn_ByteBuffer_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jn_ByteBuffer, fld_order)
};
void sysinitclass_jn_ByteBuffer() {
}
