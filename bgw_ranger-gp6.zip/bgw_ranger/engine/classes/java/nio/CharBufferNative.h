#pragma once
#include "../../../runtime.h"
#include "CharBufferImpl.h"
#include "CharBufferNative.h"

extern void sysinitclass_jn_CharBufferNative();
typedef struct cls_jn_CharBufferNative {
    struct cls_jn_CharBufferImpl parent;
    TeaVM_Array* fld_array;
    int8_t fld_readOnly;
    void* fld_base;
    void* fld_address;
    int32_t fld_capacity;
    int8_t fld_swap;
} cls_jn_CharBufferNative;
extern void meth_jn_CharBufferNative__init_(void*, void*, TeaVM_Array*, int32_t, int32_t, int32_t, void*, void*, int32_t, int32_t);
extern int32_t meth_jn_CharBufferNative_capacityImpl(void*);
extern int32_t meth_jn_CharBufferNative_isArrayPresent(void*);
extern TeaVM_Array* meth_jn_CharBufferNative_getArray(void*);
extern int32_t meth_jn_CharBufferNative_readOnly(void*);
extern void meth_jn_CharBufferNative_getImpl(void*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void meth_jn_CharBufferNative_putImpl(void*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void meth_jn_CharBufferNative_putImpl_0(void*, int32_t, void*, int32_t, int32_t);
extern void meth_jn_CharBufferNative_copy(void*, TeaVM_Array*, int32_t, void*, int32_t);
extern void meth_jn_CharBufferNative_copy_0(void*, void*, TeaVM_Array*, int32_t, int32_t);
extern int32_t supertypeof_jn_CharBufferNative(TeaVM_Class*, TeaVM_Class*);
typedef struct jn_CharBufferNative_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_putImpl_1)(void*, int32_t, void*, int32_t, int32_t); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void* (*virt_flip_0)(void*); // 13
    void (*virt_getImpl)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void* (*virt_subSequence)(void*, int32_t, int32_t); // 17
    void (*pad1)(); // 18
    void* (*virt_put_2)(void*, void*); // 19
    int32_t (*virt_hasArray)(void*); // 20
    void* (*virt_put_1)(void*, void*, int32_t, int32_t); // 21
    int32_t (*virt_isReadOnly)(void*); // 22
    void* (*virt_put_3)(void*, TeaVM_Array*, int32_t, int32_t); // 23
    void* (*virt_position_1)(void*, int32_t); // 24
    int32_t (*virt_length)(void*); // 25
    int32_t (*virt_charAt)(void*, int32_t); // 26
    void* (*virt_get_8)(void*, TeaVM_Array*); // 27
    void* (*virt_get_10)(void*, TeaVM_Array*, int32_t, int32_t); // 28
    int32_t (*virt_position)(void*); // 29
    void* (*virt_position_0)(void*, int32_t); // 30
    TeaVM_Array* (*virt_getArray)(void*); // 31
    int32_t (*virt_limit_0)(void*); // 32
    void* (*virt_clear_0)(void*); // 33
    void (*pad2)(); // 34
    void (*pad3)(); // 35
    void* (*virt_flip)(void*); // 36
    void (*virt_putImpl_0)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 37
    int32_t (*virt_capacityImpl)(void*); // 38
    int32_t (*virt_readOnly)(void*); // 39
    void (*pad4)(); // 40
    void (*pad5)(); // 41
    int32_t (*virt_remaining)(void*); // 42
    int32_t (*virt_hasRemaining)(void*); // 43
    void (*virt_copy_3)(void*, TeaVM_Array*, int32_t, void*, int32_t); // 44
    void (*virt_copy_2)(void*, void*, TeaVM_Array*, int32_t, int32_t); // 45
    void* (*virt_append_19)(void*, void*); // 46
    TeaVM_Array* (*virt_array)(void*); // 47
    int32_t (*virt_isArrayPresent)(void*); // 48
    int32_t (*virt_capacity)(void*); // 49
} jn_CharBufferNative_VT;
extern jn_CharBufferNative_VT jn_CharBufferNative_Cls;
