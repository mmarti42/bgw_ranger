#pragma once
#include "../../../runtime.h"
#include "Buffer.h"
#include "ByteBuffer.h"

extern void sysinitclass_jn_ByteBuffer();
typedef struct cls_jn_ByteBuffer {
    struct cls_jn_Buffer parent;
    void* fld_order;
} cls_jn_ByteBuffer;
extern void meth_jn_ByteBuffer__init_(void*);
extern void* meth_jn_ByteBuffer_allocate(int32_t);
extern void* meth_jn_ByteBuffer_wrap_0(TeaVM_Array*, int32_t, int32_t);
extern void* meth_jn_ByteBuffer_wrap(TeaVM_Array*);
extern void* meth_jn_ByteBuffer_get_0(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jn_ByteBuffer_get(void*, TeaVM_Array*);
extern void* meth_jn_ByteBuffer_put_0(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jn_ByteBuffer_put(void*, TeaVM_Array*);
extern int32_t meth_jn_ByteBuffer_hasArray(void*);
extern TeaVM_Array* meth_jn_ByteBuffer_array(void*);
extern void* meth_jn_ByteBuffer_clear(void*);
extern void* meth_jn_ByteBuffer_flip(void*);
extern void* meth_jn_ByteBuffer_position(void*, int32_t);
extern int32_t supertypeof_jn_ByteBuffer(TeaVM_Class*, TeaVM_Class*);
typedef struct jn_ByteBuffer_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_get_9)(void*, TeaVM_Array*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*virt_getImpl_0)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void* (*virt_clear_3)(void*); // 19
    int32_t (*virt_hasArray)(void*); // 20
    void (*virt_putImpl_2)(void*, TeaVM_Array*, int32_t, int32_t, int32_t); // 21
    int32_t (*virt_isReadOnly)(void*); // 22
    void* (*virt_get_14)(void*, TeaVM_Array*, int32_t, int32_t); // 23
    void* (*virt_put_5)(void*, TeaVM_Array*); // 24
    void (*pad5)(); // 25
    void (*pad6)(); // 26
    int32_t (*virt_hasArrayImpl)(void*); // 27
    TeaVM_Array* (*virt_arrayImpl)(void*); // 28
    int32_t (*virt_position)(void*); // 29
    void* (*virt_position_0)(void*, int32_t); // 30
    TeaVM_Array* (*virt_array_0)(void*); // 31
    int32_t (*virt_limit_0)(void*); // 32
    void* (*virt_clear_0)(void*); // 33
    void (*pad7)(); // 34
    void (*pad8)(); // 35
    void* (*virt_flip)(void*); // 36
    void* (*virt_put_4)(void*, TeaVM_Array*, int32_t, int32_t); // 37
    int32_t (*virt_capacityImpl)(void*); // 38
    void (*pad9)(); // 39
    void (*pad10)(); // 40
    void (*pad11)(); // 41
    int32_t (*virt_remaining)(void*); // 42
    int32_t (*virt_hasRemaining)(void*); // 43
    void (*pad12)(); // 44
    void (*pad13)(); // 45
    void (*pad14)(); // 46
    void* (*virt_flip_1)(void*); // 47
    void* (*virt_position_2)(void*, int32_t); // 48
    int32_t (*virt_capacity)(void*); // 49
} jn_ByteBuffer_VT;
extern jn_ByteBuffer_VT jn_ByteBuffer_Cls;
