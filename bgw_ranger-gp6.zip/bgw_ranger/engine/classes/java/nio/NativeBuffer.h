#pragma once
#include "../../../runtime.h"
#include "NativeBuffer.h"

extern void sysinitclass_jn_NativeBuffer();
extern int32_t supertypeof_jn_NativeBuffer(TeaVM_Class*, TeaVM_Class*);
typedef struct jn_NativeBuffer_VT {
    TeaVM_Class parent;
    void (*pad0)(); // 0
    void (*pad1)(); // 1
    void* (*virt_clone)(void*); // 2
    void (*pad2)(); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
} jn_NativeBuffer_VT;
extern TeaVM_Class jn_NativeBuffer_Cls;
