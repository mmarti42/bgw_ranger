#include "Charset.h"
#include "../../lang/Object.h"
#include "../../../../arrayclass.h"
#include "../../lang/String.h"
#include "IllegalCharsetNameException.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../../org/teavm/runtime/ExceptionHandling.h"
#include "CodingErrorAction.h"
#include "CharsetDecoder.h"
#include "../../lang/AssertionError.h"
#include "../../../../strings.h"
#include "CharsetEncoder.h"

void meth_jnc_Charset__init_(void* teavm_this_, void* teavm_local_1, TeaVM_Array* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(4848, meth_jl_Object__init_(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(4849, meth_jnc_Charset_checkCanonicalName(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4850, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = teavm_local_2;
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    teavm_local_5 = INT32_C(0);
    while (1) {
        if (!(teavm_local_5 < teavm_local_4)) break;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(4851, teavm_checkLowerBound(teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(4852, meth_jnc_Charset_checkCanonicalName(teavm_local_6));
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_Charset, fld_canonicalName) = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(4853, TEAVM_METHOD(teavm_local_2, jl_Object_VT, virt_clone)(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4854, teavm_checkcast(teavm_local_7, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_Charset, fld_aliases) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void meth_jnc_Charset_checkCanonicalName(void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(4855, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!TEAVM_WITH_CALL_SITE_ID(4856, meth_jl_String_isEmpty(teavm_local_1)))) {
        if (TEAVM_WITH_CALL_SITE_ID(4857, meth_jnc_Charset_isValidCharsetStart(TEAVM_WITH_CALL_SITE_ID(4858, meth_jl_String_charAt(teavm_local_1, INT32_C(0)))))) {
            teavm_local_2 = INT32_C(1);
            while (1) {
                if (!(teavm_local_2 < TEAVM_WITH_CALL_SITE_ID(4859, meth_jl_String_length(teavm_local_1)))) break;
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4860, meth_jl_String_charAt(teavm_local_1, teavm_local_2));
                switch (teavm_local_3) {
                    case 43:
                    case 45:
                    case 46:
                    case 58:
                    case 95:
                        goto teavm_label_4;
                    default:
                        goto teavm_label_3;
                }
            teavm_label_4:;
                goto teavm_label_2;
            teavm_label_3:;
                if ((!TEAVM_WITH_CALL_SITE_ID(4861, meth_jnc_Charset_isValidCharsetStart(teavm_local_3)))) {
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(4862, meth_otr_Allocator_allocate(&jnc_IllegalCharsetNameException_Cls));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                    TEAVM_WITH_CALL_SITE_ID(4863, meth_jnc_IllegalCharsetNameException__init_(teavm_local_4, teavm_local_1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_WITH_CALL_SITE_ID(4864, meth_otr_ExceptionHandling_throwException(teavm_local_4));
                    TEAVM_UNREACHABLE
                }
            teavm_label_2:;
                teavm_local_2 = (teavm_local_2 + INT32_C(1));
            }
            TEAVM_RELEASE_STACK;
            return;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(4865, meth_otr_Allocator_allocate(&jnc_IllegalCharsetNameException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(4866, meth_jnc_IllegalCharsetNameException__init_(teavm_local_4, teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(4867, meth_otr_ExceptionHandling_throwException(teavm_local_4));
        TEAVM_UNREACHABLE
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(4868, meth_otr_Allocator_allocate(&jnc_IllegalCharsetNameException_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(4869, meth_jnc_IllegalCharsetNameException__init_(teavm_local_4, teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(4870, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
int32_t meth_jnc_Charset_isValidCharsetStart(int32_t teavm_local_1) {
    int32_t teavm_local_2;
    if (((!((teavm_local_1 >= INT32_C(48)) && (teavm_local_1 <= INT32_C(57)))) && (!((teavm_local_1 >= INT32_C(97)) && (teavm_local_1 <= INT32_C(122)))))) {
        if ((teavm_local_1 < INT32_C(65))) {
            goto teavm_label_2;
        }
        if ((teavm_local_1 > INT32_C(90))) {
            goto teavm_label_2;
        }
    }
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    return teavm_local_2;
}
void* meth_jnc_Charset_decode(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void * volatile teavm_spill_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_TRY
        teavm_spill_3 = teavm_local_3;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4871, TEAVM_METHOD(teavm_this_, jnc_Charset_VT, virt_newDecoder)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(4872, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
        teavm_local_3 = sfld_jnc_CodingErrorAction_REPLACE;
        teavm_spill_3 = teavm_local_3;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4873, meth_jnc_CharsetDecoder_onMalformedInput(TEAVM_WITH_CALL_SITE_ID(4874, teavm_nullCheck(teavm_local_2)), teavm_local_3));
        teavm_spill_3 = teavm_local_3;
        teavm_local_2 = sfld_jnc_CodingErrorAction_REPLACE;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4875, meth_jnc_CharsetDecoder_onUnmappableCharacter(TEAVM_WITH_CALL_SITE_ID(4876, teavm_nullCheck(teavm_local_3)), teavm_local_2));
        teavm_spill_3 = teavm_local_3;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4877, meth_jnc_CharsetDecoder_decode(TEAVM_WITH_CALL_SITE_ID(4878, teavm_nullCheck(teavm_local_3)), teavm_local_1));
        teavm_spill_3 = teavm_local_3;
    TEAVM_CATCH
        // CATCH java.nio.charset.CharacterCodingException
        case 1: {
            teavm_local_3 = teavm_spill_3;
            teavm_local_4 = teavm_catchException();
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4879, meth_otr_Allocator_allocate(&jl_AssertionError_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(4880, meth_jl_AssertionError__init_(teavm_local_2, TEAVM_GET_STRING(495), teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(4881, meth_otr_ExceptionHandling_throwException(teavm_local_2));
            TEAVM_UNREACHABLE
            break;
        }
    TEAVM_END_TRY
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jnc_Charset_encode(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void * volatile teavm_spill_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_TRY
        teavm_spill_3 = teavm_local_3;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4882, TEAVM_METHOD(teavm_this_, jnc_Charset_VT, virt_newEncoder)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(4883, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
        teavm_local_3 = sfld_jnc_CodingErrorAction_REPLACE;
        teavm_spill_3 = teavm_local_3;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4884, meth_jnc_CharsetEncoder_onMalformedInput(TEAVM_WITH_CALL_SITE_ID(4885, teavm_nullCheck(teavm_local_2)), teavm_local_3));
        teavm_spill_3 = teavm_local_3;
        teavm_local_2 = sfld_jnc_CodingErrorAction_REPLACE;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4886, meth_jnc_CharsetEncoder_onUnmappableCharacter(TEAVM_WITH_CALL_SITE_ID(4887, teavm_nullCheck(teavm_local_3)), teavm_local_2));
        teavm_spill_3 = teavm_local_3;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(4888, meth_jnc_CharsetEncoder_encode_0(TEAVM_WITH_CALL_SITE_ID(4889, teavm_nullCheck(teavm_local_3)), teavm_local_1));
        teavm_spill_3 = teavm_local_3;
    TEAVM_CATCH
        // CATCH java.nio.charset.CharacterCodingException
        case 1: {
            teavm_local_3 = teavm_spill_3;
            teavm_local_4 = teavm_catchException();
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(4890, meth_otr_Allocator_allocate(&jl_AssertionError_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(4891, meth_jl_AssertionError__init_(teavm_local_2, TEAVM_GET_STRING(495), teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(4892, meth_otr_ExceptionHandling_throwException(teavm_local_2));
            TEAVM_UNREACHABLE
            break;
        }
    TEAVM_END_TRY
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t supertypeof_jnc_Charset(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 223 || tag >= 233) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnc_Charset_Cls[3];
alignas(8) jnc_Charset_VT jnc_Charset_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_Charset), sizeof(void*)),
        .flags = 0,
        .tag = 223,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnc_Charset,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jnc_Charset_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_decode = &meth_jnc_Charset_decode,
    .virt_encode = &meth_jnc_Charset_encode
};
static int16_t teavm_classLayouts_jnc_Charset_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jnc_Charset, fld_canonicalName), (int16_t) offsetof(cls_jnc_Charset, fld_aliases)
};
void sysinitclass_jnc_Charset() {
}
