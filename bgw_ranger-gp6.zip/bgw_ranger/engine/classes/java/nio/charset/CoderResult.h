#pragma once
#include "../../../../runtime.h"
#include "../../lang/Object.h"
#include "CoderResult.h"

extern void sysinitclass_jnc_CoderResult();
typedef struct cls_jnc_CoderResult {
    struct TeaVM_Object parent;
    int8_t fld_kind;
    int32_t fld_length;
} cls_jnc_CoderResult;
extern void* sfld_jnc_CoderResult_UNDERFLOW;
extern void* sfld_jnc_CoderResult_OVERFLOW;
extern void meth_jnc_CoderResult__init_(void*, int32_t, int32_t);
extern int32_t meth_jnc_CoderResult_isUnderflow(void*);
extern int32_t meth_jnc_CoderResult_isOverflow(void*);
extern int32_t meth_jnc_CoderResult_isError(void*);
extern int32_t meth_jnc_CoderResult_isMalformed(void*);
extern int32_t meth_jnc_CoderResult_isUnmappable(void*);
extern int32_t meth_jnc_CoderResult_length(void*);
extern void* meth_jnc_CoderResult_malformedForLength(int32_t);
extern void meth_jnc_CoderResult_throwException(void*);
extern void meth_jnc_CoderResult__clinit_();
extern void initclass_jnc_CoderResult();
extern int32_t supertypeof_jnc_CoderResult(TeaVM_Class*, TeaVM_Class*);
typedef struct jnc_CoderResult_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_isError)(void*); // 11
    int32_t (*virt_isMalformed)(void*); // 12
    void (*pad0)(); // 13
    void (*virt_throwException)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    int32_t (*virt_isOverflow)(void*); // 21
    int32_t (*virt_isUnmappable)(void*); // 22
    void (*pad7)(); // 23
    void (*pad8)(); // 24
    int32_t (*virt_length)(void*); // 25
    void (*pad9)(); // 26
    void (*pad10)(); // 27
    int32_t (*virt_isUnderflow)(void*); // 28
    void (*pad11)(); // 29
    void (*pad12)(); // 30
    void (*pad13)(); // 31
    void (*pad14)(); // 32
    void (*pad15)(); // 33
    void (*pad16)(); // 34
    void (*pad17)(); // 35
    void (*pad18)(); // 36
    void (*pad19)(); // 37
    void (*pad20)(); // 38
    void (*pad21)(); // 39
    void (*pad22)(); // 40
    void (*pad23)(); // 41
    void (*pad24)(); // 42
    void (*pad25)(); // 43
    void (*pad26)(); // 44
    void (*pad27)(); // 45
    void (*pad28)(); // 46
    void (*pad29)(); // 47
    void (*pad30)(); // 48
    void (*pad31)(); // 49
} jnc_CoderResult_VT;
extern jnc_CoderResult_VT jnc_CoderResult_Cls;
