#pragma once
#include "../../../../runtime.h"
#include "../../lang/Object.h"
#include "CharsetDecoder.h"

extern void sysinitclass_jnc_CharsetDecoder();
typedef struct cls_jnc_CharsetDecoder {
    struct TeaVM_Object parent;
    void* fld_charset;
    float fld_averageCharsPerByte;
    float fld_maxCharsPerByte;
    void* fld_replacement;
    void* fld_malformedAction;
    void* fld_unmappableAction;
    int32_t fld_state;
} cls_jnc_CharsetDecoder;
extern void meth_jnc_CharsetDecoder__init_(void*, void*, float, float);
extern void* meth_jnc_CharsetDecoder_onMalformedInput(void*, void*);
extern void meth_jnc_CharsetDecoder_implOnMalformedInput(void*, void*);
extern void* meth_jnc_CharsetDecoder_onUnmappableCharacter(void*, void*);
extern void meth_jnc_CharsetDecoder_implOnUnmappableCharacter(void*, void*);
extern void* meth_jnc_CharsetDecoder_decode_0(void*, void*, void*, int32_t);
extern void* meth_jnc_CharsetDecoder_flush(void*, void*);
extern void* meth_jnc_CharsetDecoder_reset(void*);
extern void* meth_jnc_CharsetDecoder_decode(void*, void*);
extern void* meth_jnc_CharsetDecoder_expand(void*, void*);
extern void* meth_jnc_CharsetDecoder_implFlush(void*, void*);
extern void meth_jnc_CharsetDecoder_implReset(void*);
extern int32_t supertypeof_jnc_CharsetDecoder(TeaVM_Class*, TeaVM_Class*);
typedef struct jnc_CharsetDecoder_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_implReset)(void*); // 11
    void (*virt_implOnUnmappableCharacter)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_decode)(void*, void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_implFlush_0)(void*, void*); // 21
    void* (*virt_decodeLoop)(void*, void*, void*); // 22
    void* (*virt_onMalformedInput_0)(void*, void*); // 23
    void* (*virt_reset_2)(void*); // 24
    void (*pad7)(); // 25
    void (*pad8)(); // 26
    void* (*virt_flush_0)(void*, void*); // 27
    void (*virt_implOnMalformedInput)(void*, void*); // 28
    void (*pad9)(); // 29
    void (*pad10)(); // 30
    void (*pad11)(); // 31
    void (*pad12)(); // 32
    void (*pad13)(); // 33
    void (*pad14)(); // 34
    void (*pad15)(); // 35
    void (*pad16)(); // 36
    void* (*virt_decode_0)(void*, void*, void*, int32_t); // 37
    void (*pad17)(); // 38
    void (*pad18)(); // 39
    void (*pad19)(); // 40
    void (*pad20)(); // 41
    void (*pad21)(); // 42
    void (*pad22)(); // 43
    void (*pad23)(); // 44
    void (*pad24)(); // 45
    void (*pad25)(); // 46
    void (*pad26)(); // 47
    void* (*virt_onUnmappableCharacter_0)(void*, void*); // 48
    void (*pad27)(); // 49
} jnc_CharsetDecoder_VT;
extern jnc_CharsetDecoder_VT jnc_CharsetDecoder_Cls;
