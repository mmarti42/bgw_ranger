#pragma once
#include "../../../../../runtime.h"
#include "../../../lang/Object.h"
#include "BufferedDecoder@dController.h"

extern void sysinitclass_jnci_BufferedDecoder_Controller();
typedef struct cls_jnci_BufferedDecoder_Controller {
    struct TeaVM_Object parent;
    void* fld_in;
    void* fld_out;
    int32_t fld_inPosition;
    int32_t fld_outPosition;
} cls_jnci_BufferedDecoder_Controller;
extern void meth_jnci_BufferedDecoder_Controller__init_(void*, void*, void*);
extern int32_t meth_jnci_BufferedDecoder_Controller_hasMoreInput(void*, int32_t);
extern int32_t meth_jnci_BufferedDecoder_Controller_hasMoreOutput(void*, int32_t);
extern void meth_jnci_BufferedDecoder_Controller_setInPosition(void*, int32_t);
extern void meth_jnci_BufferedDecoder_Controller_setOutPosition(void*, int32_t);
extern int32_t supertypeof_jnci_BufferedDecoder_Controller(TeaVM_Class*, TeaVM_Class*);
typedef struct jnci_BufferedDecoder_Controller_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_setOutPosition)(void*, int32_t); // 11
    void (*virt_setInPosition)(void*, int32_t); // 12
    void (*pad0)(); // 13
    int32_t (*virt_hasMoreOutput)(void*, int32_t); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void (*pad8)(); // 22
    void (*pad9)(); // 23
    void (*pad10)(); // 24
    void (*pad11)(); // 25
    void (*pad12)(); // 26
    void (*pad13)(); // 27
    int32_t (*virt_hasMoreInput_0)(void*, int32_t); // 28
    void (*pad14)(); // 29
    void (*pad15)(); // 30
    void (*pad16)(); // 31
    void (*pad17)(); // 32
    void (*pad18)(); // 33
    void (*pad19)(); // 34
    void (*pad20)(); // 35
    void (*pad21)(); // 36
    void (*pad22)(); // 37
    void (*pad23)(); // 38
    void (*pad24)(); // 39
    void (*pad25)(); // 40
    void (*pad26)(); // 41
    void (*pad27)(); // 42
    void (*pad28)(); // 43
    void (*pad29)(); // 44
    void (*pad30)(); // 45
    void (*pad31)(); // 46
    void (*pad32)(); // 47
    void (*pad33)(); // 48
    void (*pad34)(); // 49
} jnci_BufferedDecoder_Controller_VT;
extern jnci_BufferedDecoder_Controller_VT jnci_BufferedDecoder_Controller_Cls;
