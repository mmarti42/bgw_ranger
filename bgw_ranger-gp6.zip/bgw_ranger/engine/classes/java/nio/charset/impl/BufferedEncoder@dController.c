#include "BufferedEncoder@dController.h"
#include "../../../lang/Object.h"
#include "../../Buffer.h"
#include "../../../../../strings.h"

void meth_jnci_BufferedEncoder_Controller__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(27, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder_Controller, fld_in) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder_Controller, fld_out) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jnci_BufferedEncoder_Controller_hasMoreInput(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder_Controller, fld_in);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(28, meth_jn_Buffer_hasRemaining(TEAVM_WITH_CALL_SITE_ID(29, teavm_nullCheck(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jnci_BufferedEncoder_Controller_hasMoreOutput(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder_Controller, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = ((TEAVM_WITH_CALL_SITE_ID(30, meth_jn_Buffer_remaining(TEAVM_WITH_CALL_SITE_ID(31, teavm_nullCheck(teavm_local_2)))) < teavm_local_1) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jnci_BufferedEncoder_Controller_setInPosition(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder_Controller, fld_inPosition) = teavm_local_1;
}
void meth_jnci_BufferedEncoder_Controller_setOutPosition(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder_Controller, fld_outPosition) = teavm_local_1;
}
int32_t supertypeof_jnci_BufferedEncoder_Controller(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 7 || tag >= 9) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnci_BufferedEncoder_Controller_Cls[3];
alignas(8) jnci_BufferedEncoder_Controller_VT jnci_BufferedEncoder_Controller_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_BufferedEncoder_Controller), sizeof(void*)),
        .flags = 0,
        .tag = 7,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnci_BufferedEncoder_Controller,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jnci_BufferedEncoder_Controller_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_setOutPosition = &meth_jnci_BufferedEncoder_Controller_setOutPosition,
    .virt_setInPosition = &meth_jnci_BufferedEncoder_Controller_setInPosition,
    .virt_hasMoreOutput = &meth_jnci_BufferedEncoder_Controller_hasMoreOutput,
    .virt_hasMoreInput = &meth_jnci_BufferedEncoder_Controller_hasMoreInput
};
static int16_t teavm_classLayouts_jnci_BufferedEncoder_Controller_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jnci_BufferedEncoder_Controller, fld_in), (int16_t) offsetof(cls_jnci_BufferedEncoder_Controller, fld_out)
};
void sysinitclass_jnci_BufferedEncoder_Controller() {
}
