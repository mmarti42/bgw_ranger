#include "BufferedDecoder.h"
#include "../CharsetDecoder.h"
#include "../../../../../arrays/primitives/byte.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../arrays/primitives/char.h"
#include "../../Buffer.h"
#include "../../../lang/Math.h"
#include "../../ByteBuffer.h"
#include "BufferedDecoder@dController.h"
#include "../CoderResult.h"
#include "../../CharBuffer.h"
#include "../../../../../strings.h"
#include "../../../lang/Object.h"

void meth_jnci_BufferedDecoder__init_(void* teavm_this_, void* teavm_local_1, float teavm_local_2, float teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(36824, meth_jnc_CharsetDecoder__init_(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(36825, meth_otr_Allocator_allocateArray(&Arr_B_Cls, INT32_C(512)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedDecoder, fld_inArray) = teavm_local_4;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(36826, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(512)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedDecoder, fld_outArray) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
void* meth_jnci_BufferedDecoder_decodeLoop(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    void* teavm_local_14;
    void* teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(5));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jnci_BufferedDecoder, fld_inArray);
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnci_BufferedDecoder, fld_outArray);
    while (1) {
        if (((teavm_local_4 + INT32_C(32)) > teavm_local_5)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36827, teavm_nullCheck(teavm_local_1));
            if (TEAVM_WITH_CALL_SITE_ID(36828, meth_jn_Buffer_hasRemaining(teavm_local_1))) {
                teavm_local_7 = teavm_local_4;
                while (1) {
                    if (!(teavm_local_7 < teavm_local_5)) break;
                    teavm_local_8 = (teavm_local_7 - teavm_local_4);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(36829, teavm_nullCheck(teavm_local_3));
                    teavm_local_9 = teavm_local_3;
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(36830, teavm_checkBounds(teavm_local_7, teavm_local_9));
                    TEAVM_ARRAY_AT(teavm_local_9, int8_t, TEAVM_WITH_CALL_SITE_ID(36831, teavm_checkBounds(teavm_local_8, teavm_local_9))) = TEAVM_ARRAY_AT(teavm_local_9, int8_t, teavm_local_7);
                    teavm_local_7 = (teavm_local_7 + INT32_C(1));
                }
                teavm_local_10 = (teavm_local_5 - teavm_local_4);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                teavm_local_11 = (TEAVM_WITH_CALL_SITE_ID(36832, meth_jn_Buffer_remaining(teavm_local_1)) + teavm_local_10);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(36833, teavm_nullCheck(teavm_local_3));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(36834, meth_jl_Math_min(teavm_local_11, TEAVM_ARRAY_LENGTH(teavm_local_3)));
                TEAVM_WITH_CALL_SITE_ID(36835, TEAVM_METHOD(teavm_local_1, jn_ByteBuffer_VT, virt_get_14)(teavm_local_1, teavm_local_3, teavm_local_10, (teavm_local_5 - teavm_local_10)));
                teavm_local_4 = INT32_C(0);
            }
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36836, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(36837, meth_jn_Buffer_hasRemaining(teavm_local_2)))) {
            goto teavm_label_2;
        }
        teavm_local_12 = INT32_C(0);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(36838, meth_jn_Buffer_remaining(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(36839, teavm_nullCheck(teavm_local_6));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(36840, meth_jl_Math_min(teavm_local_8, TEAVM_ARRAY_LENGTH(teavm_local_6)));
        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(36841, meth_otr_Allocator_allocate(&jnci_BufferedDecoder_Controller_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
        TEAVM_WITH_CALL_SITE_ID(36842, meth_jnci_BufferedDecoder_Controller__init_(teavm_local_14, teavm_local_1, teavm_local_2));
        teavm_local_15 = TEAVM_WITH_CALL_SITE_ID(36843, TEAVM_METHOD(teavm_this_, jnci_BufferedDecoder_VT, virt_arrayDecode)(teavm_this_, teavm_local_3, teavm_local_4, teavm_local_5, teavm_local_6, teavm_local_12, teavm_local_13, teavm_local_14));
        teavm_local_4 = TEAVM_FIELD(teavm_local_14, cls_jnci_BufferedDecoder_Controller, fld_inPosition);
        if (((teavm_local_15 == NULL) && (teavm_local_12 == TEAVM_FIELD(teavm_local_14, cls_jnci_BufferedDecoder_Controller, fld_outPosition)))) {
            TEAVM_WITH_CALL_SITE_ID(36844, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
            teavm_local_15 = sfld_jnc_CoderResult_UNDERFLOW;
        }
        teavm_local_10 = TEAVM_FIELD(teavm_local_14, cls_jnci_BufferedDecoder_Controller, fld_outPosition);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_15);
        TEAVM_WITH_CALL_SITE_ID(36845, TEAVM_METHOD(teavm_local_2, jn_CharBuffer_VT, virt_put_3)(teavm_local_2, teavm_local_6, INT32_C(0), teavm_local_10));
        if ((teavm_local_15 != NULL)) {
            goto teavm_label_3;
        }
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36846, teavm_nullCheck(teavm_local_1));
    if ((!((!TEAVM_WITH_CALL_SITE_ID(36847, meth_jn_Buffer_hasRemaining(teavm_local_1))) && (teavm_local_4 >= teavm_local_5)))) {
        TEAVM_WITH_CALL_SITE_ID(36848, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
        teavm_local_15 = sfld_jnc_CoderResult_OVERFLOW;
    } else {
        TEAVM_WITH_CALL_SITE_ID(36849, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
        teavm_local_15 = sfld_jnc_CoderResult_UNDERFLOW;
    }
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_15);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36850, teavm_nullCheck(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(36851, TEAVM_METHOD(teavm_local_1, jn_ByteBuffer_VT, virt_position_2)(teavm_local_1, (TEAVM_WITH_CALL_SITE_ID(36852, meth_jn_Buffer_position(teavm_local_1)) - (teavm_local_5 - teavm_local_4))));
    TEAVM_RELEASE_STACK;
    return teavm_local_15;
}
int32_t supertypeof_jnci_BufferedDecoder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1252 || tag >= 1256) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnci_BufferedDecoder_Cls[3];
alignas(8) jnci_BufferedDecoder_VT jnci_BufferedDecoder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_BufferedDecoder), sizeof(void*)),
        .flags = 0,
        .tag = 1252,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnci_BufferedDecoder,
        .superclass = (TeaVM_Class*) &jnc_CharsetDecoder_Cls,
        .layout = teavm_classLayouts_jnci_BufferedDecoder_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_implReset = &meth_jnc_CharsetDecoder_implReset,
    .virt_implOnUnmappableCharacter = &meth_jnc_CharsetDecoder_implOnUnmappableCharacter,
    .virt_decode = &meth_jnc_CharsetDecoder_decode,
    .virt_implFlush_0 = &meth_jnc_CharsetDecoder_implFlush,
    .virt_decodeLoop = &meth_jnci_BufferedDecoder_decodeLoop,
    .virt_onMalformedInput_0 = &meth_jnc_CharsetDecoder_onMalformedInput,
    .virt_reset_2 = &meth_jnc_CharsetDecoder_reset,
    .virt_flush_0 = &meth_jnc_CharsetDecoder_flush,
    .virt_implOnMalformedInput = &meth_jnc_CharsetDecoder_implOnMalformedInput,
    .virt_decode_0 = &meth_jnc_CharsetDecoder_decode_0,
    .virt_onUnmappableCharacter_0 = &meth_jnc_CharsetDecoder_onUnmappableCharacter
};
static int16_t teavm_classLayouts_jnci_BufferedDecoder_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jnci_BufferedDecoder, fld_inArray), (int16_t) offsetof(cls_jnci_BufferedDecoder, fld_outArray)
};
void sysinitclass_jnci_BufferedDecoder() {
}
