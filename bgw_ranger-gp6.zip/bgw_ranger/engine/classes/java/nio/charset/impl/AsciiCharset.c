#include "AsciiCharset.h"
#include "../Charset.h"
#include "../../../../../arrayclass.h"
#include "../../../lang/String.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../strings.h"
#include "../../../lang/Object.h"

void meth_jnci_AsciiCharset__init_(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3974, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(3975, meth_jnc_Charset__init_(teavm_this_, TEAVM_GET_STRING(454), teavm_local_1));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jnci_AsciiCharset(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 226 || tag >= 228) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnci_AsciiCharset_VT jnci_AsciiCharset_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_AsciiCharset), sizeof(void*)),
            .flags = 0,
            .tag = 226,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jnci_AsciiCharset,
            .superclass = (TeaVM_Class*) &jnc_Charset_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_decode = &meth_jnc_Charset_decode,
        .virt_encode = &meth_jnc_Charset_encode
    }
};
void sysinitclass_jnci_AsciiCharset() {
}
