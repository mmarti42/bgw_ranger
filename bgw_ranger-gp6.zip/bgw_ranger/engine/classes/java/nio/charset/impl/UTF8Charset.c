#include "UTF8Charset.h"
#include "../Charset.h"
#include "../../../../../arrayclass.h"
#include "../../../lang/String.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../strings.h"
#include "UTF8Decoder.h"
#include "UTF8Encoder.h"
#include "../../../lang/Object.h"

void* sfld_jnci_UTF8Charset_INSTANCE;
void meth_jnci_UTF8Charset__init_(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9126, teavm_initializeClass((TeaVM_Class*) &jnci_UTF8Charset_Cls, &initclass_jnci_UTF8Charset));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9127, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9128, meth_jnc_Charset__init_(teavm_this_, TEAVM_GET_STRING(678), teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_jnci_UTF8Charset_newDecoder(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9129, meth_otr_Allocator_allocate(&jnci_UTF8Decoder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9130, meth_jnci_UTF8Decoder__init_(teavm_local_1, teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jnci_UTF8Charset_newEncoder(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9131, meth_otr_Allocator_allocate(&jnci_UTF8Encoder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9132, meth_jnci_UTF8Encoder__init_(teavm_local_1, teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_jnci_UTF8Charset__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9133, meth_otr_Allocator_allocate(&jnci_UTF8Charset_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9134, meth_jnci_UTF8Charset__init_(teavm_local_1));
    sfld_jnci_UTF8Charset_INSTANCE = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jnci_UTF8Charset() {
    TeaVM_Class* cls = (TeaVM_Class*) &jnci_UTF8Charset_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jnci_UTF8Charset__clinit_();
    }
}
int32_t supertypeof_jnci_UTF8Charset(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 228 || tag >= 230) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnci_UTF8Charset_VT jnci_UTF8Charset_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_UTF8Charset), sizeof(void*)),
            .flags = 0,
            .tag = 228,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jnci_UTF8Charset,
            .superclass = (TeaVM_Class*) &jnc_Charset_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_newEncoder = &meth_jnci_UTF8Charset_newEncoder,
        .virt_decode = &meth_jnc_Charset_decode,
        .virt_encode = &meth_jnc_Charset_encode,
        .virt_newDecoder = &meth_jnci_UTF8Charset_newDecoder
    }
};
static void** teavm_gc_localStaticRoots_jnci_UTF8Charset_Cls[1] = {
(void**) &sfld_jnci_UTF8Charset_INSTANCE
};
void sysinitclass_jnci_UTF8Charset() {
sfld_jnci_UTF8Charset_INSTANCE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jnci_UTF8Charset_Cls, 1);
}
