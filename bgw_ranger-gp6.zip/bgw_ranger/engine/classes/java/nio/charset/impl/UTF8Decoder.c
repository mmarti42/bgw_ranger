#include "UTF8Decoder.h"
#include "BufferedDecoder.h"
#include "../../../lang/Character.h"
#include "../CoderResult.h"
#include "BufferedDecoder@dController.h"
#include "../../../../../strings.h"
#include "../../../lang/Object.h"
#include "../CharsetDecoder.h"

void meth_jnci_UTF8Decoder__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13490, meth_jnci_BufferedDecoder__init_(teavm_this_, teavm_local_1, 0x1.555556p-2f, 0x1.0p-1f));
    TEAVM_RELEASE_STACK;
}
void* meth_jnci_UTF8Decoder_arrayDecode(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, TeaVM_Array* teavm_local_4, int32_t teavm_local_5, int32_t teavm_local_6, void* teavm_local_7) {
    void* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    int32_t teavm_local_18;
    int32_t teavm_local_19;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_8 = NULL;
    while (1) {
        if (!(teavm_local_2 < teavm_local_3)) break;
        if ((teavm_local_5 >= teavm_local_6)) {
            goto teavm_label_11;
        }
        teavm_local_9 = (teavm_local_2 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13491, teavm_nullCheck(teavm_local_1));
        teavm_local_10 = teavm_local_1;
        teavm_local_11 = (TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13492, teavm_checkBounds(teavm_local_2, teavm_local_10))) & INT32_C(255));
        if ((!(teavm_local_11 & INT32_C(128)))) {
            teavm_local_12 = (teavm_local_5 + INT32_C(1));
            teavm_local_13 = TEAVM_TO_CHAR(teavm_local_11);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13493, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(13494, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_13;
        } else if (((teavm_local_11 & INT32_C(224)) == INT32_C(192))) {
            if ((teavm_local_9 >= teavm_local_3)) {
                goto teavm_label_2;
            }
            teavm_local_13 = (teavm_local_9 + INT32_C(1));
            teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13495, teavm_checkBounds(teavm_local_9, teavm_local_10)));
            if ((!TEAVM_WITH_CALL_SITE_ID(13496, meth_jnci_UTF8Decoder_checkMidByte(teavm_this_, teavm_local_14)))) {
                goto teavm_label_6;
            }
            teavm_local_12 = (teavm_local_5 + INT32_C(1));
            teavm_local_15 = TEAVM_TO_CHAR((((teavm_local_11 & INT32_C(31)) << INT32_C(6)) | (teavm_local_14 & INT32_C(63))));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13497, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(13498, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_15;
            teavm_local_9 = teavm_local_13;
        } else if (((teavm_local_11 & INT32_C(240)) == INT32_C(224))) {
            if (((teavm_local_9 + INT32_C(2)) > teavm_local_3)) {
                goto teavm_label_3;
            }
            teavm_local_13 = (teavm_local_9 + INT32_C(1));
            teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13499, teavm_checkBounds(teavm_local_9, teavm_local_10)));
            teavm_local_9 = (teavm_local_13 + INT32_C(1));
            teavm_local_16 = TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13500, teavm_checkBounds(teavm_local_13, teavm_local_10)));
            if ((!TEAVM_WITH_CALL_SITE_ID(13501, meth_jnci_UTF8Decoder_checkMidByte(teavm_this_, teavm_local_14)))) {
                goto teavm_label_7;
            }
            if ((!TEAVM_WITH_CALL_SITE_ID(13502, meth_jnci_UTF8Decoder_checkMidByte(teavm_this_, teavm_local_16)))) {
                goto teavm_label_7;
            }
            teavm_local_17 = TEAVM_TO_CHAR(((((teavm_local_11 & INT32_C(15)) << INT32_C(12)) | ((teavm_local_14 & INT32_C(63)) << INT32_C(6))) | (teavm_local_16 & INT32_C(63))));
            if (TEAVM_WITH_CALL_SITE_ID(13503, meth_jl_Character_isSurrogate(teavm_local_17))) {
                goto teavm_label_8;
            }
            teavm_local_12 = (teavm_local_5 + INT32_C(1));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13504, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(13505, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_17;
        } else {
            if (((teavm_local_11 & INT32_C(248)) != INT32_C(240))) {
                goto teavm_label_9;
            }
            if (((teavm_local_9 + INT32_C(3)) > teavm_local_3)) {
                goto teavm_label_4;
            }
            if (((teavm_local_5 + INT32_C(2)) > teavm_local_6)) {
                goto teavm_label_5;
            }
            teavm_local_12 = (teavm_local_9 + INT32_C(1));
            teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13506, teavm_checkBounds(teavm_local_9, teavm_local_10)));
            teavm_local_13 = (teavm_local_12 + INT32_C(1));
            teavm_local_16 = TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13507, teavm_checkBounds(teavm_local_12, teavm_local_10)));
            teavm_local_9 = (teavm_local_13 + INT32_C(1));
            teavm_local_18 = TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(13508, teavm_checkBounds(teavm_local_13, teavm_local_10)));
            if ((!TEAVM_WITH_CALL_SITE_ID(13509, meth_jnci_UTF8Decoder_checkMidByte(teavm_this_, teavm_local_14)))) {
                goto teavm_label_10;
            }
            if ((!TEAVM_WITH_CALL_SITE_ID(13510, meth_jnci_UTF8Decoder_checkMidByte(teavm_this_, teavm_local_16)))) {
                goto teavm_label_10;
            }
            if ((!TEAVM_WITH_CALL_SITE_ID(13511, meth_jnci_UTF8Decoder_checkMidByte(teavm_this_, teavm_local_18)))) {
                goto teavm_label_10;
            }
            teavm_local_19 = (((((teavm_local_11 & INT32_C(7)) << INT32_C(18)) | ((teavm_local_14 & INT32_C(63)) << INT32_C(12))) | ((teavm_local_16 & INT32_C(63)) << INT32_C(6))) | (teavm_local_18 & INT32_C(63)));
            teavm_local_13 = (teavm_local_5 + INT32_C(1));
            teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(13512, meth_jl_Character_highSurrogate(teavm_local_19));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13513, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(13514, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_12;
            teavm_local_12 = (teavm_local_13 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(13515, teavm_checkBounds(teavm_local_13, teavm_local_10))) = TEAVM_WITH_CALL_SITE_ID(13516, meth_jl_Character_lowSurrogate(teavm_local_19));
        }
        teavm_local_2 = teavm_local_9;
        teavm_local_5 = teavm_local_12;
    }
    goto teavm_label_1;
teavm_label_11:;
    goto teavm_label_1;
teavm_label_10:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(13517, meth_jnc_CoderResult_malformedForLength(INT32_C(1)));
    goto teavm_label_1;
teavm_label_9:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(13518, meth_jnc_CoderResult_malformedForLength(INT32_C(1)));
    goto teavm_label_1;
teavm_label_8:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(13519, meth_jnc_CoderResult_malformedForLength(INT32_C(3)));
    goto teavm_label_1;
teavm_label_7:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(13520, meth_jnc_CoderResult_malformedForLength(INT32_C(1)));
    goto teavm_label_1;
teavm_label_6:;
    teavm_local_2 = (teavm_local_13 + -INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(13521, meth_jnc_CoderResult_malformedForLength(INT32_C(1)));
    goto teavm_label_1;
teavm_label_5:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13522, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if (TEAVM_WITH_CALL_SITE_ID(13523, TEAVM_METHOD(teavm_local_7, jnci_BufferedDecoder_Controller_VT, virt_hasMoreOutput)(teavm_local_7, INT32_C(2)))) {
        goto teavm_label_1;
    }
    TEAVM_WITH_CALL_SITE_ID(13524, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_8 = sfld_jnc_CoderResult_OVERFLOW;
    goto teavm_label_1;
teavm_label_4:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13525, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if (TEAVM_WITH_CALL_SITE_ID(13526, TEAVM_METHOD(teavm_local_7, jnci_BufferedDecoder_Controller_VT, virt_hasMoreInput_0)(teavm_local_7, INT32_C(4)))) {
        goto teavm_label_1;
    }
    TEAVM_WITH_CALL_SITE_ID(13527, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_8 = sfld_jnc_CoderResult_UNDERFLOW;
    goto teavm_label_1;
teavm_label_3:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13528, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if (TEAVM_WITH_CALL_SITE_ID(13529, TEAVM_METHOD(teavm_local_7, jnci_BufferedDecoder_Controller_VT, virt_hasMoreInput_0)(teavm_local_7, INT32_C(3)))) {
        goto teavm_label_1;
    }
    TEAVM_WITH_CALL_SITE_ID(13530, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_8 = sfld_jnc_CoderResult_UNDERFLOW;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13531, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(13532, TEAVM_METHOD(teavm_local_7, jnci_BufferedDecoder_Controller_VT, virt_hasMoreInput_0)(teavm_local_7, INT32_C(2))))) {
        TEAVM_WITH_CALL_SITE_ID(13533, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
        teavm_local_8 = sfld_jnc_CoderResult_UNDERFLOW;
    }
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13534, teavm_nullCheck(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(13535, TEAVM_METHOD(teavm_local_7, jnci_BufferedDecoder_Controller_VT, virt_setInPosition)(teavm_local_7, teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(13536, TEAVM_METHOD(teavm_local_7, jnci_BufferedDecoder_Controller_VT, virt_setOutPosition)(teavm_local_7, teavm_local_5));
    TEAVM_RELEASE_STACK;
    return teavm_local_8;
}
int32_t meth_jnci_UTF8Decoder_checkMidByte(void* teavm_this_, int32_t teavm_local_1) {
    return (((teavm_local_1 & INT32_C(192)) != INT32_C(128)) ? INT32_C(0) : INT32_C(1));
}
int32_t supertypeof_jnci_UTF8Decoder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1253 || tag >= 1255) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnci_UTF8Decoder_VT jnci_UTF8Decoder_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_UTF8Decoder), sizeof(void*)),
            .flags = 0,
            .tag = 1253,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jnci_UTF8Decoder,
            .superclass = (TeaVM_Class*) &jnci_BufferedDecoder_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_implReset = &meth_jnc_CharsetDecoder_implReset,
        .virt_implOnUnmappableCharacter = &meth_jnc_CharsetDecoder_implOnUnmappableCharacter,
        .virt_decode = &meth_jnc_CharsetDecoder_decode,
        .virt_implFlush_0 = &meth_jnc_CharsetDecoder_implFlush,
        .virt_decodeLoop = &meth_jnci_BufferedDecoder_decodeLoop,
        .virt_onMalformedInput_0 = &meth_jnc_CharsetDecoder_onMalformedInput,
        .virt_reset_2 = &meth_jnc_CharsetDecoder_reset,
        .virt_flush_0 = &meth_jnc_CharsetDecoder_flush,
        .virt_implOnMalformedInput = &meth_jnc_CharsetDecoder_implOnMalformedInput,
        .virt_arrayDecode = &meth_jnci_UTF8Decoder_arrayDecode,
        .virt_decode_0 = &meth_jnc_CharsetDecoder_decode_0,
        .virt_onUnmappableCharacter_0 = &meth_jnc_CharsetDecoder_onUnmappableCharacter
    }
};
void sysinitclass_jnci_UTF8Decoder() {
}
