#include "BufferedEncoder.h"
#include "../CharsetEncoder.h"
#include "../../../../../arrays/primitives/char.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../arrays/primitives/byte.h"
#include "../../Buffer.h"
#include "../../../lang/Math.h"
#include "../../CharBuffer.h"
#include "BufferedEncoder@dController.h"
#include "../CoderResult.h"
#include "../../ByteBuffer.h"
#include "../../../../../strings.h"
#include "../../../lang/Object.h"

void meth_jnci_BufferedEncoder__init_(void* teavm_this_, void* teavm_local_1, float teavm_local_2, float teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(10628, meth_jnc_CharsetEncoder__init__0(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10629, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(512)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder, fld_inArray) = teavm_local_4;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10630, meth_otr_Allocator_allocateArray(&Arr_B_Cls, INT32_C(512)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder, fld_outArray) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
void* meth_jnci_BufferedEncoder_encodeLoop(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    void* teavm_local_13;
    void* teavm_local_14;
    int32_t teavm_local_15;
    TEAVM_ALLOC_STACK(INT32_C(5));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder, fld_inArray);
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnci_BufferedEncoder, fld_outArray);
    while (1) {
        if (((teavm_local_4 + INT32_C(32)) > teavm_local_5)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(4));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10631, teavm_nullCheck(teavm_local_1));
            if (TEAVM_WITH_CALL_SITE_ID(10632, meth_jn_Buffer_hasRemaining(teavm_local_1))) {
                teavm_local_7 = teavm_local_4;
                while (1) {
                    if (!(teavm_local_7 < teavm_local_5)) break;
                    teavm_local_8 = (teavm_local_7 - teavm_local_4);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10633, teavm_nullCheck(teavm_local_3));
                    teavm_local_9 = teavm_local_3;
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(10634, teavm_checkBounds(teavm_local_7, teavm_local_9));
                    TEAVM_ARRAY_AT(teavm_local_9, char16_t, TEAVM_WITH_CALL_SITE_ID(10635, teavm_checkBounds(teavm_local_8, teavm_local_9))) = TEAVM_ARRAY_AT(teavm_local_9, char16_t, teavm_local_7);
                    teavm_local_7 = (teavm_local_7 + INT32_C(1));
                }
                teavm_local_10 = (teavm_local_5 - teavm_local_4);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                teavm_local_8 = (TEAVM_WITH_CALL_SITE_ID(10636, meth_jn_Buffer_remaining(teavm_local_1)) + teavm_local_10);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10637, teavm_nullCheck(teavm_local_3));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(10638, meth_jl_Math_min(teavm_local_8, TEAVM_ARRAY_LENGTH(teavm_local_3)));
                TEAVM_WITH_CALL_SITE_ID(10639, TEAVM_METHOD(teavm_local_1, jn_CharBuffer_VT, virt_get_10)(teavm_local_1, teavm_local_3, teavm_local_10, (teavm_local_5 - teavm_local_10)));
                teavm_local_4 = INT32_C(0);
            }
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10640, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(10641, meth_jn_Buffer_hasRemaining(teavm_local_2)))) {
            goto teavm_label_2;
        }
        teavm_local_11 = INT32_C(0);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(10642, meth_jn_Buffer_remaining(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(10643, teavm_nullCheck(teavm_local_6));
        teavm_local_12 = TEAVM_WITH_CALL_SITE_ID(10644, meth_jl_Math_min(teavm_local_8, TEAVM_ARRAY_LENGTH(teavm_local_6)));
        teavm_local_13 = TEAVM_WITH_CALL_SITE_ID(10645, meth_otr_Allocator_allocate(&jnci_BufferedEncoder_Controller_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_13);
        TEAVM_WITH_CALL_SITE_ID(10646, meth_jnci_BufferedEncoder_Controller__init_(teavm_local_13, teavm_local_1, teavm_local_2));
        teavm_local_14 = TEAVM_WITH_CALL_SITE_ID(10647, TEAVM_METHOD(teavm_this_, jnci_BufferedEncoder_VT, virt_arrayEncode)(teavm_this_, teavm_local_3, teavm_local_4, teavm_local_5, teavm_local_6, teavm_local_11, teavm_local_12, teavm_local_13));
        teavm_local_4 = TEAVM_FIELD(teavm_local_13, cls_jnci_BufferedEncoder_Controller, fld_inPosition);
        teavm_local_15 = TEAVM_FIELD(teavm_local_13, cls_jnci_BufferedEncoder_Controller, fld_outPosition);
        if ((teavm_local_14 == NULL)) {
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10648, teavm_nullCheck(teavm_local_1));
            if (((!TEAVM_WITH_CALL_SITE_ID(10649, meth_jn_Buffer_hasRemaining(teavm_local_1))) && (teavm_local_4 >= teavm_local_5))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(10650, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
                teavm_local_14 = sfld_jnc_CoderResult_UNDERFLOW;
            } else if (((!TEAVM_WITH_CALL_SITE_ID(10651, meth_jn_Buffer_hasRemaining(teavm_local_2))) && (teavm_local_4 >= teavm_local_5))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(10652, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
                teavm_local_14 = sfld_jnc_CoderResult_OVERFLOW;
            }
        }
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(10653, TEAVM_METHOD(teavm_local_2, jn_ByteBuffer_VT, virt_put_4)(teavm_local_2, teavm_local_6, INT32_C(0), teavm_local_15));
        if ((teavm_local_14 != NULL)) {
            goto teavm_label_3;
        }
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10654, teavm_nullCheck(teavm_local_1));
    if ((!((!TEAVM_WITH_CALL_SITE_ID(10655, meth_jn_Buffer_hasRemaining(teavm_local_1))) && (teavm_local_4 >= teavm_local_5)))) {
        TEAVM_WITH_CALL_SITE_ID(10656, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
        teavm_local_14 = sfld_jnc_CoderResult_OVERFLOW;
    } else {
        TEAVM_WITH_CALL_SITE_ID(10657, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
        teavm_local_14 = sfld_jnc_CoderResult_UNDERFLOW;
    }
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_14);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(4));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10658, teavm_nullCheck(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(10659, TEAVM_METHOD(teavm_local_1, jn_CharBuffer_VT, virt_position_1)(teavm_local_1, (TEAVM_WITH_CALL_SITE_ID(10660, meth_jn_Buffer_position(teavm_local_1)) - (teavm_local_5 - teavm_local_4))));
    TEAVM_RELEASE_STACK;
    return teavm_local_14;
}
int32_t supertypeof_jnci_BufferedEncoder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 184 || tag >= 188) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnci_BufferedEncoder_Cls[3];
alignas(8) jnci_BufferedEncoder_VT jnci_BufferedEncoder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_BufferedEncoder), sizeof(void*)),
        .flags = 0,
        .tag = 184,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnci_BufferedEncoder,
        .superclass = (TeaVM_Class*) &jnc_CharsetEncoder_Cls,
        .layout = teavm_classLayouts_jnci_BufferedEncoder_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_implReset = &meth_jnc_CharsetEncoder_implReset,
    .virt_implOnUnmappableCharacter = &meth_jnc_CharsetEncoder_implOnUnmappableCharacter,
    .virt_encodeLoop = &meth_jnci_BufferedEncoder_encodeLoop,
    .virt_implFlush = &meth_jnc_CharsetEncoder_implFlush,
    .virt_encode = &meth_jnc_CharsetEncoder_encode_0,
    .virt_onMalformedInput = &meth_jnc_CharsetEncoder_onMalformedInput,
    .virt_reset = &meth_jnc_CharsetEncoder_reset,
    .virt_flush = &meth_jnc_CharsetEncoder_flush,
    .virt_implOnMalformedInput = &meth_jnc_CharsetEncoder_implOnMalformedInput,
    .virt_encode_0 = &meth_jnc_CharsetEncoder_encode,
    .virt_onUnmappableCharacter = &meth_jnc_CharsetEncoder_onUnmappableCharacter
};
static int16_t teavm_classLayouts_jnci_BufferedEncoder_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jnci_BufferedEncoder, fld_inArray), (int16_t) offsetof(cls_jnci_BufferedEncoder, fld_outArray)
};
void sysinitclass_jnci_BufferedEncoder() {
}
