#pragma once
#include "../../../../../runtime.h"
#include "../CharsetEncoder.h"
#include "BufferedEncoder.h"

extern void sysinitclass_jnci_BufferedEncoder();
typedef struct cls_jnci_BufferedEncoder {
    struct cls_jnc_CharsetEncoder parent;
    TeaVM_Array* fld_inArray;
    TeaVM_Array* fld_outArray;
} cls_jnci_BufferedEncoder;
extern void meth_jnci_BufferedEncoder__init_(void*, void*, float, float);
extern void* meth_jnci_BufferedEncoder_encodeLoop(void*, void*, void*);
extern int32_t supertypeof_jnci_BufferedEncoder(TeaVM_Class*, TeaVM_Class*);
typedef struct jnci_BufferedEncoder_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_implReset)(void*); // 11
    void (*virt_implOnUnmappableCharacter)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_encodeLoop)(void*, void*, void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_implFlush)(void*, void*); // 21
    void* (*virt_encode)(void*, void*); // 22
    void* (*virt_onMalformedInput)(void*, void*); // 23
    void* (*virt_reset)(void*); // 24
    void (*pad7)(); // 25
    void (*pad8)(); // 26
    void* (*virt_flush)(void*, void*); // 27
    void (*virt_implOnMalformedInput)(void*, void*); // 28
    void (*pad9)(); // 29
    void (*pad10)(); // 30
    void* (*virt_arrayEncode)(void*, TeaVM_Array*, int32_t, int32_t, TeaVM_Array*, int32_t, int32_t, void*); // 31
    void (*pad11)(); // 32
    void (*pad12)(); // 33
    void (*pad13)(); // 34
    void (*pad14)(); // 35
    void (*pad15)(); // 36
    void* (*virt_encode_0)(void*, void*, void*, int32_t); // 37
    void (*pad16)(); // 38
    void (*pad17)(); // 39
    void (*pad18)(); // 40
    void (*pad19)(); // 41
    void (*pad20)(); // 42
    void (*pad21)(); // 43
    void (*pad22)(); // 44
    void (*pad23)(); // 45
    void (*pad24)(); // 46
    void (*pad25)(); // 47
    void* (*virt_onUnmappableCharacter)(void*, void*); // 48
    void (*pad26)(); // 49
} jnci_BufferedEncoder_VT;
extern jnci_BufferedEncoder_VT jnci_BufferedEncoder_Cls;
