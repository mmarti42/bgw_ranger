#pragma once
#include "../../../../../runtime.h"
#include "BufferedDecoder.h"
#include "UTF8Decoder.h"

extern void sysinitclass_jnci_UTF8Decoder();
typedef struct cls_jnci_UTF8Decoder {
    struct cls_jnci_BufferedDecoder parent;
} cls_jnci_UTF8Decoder;
extern void meth_jnci_UTF8Decoder__init_(void*, void*);
extern void* meth_jnci_UTF8Decoder_arrayDecode(void*, TeaVM_Array*, int32_t, int32_t, TeaVM_Array*, int32_t, int32_t, void*);
extern int32_t meth_jnci_UTF8Decoder_checkMidByte(void*, int32_t);
extern int32_t supertypeof_jnci_UTF8Decoder(TeaVM_Class*, TeaVM_Class*);
typedef struct jnci_UTF8Decoder_VT {
    jnci_BufferedDecoder_VT parent;
} jnci_UTF8Decoder_VT;
extern jnci_UTF8Decoder_VT jnci_UTF8Decoder_Cls;
