#include "UTF8Encoder.h"
#include "BufferedEncoder.h"
#include "../../../lang/Character.h"
#include "../CoderResult.h"
#include "BufferedEncoder@dController.h"
#include "../../../../../strings.h"
#include "../../../lang/Object.h"
#include "../CharsetEncoder.h"

void meth_jnci_UTF8Encoder__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(8930, meth_jnci_BufferedEncoder__init_(teavm_this_, teavm_local_1, 2.0f, 4.0f));
    TEAVM_RELEASE_STACK;
}
void* meth_jnci_UTF8Encoder_arrayEncode(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, TeaVM_Array* teavm_local_4, int32_t teavm_local_5, int32_t teavm_local_6, void* teavm_local_7) {
    void* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    int32_t teavm_local_14;
    int32_t teavm_local_15;
    int32_t teavm_local_16;
    int32_t teavm_local_17;
    int32_t teavm_local_18;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_8 = NULL;
    while (1) {
        if (!(teavm_local_2 < teavm_local_3)) break;
        if ((teavm_local_5 >= teavm_local_6)) {
            goto teavm_label_8;
        }
        teavm_local_9 = (teavm_local_2 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(8931, teavm_nullCheck(teavm_local_1));
        teavm_local_10 = teavm_local_1;
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(8932, teavm_checkBounds(teavm_local_2, teavm_local_10)));
        if ((teavm_local_11 < INT32_C(128))) {
            teavm_local_12 = (teavm_local_5 + INT32_C(1));
            teavm_local_13 = TEAVM_TO_BYTE(teavm_local_11);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8933, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8934, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_13;
        } else if ((teavm_local_11 < INT32_C(2048))) {
            if (((teavm_local_5 + INT32_C(2)) > teavm_local_6)) {
                goto teavm_label_2;
            }
            teavm_local_13 = (teavm_local_5 + INT32_C(1));
            teavm_local_12 = TEAVM_TO_BYTE((INT32_C(192) | (teavm_local_11 >> INT32_C(6))));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8935, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8936, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_12;
            teavm_local_12 = (teavm_local_13 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8937, teavm_checkBounds(teavm_local_13, teavm_local_10))) = TEAVM_TO_BYTE((INT32_C(128) | (teavm_local_11 & INT32_C(63))));
        } else if ((!TEAVM_WITH_CALL_SITE_ID(8938, meth_jl_Character_isSurrogate(teavm_local_11)))) {
            if (((teavm_local_5 + INT32_C(3)) > teavm_local_6)) {
                goto teavm_label_3;
            }
            teavm_local_12 = (teavm_local_5 + INT32_C(1));
            teavm_local_13 = TEAVM_TO_BYTE((INT32_C(224) | (teavm_local_11 >> INT32_C(12))));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8939, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8940, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_13;
            teavm_local_13 = (teavm_local_12 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8941, teavm_checkBounds(teavm_local_12, teavm_local_10))) = TEAVM_TO_BYTE((INT32_C(128) | ((teavm_local_11 >> INT32_C(6)) & INT32_C(63))));
            teavm_local_12 = (teavm_local_13 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8942, teavm_checkBounds(teavm_local_13, teavm_local_10))) = TEAVM_TO_BYTE((INT32_C(128) | (teavm_local_11 & INT32_C(63))));
        } else {
            if ((!TEAVM_WITH_CALL_SITE_ID(8943, meth_jl_Character_isHighSurrogate(teavm_local_11)))) {
                goto teavm_label_7;
            }
            if ((teavm_local_9 >= teavm_local_3)) {
                goto teavm_label_5;
            }
            teavm_local_14 = (teavm_local_9 + INT32_C(1));
            teavm_local_15 = TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(8944, teavm_checkBounds(teavm_local_9, teavm_local_10)));
            if ((!TEAVM_WITH_CALL_SITE_ID(8945, meth_jl_Character_isLowSurrogate(teavm_local_15)))) {
                goto teavm_label_6;
            }
            if (((teavm_local_5 + INT32_C(4)) > teavm_local_6)) {
                goto teavm_label_4;
            }
            teavm_local_16 = TEAVM_WITH_CALL_SITE_ID(8946, meth_jl_Character_toCodePoint(teavm_local_11, teavm_local_15));
            teavm_local_17 = (teavm_local_5 + INT32_C(1));
            teavm_local_13 = TEAVM_TO_BYTE((INT32_C(240) | (teavm_local_16 >> INT32_C(18))));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(8947, teavm_nullCheck(teavm_local_4));
            teavm_local_10 = teavm_local_4;
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8948, teavm_checkBounds(teavm_local_5, teavm_local_10))) = teavm_local_13;
            teavm_local_13 = (teavm_local_17 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8949, teavm_checkBounds(teavm_local_17, teavm_local_10))) = TEAVM_TO_BYTE((INT32_C(128) | ((teavm_local_16 >> INT32_C(12)) & INT32_C(63))));
            teavm_local_18 = (teavm_local_13 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8950, teavm_checkBounds(teavm_local_13, teavm_local_10))) = TEAVM_TO_BYTE((INT32_C(128) | ((teavm_local_16 >> INT32_C(6)) & INT32_C(63))));
            teavm_local_12 = (teavm_local_18 + INT32_C(1));
            TEAVM_ARRAY_AT(teavm_local_10, int8_t, TEAVM_WITH_CALL_SITE_ID(8951, teavm_checkBounds(teavm_local_18, teavm_local_10))) = TEAVM_TO_BYTE((INT32_C(128) | (teavm_local_16 & INT32_C(63))));
            teavm_local_9 = teavm_local_14;
        }
        teavm_local_2 = teavm_local_9;
        teavm_local_5 = teavm_local_12;
    }
    teavm_local_9 = teavm_local_2;
    goto teavm_label_1;
teavm_label_8:;
    teavm_local_9 = teavm_local_2;
    goto teavm_label_1;
teavm_label_7:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8952, meth_jnc_CoderResult_malformedForLength(INT32_C(1)));
    goto teavm_label_1;
teavm_label_6:;
    teavm_local_9 = (teavm_local_14 + -INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(8953, meth_jnc_CoderResult_malformedForLength(INT32_C(1)));
    goto teavm_label_1;
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8954, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if (TEAVM_WITH_CALL_SITE_ID(8955, TEAVM_METHOD(teavm_local_7, jnci_BufferedEncoder_Controller_VT, virt_hasMoreInput)(teavm_local_7))) {
        goto teavm_label_1;
    }
    TEAVM_WITH_CALL_SITE_ID(8956, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_8 = sfld_jnc_CoderResult_UNDERFLOW;
    goto teavm_label_1;
teavm_label_4:;
    teavm_local_9 = (teavm_local_14 + -INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8957, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if (TEAVM_WITH_CALL_SITE_ID(8958, TEAVM_METHOD(teavm_local_7, jnci_BufferedEncoder_Controller_VT, virt_hasMoreOutput)(teavm_local_7, INT32_C(4)))) {
        goto teavm_label_1;
    }
    TEAVM_WITH_CALL_SITE_ID(8959, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_8 = sfld_jnc_CoderResult_OVERFLOW;
    goto teavm_label_1;
teavm_label_3:;
    teavm_local_9 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8960, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if (TEAVM_WITH_CALL_SITE_ID(8961, TEAVM_METHOD(teavm_local_7, jnci_BufferedEncoder_Controller_VT, virt_hasMoreOutput)(teavm_local_7, INT32_C(3)))) {
        goto teavm_label_1;
    }
    TEAVM_WITH_CALL_SITE_ID(8962, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_8 = sfld_jnc_CoderResult_OVERFLOW;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_9 = (teavm_local_9 + -INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8963, teavm_nullCheck(teavm_local_7));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    if ((!TEAVM_WITH_CALL_SITE_ID(8964, TEAVM_METHOD(teavm_local_7, jnci_BufferedEncoder_Controller_VT, virt_hasMoreOutput)(teavm_local_7, INT32_C(2))))) {
        TEAVM_WITH_CALL_SITE_ID(8965, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
        teavm_local_8 = sfld_jnc_CoderResult_OVERFLOW;
    }
teavm_label_1:;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(8966, teavm_nullCheck(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(8967, TEAVM_METHOD(teavm_local_7, jnci_BufferedEncoder_Controller_VT, virt_setInPosition)(teavm_local_7, teavm_local_9));
    TEAVM_WITH_CALL_SITE_ID(8968, TEAVM_METHOD(teavm_local_7, jnci_BufferedEncoder_Controller_VT, virt_setOutPosition)(teavm_local_7, teavm_local_5));
    TEAVM_RELEASE_STACK;
    return teavm_local_8;
}
int32_t supertypeof_jnci_UTF8Encoder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 185 || tag >= 187) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnci_UTF8Encoder_VT jnci_UTF8Encoder_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnci_UTF8Encoder), sizeof(void*)),
            .flags = 0,
            .tag = 185,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jnci_UTF8Encoder,
            .superclass = (TeaVM_Class*) &jnci_BufferedEncoder_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_implReset = &meth_jnc_CharsetEncoder_implReset,
        .virt_implOnUnmappableCharacter = &meth_jnc_CharsetEncoder_implOnUnmappableCharacter,
        .virt_encodeLoop = &meth_jnci_BufferedEncoder_encodeLoop,
        .virt_implFlush = &meth_jnc_CharsetEncoder_implFlush,
        .virt_encode = &meth_jnc_CharsetEncoder_encode_0,
        .virt_onMalformedInput = &meth_jnc_CharsetEncoder_onMalformedInput,
        .virt_reset = &meth_jnc_CharsetEncoder_reset,
        .virt_flush = &meth_jnc_CharsetEncoder_flush,
        .virt_implOnMalformedInput = &meth_jnc_CharsetEncoder_implOnMalformedInput,
        .virt_arrayEncode = &meth_jnci_UTF8Encoder_arrayEncode,
        .virt_encode_0 = &meth_jnc_CharsetEncoder_encode,
        .virt_onUnmappableCharacter = &meth_jnc_CharsetEncoder_onUnmappableCharacter
    }
};
void sysinitclass_jnci_UTF8Encoder() {
}
