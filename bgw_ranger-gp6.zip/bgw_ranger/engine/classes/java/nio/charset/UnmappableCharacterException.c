#include "UnmappableCharacterException.h"
#include "CharacterCodingException.h"
#include "../../lang/StringBuilder.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../../../strings.h"
#include "../../lang/Object.h"
#include "../../lang/Throwable.h"

void meth_jnc_UnmappableCharacterException__init_(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(33448, meth_jnc_CharacterCodingException__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jnc_UnmappableCharacterException, fld_length) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jnc_UnmappableCharacterException_getMessage(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jnc_UnmappableCharacterException, fld_length);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33449, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(33450, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(33451, meth_jl_StringBuilder_append(teavm_local_2, TEAVM_GET_STRING(7656)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(33452, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(33453, teavm_nullCheck(teavm_local_3)), teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(33454, meth_jl_StringBuilder_toString(teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_jnc_UnmappableCharacterException(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 863 || tag >= 865) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnc_UnmappableCharacterException_VT jnc_UnmappableCharacterException_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .parent = {
                        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_UnmappableCharacterException), sizeof(void*)),
                        .flags = 0,
                        .tag = 863,
                        .modifiers = 1,
                        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7657),
                        .simpleName = NULL,
                        .arrayType = NULL,
                        .itemType = NULL,
                        .isSupertypeOf = &supertypeof_jnc_UnmappableCharacterException,
                        .superclass = (TeaVM_Class*) &jnc_CharacterCodingException_Cls,
                        .layout = NULL,
                        .enumValues = NULL,
                        .declaringClass = NULL,
                        .enclosingClass = NULL,
                        .init = NULL
                    },
                    .virt_hashCode = &meth_jl_Object_hashCode,
                    .virt_equals = &meth_jl_Object_equals,
                    .virt_clone = &meth_jl_Object_clone,
                    .virt_toString = &meth_jl_Throwable_toString,
                    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                    .virt_getClass = &meth_jl_Object_getClass,
                    .virt_identity = &meth_jl_Object_identity,
                    .virt_notifyAll = &meth_jl_Object_notifyAll,
                    .virt_wait = &meth_jl_Object_wait,
                    .virt_waitImpl = &meth_jl_Object_waitImpl,
                    .virt_wait_0 = &meth_jl_Object_wait_0,
                    .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
                    .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
                    .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
                    .virt_getMessage = &meth_jnc_UnmappableCharacterException_getMessage,
                    .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
                    .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
                }
            }
        }
    }
};
void sysinitclass_jnc_UnmappableCharacterException() {
}
