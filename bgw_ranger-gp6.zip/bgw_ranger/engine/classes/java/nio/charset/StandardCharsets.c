#include "StandardCharsets.h"
#include "../../lang/Object.h"
#include "impl/UTF8Charset.h"
#include "impl/AsciiCharset.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "impl/Iso8859Charset.h"
#include "impl/UTF16Charset.h"
#include "../../../../strings.h"

void* sfld_jnc_StandardCharsets_UTF_8;
void* sfld_jnc_StandardCharsets_US_ASCII;
void* sfld_jnc_StandardCharsets_ISO_8859_1;
void* sfld_jnc_StandardCharsets_UTF_16;
void* sfld_jnc_StandardCharsets_UTF_16BE;
void* sfld_jnc_StandardCharsets_UTF_16LE;
void meth_jnc_StandardCharsets__clinit_() {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(29081, teavm_initializeClass((TeaVM_Class*) &jnci_UTF8Charset_Cls, &initclass_jnci_UTF8Charset));
    sfld_jnc_StandardCharsets_UTF_8 = sfld_jnci_UTF8Charset_INSTANCE;
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(29082, meth_otr_Allocator_allocate(&jnci_AsciiCharset_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(29083, meth_jnci_AsciiCharset__init_(teavm_local_1));
    sfld_jnc_StandardCharsets_US_ASCII = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(29084, meth_otr_Allocator_allocate(&jnci_Iso8859Charset_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(29085, meth_jnci_Iso8859Charset__init_(teavm_local_1));
    sfld_jnc_StandardCharsets_ISO_8859_1 = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(29086, meth_otr_Allocator_allocate(&jnci_UTF16Charset_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(29087, meth_jnci_UTF16Charset__init_(teavm_local_2, TEAVM_GET_STRING(7379), INT32_C(1), INT32_C(0)));
    sfld_jnc_StandardCharsets_UTF_16 = teavm_local_2;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(29088, meth_otr_Allocator_allocate(&jnci_UTF16Charset_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(29089, meth_jnci_UTF16Charset__init_(teavm_local_1, TEAVM_GET_STRING(7380), INT32_C(0), INT32_C(0)));
    sfld_jnc_StandardCharsets_UTF_16BE = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(29090, meth_otr_Allocator_allocate(&jnci_UTF16Charset_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(29091, meth_jnci_UTF16Charset__init_(teavm_local_1, TEAVM_GET_STRING(7381), INT32_C(0), INT32_C(1)));
    sfld_jnc_StandardCharsets_UTF_16LE = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jnc_StandardCharsets() {
    TeaVM_Class* cls = (TeaVM_Class*) &jnc_StandardCharsets_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jnc_StandardCharsets__clinit_();
    }
}
int32_t supertypeof_jnc_StandardCharsets(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1467 || tag >= 1469) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnc_StandardCharsets_VT jnc_StandardCharsets_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_StandardCharsets), sizeof(void*)),
            .flags = 0,
            .tag = 1467,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jnc_StandardCharsets,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jnc_StandardCharsets_Cls[6] = {
(void**) &sfld_jnc_StandardCharsets_UTF_8, (void**) &sfld_jnc_StandardCharsets_US_ASCII, (void**) &sfld_jnc_StandardCharsets_ISO_8859_1, (void**) &sfld_jnc_StandardCharsets_UTF_16, (void**) &sfld_jnc_StandardCharsets_UTF_16BE, (void**) &sfld_jnc_StandardCharsets_UTF_16LE
};
void sysinitclass_jnc_StandardCharsets() {
sfld_jnc_StandardCharsets_UTF_8 = NULL;
sfld_jnc_StandardCharsets_US_ASCII = NULL;
sfld_jnc_StandardCharsets_ISO_8859_1 = NULL;
sfld_jnc_StandardCharsets_UTF_16 = NULL;
sfld_jnc_StandardCharsets_UTF_16BE = NULL;
sfld_jnc_StandardCharsets_UTF_16LE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jnc_StandardCharsets_Cls, 6);
}
