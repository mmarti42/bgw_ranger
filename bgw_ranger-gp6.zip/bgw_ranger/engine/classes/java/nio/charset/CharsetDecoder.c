#include "CharsetDecoder.h"
#include "../../lang/Object.h"
#include "../../../../strings.h"
#include "CodingErrorAction.h"
#include "../../lang/IllegalArgumentException.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../lang/StringBuilder.h"
#include "../../../org/teavm/runtime/ExceptionHandling.h"
#include "CoderResult.h"
#include "../Buffer.h"
#include "../../lang/String.h"
#include "../ByteBuffer.h"
#include "../CharBuffer.h"
#include "CoderMalfunctionError.h"
#include "../../lang/IllegalStateException.h"
#include "../../lang/Math.h"
#include "../../util/Arrays.h"

void meth_jnc_CharsetDecoder__init_(void* teavm_this_, void* teavm_local_1, float teavm_local_2, float teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(21019, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement) = TEAVM_GET_STRING(6875);
    TEAVM_WITH_CALL_SITE_ID(21020, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
    teavm_local_4 = sfld_jnc_CodingErrorAction_REPORT;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_malformedAction) = teavm_local_4;
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_unmappableAction) = sfld_jnc_CodingErrorAction_REPORT;
    if ((!(teavm_local_2 <= 0.0f))) {
        if ((teavm_local_3 <= 0.0f)) {
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21021, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(21022, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_WITH_CALL_SITE_ID(21023, meth_jl_StringBuilder__init_(teavm_local_5));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(21024, meth_jl_StringBuilder_append(teavm_local_5, TEAVM_GET_STRING(6876)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(21025, meth_jl_StringBuilder_append_3(TEAVM_WITH_CALL_SITE_ID(21026, teavm_nullCheck(teavm_local_6)), teavm_local_3));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(21027, meth_jl_StringBuilder_toString(teavm_local_5));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            TEAVM_WITH_CALL_SITE_ID(21028, meth_jl_IllegalArgumentException__init__0(teavm_local_4, teavm_local_5));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(21029, meth_otr_ExceptionHandling_throwException(teavm_local_4));
            TEAVM_UNREACHABLE
        }
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_charset) = teavm_local_1;
        TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_averageCharsPerByte) = teavm_local_2;
        TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_maxCharsPerByte) = teavm_local_3;
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21030, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(21031, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(21032, meth_jl_StringBuilder__init_(teavm_local_5));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(21033, meth_jl_StringBuilder_append(teavm_local_5, TEAVM_GET_STRING(6877)));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(21034, meth_jl_StringBuilder_append_3(TEAVM_WITH_CALL_SITE_ID(21035, teavm_nullCheck(teavm_local_6)), teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(21036, meth_jl_StringBuilder_toString(teavm_local_5));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(21037, meth_jl_IllegalArgumentException__init__0(teavm_local_4, teavm_local_5));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(21038, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
void* meth_jnc_CharsetDecoder_onMalformedInput(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21039, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(21040, meth_jl_IllegalArgumentException__init__0(teavm_local_2, TEAVM_GET_STRING(6878)));
        TEAVM_WITH_CALL_SITE_ID(21041, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_malformedAction) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(21042, TEAVM_METHOD(teavm_this_, jnc_CharsetDecoder_VT, virt_implOnMalformedInput)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jnc_CharsetDecoder_implOnMalformedInput(void* teavm_this_, void* teavm_local_1) {
    return;
}
void* meth_jnc_CharsetDecoder_onUnmappableCharacter(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21043, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(21044, meth_jl_IllegalArgumentException__init__0(teavm_local_2, TEAVM_GET_STRING(6878)));
        TEAVM_WITH_CALL_SITE_ID(21045, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_unmappableAction) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(21046, TEAVM_METHOD(teavm_this_, jnc_CharsetDecoder_VT, virt_implOnUnmappableCharacter)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jnc_CharsetDecoder_implOnUnmappableCharacter(void* teavm_this_, void* teavm_local_1) {
    return;
}
void* meth_jnc_CharsetDecoder_decode_0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    void * volatile teavm_spill_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if (((!((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) == INT32_C(2)) && (!teavm_local_3))) && (TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) != INT32_C(3)))) {
        TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) = (teavm_local_3 ? INT32_C(2) : INT32_C(1));
        while (1) {
            TEAVM_TRY
                teavm_spill_4 = teavm_local_4;
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_1);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21047, TEAVM_METHOD(teavm_this_, jnc_CharsetDecoder_VT, virt_decodeLoop)(teavm_this_, teavm_local_1, teavm_local_2));
                teavm_spill_4 = teavm_local_4;
            TEAVM_CATCH
                // CATCH java.lang.RuntimeException
                case 1: {
                    teavm_local_4 = teavm_spill_4;
                    teavm_local_5 = teavm_catchException();
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21048, teavm_nullCheck(teavm_local_4));
            if (TEAVM_WITH_CALL_SITE_ID(21049, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isOverflow)(teavm_local_4))) {
                goto teavm_label_7;
            }
            if (TEAVM_WITH_CALL_SITE_ID(21050, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isUnderflow)(teavm_local_4))) {
                if (teavm_local_3) {
                    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21051, teavm_nullCheck(teavm_local_1));
                    if (TEAVM_WITH_CALL_SITE_ID(21052, meth_jn_Buffer_hasRemaining(teavm_local_1))) {
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_malformedAction);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                        TEAVM_WITH_CALL_SITE_ID(21053, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
                        if ((teavm_local_6 == sfld_jnc_CodingErrorAction_REPORT)) {
                            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(21054, meth_jn_Buffer_remaining(teavm_local_1));
                            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21055, meth_jnc_CoderResult_malformedForLength(teavm_local_7));
                            goto teavm_label_1;
                        }
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21056, teavm_nullCheck(teavm_local_2));
                        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(21057, meth_jn_Buffer_remaining(teavm_local_2));
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement);
                        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                        if ((teavm_local_7 <= TEAVM_WITH_CALL_SITE_ID(21058, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(21059, teavm_nullCheck(teavm_local_6)))))) {
                            teavm_local_4 = sfld_jnc_CoderResult_OVERFLOW;
                            goto teavm_label_1;
                        }
                        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                        TEAVM_WITH_CALL_SITE_ID(21060, TEAVM_METHOD(teavm_local_1, jn_ByteBuffer_VT, virt_position_2)(teavm_local_1, (TEAVM_WITH_CALL_SITE_ID(21061, meth_jn_Buffer_position(teavm_local_1)) + TEAVM_WITH_CALL_SITE_ID(21062, meth_jn_Buffer_remaining(teavm_local_1)))));
                        if ((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_malformedAction) == sfld_jnc_CodingErrorAction_REPLACE)) {
                            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement);
                            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                            TEAVM_WITH_CALL_SITE_ID(21063, meth_jn_CharBuffer_put_1(teavm_local_2, teavm_local_6));
                        }
                    }
                }
                goto teavm_label_1;
            }
            if (TEAVM_WITH_CALL_SITE_ID(21064, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isMalformed)(teavm_local_4))) {
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_malformedAction);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_WITH_CALL_SITE_ID(21065, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
                if ((teavm_local_6 == sfld_jnc_CodingErrorAction_REPORT)) {
                    goto teavm_label_5;
                }
                if ((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_malformedAction) == sfld_jnc_CodingErrorAction_REPLACE)) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21066, teavm_nullCheck(teavm_local_2));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(21067, meth_jn_Buffer_remaining(teavm_local_2));
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                    if ((teavm_local_7 < TEAVM_WITH_CALL_SITE_ID(21068, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(21069, teavm_nullCheck(teavm_local_6)))))) {
                        goto teavm_label_3;
                    }
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                    TEAVM_WITH_CALL_SITE_ID(21070, meth_jn_CharBuffer_put_1(teavm_local_2, teavm_local_6));
                }
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21071, teavm_nullCheck(teavm_local_1));
                teavm_local_7 = (TEAVM_WITH_CALL_SITE_ID(21072, meth_jn_Buffer_position(teavm_local_1)) + TEAVM_WITH_CALL_SITE_ID(21073, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_length)(teavm_local_4)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(21074, TEAVM_METHOD(teavm_local_1, jn_ByteBuffer_VT, virt_position_2)(teavm_local_1, teavm_local_7));
            } else if (TEAVM_WITH_CALL_SITE_ID(21075, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isUnmappable)(teavm_local_4))) {
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_unmappableAction);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_WITH_CALL_SITE_ID(21076, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
                if ((teavm_local_6 == sfld_jnc_CodingErrorAction_REPORT)) {
                    goto teavm_label_6;
                }
                if ((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_unmappableAction) == sfld_jnc_CodingErrorAction_REPLACE)) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21077, teavm_nullCheck(teavm_local_2));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(21078, meth_jn_Buffer_remaining(teavm_local_2));
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                    if ((teavm_local_7 < TEAVM_WITH_CALL_SITE_ID(21079, meth_jl_String_length(TEAVM_WITH_CALL_SITE_ID(21080, teavm_nullCheck(teavm_local_6)))))) {
                        goto teavm_label_4;
                    }
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_replacement);
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                    TEAVM_WITH_CALL_SITE_ID(21081, meth_jn_CharBuffer_put_1(teavm_local_2, teavm_local_6));
                }
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21082, teavm_nullCheck(teavm_local_1));
                teavm_local_7 = (TEAVM_WITH_CALL_SITE_ID(21083, meth_jn_Buffer_position(teavm_local_1)) + TEAVM_WITH_CALL_SITE_ID(21084, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_length)(teavm_local_4)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(21085, TEAVM_METHOD(teavm_local_1, jn_ByteBuffer_VT, virt_position_2)(teavm_local_1, teavm_local_7));
            }
        }
    teavm_label_7:;
        goto teavm_label_1;
    teavm_label_6:;
        goto teavm_label_1;
    teavm_label_5:;
        goto teavm_label_1;
    teavm_label_4:;
        teavm_local_4 = sfld_jnc_CoderResult_OVERFLOW;
        goto teavm_label_1;
    teavm_label_3:;
        teavm_local_4 = sfld_jnc_CoderResult_OVERFLOW;
        goto teavm_label_1;
    teavm_label_2:;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(21086, meth_otr_Allocator_allocate(&jnc_CoderMalfunctionError_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(21087, meth_jnc_CoderMalfunctionError__init_(teavm_local_6, teavm_local_5));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(21088, meth_otr_ExceptionHandling_throwException(teavm_local_6));
        TEAVM_UNREACHABLE
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_4;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(21089, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(21090, meth_jl_IllegalStateException__init__0(teavm_local_6));
    TEAVM_WITH_CALL_SITE_ID(21091, meth_otr_ExceptionHandling_throwException(teavm_local_6));
    TEAVM_UNREACHABLE
}
void* meth_jnc_CharsetDecoder_flush(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) != INT32_C(3)) && (TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) != INT32_C(2)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21092, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(21093, meth_jl_IllegalStateException__init__0(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(21094, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) = INT32_C(3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21095, TEAVM_METHOD(teavm_this_, jnc_CharsetDecoder_VT, virt_implFlush_0)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jnc_CharsetDecoder_reset(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) = INT32_C(0);
    TEAVM_WITH_CALL_SITE_ID(21096, TEAVM_METHOD(teavm_this_, jnc_CharsetDecoder_VT, virt_implReset)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jnc_CharsetDecoder_decode(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) && (TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state) != INT32_C(3)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21097, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(21098, meth_jl_IllegalStateException__init__0(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(21099, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21100, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!TEAVM_WITH_CALL_SITE_ID(21101, meth_jn_Buffer_remaining(teavm_local_1)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21102, meth_jn_CharBuffer_allocate(INT32_C(0)));
    } else {
        if (TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_state)) {
            TEAVM_WITH_CALL_SITE_ID(21103, meth_jnc_CharsetDecoder_reset(teavm_this_));
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(21104, meth_jn_CharBuffer_allocate(TEAVM_WITH_CALL_SITE_ID(21105, meth_jl_Math_max(INT32_C(8), ((int32_t) (((float) TEAVM_WITH_CALL_SITE_ID(21106, meth_jn_Buffer_remaining(teavm_local_1))) * TEAVM_FIELD(teavm_this_, cls_jnc_CharsetDecoder, fld_averageCharsPerByte)))))));
        while (1) {
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21107, meth_jnc_CharsetDecoder_decode_0(teavm_this_, teavm_local_1, teavm_local_3, INT32_C(0)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21108, teavm_nullCheck(teavm_local_4));
            if (TEAVM_WITH_CALL_SITE_ID(21109, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isUnderflow)(teavm_local_4))) {
                goto teavm_label_1;
            }
            if (TEAVM_WITH_CALL_SITE_ID(21110, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isOverflow)(teavm_local_4))) {
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(21111, meth_jnc_CharsetDecoder_expand(teavm_this_, teavm_local_3));
            }
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            if ((!TEAVM_WITH_CALL_SITE_ID(21112, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isError)(teavm_local_4)))) {
                goto teavm_cnt_1;
            }
            TEAVM_WITH_CALL_SITE_ID(21113, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_throwException)(teavm_local_4));
        teavm_cnt_1:;
        }
    teavm_label_1:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21114, meth_jnc_CharsetDecoder_decode_0(teavm_this_, teavm_local_1, teavm_local_3, INT32_C(1)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21115, teavm_nullCheck(teavm_local_2));
        if (TEAVM_WITH_CALL_SITE_ID(21116, TEAVM_METHOD(teavm_local_2, jnc_CoderResult_VT, virt_isError)(teavm_local_2))) {
            TEAVM_WITH_CALL_SITE_ID(21117, TEAVM_METHOD(teavm_local_2, jnc_CoderResult_VT, virt_throwException)(teavm_local_2));
        }
        while (1) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21118, meth_jnc_CharsetDecoder_flush(teavm_this_, teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            if (TEAVM_WITH_CALL_SITE_ID(21119, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(21120, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jnc_CoderResult_VT, virt_isUnderflow)(teavm_tmp_ptr_0)))) {
                goto teavm_label_2;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(21121, meth_jnc_CharsetDecoder_expand(teavm_this_, teavm_local_3));
        }
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21122, teavm_nullCheck(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(21123, meth_jn_CharBuffer_flip(teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jnc_CharsetDecoder_expand(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21124, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21125, meth_jn_CharBuffer_array(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(21126, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(21127, meth_ju_Arrays_copyOf_1(teavm_local_2, TEAVM_WITH_CALL_SITE_ID(21128, meth_jl_Math_max(INT32_C(8), (TEAVM_ARRAY_LENGTH(teavm_local_2) * INT32_C(2))))));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21129, meth_jn_CharBuffer_wrap_0(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(21130, meth_jn_Buffer_position(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(21131, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(21132, TEAVM_METHOD(teavm_local_4, jn_CharBuffer_VT, virt_position_1)(teavm_local_4, teavm_local_5));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jnc_CharsetDecoder_implFlush(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(21133, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_2 = sfld_jnc_CoderResult_UNDERFLOW;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jnc_CharsetDecoder_implReset(void* teavm_this_) {
    return;
}
int32_t supertypeof_jnc_CharsetDecoder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1251 || tag >= 1257) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnc_CharsetDecoder_Cls[5];
alignas(8) jnc_CharsetDecoder_VT jnc_CharsetDecoder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_CharsetDecoder), sizeof(void*)),
        .flags = 0,
        .tag = 1251,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnc_CharsetDecoder,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jnc_CharsetDecoder_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_implReset = &meth_jnc_CharsetDecoder_implReset,
    .virt_implOnUnmappableCharacter = &meth_jnc_CharsetDecoder_implOnUnmappableCharacter,
    .virt_decode = &meth_jnc_CharsetDecoder_decode,
    .virt_implFlush_0 = &meth_jnc_CharsetDecoder_implFlush,
    .virt_onMalformedInput_0 = &meth_jnc_CharsetDecoder_onMalformedInput,
    .virt_reset_2 = &meth_jnc_CharsetDecoder_reset,
    .virt_flush_0 = &meth_jnc_CharsetDecoder_flush,
    .virt_implOnMalformedInput = &meth_jnc_CharsetDecoder_implOnMalformedInput,
    .virt_decode_0 = &meth_jnc_CharsetDecoder_decode_0,
    .virt_onUnmappableCharacter_0 = &meth_jnc_CharsetDecoder_onUnmappableCharacter
};
static int16_t teavm_classLayouts_jnc_CharsetDecoder_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jnc_CharsetDecoder, fld_charset), (int16_t) offsetof(cls_jnc_CharsetDecoder, fld_replacement), (int16_t) offsetof(cls_jnc_CharsetDecoder, fld_malformedAction), (int16_t) offsetof(cls_jnc_CharsetDecoder, fld_unmappableAction)
};
void sysinitclass_jnc_CharsetDecoder() {
}
