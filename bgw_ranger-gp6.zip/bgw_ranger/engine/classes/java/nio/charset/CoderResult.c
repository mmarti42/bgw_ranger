#include "CoderResult.h"
#include "../../lang/Object.h"
#include "../../lang/UnsupportedOperationException.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../../org/teavm/runtime/ExceptionHandling.h"
#include "BufferUnderflowException.h"
#include "BufferOverflowException.h"
#include "MalformedInputException.h"
#include "UnmappableCharacterException.h"
#include "../../../../strings.h"

void* sfld_jnc_CoderResult_UNDERFLOW;
void* sfld_jnc_CoderResult_OVERFLOW;
void meth_jnc_CoderResult__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(19339, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    TEAVM_WITH_CALL_SITE_ID(19340, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_kind) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_length) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jnc_CoderResult_isUnderflow(void* teavm_this_) {
    return (TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_kind) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jnc_CoderResult_isOverflow(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_kind) != INT32_C(1)) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jnc_CoderResult_isError(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = ((!((!TEAVM_WITH_CALL_SITE_ID(19341, TEAVM_METHOD(teavm_this_, jnc_CoderResult_VT, virt_isMalformed)(teavm_this_))) && (!TEAVM_WITH_CALL_SITE_ID(19342, TEAVM_METHOD(teavm_this_, jnc_CoderResult_VT, virt_isUnmappable)(teavm_this_))))) ? INT32_C(1) : INT32_C(0));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jnc_CoderResult_isMalformed(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_kind) != INT32_C(2)) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jnc_CoderResult_isUnmappable(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_kind) != INT32_C(3)) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jnc_CoderResult_length(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((!TEAVM_WITH_CALL_SITE_ID(19343, TEAVM_METHOD(teavm_this_, jnc_CoderResult_VT, virt_isError)(teavm_this_)))) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19344, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(19345, meth_jl_UnsupportedOperationException__init__0(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(19346, meth_otr_ExceptionHandling_throwException(teavm_local_1));
        TEAVM_UNREACHABLE
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_length);
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jnc_CoderResult_malformedForLength(int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(19347, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(19348, meth_otr_Allocator_allocate(&jnc_CoderResult_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(19349, meth_jnc_CoderResult__init_(teavm_local_2, INT32_C(2), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_jnc_CoderResult_throwException(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    switch (TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_kind)) {
        case 0:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19350, meth_otr_Allocator_allocate(&jnc_BufferUnderflowException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(19351, meth_jnc_BufferUnderflowException__init_(teavm_local_1));
            TEAVM_WITH_CALL_SITE_ID(19352, meth_otr_ExceptionHandling_throwException(teavm_local_1));
            TEAVM_UNREACHABLE
        case 1:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19353, meth_otr_Allocator_allocate(&jnc_BufferOverflowException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(19354, meth_jnc_BufferOverflowException__init_(teavm_local_1));
            TEAVM_WITH_CALL_SITE_ID(19355, meth_otr_ExceptionHandling_throwException(teavm_local_1));
            TEAVM_UNREACHABLE
        case 2:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19356, meth_otr_Allocator_allocate(&jnc_MalformedInputException_Cls));
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_length);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(19357, meth_jnc_MalformedInputException__init_(teavm_local_1, teavm_local_2));
            TEAVM_WITH_CALL_SITE_ID(19358, meth_otr_ExceptionHandling_throwException(teavm_local_1));
            TEAVM_UNREACHABLE
        case 3:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19359, meth_otr_Allocator_allocate(&jnc_UnmappableCharacterException_Cls));
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jnc_CoderResult, fld_length);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(19360, meth_jnc_UnmappableCharacterException__init_(teavm_local_1, teavm_local_2));
            TEAVM_WITH_CALL_SITE_ID(19361, meth_otr_ExceptionHandling_throwException(teavm_local_1));
            TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
void meth_jnc_CoderResult__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19362, meth_otr_Allocator_allocate(&jnc_CoderResult_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(19363, meth_jnc_CoderResult__init_(teavm_local_1, INT32_C(0), INT32_C(0)));
    sfld_jnc_CoderResult_UNDERFLOW = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19364, meth_otr_Allocator_allocate(&jnc_CoderResult_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(19365, meth_jnc_CoderResult__init_(teavm_local_1, INT32_C(1), INT32_C(0)));
    sfld_jnc_CoderResult_OVERFLOW = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jnc_CoderResult() {
    TeaVM_Class* cls = (TeaVM_Class*) &jnc_CoderResult_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jnc_CoderResult__clinit_();
    }
}
int32_t supertypeof_jnc_CoderResult(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1123 || tag >= 1125) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jnc_CoderResult_VT jnc_CoderResult_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_CoderResult), sizeof(void*)),
        .flags = 0,
        .tag = 1123,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnc_CoderResult,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_isError = &meth_jnc_CoderResult_isError,
    .virt_isMalformed = &meth_jnc_CoderResult_isMalformed,
    .virt_throwException = &meth_jnc_CoderResult_throwException,
    .virt_isOverflow = &meth_jnc_CoderResult_isOverflow,
    .virt_isUnmappable = &meth_jnc_CoderResult_isUnmappable,
    .virt_length = &meth_jnc_CoderResult_length,
    .virt_isUnderflow = &meth_jnc_CoderResult_isUnderflow
};
static void** teavm_gc_localStaticRoots_jnc_CoderResult_Cls[2] = {
(void**) &sfld_jnc_CoderResult_UNDERFLOW, (void**) &sfld_jnc_CoderResult_OVERFLOW
};
void sysinitclass_jnc_CoderResult() {
sfld_jnc_CoderResult_UNDERFLOW = NULL;
sfld_jnc_CoderResult_OVERFLOW = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jnc_CoderResult_Cls, 2);
}
