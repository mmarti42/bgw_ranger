#include "CharsetEncoder.h"
#include "../../lang/Object.h"
#include "CodingErrorAction.h"
#include "../../../../arrays/primitives/byte.h"
#include "../../../org/teavm/runtime/Allocator.h"
#include "../../lang/IllegalArgumentException.h"
#include "../../../../strings.h"
#include "../../../org/teavm/runtime/ExceptionHandling.h"
#include "../../lang/IllegalStateException.h"
#include "CoderMalfunctionError.h"
#include "CoderResult.h"
#include "../Buffer.h"
#include "../ByteBuffer.h"
#include "../CharBuffer.h"
#include "../../util/Arrays.h"

void meth_jnc_CharsetEncoder__init_(void* teavm_this_, void* teavm_local_1, float teavm_local_2, float teavm_local_3, TeaVM_Array* teavm_local_4) {
    void* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(3893, meth_jl_Object__init_(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(3894, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
    teavm_local_5 = sfld_jnc_CodingErrorAction_REPORT;
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_malformedAction) = teavm_local_5;
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_unmappableAction) = sfld_jnc_CodingErrorAction_REPORT;
    TEAVM_WITH_CALL_SITE_ID(3895, meth_jnc_CharsetEncoder_checkReplacement(teavm_this_, teavm_local_4));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_charset) = teavm_local_1;
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3896, teavm_nullCheck(teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(3897, TEAVM_METHOD(teavm_local_4, jl_Object_VT, virt_clone)(teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(3898, teavm_checkcast(teavm_local_5, &Arr_B_Cls, &supertypeof_Arr_B));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_replacement) = teavm_local_6;
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_averageBytesPerChar) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_maxBytesPerChar) = teavm_local_3;
    TEAVM_RELEASE_STACK;
}
void meth_jnc_CharsetEncoder__init__0(void* teavm_this_, void* teavm_local_1, float teavm_local_2, float teavm_local_3) {
    TeaVM_Array* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3899, meth_otr_Allocator_allocateArray(&Arr_B_Cls, INT32_C(1)));
    TEAVM_ARRAY_AT(teavm_local_4, int8_t, INT32_C(0)) = INT32_C(63);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(3900, meth_jnc_CharsetEncoder__init_(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
}
void meth_jnc_CharsetEncoder_checkReplacement(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 != NULL)) {
        teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
        if ((teavm_local_2 && (!(((float) teavm_local_2) < TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_maxBytesPerChar))))) {
            TEAVM_RELEASE_STACK;
            return;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3901, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(3902, meth_jl_IllegalArgumentException__init__0(teavm_local_3, TEAVM_GET_STRING(452)));
    TEAVM_WITH_CALL_SITE_ID(3903, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void* meth_jnc_CharsetEncoder_onMalformedInput(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3904, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(3905, meth_jl_IllegalArgumentException__init__0(teavm_local_2, TEAVM_GET_STRING(453)));
        TEAVM_WITH_CALL_SITE_ID(3906, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_malformedAction) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(3907, TEAVM_METHOD(teavm_this_, jnc_CharsetEncoder_VT, virt_implOnMalformedInput)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jnc_CharsetEncoder_implOnMalformedInput(void* teavm_this_, void* teavm_local_1) {
    return;
}
void* meth_jnc_CharsetEncoder_onUnmappableCharacter(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3908, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(3909, meth_jl_IllegalArgumentException__init__0(teavm_local_2, TEAVM_GET_STRING(453)));
        TEAVM_WITH_CALL_SITE_ID(3910, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_unmappableAction) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(3911, TEAVM_METHOD(teavm_this_, jnc_CharsetEncoder_VT, virt_implOnUnmappableCharacter)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jnc_CharsetEncoder_implOnUnmappableCharacter(void* teavm_this_, void* teavm_local_1) {
    return;
}
void* meth_jnc_CharsetEncoder_encode(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    void* teavm_local_5;
    void * volatile teavm_spill_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) != INT32_C(3))) {
        if (teavm_local_3) {
            goto teavm_label_1;
        }
        if ((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) != INT32_C(2))) {
            goto teavm_label_1;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3912, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(3913, meth_jl_IllegalStateException__init__0(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(3914, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
teavm_label_1:;
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) = ((!teavm_local_3) ? INT32_C(1) : INT32_C(2));
    while (1) {
        TEAVM_TRY
            teavm_spill_5 = teavm_local_5;
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(3915, TEAVM_METHOD(teavm_this_, jnc_CharsetEncoder_VT, virt_encodeLoop)(teavm_this_, teavm_local_1, teavm_local_2));
            teavm_spill_5 = teavm_local_5;
        TEAVM_CATCH
            // CATCH java.lang.RuntimeException
            case 1: {
                teavm_local_5 = teavm_spill_5;
                teavm_local_6 = teavm_catchException();
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3916, meth_otr_Allocator_allocate(&jnc_CoderMalfunctionError_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                TEAVM_WITH_CALL_SITE_ID(3917, meth_jnc_CoderMalfunctionError__init_(teavm_local_4, teavm_local_6));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(3918, meth_otr_ExceptionHandling_throwException(teavm_local_4));
                TEAVM_UNREACHABLE
                break;
            }
        TEAVM_END_TRY
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(3919, teavm_nullCheck(teavm_local_5));
        if (TEAVM_WITH_CALL_SITE_ID(3920, TEAVM_METHOD(teavm_local_5, jnc_CoderResult_VT, virt_isUnderflow)(teavm_local_5))) {
            if ((!teavm_local_3)) {
                goto teavm_label_4;
            }
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3921, teavm_nullCheck(teavm_local_1));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(3922, meth_jn_Buffer_remaining(teavm_local_1));
            if ((teavm_local_7 <= INT32_C(0))) {
                goto teavm_label_5;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(3923, meth_jnc_CoderResult_malformedForLength(teavm_local_7));
        } else if (TEAVM_WITH_CALL_SITE_ID(3924, TEAVM_METHOD(teavm_local_5, jnc_CoderResult_VT, virt_isOverflow)(teavm_local_5))) {
            goto teavm_label_6;
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_1);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(3925, teavm_nullCheck(teavm_local_5));
        teavm_local_8 = ((!TEAVM_WITH_CALL_SITE_ID(3926, TEAVM_METHOD(teavm_local_5, jnc_CoderResult_VT, virt_isUnmappable)(teavm_local_5))) ? TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_malformedAction) : TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_unmappableAction));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
        TEAVM_WITH_CALL_SITE_ID(3927, teavm_initializeClass((TeaVM_Class*) &jnc_CodingErrorAction_Cls, &initclass_jnc_CodingErrorAction));
        if ((teavm_local_8 == sfld_jnc_CodingErrorAction_REPLACE)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3928, teavm_nullCheck(teavm_local_2));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(3929, meth_jn_Buffer_remaining(teavm_local_2));
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_replacement);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
            if ((teavm_local_9 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(3930, teavm_nullCheck(teavm_local_10))))) {
                goto teavm_label_3;
            }
            teavm_local_10 = TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_replacement);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
            TEAVM_WITH_CALL_SITE_ID(3931, meth_jn_ByteBuffer_put(teavm_local_2, teavm_local_10));
        } else if ((teavm_local_8 != sfld_jnc_CodingErrorAction_IGNORE)) {
            goto teavm_label_7;
        }
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3932, teavm_nullCheck(teavm_local_1));
        teavm_local_9 = (TEAVM_WITH_CALL_SITE_ID(3933, meth_jn_Buffer_position(teavm_local_1)) + TEAVM_WITH_CALL_SITE_ID(3934, TEAVM_METHOD(teavm_local_5, jnc_CoderResult_VT, virt_length)(teavm_local_5)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(3935, TEAVM_METHOD(teavm_local_1, jn_CharBuffer_VT, virt_position_1)(teavm_local_1, teavm_local_9));
    }
teavm_label_7:;
    goto teavm_label_2;
teavm_label_6:;
    goto teavm_label_2;
teavm_label_5:;
    goto teavm_label_2;
teavm_label_4:;
    goto teavm_label_2;
teavm_label_3:;
    teavm_local_5 = sfld_jnc_CoderResult_OVERFLOW;
teavm_label_2:;
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_jnc_CharsetEncoder_encode_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3936, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((!TEAVM_WITH_CALL_SITE_ID(3937, meth_jn_Buffer_remaining(teavm_local_1)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3938, meth_jn_ByteBuffer_allocate(INT32_C(0)));
    } else {
        TEAVM_WITH_CALL_SITE_ID(3939, meth_jnc_CharsetEncoder_reset(teavm_this_));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3940, meth_jn_ByteBuffer_allocate(((int32_t) (((float) TEAVM_WITH_CALL_SITE_ID(3941, meth_jn_Buffer_remaining(teavm_local_1))) * TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_averageBytesPerChar)))));
        while (1) {
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3942, meth_jnc_CharsetEncoder_encode(teavm_this_, teavm_local_1, teavm_local_3, INT32_C(0)));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(3943, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
            if ((teavm_local_4 == sfld_jnc_CoderResult_UNDERFLOW)) {
                goto teavm_label_1;
            }
            if ((teavm_local_4 == sfld_jnc_CoderResult_OVERFLOW)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3944, meth_jnc_CharsetEncoder_allocateMore(teavm_this_, teavm_local_3));
                goto teavm_cnt_1;
            }
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3945, teavm_nullCheck(teavm_local_4));
            if ((!TEAVM_WITH_CALL_SITE_ID(3946, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_isError)(teavm_local_4)))) {
                goto teavm_cnt_1;
            }
            TEAVM_WITH_CALL_SITE_ID(3947, TEAVM_METHOD(teavm_local_4, jnc_CoderResult_VT, virt_throwException)(teavm_local_4));
        teavm_cnt_1:;
        }
    teavm_label_1:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3948, meth_jnc_CharsetEncoder_encode(teavm_this_, teavm_local_1, teavm_local_3, INT32_C(1)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3949, teavm_nullCheck(teavm_local_2));
        if (TEAVM_WITH_CALL_SITE_ID(3950, TEAVM_METHOD(teavm_local_2, jnc_CoderResult_VT, virt_isError)(teavm_local_2))) {
            TEAVM_WITH_CALL_SITE_ID(3951, TEAVM_METHOD(teavm_local_2, jnc_CoderResult_VT, virt_throwException)(teavm_local_2));
        }
        while (1) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3952, meth_jnc_CharsetEncoder_flush(teavm_this_, teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3953, teavm_nullCheck(teavm_local_2));
            if (TEAVM_WITH_CALL_SITE_ID(3954, TEAVM_METHOD(teavm_local_2, jnc_CoderResult_VT, virt_isUnderflow)(teavm_local_2))) {
                goto teavm_label_2;
            }
            if ((!TEAVM_WITH_CALL_SITE_ID(3955, TEAVM_METHOD(teavm_local_2, jnc_CoderResult_VT, virt_isOverflow)(teavm_local_2)))) {
                goto teavm_cnt_2;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3956, meth_jnc_CharsetEncoder_allocateMore(teavm_this_, teavm_local_3));
        teavm_cnt_2:;
        }
    teavm_label_2:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3957, teavm_nullCheck(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(3958, meth_jn_ByteBuffer_flip(teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jnc_CharsetEncoder_allocateMore(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(3959, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3960, meth_jn_ByteBuffer_array(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3961, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3962, meth_ju_Arrays_copyOf_0(teavm_local_2, (TEAVM_ARRAY_LENGTH(teavm_local_2) * INT32_C(2))));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3963, meth_jn_ByteBuffer_wrap(teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(3964, meth_jn_Buffer_position(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(3965, teavm_nullCheck(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(3966, TEAVM_METHOD(teavm_local_4, jn_ByteBuffer_VT, virt_position_2)(teavm_local_4, teavm_local_5));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_jnc_CharsetEncoder_flush(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) != INT32_C(2)) && (TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) != INT32_C(4)))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(3967, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(3968, meth_jl_IllegalStateException__init__0(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(3969, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(3970, TEAVM_METHOD(teavm_this_, jnc_CharsetEncoder_VT, virt_implFlush)(teavm_this_, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(3971, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    if ((teavm_local_3 == sfld_jnc_CoderResult_UNDERFLOW)) {
        TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) = INT32_C(3);
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jnc_CharsetEncoder_implFlush(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(3972, teavm_initializeClass((TeaVM_Class*) &jnc_CoderResult_Cls, &initclass_jnc_CoderResult));
    teavm_local_2 = sfld_jnc_CoderResult_UNDERFLOW;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jnc_CharsetEncoder_reset(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_FIELD(teavm_this_, cls_jnc_CharsetEncoder, fld_status) = INT32_C(0);
    TEAVM_WITH_CALL_SITE_ID(3973, TEAVM_METHOD(teavm_this_, jnc_CharsetEncoder_VT, virt_implReset)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_jnc_CharsetEncoder_implReset(void* teavm_this_) {
    return;
}
int32_t supertypeof_jnc_CharsetEncoder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 183 || tag >= 189) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnc_CharsetEncoder_Cls[5];
alignas(8) jnc_CharsetEncoder_VT jnc_CharsetEncoder_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_CharsetEncoder), sizeof(void*)),
        .flags = 0,
        .tag = 183,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jnc_CharsetEncoder,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_jnc_CharsetEncoder_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_implReset = &meth_jnc_CharsetEncoder_implReset,
    .virt_implOnUnmappableCharacter = &meth_jnc_CharsetEncoder_implOnUnmappableCharacter,
    .virt_implFlush = &meth_jnc_CharsetEncoder_implFlush,
    .virt_encode = &meth_jnc_CharsetEncoder_encode_0,
    .virt_onMalformedInput = &meth_jnc_CharsetEncoder_onMalformedInput,
    .virt_reset = &meth_jnc_CharsetEncoder_reset,
    .virt_flush = &meth_jnc_CharsetEncoder_flush,
    .virt_implOnMalformedInput = &meth_jnc_CharsetEncoder_implOnMalformedInput,
    .virt_encode_0 = &meth_jnc_CharsetEncoder_encode,
    .virt_onUnmappableCharacter = &meth_jnc_CharsetEncoder_onUnmappableCharacter
};
static int16_t teavm_classLayouts_jnc_CharsetEncoder_Cls[5] = {
INT16_C(4), (int16_t) offsetof(cls_jnc_CharsetEncoder, fld_charset), (int16_t) offsetof(cls_jnc_CharsetEncoder, fld_replacement), (int16_t) offsetof(cls_jnc_CharsetEncoder, fld_malformedAction), (int16_t) offsetof(cls_jnc_CharsetEncoder, fld_unmappableAction)
};
void sysinitclass_jnc_CharsetEncoder() {
}
