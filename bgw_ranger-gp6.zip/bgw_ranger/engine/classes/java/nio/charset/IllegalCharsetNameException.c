#include "IllegalCharsetNameException.h"
#include "../../lang/IllegalArgumentException.h"
#include "../../../../strings.h"
#include "../../lang/Object.h"
#include "../../lang/Throwable.h"

void meth_jnc_IllegalCharsetNameException__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5251, meth_jl_IllegalArgumentException__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jnc_IllegalCharsetNameException, fld_charsetName) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jnc_IllegalCharsetNameException(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 891 || tag >= 893) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jnc_IllegalCharsetNameException_Cls[2];
alignas(8) jnc_IllegalCharsetNameException_VT jnc_IllegalCharsetNameException_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .parent = {
                        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jnc_IllegalCharsetNameException), sizeof(void*)),
                        .flags = 0,
                        .tag = 891,
                        .modifiers = 1,
                        .name = NULL,
                        .simpleName = NULL,
                        .arrayType = NULL,
                        .itemType = NULL,
                        .isSupertypeOf = &supertypeof_jnc_IllegalCharsetNameException,
                        .superclass = (TeaVM_Class*) &jl_IllegalArgumentException_Cls,
                        .layout = teavm_classLayouts_jnc_IllegalCharsetNameException_Cls,
                        .enumValues = NULL,
                        .declaringClass = NULL,
                        .enclosingClass = NULL,
                        .init = NULL
                    },
                    .virt_hashCode = &meth_jl_Object_hashCode,
                    .virt_equals = &meth_jl_Object_equals,
                    .virt_clone = &meth_jl_Object_clone,
                    .virt_toString = &meth_jl_Throwable_toString,
                    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                    .virt_getClass = &meth_jl_Object_getClass,
                    .virt_identity = &meth_jl_Object_identity,
                    .virt_notifyAll = &meth_jl_Object_notifyAll,
                    .virt_wait = &meth_jl_Object_wait,
                    .virt_waitImpl = &meth_jl_Object_waitImpl,
                    .virt_wait_0 = &meth_jl_Object_wait_0,
                    .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
                    .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
                    .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
                    .virt_getMessage = &meth_jl_Throwable_getMessage,
                    .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
                    .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
                }
            }
        }
    }
};
static int16_t teavm_classLayouts_jnc_IllegalCharsetNameException_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jnc_IllegalCharsetNameException, fld_charsetName)
};
void sysinitclass_jnc_IllegalCharsetNameException() {
}
