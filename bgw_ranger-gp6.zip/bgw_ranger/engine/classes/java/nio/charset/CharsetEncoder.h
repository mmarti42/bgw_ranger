#pragma once
#include "../../../../runtime.h"
#include "../../lang/Object.h"
#include "CharsetEncoder.h"

extern void sysinitclass_jnc_CharsetEncoder();
typedef struct cls_jnc_CharsetEncoder {
    struct TeaVM_Object parent;
    void* fld_charset;
    TeaVM_Array* fld_replacement;
    float fld_averageBytesPerChar;
    float fld_maxBytesPerChar;
    void* fld_malformedAction;
    void* fld_unmappableAction;
    int32_t fld_status;
} cls_jnc_CharsetEncoder;
extern void meth_jnc_CharsetEncoder__init_(void*, void*, float, float, TeaVM_Array*);
extern void meth_jnc_CharsetEncoder__init__0(void*, void*, float, float);
extern void meth_jnc_CharsetEncoder_checkReplacement(void*, TeaVM_Array*);
extern void* meth_jnc_CharsetEncoder_onMalformedInput(void*, void*);
extern void meth_jnc_CharsetEncoder_implOnMalformedInput(void*, void*);
extern void* meth_jnc_CharsetEncoder_onUnmappableCharacter(void*, void*);
extern void meth_jnc_CharsetEncoder_implOnUnmappableCharacter(void*, void*);
extern void* meth_jnc_CharsetEncoder_encode(void*, void*, void*, int32_t);
extern void* meth_jnc_CharsetEncoder_encode_0(void*, void*);
extern void* meth_jnc_CharsetEncoder_allocateMore(void*, void*);
extern void* meth_jnc_CharsetEncoder_flush(void*, void*);
extern void* meth_jnc_CharsetEncoder_implFlush(void*, void*);
extern void* meth_jnc_CharsetEncoder_reset(void*);
extern void meth_jnc_CharsetEncoder_implReset(void*);
extern int32_t supertypeof_jnc_CharsetEncoder(TeaVM_Class*, TeaVM_Class*);
typedef struct jnc_CharsetEncoder_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_implReset)(void*); // 11
    void (*virt_implOnUnmappableCharacter)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_encodeLoop)(void*, void*, void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_implFlush)(void*, void*); // 21
    void* (*virt_encode)(void*, void*); // 22
    void* (*virt_onMalformedInput)(void*, void*); // 23
    void* (*virt_reset)(void*); // 24
    void (*pad7)(); // 25
    void (*pad8)(); // 26
    void* (*virt_flush)(void*, void*); // 27
    void (*virt_implOnMalformedInput)(void*, void*); // 28
    void (*pad9)(); // 29
    void (*pad10)(); // 30
    void (*pad11)(); // 31
    void (*pad12)(); // 32
    void (*pad13)(); // 33
    void (*pad14)(); // 34
    void (*pad15)(); // 35
    void (*pad16)(); // 36
    void* (*virt_encode_0)(void*, void*, void*, int32_t); // 37
    void (*pad17)(); // 38
    void (*pad18)(); // 39
    void (*pad19)(); // 40
    void (*pad20)(); // 41
    void (*pad21)(); // 42
    void (*pad22)(); // 43
    void (*pad23)(); // 44
    void (*pad24)(); // 45
    void (*pad25)(); // 46
    void (*pad26)(); // 47
    void* (*virt_onUnmappableCharacter)(void*, void*); // 48
    void (*pad27)(); // 49
} jnc_CharsetEncoder_VT;
extern jnc_CharsetEncoder_VT jnc_CharsetEncoder_Cls;
