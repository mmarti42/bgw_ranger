#pragma once
#include "../../../../runtime.h"
#include "../../lang/Object.h"
#include "Charset.h"

extern void sysinitclass_jnc_Charset();
typedef struct cls_jnc_Charset {
    struct TeaVM_Object parent;
    void* fld_canonicalName;
    TeaVM_Array* fld_aliases;
} cls_jnc_Charset;
extern void meth_jnc_Charset__init_(void*, void*, TeaVM_Array*);
extern void meth_jnc_Charset_checkCanonicalName(void*);
extern int32_t meth_jnc_Charset_isValidCharsetStart(int32_t);
extern void* meth_jnc_Charset_decode(void*, void*);
extern void* meth_jnc_Charset_encode(void*, void*);
extern int32_t supertypeof_jnc_Charset(TeaVM_Class*, TeaVM_Class*);
typedef struct jnc_Charset_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_newEncoder)(void*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_decode)(void*, void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void* (*virt_encode)(void*, void*); // 22
    void (*pad8)(); // 23
    void (*pad9)(); // 24
    void (*pad10)(); // 25
    void (*pad11)(); // 26
    void (*pad12)(); // 27
    void* (*virt_newDecoder)(void*); // 28
    void (*pad13)(); // 29
    void (*pad14)(); // 30
    void (*pad15)(); // 31
    void (*pad16)(); // 32
    void (*pad17)(); // 33
    void (*pad18)(); // 34
    void (*pad19)(); // 35
    void (*pad20)(); // 36
    void (*pad21)(); // 37
    void (*pad22)(); // 38
    void (*pad23)(); // 39
    void (*pad24)(); // 40
    void (*pad25)(); // 41
    void (*pad26)(); // 42
    void (*pad27)(); // 43
    void (*pad28)(); // 44
    void (*pad29)(); // 45
    void (*pad30)(); // 46
    void (*pad31)(); // 47
    void (*pad32)(); // 48
    void (*pad33)(); // 49
} jnc_Charset_VT;
extern jnc_Charset_VT jnc_Charset_Cls;
