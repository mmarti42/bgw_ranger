#pragma once
#include "../../../runtime.h"
#include "Buffer.h"
#include "CharBuffer.h"

extern void sysinitclass_jn_CharBuffer();
typedef struct cls_jn_CharBuffer {
    struct cls_jn_Buffer parent;
} cls_jn_CharBuffer;
extern void meth_jn_CharBuffer__init_(void*, int32_t, int32_t);
extern void* meth_jn_CharBuffer_allocate(int32_t);
extern void* meth_jn_CharBuffer_wrap(TeaVM_Array*, int32_t, int32_t);
extern void* meth_jn_CharBuffer_wrap_0(TeaVM_Array*);
extern void* meth_jn_CharBuffer_get(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jn_CharBuffer_get_0(void*, TeaVM_Array*);
extern void* meth_jn_CharBuffer_put(void*, TeaVM_Array*, int32_t, int32_t);
extern void* meth_jn_CharBuffer_put_0(void*, void*, int32_t, int32_t);
extern void* meth_jn_CharBuffer_put_1(void*, void*);
extern int32_t meth_jn_CharBuffer_hasArray(void*);
extern TeaVM_Array* meth_jn_CharBuffer_array(void*);
extern void* meth_jn_CharBuffer_flip(void*);
extern void* meth_jn_CharBuffer_position(void*, int32_t);
extern int32_t supertypeof_jn_CharBuffer(TeaVM_Class*, TeaVM_Class*);
typedef struct jn_CharBuffer_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_putImpl_1)(void*, int32_t, void*, int32_t, int32_t); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void* (*virt_flip_0)(void*); // 13
    void (*virt_getImpl)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void* (*virt_subSequence)(void*, int32_t, int32_t); // 17
    void (*pad1)(); // 18
    void* (*virt_put_2)(void*, void*); // 19
    int32_t (*virt_hasArray)(void*); // 20
    void* (*virt_put_1)(void*, void*, int32_t, int32_t); // 21
    int32_t (*virt_isReadOnly)(void*); // 22
    void* (*virt_put_3)(void*, TeaVM_Array*, int32_t, int32_t); // 23
    void* (*virt_position_1)(void*, int32_t); // 24
    int32_t (*virt_length)(void*); // 25
    int32_t (*virt_charAt)(void*, int32_t); // 26
    void* (*virt_get_8)(void*, TeaVM_Array*); // 27
    void* (*virt_get_10)(void*, TeaVM_Array*, int32_t, int32_t); // 28
    int32_t (*virt_position)(void*); // 29
    void* (*virt_position_0)(void*, int32_t); // 30
    TeaVM_Array* (*virt_getArray)(void*); // 31
    int32_t (*virt_limit_0)(void*); // 32
    void* (*virt_clear_0)(void*); // 33
    void (*pad2)(); // 34
    void (*pad3)(); // 35
    void* (*virt_flip)(void*); // 36
    void (*virt_putImpl_0)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 37
    int32_t (*virt_capacityImpl)(void*); // 38
    void (*pad4)(); // 39
    void (*pad5)(); // 40
    void (*pad6)(); // 41
    int32_t (*virt_remaining)(void*); // 42
    int32_t (*virt_hasRemaining)(void*); // 43
    void (*pad7)(); // 44
    void (*pad8)(); // 45
    void* (*virt_append_19)(void*, void*); // 46
    TeaVM_Array* (*virt_array)(void*); // 47
    int32_t (*virt_isArrayPresent)(void*); // 48
    int32_t (*virt_capacity)(void*); // 49
} jn_CharBuffer_VT;
extern jn_CharBuffer_VT jn_CharBuffer_Cls;
