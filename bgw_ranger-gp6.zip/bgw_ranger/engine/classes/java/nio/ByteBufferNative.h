#pragma once
#include "../../../runtime.h"
#include "ByteBuffer.h"
#include "ByteBufferNative.h"

extern void sysinitclass_jn_ByteBufferNative();
typedef struct cls_jn_ByteBufferNative {
    struct cls_jn_ByteBuffer parent;
    void* fld_gcRef;
    TeaVM_Array* fld_array;
    int32_t fld_arrayOffset;
    void* fld_base;
    void* fld_address;
    int32_t fld_capacity;
    int8_t fld_readOnly;
    int8_t fld_swap;
} cls_jn_ByteBufferNative;
extern void meth_jn_ByteBufferNative__init_(void*, void*, TeaVM_Array*, int32_t, void*, void*, int32_t, int32_t);
extern void meth_jn_ByteBufferNative_updateSwap(void*);
extern TeaVM_Array* meth_jn_ByteBufferNative_arrayImpl(void*);
extern int32_t meth_jn_ByteBufferNative_hasArrayImpl(void*);
extern int32_t meth_jn_ByteBufferNative_capacityImpl(void*);
extern void meth_jn_ByteBufferNative_getImpl(void*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern void meth_jn_ByteBufferNative_putImpl(void*, TeaVM_Array*, int32_t, int32_t, int32_t);
extern int32_t meth_jn_ByteBufferNative_isReadOnly(void*);
extern void meth_jn_ByteBufferNative_copy(void*, TeaVM_Array*, int32_t, void*, int32_t);
extern void meth_jn_ByteBufferNative_copy_1(void*, void*, TeaVM_Array*, int32_t, int32_t);
extern void meth_jn_ByteBufferNative_copy_0(void*, void*, int32_t);
extern int32_t supertypeof_jn_ByteBufferNative(TeaVM_Class*, TeaVM_Class*);
typedef struct jn_ByteBufferNative_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_get_9)(void*, TeaVM_Array*); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    void (*virt_copy_0)(void*, void*, TeaVM_Array*, int32_t, int32_t); // 13
    void (*virt_getImpl_0)(void*, int32_t, TeaVM_Array*, int32_t, int32_t); // 14
    void (*pad0)(); // 15
    void (*virt_copy_1)(void*, TeaVM_Array*, int32_t, void*, int32_t); // 16
    void (*pad1)(); // 17
    void (*pad2)(); // 18
    void* (*virt_clear_3)(void*); // 19
    int32_t (*virt_hasArray)(void*); // 20
    void (*virt_putImpl_2)(void*, TeaVM_Array*, int32_t, int32_t, int32_t); // 21
    int32_t (*virt_isReadOnly)(void*); // 22
    void* (*virt_get_14)(void*, TeaVM_Array*, int32_t, int32_t); // 23
    void* (*virt_put_5)(void*, TeaVM_Array*); // 24
    void (*pad3)(); // 25
    void (*pad4)(); // 26
    int32_t (*virt_hasArrayImpl)(void*); // 27
    TeaVM_Array* (*virt_arrayImpl)(void*); // 28
    int32_t (*virt_position)(void*); // 29
    void* (*virt_position_0)(void*, int32_t); // 30
    TeaVM_Array* (*virt_array_0)(void*); // 31
    int32_t (*virt_limit_0)(void*); // 32
    void* (*virt_clear_0)(void*); // 33
    void (*pad5)(); // 34
    void (*pad6)(); // 35
    void* (*virt_flip)(void*); // 36
    void* (*virt_put_4)(void*, TeaVM_Array*, int32_t, int32_t); // 37
    int32_t (*virt_capacityImpl)(void*); // 38
    void (*pad7)(); // 39
    void (*pad8)(); // 40
    void (*pad9)(); // 41
    int32_t (*virt_remaining)(void*); // 42
    int32_t (*virt_hasRemaining)(void*); // 43
    void (*pad10)(); // 44
    void (*pad11)(); // 45
    void (*pad12)(); // 46
    void* (*virt_flip_1)(void*); // 47
    void* (*virt_position_2)(void*, int32_t); // 48
    int32_t (*virt_capacity)(void*); // 49
} jn_ByteBufferNative_VT;
extern jn_ByteBufferNative_VT jn_ByteBufferNative_Cls;
