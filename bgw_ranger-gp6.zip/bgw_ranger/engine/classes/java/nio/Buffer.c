#include "Buffer.h"
#include "../lang/Object.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"

void meth_jn_Buffer__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1431, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_mark) = -INT32_C(1);
    TEAVM_RELEASE_STACK;
}
int32_t meth_jn_Buffer_capacity(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1432, TEAVM_METHOD(teavm_this_, jn_Buffer_VT, virt_capacityImpl)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_jn_Buffer_position(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position);
}
void* meth_jn_Buffer_position_0(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit)))) {
        TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = teavm_local_1;
        if ((teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_mark))) {
            TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_mark) = INT32_C(0);
        }
        TEAVM_RELEASE_STACK;
        return teavm_this_;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1433, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1434, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(1435, meth_jl_StringBuilder__init_(teavm_local_4));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1436, meth_jl_StringBuilder_append(teavm_local_4, TEAVM_GET_STRING(105)));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1437, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(1438, teavm_nullCheck(teavm_local_5)), teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1439, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(1440, teavm_nullCheck(teavm_local_5)), TEAVM_GET_STRING(106)));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1441, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(1442, teavm_nullCheck(teavm_local_5)), teavm_local_3));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(1443, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(1444, teavm_nullCheck(teavm_local_5)), INT32_C(93)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1445, meth_jl_StringBuilder_toString(teavm_local_4));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(1446, meth_jl_IllegalArgumentException__init__0(teavm_local_2, teavm_local_4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(1447, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_jn_Buffer_limit(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit);
}
void* meth_jn_Buffer_clear(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit) = TEAVM_WITH_CALL_SITE_ID(1448, meth_jn_Buffer_capacity(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_mark) = -INT32_C(1);
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jn_Buffer_flip(void* teavm_this_) {
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit) = TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position);
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_mark) = -INT32_C(1);
    return teavm_this_;
}
int32_t meth_jn_Buffer_remaining(void* teavm_this_) {
    return (TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit) - TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position));
}
int32_t meth_jn_Buffer_hasRemaining(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) >= TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit)) ? INT32_C(0) : INT32_C(1));
}
int32_t supertypeof_jn_Buffer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 115 || tag >= 127) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jn_Buffer_VT jn_Buffer_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_Buffer), sizeof(void*)),
        .flags = 0,
        .tag = 115,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jn_Buffer,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_position = &meth_jn_Buffer_position,
    .virt_position_0 = &meth_jn_Buffer_position_0,
    .virt_limit_0 = &meth_jn_Buffer_limit,
    .virt_clear_0 = &meth_jn_Buffer_clear,
    .virt_flip = &meth_jn_Buffer_flip,
    .virt_remaining = &meth_jn_Buffer_remaining,
    .virt_hasRemaining = &meth_jn_Buffer_hasRemaining,
    .virt_capacity = &meth_jn_Buffer_capacity
};
void sysinitclass_jn_Buffer() {
}
