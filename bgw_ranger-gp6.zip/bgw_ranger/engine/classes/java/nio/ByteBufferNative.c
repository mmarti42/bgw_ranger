#include "ByteBufferNative.h"
#include "ByteBuffer.h"
#include "ByteOrder.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include <string.h>
#include "../../../strings.h"
#include "../lang/Object.h"
#include "Buffer.h"

void meth_jn_ByteBufferNative__init_(void* teavm_this_, void* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, void* teavm_local_4, void* teavm_local_5, int32_t teavm_local_6, int32_t teavm_local_7) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13436, meth_jn_ByteBuffer__init_(teavm_this_));
    if ((teavm_local_1 == NULL)) {
        teavm_local_1 = teavm_this_;
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_gcRef) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_array) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_arrayOffset) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_base) = teavm_local_4;
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_address) = teavm_local_5;
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_capacity) = teavm_local_6;
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_readOnly) = teavm_local_7;
    TEAVM_WITH_CALL_SITE_ID(13437, meth_jn_ByteBufferNative_updateSwap(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_jn_ByteBufferNative_updateSwap(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_jn_ByteBuffer, fld_order);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_swap) = ((teavm_local_1 == TEAVM_WITH_CALL_SITE_ID(13438, meth_jn_ByteOrder_nativeOrder())) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
}
TeaVM_Array* meth_jn_ByteBufferNative_arrayImpl(void* teavm_this_) {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_array) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13439, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(13440, meth_jl_UnsupportedOperationException__init__0(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(13441, meth_otr_ExceptionHandling_throwException(teavm_local_1));
        TEAVM_UNREACHABLE
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_array);
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jn_ByteBufferNative_hasArrayImpl(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_array) == NULL) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_jn_ByteBufferNative_capacityImpl(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_capacity);
}
void meth_jn_ByteBufferNative_getImpl(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13442, TEAVM_METHOD(teavm_this_, jn_ByteBufferNative_VT, virt_copy_0)(teavm_this_, TEAVM_ADDRESS_ADD(TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_address), teavm_local_1), teavm_local_2, teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
}
void meth_jn_ByteBufferNative_putImpl(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13443, TEAVM_METHOD(teavm_this_, jn_ByteBufferNative_VT, virt_copy_1)(teavm_this_, teavm_local_1, teavm_local_2, TEAVM_ADDRESS_ADD(TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_address), teavm_local_3), teavm_local_4));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jn_ByteBufferNative_isReadOnly(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jn_ByteBufferNative, fld_readOnly);
}
void meth_jn_ByteBufferNative_copy(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13444, meth_jn_ByteBufferNative_copy_0(TEAVM_ADDRESS_ADD(TEAVM_ARRAY_DATA(teavm_local_1, int32_t), teavm_local_2), teavm_local_3, teavm_local_4));
    TEAVM_RELEASE_STACK;
}
void meth_jn_ByteBufferNative_copy_1(void* teavm_this_, void* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13445, meth_jn_ByteBufferNative_copy_0(teavm_local_1, TEAVM_ADDRESS_ADD(TEAVM_ARRAY_DATA(teavm_local_2, int32_t), teavm_local_3), teavm_local_4));
    TEAVM_RELEASE_STACK;
}
void meth_jn_ByteBufferNative_copy_0(void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3) {
    memmove(teavm_local_2, teavm_local_1, teavm_local_3);
}
int32_t supertypeof_jn_ByteBufferNative(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 123 || tag >= 125) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jn_ByteBufferNative_Cls[4];
alignas(8) jn_ByteBufferNative_VT jn_ByteBufferNative_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_ByteBufferNative), sizeof(void*)),
        .flags = 0,
        .tag = 123,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jn_ByteBufferNative,
        .superclass = (TeaVM_Class*) &jn_ByteBuffer_Cls,
        .layout = teavm_classLayouts_jn_ByteBufferNative_Cls,
        .enumValues = (void*) offsetof(cls_jn_ByteBufferNative, fld_base),
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_get_9 = &meth_jn_ByteBuffer_get,
    .virt_copy_0 = &meth_jn_ByteBufferNative_copy_1,
    .virt_getImpl_0 = &meth_jn_ByteBufferNative_getImpl,
    .virt_copy_1 = &meth_jn_ByteBufferNative_copy,
    .virt_clear_3 = &meth_jn_ByteBuffer_clear,
    .virt_hasArray = &meth_jn_ByteBuffer_hasArray,
    .virt_putImpl_2 = &meth_jn_ByteBufferNative_putImpl,
    .virt_isReadOnly = &meth_jn_ByteBufferNative_isReadOnly,
    .virt_get_14 = &meth_jn_ByteBuffer_get_0,
    .virt_put_5 = &meth_jn_ByteBuffer_put,
    .virt_hasArrayImpl = &meth_jn_ByteBufferNative_hasArrayImpl,
    .virt_arrayImpl = &meth_jn_ByteBufferNative_arrayImpl,
    .virt_position = &meth_jn_Buffer_position,
    .virt_array_0 = &meth_jn_ByteBuffer_array,
    .virt_limit_0 = &meth_jn_Buffer_limit,
    .virt_put_4 = &meth_jn_ByteBuffer_put_0,
    .virt_capacityImpl = &meth_jn_ByteBufferNative_capacityImpl,
    .virt_remaining = &meth_jn_Buffer_remaining,
    .virt_hasRemaining = &meth_jn_Buffer_hasRemaining,
    .virt_flip_1 = &meth_jn_ByteBuffer_flip,
    .virt_position_2 = &meth_jn_ByteBuffer_position,
    .virt_capacity = &meth_jn_Buffer_capacity
};
static int16_t teavm_classLayouts_jn_ByteBufferNative_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_jn_ByteBufferNative, fld_gcRef), (int16_t) offsetof(cls_jn_ByteBufferNative, fld_array), (int16_t) offsetof(cls_jn_ByteBufferNative, fld_base)
};
void sysinitclass_jn_ByteBufferNative() {
}
