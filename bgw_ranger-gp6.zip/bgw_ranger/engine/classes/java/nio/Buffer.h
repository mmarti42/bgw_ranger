#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Buffer.h"

extern void sysinitclass_jn_Buffer();
typedef struct cls_jn_Buffer {
    struct TeaVM_Object parent;
    void* fld_nextRef;
    int32_t fld_position;
    int32_t fld_limit;
    int32_t fld_mark;
} cls_jn_Buffer;
extern void meth_jn_Buffer__init_(void*);
extern int32_t meth_jn_Buffer_capacity(void*);
extern int32_t meth_jn_Buffer_position(void*);
extern void* meth_jn_Buffer_position_0(void*, int32_t);
extern int32_t meth_jn_Buffer_limit(void*);
extern void* meth_jn_Buffer_clear(void*);
extern void* meth_jn_Buffer_flip(void*);
extern int32_t meth_jn_Buffer_remaining(void*);
extern int32_t meth_jn_Buffer_hasRemaining(void*);
extern int32_t supertypeof_jn_Buffer(TeaVM_Class*, TeaVM_Class*);
typedef struct jn_Buffer_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*pad1)(); // 12
    void (*pad2)(); // 13
    void (*pad3)(); // 14
    void (*pad4)(); // 15
    void (*pad5)(); // 16
    void (*pad6)(); // 17
    void (*pad7)(); // 18
    void (*pad8)(); // 19
    void (*pad9)(); // 20
    void (*pad10)(); // 21
    void (*pad11)(); // 22
    void (*pad12)(); // 23
    void (*pad13)(); // 24
    void (*pad14)(); // 25
    void (*pad15)(); // 26
    void (*pad16)(); // 27
    void (*pad17)(); // 28
    int32_t (*virt_position)(void*); // 29
    void* (*virt_position_0)(void*, int32_t); // 30
    void (*pad18)(); // 31
    int32_t (*virt_limit_0)(void*); // 32
    void* (*virt_clear_0)(void*); // 33
    void (*pad19)(); // 34
    void (*pad20)(); // 35
    void* (*virt_flip)(void*); // 36
    void (*pad21)(); // 37
    int32_t (*virt_capacityImpl)(void*); // 38
    void (*pad22)(); // 39
    void (*pad23)(); // 40
    void (*pad24)(); // 41
    int32_t (*virt_remaining)(void*); // 42
    int32_t (*virt_hasRemaining)(void*); // 43
    void (*pad25)(); // 44
    void (*pad26)(); // 45
    void (*pad27)(); // 46
    void (*pad28)(); // 47
    void (*pad29)(); // 48
    int32_t (*virt_capacity)(void*); // 49
} jn_Buffer_VT;
extern jn_Buffer_VT jn_Buffer_Cls;
