#pragma once
#include "../../../../runtime.h"
#include "AddressBasedBuffer.h"

extern void sysinitclass_jnf_AddressBasedBuffer();
extern int32_t supertypeof_jnf_AddressBasedBuffer(TeaVM_Class*, TeaVM_Class*);
typedef struct jnf_AddressBasedBuffer_VT {
    TeaVM_Class parent;
    void (*pad0)(); // 0
    void (*pad1)(); // 1
    void* (*virt_clone)(void*); // 2
    void (*pad2)(); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
} jnf_AddressBasedBuffer_VT;
extern TeaVM_Class jnf_AddressBasedBuffer_Cls;
