#include "CharBuffer.h"
#include "Buffer.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../arrays/primitives/char.h"
#include "CharBufferNative.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "BufferUnderflowException.h"
#include "BufferOverflowException.h"
#include "ReadOnlyBufferException.h"
#include "../lang/String.h"
#include "../lang/Object.h"

void meth_jn_CharBuffer__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9605, meth_jn_Buffer__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_limit) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_jn_CharBuffer_allocate(int32_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_local_1 < INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9606, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9607, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(9608, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9609, meth_jl_StringBuilder_append(teavm_local_3, TEAVM_GET_STRING(709)));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(9610, meth_jl_StringBuilder_append_0(TEAVM_WITH_CALL_SITE_ID(9611, teavm_nullCheck(teavm_local_4)), teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9612, meth_jl_StringBuilder_toString(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(9613, meth_jl_IllegalArgumentException__init__0(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(9614, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9615, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9616, meth_otr_Allocator_allocate(&jn_CharBufferNative_Cls));
    teavm_local_3 = NULL;
    teavm_local_4 = TEAVM_ARRAY_DATA(teavm_local_5, int32_t);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(9617, meth_jn_CharBufferNative__init_(teavm_local_2, teavm_local_3, teavm_local_5, INT32_C(0), teavm_local_1, INT32_C(0), teavm_local_5, teavm_local_4, teavm_local_1, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_jn_CharBuffer_wrap(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if (((teavm_local_3 >= INT32_C(0)) && (teavm_local_2 >= INT32_C(0)))) {
        teavm_local_4 = (teavm_local_3 + teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9618, teavm_nullCheck(teavm_local_1));
        teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_1);
        if ((teavm_local_4 <= teavm_local_5)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(9619, meth_otr_Allocator_allocate(&jn_CharBufferNative_Cls));
            teavm_local_7 = NULL;
            teavm_local_8 = TEAVM_ARRAY_DATA(teavm_local_1, int32_t);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(9620, meth_jn_CharBufferNative__init_(teavm_local_6, teavm_local_7, teavm_local_1, INT32_C(0), teavm_local_5, INT32_C(0), teavm_local_1, teavm_local_8, teavm_local_5, INT32_C(0)));
            TEAVM_FIELD(teavm_local_6, cls_jn_Buffer, fld_position) = teavm_local_2;
            TEAVM_FIELD(teavm_local_6, cls_jn_Buffer, fld_limit) = teavm_local_4;
            TEAVM_RELEASE_STACK;
            return teavm_local_6;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(9621, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(9622, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(9623, meth_otr_ExceptionHandling_throwException(teavm_local_7));
    TEAVM_UNREACHABLE
}
void* meth_jn_CharBuffer_wrap_0(TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9624, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9625, meth_jn_CharBuffer_wrap(teavm_local_1, INT32_C(0), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jn_CharBuffer_get(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_3 >= INT32_C(0)) && (teavm_local_2 >= INT32_C(0)))) {
        teavm_local_4 = (teavm_local_2 + teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9626, teavm_nullCheck(teavm_local_1));
        if ((teavm_local_4 <= TEAVM_ARRAY_LENGTH(teavm_local_1))) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            if ((teavm_local_3 <= TEAVM_WITH_CALL_SITE_ID(9627, meth_jn_Buffer_remaining(teavm_this_)))) {
                TEAVM_WITH_CALL_SITE_ID(9628, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_getImpl)(teavm_this_, TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position), teavm_local_1, teavm_local_2, teavm_local_3));
                TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = (TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) + teavm_local_3);
                TEAVM_RELEASE_STACK;
                return teavm_this_;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9629, meth_otr_Allocator_allocate(&jn_BufferUnderflowException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_WITH_CALL_SITE_ID(9630, meth_jn_BufferUnderflowException__init_(teavm_local_5));
            TEAVM_WITH_CALL_SITE_ID(9631, meth_otr_ExceptionHandling_throwException(teavm_local_5));
            TEAVM_UNREACHABLE
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9632, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(9633, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(9634, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void* meth_jn_CharBuffer_get_0(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9635, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9636, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_get_10)(teavm_this_, teavm_local_1, INT32_C(0), teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_jn_CharBuffer_put(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((!TEAVM_WITH_CALL_SITE_ID(9637, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_isReadOnly)(teavm_this_)))) {
        if ((TEAVM_WITH_CALL_SITE_ID(9638, meth_jn_Buffer_remaining(teavm_this_)) >= teavm_local_3)) {
            if (((teavm_local_3 >= INT32_C(0)) && (teavm_local_2 >= INT32_C(0)))) {
                teavm_local_4 = (teavm_local_2 + teavm_local_3);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9639, teavm_nullCheck(teavm_local_1));
                if ((teavm_local_4 <= TEAVM_ARRAY_LENGTH(teavm_local_1))) {
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                    TEAVM_WITH_CALL_SITE_ID(9640, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_putImpl_0)(teavm_this_, teavm_local_4, teavm_local_1, teavm_local_2, teavm_local_3));
                    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = (TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) + teavm_local_3);
                    TEAVM_RELEASE_STACK;
                    return teavm_this_;
                }
            }
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9641, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            TEAVM_WITH_CALL_SITE_ID(9642, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_5));
            TEAVM_WITH_CALL_SITE_ID(9643, meth_otr_ExceptionHandling_throwException(teavm_local_5));
            TEAVM_UNREACHABLE
        }
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9644, meth_otr_Allocator_allocate(&jn_BufferOverflowException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_WITH_CALL_SITE_ID(9645, meth_jn_BufferOverflowException__init_(teavm_local_5));
        TEAVM_WITH_CALL_SITE_ID(9646, meth_otr_ExceptionHandling_throwException(teavm_local_5));
        TEAVM_UNREACHABLE
    }
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9647, meth_otr_Allocator_allocate(&jn_ReadOnlyBufferException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(9648, meth_jn_ReadOnlyBufferException__init_(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(9649, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void* meth_jn_CharBuffer_put_0(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if ((!TEAVM_WITH_CALL_SITE_ID(9650, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_isReadOnly)(teavm_this_)))) {
        if (((teavm_local_3 >= teavm_local_2) && (teavm_local_2 >= INT32_C(0)))) {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9651, teavm_nullCheck(teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            if ((teavm_local_3 <= TEAVM_WITH_CALL_SITE_ID(9652, meth_jl_String_length(teavm_local_1)))) {
                teavm_local_4 = (teavm_local_3 - teavm_local_2);
                if ((TEAVM_WITH_CALL_SITE_ID(9653, meth_jn_Buffer_remaining(teavm_this_)) >= teavm_local_4)) {
                    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position);
                    TEAVM_WITH_CALL_SITE_ID(9654, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_putImpl_1)(teavm_this_, teavm_local_5, teavm_local_1, teavm_local_2, teavm_local_3));
                    TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) = (TEAVM_FIELD(teavm_this_, cls_jn_Buffer, fld_position) + teavm_local_4);
                    TEAVM_RELEASE_STACK;
                    return teavm_this_;
                }
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(9655, meth_otr_Allocator_allocate(&jn_BufferOverflowException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_WITH_CALL_SITE_ID(9656, meth_jn_BufferOverflowException__init_(teavm_local_6));
                TEAVM_WITH_CALL_SITE_ID(9657, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                TEAVM_UNREACHABLE
            }
        }
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(9658, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(9659, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_6));
        TEAVM_WITH_CALL_SITE_ID(9660, meth_otr_ExceptionHandling_throwException(teavm_local_6));
        TEAVM_UNREACHABLE
    }
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(9661, meth_otr_Allocator_allocate(&jn_ReadOnlyBufferException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(9662, meth_jn_ReadOnlyBufferException__init_(teavm_local_6));
    TEAVM_WITH_CALL_SITE_ID(9663, meth_otr_ExceptionHandling_throwException(teavm_local_6));
    TEAVM_UNREACHABLE
}
void* meth_jn_CharBuffer_put_1(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9664, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9665, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_put_1)(teavm_this_, teavm_local_1, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(9666, meth_jl_String_length(teavm_local_1))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jn_CharBuffer_hasArray(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9667, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_isArrayPresent)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_jn_CharBuffer_array(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9668, TEAVM_METHOD(teavm_this_, jn_CharBuffer_VT, virt_getArray)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_jn_CharBuffer_flip(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9669, meth_jn_Buffer_flip(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_jn_CharBuffer_position(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9670, meth_jn_Buffer_position_0(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
int32_t supertypeof_jn_CharBuffer(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 116 || tag >= 122) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jn_CharBuffer_VT jn_CharBuffer_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_CharBuffer), sizeof(void*)),
        .flags = 0,
        .tag = 116,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jn_CharBuffer,
        .superclass = (TeaVM_Class*) &jn_Buffer_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_flip_0 = &meth_jn_CharBuffer_flip,
    .virt_put_2 = &meth_jn_CharBuffer_put_1,
    .virt_hasArray = &meth_jn_CharBuffer_hasArray,
    .virt_put_1 = &meth_jn_CharBuffer_put_0,
    .virt_put_3 = &meth_jn_CharBuffer_put,
    .virt_position_1 = &meth_jn_CharBuffer_position,
    .virt_get_8 = &meth_jn_CharBuffer_get_0,
    .virt_get_10 = &meth_jn_CharBuffer_get,
    .virt_position = &meth_jn_Buffer_position,
    .virt_limit_0 = &meth_jn_Buffer_limit,
    .virt_remaining = &meth_jn_Buffer_remaining,
    .virt_hasRemaining = &meth_jn_Buffer_hasRemaining,
    .virt_array = &meth_jn_CharBuffer_array,
    .virt_capacity = &meth_jn_Buffer_capacity
};
void sysinitclass_jn_CharBuffer() {
}
