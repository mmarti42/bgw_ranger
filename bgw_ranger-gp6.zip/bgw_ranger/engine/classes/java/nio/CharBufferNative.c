#include "CharBufferNative.h"
#include "CharBufferImpl.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/Character.h"
#include "../lang/String.h"
#include "ByteBufferNative.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "CharBuffer.h"
#include "Buffer.h"

void meth_jn_CharBufferNative__init_(void* teavm_this_, void* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5, void* teavm_local_6, void* teavm_local_7, int32_t teavm_local_8, int32_t teavm_local_9) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24020, meth_jn_CharBufferImpl__init_(teavm_this_, teavm_local_3, teavm_local_4));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_array) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_readOnly) = teavm_local_5;
    TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_base) = teavm_local_6;
    TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_address) = teavm_local_7;
    TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_capacity) = teavm_local_8;
    TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_swap) = teavm_local_9;
    TEAVM_RELEASE_STACK;
}
int32_t meth_jn_CharBufferNative_capacityImpl(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_capacity);
}
int32_t meth_jn_CharBufferNative_isArrayPresent(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_array) == NULL) ? INT32_C(0) : INT32_C(1));
}
TeaVM_Array* meth_jn_CharBufferNative_getArray(void* teavm_this_) {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_array) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(24021, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(24022, meth_jl_UnsupportedOperationException__init__0(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(24023, meth_otr_ExceptionHandling_throwException(teavm_local_1));
        TEAVM_UNREACHABLE
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_array);
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_jn_CharBufferNative_readOnly(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_readOnly);
}
void meth_jn_CharBufferNative_getImpl(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_5 = TEAVM_ADDRESS_ADD(TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_address), (teavm_local_1 * INT32_C(2)));
    if ((!TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_swap))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(24024, TEAVM_METHOD(teavm_this_, jn_CharBufferNative_VT, virt_copy_2)(teavm_this_, teavm_local_5, teavm_local_2, teavm_local_3, teavm_local_4));
    } else {
        while (1) {
            teavm_local_6 = (teavm_local_4 + -INT32_C(1));
            if ((teavm_local_4 <= INT32_C(0))) {
                goto teavm_label_1;
            }
            teavm_local_7 = (teavm_local_3 + INT32_C(1));
            teavm_local_8 = ((int32_t) *(char16_t*) teavm_local_5);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(24025, meth_jl_Character_reverseBytes(teavm_local_8));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24026, teavm_nullCheck(teavm_local_2));
            teavm_local_10 = teavm_local_2;
            TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(24027, teavm_checkBounds(teavm_local_3, teavm_local_10))) = teavm_local_9;
            teavm_local_5 = TEAVM_ADDRESS_ADD(teavm_local_5, INT32_C(2));
            teavm_local_4 = teavm_local_6;
            teavm_local_3 = teavm_local_7;
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jn_CharBufferNative_putImpl(void* teavm_this_, int32_t teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_5 = TEAVM_ADDRESS_ADD(TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_address), (teavm_local_1 * INT32_C(2)));
    if ((!TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_swap))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(24028, TEAVM_METHOD(teavm_this_, jn_CharBufferNative_VT, virt_copy_3)(teavm_this_, teavm_local_2, teavm_local_3, teavm_local_5, teavm_local_4));
    } else {
        while (1) {
            teavm_local_6 = (teavm_local_4 + -INT32_C(1));
            if ((teavm_local_4 <= INT32_C(0))) {
                goto teavm_label_1;
            }
            teavm_local_7 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24029, teavm_nullCheck(teavm_local_2));
            teavm_local_8 = teavm_local_2;
            (*(char16_t*) teavm_local_5 = (char16_t) TEAVM_WITH_CALL_SITE_ID(24030, meth_jl_Character_reverseBytes(TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(24031, teavm_checkBounds(teavm_local_3, teavm_local_8))))));
            teavm_local_5 = TEAVM_ADDRESS_ADD(teavm_local_5, INT32_C(2));
            teavm_local_4 = teavm_local_6;
            teavm_local_3 = teavm_local_7;
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jn_CharBufferNative_putImpl_0(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_5 = TEAVM_ADDRESS_ADD(TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_address), (teavm_local_1 * INT32_C(2)));
    if ((!TEAVM_FIELD(teavm_this_, cls_jn_CharBufferNative, fld_swap))) {
        while (1) {
            teavm_local_6 = (teavm_local_4 + -INT32_C(1));
            if ((teavm_local_4 <= INT32_C(0))) {
                goto teavm_label_1;
            }
            teavm_local_7 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24032, teavm_nullCheck(teavm_local_2));
            (*(char16_t*) teavm_local_5 = (char16_t) TEAVM_WITH_CALL_SITE_ID(24033, meth_jl_String_charAt(teavm_local_2, teavm_local_3)));
            teavm_local_5 = TEAVM_ADDRESS_ADD(teavm_local_5, INT32_C(2));
            teavm_local_4 = teavm_local_6;
            teavm_local_3 = teavm_local_7;
        }
    }
    while (1) {
        teavm_local_6 = (teavm_local_4 + -INT32_C(1));
        if ((teavm_local_4 <= INT32_C(0))) {
            goto teavm_label_1;
        }
        teavm_local_7 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(24034, teavm_nullCheck(teavm_local_2));
        (*(char16_t*) teavm_local_5 = (char16_t) TEAVM_WITH_CALL_SITE_ID(24035, meth_jl_Character_reverseBytes(TEAVM_WITH_CALL_SITE_ID(24036, meth_jl_String_charAt(teavm_local_2, teavm_local_3)))));
        teavm_local_5 = TEAVM_ADDRESS_ADD(teavm_local_5, INT32_C(2));
        teavm_local_4 = teavm_local_6;
        teavm_local_3 = teavm_local_7;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_jn_CharBufferNative_copy(void* teavm_this_, TeaVM_Array* teavm_local_1, int32_t teavm_local_2, void* teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24037, meth_jn_ByteBufferNative_copy_0(TEAVM_ADDRESS_ADD(TEAVM_ARRAY_DATA(teavm_local_1, int32_t), (teavm_local_2 * INT32_C(2))), teavm_local_3, (teavm_local_4 * INT32_C(2))));
    TEAVM_RELEASE_STACK;
}
void meth_jn_CharBufferNative_copy_0(void* teavm_this_, void* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(24038, meth_jn_ByteBufferNative_copy_0(teavm_local_1, TEAVM_ADDRESS_ADD(TEAVM_ARRAY_DATA(teavm_local_2, int32_t), (teavm_local_3 * INT32_C(2))), (teavm_local_4 * INT32_C(2))));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_jn_CharBufferNative(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 118 || tag >= 120) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jn_CharBufferNative_Cls[3];
alignas(8) jn_CharBufferNative_VT jn_CharBufferNative_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_CharBufferNative), sizeof(void*)),
        .flags = 0,
        .tag = 118,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jn_CharBufferNative,
        .superclass = (TeaVM_Class*) &jn_CharBufferImpl_Cls,
        .layout = teavm_classLayouts_jn_CharBufferNative_Cls,
        .enumValues = (void*) offsetof(cls_jn_CharBufferNative, fld_base),
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_putImpl_1 = &meth_jn_CharBufferNative_putImpl_0,
    .virt_flip_0 = &meth_jn_CharBuffer_flip,
    .virt_getImpl = &meth_jn_CharBufferNative_getImpl,
    .virt_put_2 = &meth_jn_CharBuffer_put_1,
    .virt_hasArray = &meth_jn_CharBuffer_hasArray,
    .virt_put_1 = &meth_jn_CharBuffer_put_0,
    .virt_isReadOnly = &meth_jn_CharBufferImpl_isReadOnly,
    .virt_put_3 = &meth_jn_CharBuffer_put,
    .virt_position_1 = &meth_jn_CharBuffer_position,
    .virt_get_8 = &meth_jn_CharBuffer_get_0,
    .virt_get_10 = &meth_jn_CharBuffer_get,
    .virt_position = &meth_jn_Buffer_position,
    .virt_getArray = &meth_jn_CharBufferNative_getArray,
    .virt_limit_0 = &meth_jn_Buffer_limit,
    .virt_putImpl_0 = &meth_jn_CharBufferNative_putImpl,
    .virt_capacityImpl = &meth_jn_CharBufferNative_capacityImpl,
    .virt_readOnly = &meth_jn_CharBufferNative_readOnly,
    .virt_remaining = &meth_jn_Buffer_remaining,
    .virt_hasRemaining = &meth_jn_Buffer_hasRemaining,
    .virt_copy_3 = &meth_jn_CharBufferNative_copy,
    .virt_copy_2 = &meth_jn_CharBufferNative_copy_0,
    .virt_array = &meth_jn_CharBuffer_array,
    .virt_isArrayPresent = &meth_jn_CharBufferNative_isArrayPresent,
    .virt_capacity = &meth_jn_Buffer_capacity
};
static int16_t teavm_classLayouts_jn_CharBufferNative_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_jn_CharBufferNative, fld_array), (int16_t) offsetof(cls_jn_CharBufferNative, fld_base)
};
void sysinitclass_jn_CharBufferNative() {
}
