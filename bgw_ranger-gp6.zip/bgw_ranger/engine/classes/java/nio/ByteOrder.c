#include "ByteOrder.h"
#include "../lang/Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrays/primitives/short.h"
#include "../../../strings.h"

void* sfld_jn_ByteOrder_BIG_ENDIAN;
void* sfld_jn_ByteOrder_LITTLE_ENDIAN;
void* sfld_jn_ByteOrder_nativeOrder;
void meth_jn_ByteOrder__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(21158, teavm_initializeClass((TeaVM_Class*) &jn_ByteOrder_Cls, &initclass_jn_ByteOrder));
    TEAVM_WITH_CALL_SITE_ID(21159, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_jn_ByteOrder, fld_name) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_jn_ByteOrder_nativeOrder() {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(21160, teavm_initializeClass((TeaVM_Class*) &jn_ByteOrder_Cls, &initclass_jn_ByteOrder));
    if ((sfld_jn_ByteOrder_nativeOrder == NULL)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21161, teavm_fillShortArray(meth_otr_Allocator_allocateArray(&Arr_S_Cls, 1), INT32_C(1)));
        teavm_local_2 = ((int32_t) *(int8_t*) TEAVM_ARRAY_DATA(teavm_local_1, int32_t));
        sfld_jn_ByteOrder_nativeOrder = (teavm_local_2 ? sfld_jn_ByteOrder_LITTLE_ENDIAN : sfld_jn_ByteOrder_BIG_ENDIAN);
    }
    teavm_local_3 = sfld_jn_ByteOrder_nativeOrder;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_jn_ByteOrder__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21162, meth_otr_Allocator_allocate(&jn_ByteOrder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(21163, meth_jn_ByteOrder__init_(teavm_local_1, TEAVM_GET_STRING(6881)));
    sfld_jn_ByteOrder_BIG_ENDIAN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21164, meth_otr_Allocator_allocate(&jn_ByteOrder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(21165, meth_jn_ByteOrder__init_(teavm_local_1, TEAVM_GET_STRING(6882)));
    sfld_jn_ByteOrder_LITTLE_ENDIAN = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_jn_ByteOrder() {
    TeaVM_Class* cls = (TeaVM_Class*) &jn_ByteOrder_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_jn_ByteOrder__clinit_();
    }
}
int32_t supertypeof_jn_ByteOrder(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1257 || tag >= 1259) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_jn_ByteOrder_Cls[2];
alignas(8) jn_ByteOrder_VT jn_ByteOrder_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_ByteOrder), sizeof(void*)),
            .flags = 0,
            .tag = 1257,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_jn_ByteOrder,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = teavm_classLayouts_jn_ByteOrder_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_jn_ByteOrder_Cls[3] = {
(void**) &sfld_jn_ByteOrder_BIG_ENDIAN, (void**) &sfld_jn_ByteOrder_LITTLE_ENDIAN, (void**) &sfld_jn_ByteOrder_nativeOrder
};
static int16_t teavm_classLayouts_jn_ByteOrder_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_jn_ByteOrder, fld_name)
};
void sysinitclass_jn_ByteOrder() {
sfld_jn_ByteOrder_BIG_ENDIAN = NULL;
sfld_jn_ByteOrder_LITTLE_ENDIAN = NULL;
sfld_jn_ByteOrder_nativeOrder = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_jn_ByteOrder_Cls, 3);
}
