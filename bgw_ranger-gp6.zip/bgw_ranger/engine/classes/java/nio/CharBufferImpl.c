#include "CharBufferImpl.h"
#include "CharBuffer.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "Buffer.h"

void meth_jn_CharBufferImpl__init_(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43631, meth_jn_CharBuffer__init_(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
int32_t meth_jn_CharBufferImpl_isReadOnly(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43632, TEAVM_METHOD(teavm_this_, jn_CharBufferImpl_VT, virt_readOnly)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_jn_CharBufferImpl(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 117 || tag >= 121) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) jn_CharBufferImpl_VT jn_CharBufferImpl_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_jn_CharBufferImpl), sizeof(void*)),
        .flags = 0,
        .tag = 117,
        .modifiers = 1024,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_jn_CharBufferImpl,
        .superclass = (TeaVM_Class*) &jn_CharBuffer_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_flip_0 = &meth_jn_CharBuffer_flip,
    .virt_put_2 = &meth_jn_CharBuffer_put_1,
    .virt_hasArray = &meth_jn_CharBuffer_hasArray,
    .virt_put_1 = &meth_jn_CharBuffer_put_0,
    .virt_isReadOnly = &meth_jn_CharBufferImpl_isReadOnly,
    .virt_put_3 = &meth_jn_CharBuffer_put,
    .virt_position_1 = &meth_jn_CharBuffer_position,
    .virt_get_8 = &meth_jn_CharBuffer_get_0,
    .virt_get_10 = &meth_jn_CharBuffer_get,
    .virt_position = &meth_jn_Buffer_position,
    .virt_limit_0 = &meth_jn_Buffer_limit,
    .virt_remaining = &meth_jn_Buffer_remaining,
    .virt_hasRemaining = &meth_jn_Buffer_hasRemaining,
    .virt_array = &meth_jn_CharBuffer_array,
    .virt_capacity = &meth_jn_Buffer_capacity
};
void sysinitclass_jn_CharBufferImpl() {
}
