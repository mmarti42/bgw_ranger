#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "BitSet.h"

extern void sysinitclass_ju_BitSet();
typedef struct cls_ju_BitSet {
    struct TeaVM_Object parent;
    TeaVM_Array* fld_data;
    int32_t fld_length;
} cls_ju_BitSet;
extern void meth_ju_BitSet__init_(void*);
extern void meth_ju_BitSet__init__0(void*, int32_t);
extern void meth_ju_BitSet_set(void*, int32_t);
extern void meth_ju_BitSet_set_0(void*, int32_t, int32_t);
extern int32_t meth_ju_BitSet_trailingZeroBits(void*, int32_t);
extern int32_t meth_ju_BitSet_trailingOneBits(void*, int32_t);
extern void meth_ju_BitSet_clear(void*, int32_t);
extern void meth_ju_BitSet_clear_0(void*, int32_t, int32_t);
extern int32_t meth_ju_BitSet_get(void*, int32_t);
extern int32_t meth_ju_BitSet_nextSetBit(void*, int32_t);
extern int32_t meth_ju_BitSet_nextClearBit(void*, int32_t);
extern void meth_ju_BitSet_ensureCapacity(void*, int32_t);
extern void meth_ju_BitSet_recalculateLength(void*);
extern int32_t meth_ju_BitSet_intersects(void*, void*);
extern void meth_ju_BitSet_and(void*, void*);
extern void meth_ju_BitSet_andNot(void*, void*);
extern void meth_ju_BitSet_or(void*, void*);
extern void meth_ju_BitSet_xor(void*, void*);
extern int32_t meth_ju_BitSet_isEmpty(void*);
extern int32_t supertypeof_ju_BitSet(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_BitSet_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_intersects)(void*, void*); // 11
    void (*virt_and)(void*, void*); // 12
    void (*pad0)(); // 13
    void (*virt_set_1)(void*, int32_t, int32_t); // 14
    void (*pad1)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    void (*pad2)(); // 17
    void (*pad3)(); // 18
    void (*pad4)(); // 19
    void (*pad5)(); // 20
    void (*virt_xor)(void*, void*); // 21
    void (*virt_or)(void*, void*); // 22
    int32_t (*virt_get_7)(void*, int32_t); // 23
    void (*virt_clear_1)(void*, int32_t, int32_t); // 24
    void (*pad6)(); // 25
    void (*pad7)(); // 26
    void (*virt_andNot)(void*, void*); // 27
    int32_t (*virt_nextClearBit)(void*, int32_t); // 28
    void (*pad8)(); // 29
    void (*pad9)(); // 30
    void (*virt_set_3)(void*, int32_t); // 31
    void (*pad10)(); // 32
    void (*pad11)(); // 33
    void (*pad12)(); // 34
    void (*pad13)(); // 35
    void (*pad14)(); // 36
    int32_t (*virt_nextSetBit)(void*, int32_t); // 37
    void (*pad15)(); // 38
    void (*pad16)(); // 39
    void (*pad17)(); // 40
    void (*pad18)(); // 41
    void (*pad19)(); // 42
    void (*pad20)(); // 43
    void (*pad21)(); // 44
    void (*pad22)(); // 45
    void (*pad23)(); // 46
    void (*pad24)(); // 47
    void (*virt_clear_2)(void*, int32_t); // 48
    void (*pad25)(); // 49
} ju_BitSet_VT;
extern ju_BitSet_VT ju_BitSet_Cls;
