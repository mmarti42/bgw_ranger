#include "Collections@d12.h"
#include "AbstractSet.h"
#include "Set.h"
#include "Collections.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_Collections_12__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Collections_12, fld_val_s) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(32574, meth_ju_AbstractSet__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Collections_12_iterator(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_12, fld_val_s);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32575, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32576, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32577, meth_ju_Collections_unmodifiableIterator(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_Collections_12_size(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_12, fld_val_s);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32578, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32579, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_size)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Collections_12_remove(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32580, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(32581, meth_jl_UnsupportedOperationException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(32582, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Collections_12_contains(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_12, fld_val_s);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(32583, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32584, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_contains)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Collections_12_containsAll(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_12, fld_val_s);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(32585, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32586, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_containsAll)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Collections_12_isEmpty(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_12, fld_val_s);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32587, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32588, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_isEmpty)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_Collections_12(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1327 || tag >= 1329) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Collections_12_Cls[2];
alignas(8) ju_Collections_12_VT ju_Collections_12_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_12), sizeof(void*)),
                .flags = 0,
                .tag = 1327,
                .modifiers = 0,
                .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7596),
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_ju_Collections_12,
                .superclass = (TeaVM_Class*) &ju_AbstractSet_Cls,
                .layout = teavm_classLayouts_ju_Collections_12_Cls,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = (TeaVM_Class*) &ju_Collections_Cls,
                .init = NULL
            },
            .virt_hashCode = &meth_ju_AbstractSet_hashCode,
            .virt_equals = &meth_ju_AbstractSet_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_ju_AbstractCollection_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_forEach = &meth_jl_Iterable_forEach,
            .virt_iterator = &meth_ju_Collections_12_iterator,
            .virt_spliterator = &meth_ju_Collection_spliterator,
            .virt_remove_0 = &meth_ju_Collections_12_remove,
            .virt_isEmpty = &meth_ju_Collections_12_isEmpty,
            .virt_size = &meth_ju_Collections_12_size,
            .virt_stream = &meth_ju_Collection_stream,
            .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
            .virt_removeIf = &meth_ju_Collection_removeIf,
            .virt_toArray = &meth_ju_AbstractCollection_toArray,
            .virt_removeAll = &meth_ju_AbstractSet_removeAll,
            .virt_add_2 = &meth_ju_AbstractCollection_add,
            .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
            .virt_containsAll = &meth_ju_Collections_12_containsAll,
            .virt_contains = &meth_ju_Collections_12_contains
        }
    }
};
static int16_t teavm_classLayouts_ju_Collections_12_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_Collections_12, fld_val_s)
};
void sysinitclass_ju_Collections_12() {
}
