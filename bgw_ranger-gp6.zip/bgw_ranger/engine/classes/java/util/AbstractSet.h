#pragma once
#include "../../../runtime.h"
#include "AbstractCollection.h"
#include "AbstractSet.h"

extern void sysinitclass_ju_AbstractSet();
typedef struct cls_ju_AbstractSet {
    struct cls_ju_AbstractCollection parent;
} cls_ju_AbstractSet;
extern void meth_ju_AbstractSet__init_(void*);
extern int32_t meth_ju_AbstractSet_removeAll(void*, void*);
extern int32_t meth_ju_AbstractSet_equals(void*, void*);
extern int32_t meth_ju_AbstractSet_hashCode(void*);
extern int32_t supertypeof_ju_AbstractSet(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractSet_VT {
    ju_AbstractCollection_VT parent;
} ju_AbstractSet_VT;
extern ju_AbstractSet_VT ju_AbstractSet_Cls;
