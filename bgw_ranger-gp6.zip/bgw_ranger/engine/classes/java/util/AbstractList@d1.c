#include "AbstractList@d1.h"
#include "../lang/Object.h"
#include "AbstractList.h"
#include "../lang/IllegalStateException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "ConcurrentModificationException.h"
#include "../../../strings.h"

void meth_ju_AbstractList_1__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13336, meth_jl_Object__init_(teavm_this_));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_modCount) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(13337, teavm_nullCheck(teavm_local_2)), cls_ju_AbstractList, fld_modCount);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_size) = TEAVM_WITH_CALL_SITE_ID(13338, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13339, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_size)(teavm_tmp_ptr_0)));
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_removeIndex) = -INT32_C(1);
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractList_1_hasNext(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index) >= TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_size)) ? INT32_C(0) : INT32_C(1));
}
void* meth_ju_AbstractList_1_next(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13340, meth_ju_AbstractList_1_checkConcurrentModification(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_removeIndex) = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index);
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index) = (teavm_local_2 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13341, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13342, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_get)(teavm_tmp_ptr_0, teavm_local_2)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ju_AbstractList_1_remove(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_removeIndex) >= INT32_C(0))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(13343, meth_ju_AbstractList_1_checkConcurrentModification(teavm_this_));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_removeIndex);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(13344, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13345, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_remove_1)(teavm_tmp_ptr_0, teavm_local_2)));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_modCount) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(13346, teavm_nullCheck(teavm_local_1)), cls_ju_AbstractList, fld_modCount);
        if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_removeIndex) < TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index))) {
            TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_index) - INT32_C(1));
        }
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_size) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_size) - INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_removeIndex) = -INT32_C(1);
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13347, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(13348, meth_jl_IllegalStateException__init__0(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(13349, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void meth_ju_AbstractList_1_checkConcurrentModification(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_modCount);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_1, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((teavm_local_1 != TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(13350, teavm_nullCheck(teavm_local_2)), cls_ju_AbstractList, fld_modCount))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13351, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(13352, meth_ju_ConcurrentModificationException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(13353, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ju_AbstractList_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 585 || tag >= 587) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractList_1_Cls[2];
alignas(8) ju_AbstractList_1_VT ju_AbstractList_1_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractList_1), sizeof(void*)),
        .flags = 0,
        .tag = 585,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractList_1,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractList_1_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_remove = &meth_ju_AbstractList_1_remove,
    .virt_next = &meth_ju_AbstractList_1_next,
    .virt_hasNext = &meth_ju_AbstractList_1_hasNext
};
static int16_t teavm_classLayouts_ju_AbstractList_1_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_AbstractList_1, fld_this_0)
};
void sysinitclass_ju_AbstractList_1() {
}
