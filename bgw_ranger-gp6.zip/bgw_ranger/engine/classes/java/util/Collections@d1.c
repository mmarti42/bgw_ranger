#include "Collections@d1.h"
#include "TemplateCollections@dAbstractImmutableSet.h"
#include "Collections.h"
#include "Collection.h"
#include "../../../strings.h"
#include "AbstractSet.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"

void meth_ju_Collections_1__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5923, meth_ju_TemplateCollections_AbstractImmutableSet__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Collections_1_size(void* teavm_this_) {
    return INT32_C(0);
}
void* meth_ju_Collections_1_iterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5924, meth_ju_Collections_emptyIterator());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_Collections_1_isEmpty(void* teavm_this_) {
    return INT32_C(1);
}
int32_t meth_ju_Collections_1_contains(void* teavm_this_, void* teavm_local_1) {
    return INT32_C(0);
}
int32_t meth_ju_Collections_1_containsAll(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5925, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5926, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_isEmpty)(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_Collections_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1312 || tag >= 1314) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_Collections_1_VT ju_Collections_1_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_1), sizeof(void*)),
                    .flags = 0,
                    .tag = 1312,
                    .modifiers = 0,
                    .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(529),
                    .simpleName = NULL,
                    .arrayType = NULL,
                    .itemType = NULL,
                    .isSupertypeOf = &supertypeof_ju_Collections_1,
                    .superclass = (TeaVM_Class*) &ju_TemplateCollections_AbstractImmutableSet_Cls,
                    .layout = NULL,
                    .enumValues = NULL,
                    .declaringClass = NULL,
                    .enclosingClass = (TeaVM_Class*) &ju_Collections_Cls,
                    .init = NULL
                },
                .virt_hashCode = &meth_ju_AbstractSet_hashCode,
                .virt_equals = &meth_ju_AbstractSet_equals,
                .virt_clone = &meth_jl_Object_clone,
                .virt_toString = &meth_ju_AbstractCollection_toString,
                .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                .virt_getClass = &meth_jl_Object_getClass,
                .virt_identity = &meth_jl_Object_identity,
                .virt_notifyAll = &meth_jl_Object_notifyAll,
                .virt_wait = &meth_jl_Object_wait,
                .virt_waitImpl = &meth_jl_Object_waitImpl,
                .virt_wait_0 = &meth_jl_Object_wait_0,
                .virt_forEach = &meth_jl_Iterable_forEach,
                .virt_iterator = &meth_ju_Collections_1_iterator,
                .virt_spliterator = &meth_ju_Collection_spliterator,
                .virt_remove_0 = &meth_ju_TemplateCollections_AbstractImmutableSet_remove,
                .virt_isEmpty = &meth_ju_Collections_1_isEmpty,
                .virt_size = &meth_ju_Collections_1_size,
                .virt_stream = &meth_ju_Collection_stream,
                .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
                .virt_toArray = &meth_ju_AbstractCollection_toArray,
                .virt_removeAll = &meth_ju_TemplateCollections_AbstractImmutableSet_removeAll,
                .virt_add_2 = &meth_ju_AbstractCollection_add,
                .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
                .virt_containsAll = &meth_ju_Collections_1_containsAll,
                .virt_contains = &meth_ju_Collections_1_contains
            }
        }
    }
};
void sysinitclass_ju_Collections_1() {
}
