#include "Calendar.h"
#include "../lang/Object.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../arrays/primitives/boolean.h"
#include "Locale.h"
#include "../../org/teavm/classlib/impl/unicode/CLDRHelper.h"
#include "../../../resource.h"
#include "../../../resources/org/teavm/platform/metadata/IntResource.h"
#include "../../../strings.h"
#include "TimeZone.h"
#include "GregorianCalendar.h"
#include "Date.h"
#include "../lang/NullPointerException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../arrayclass.h"
#include "../lang/String.h"

TeaVM_Array* sfld_ju_Calendar_fieldNames;
int32_t sfld_ju_Calendar_firstDayOfWeekCache;
int32_t sfld_ju_Calendar_minimalDaysInFirstWeekCache;
void* sfld_ju_Calendar_cacheFor;
void meth_ju_Calendar__init_(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(990, teavm_initializeClass((TeaVM_Class*) &ju_Calendar_Cls, &initclass_ju_Calendar));
    TEAVM_WITH_CALL_SITE_ID(991, meth_jl_Object__init_(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(992, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(17)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_fields) = teavm_local_2;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(993, meth_otr_Allocator_allocateArray(&Arr_Z_Cls, INT32_C(17)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isSet) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(0);
    TEAVM_WITH_CALL_SITE_ID(994, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_setLenient)(teavm_this_, INT32_C(1)));
    TEAVM_WITH_CALL_SITE_ID(995, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_setTimeZone)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void meth_ju_Calendar__init__0(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(996, teavm_initializeClass((TeaVM_Class*) &ju_Calendar_Cls, &initclass_ju_Calendar));
    TEAVM_WITH_CALL_SITE_ID(997, meth_ju_Calendar__init_(teavm_this_, teavm_local_1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(998, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(17)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_fields) = teavm_local_3;
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(999, meth_otr_Allocator_allocateArray(&Arr_Z_Cls, INT32_C(17)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isSet) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(0);
    TEAVM_WITH_CALL_SITE_ID(1000, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_setLenient)(teavm_this_, INT32_C(1)));
    TEAVM_WITH_CALL_SITE_ID(1001, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_setFirstDayOfWeek)(teavm_this_, TEAVM_WITH_CALL_SITE_ID(1002, meth_ju_Calendar_resolveFirstDayOfWeek(teavm_local_2))));
    TEAVM_WITH_CALL_SITE_ID(1003, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_setMinimalDaysInFirstWeek)(teavm_this_, TEAVM_WITH_CALL_SITE_ID(1004, meth_ju_Calendar_resolveMinimalDaysInFirstWeek(teavm_local_2))));
    sfld_ju_Calendar_cacheFor = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Calendar_resolveFirstDayOfWeek(void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(1005, teavm_initializeClass((TeaVM_Class*) &ju_Calendar_Cls, &initclass_ju_Calendar));
    if (((teavm_local_1 == sfld_ju_Calendar_cacheFor) && (sfld_ju_Calendar_firstDayOfWeekCache >= INT32_C(0)))) {
        teavm_local_2 = sfld_ju_Calendar_firstDayOfWeekCache;
    } else {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1006, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1007, meth_ju_Locale_getLanguage(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1008, meth_ju_Locale_getCountry(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1009, meth_otciu_CLDRHelper_resolveCountry(teavm_local_3, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(1010, meth_otciu_CLDRHelper_getFirstDayOfWeek());
        if (TEAVM_WITH_CALL_SITE_ID(1011, (teavm_lookupResource((TeaVM_ResourceMap*) teavm_local_6, (TeaVM_String*) teavm_local_5) != NULL))) {
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1012, teavm_lookupResourceValue((TeaVM_ResourceMap*) teavm_local_6, (TeaVM_String*) teavm_local_5));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1013, TEAVM_FIELD(teavm_local_3, cls_otpm_IntResource, value));
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1014, TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(1015, teavm_lookupResourceValue((TeaVM_ResourceMap*) teavm_local_6, (TeaVM_String*) TEAVM_GET_STRING(71))), cls_otpm_IntResource, value));
        }
        sfld_ju_Calendar_firstDayOfWeekCache = teavm_local_2;
        teavm_local_2 = sfld_ju_Calendar_firstDayOfWeekCache;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Calendar_resolveMinimalDaysInFirstWeek(void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(1016, teavm_initializeClass((TeaVM_Class*) &ju_Calendar_Cls, &initclass_ju_Calendar));
    if (((teavm_local_1 == sfld_ju_Calendar_cacheFor) && (sfld_ju_Calendar_minimalDaysInFirstWeekCache >= INT32_C(0)))) {
        teavm_local_2 = sfld_ju_Calendar_minimalDaysInFirstWeekCache;
    } else {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1017, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1018, meth_ju_Locale_getLanguage(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1019, meth_ju_Locale_getCountry(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1020, meth_otciu_CLDRHelper_resolveCountry(teavm_local_3, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(1021, meth_otciu_CLDRHelper_getMinimalDaysInFirstWeek());
        if (TEAVM_WITH_CALL_SITE_ID(1022, (teavm_lookupResource((TeaVM_ResourceMap*) teavm_local_6, (TeaVM_String*) teavm_local_5) != NULL))) {
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1023, teavm_lookupResourceValue((TeaVM_ResourceMap*) teavm_local_6, (TeaVM_String*) teavm_local_5));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1024, TEAVM_FIELD(teavm_local_3, cls_otpm_IntResource, value));
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1025, TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(1026, teavm_lookupResourceValue((TeaVM_ResourceMap*) teavm_local_6, (TeaVM_String*) TEAVM_GET_STRING(71))), cls_otpm_IntResource, value));
        }
        sfld_ju_Calendar_minimalDaysInFirstWeekCache = teavm_local_2;
        teavm_local_2 = sfld_ju_Calendar_minimalDaysInFirstWeekCache;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Calendar_after(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int64_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!teavm_instanceof(teavm_local_1, &ju_Calendar_Cls, &supertypeof_ju_Calendar))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1027, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_getTimeInMillis)(teavm_this_));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1028, teavm_checkcast(teavm_local_1, &ju_Calendar_Cls, &supertypeof_ju_Calendar));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_2 = ((teavm_local_3 <= TEAVM_WITH_CALL_SITE_ID(1029, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(1030, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getTimeInMillis)(teavm_tmp_ptr_0)))) ? INT32_C(0) : INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Calendar_before(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int64_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!teavm_instanceof(teavm_local_1, &ju_Calendar_Cls, &supertypeof_ju_Calendar))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1031, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_getTimeInMillis)(teavm_this_));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(1032, teavm_checkcast(teavm_local_1, &ju_Calendar_Cls, &supertypeof_ju_Calendar));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_2 = ((teavm_local_3 >= TEAVM_WITH_CALL_SITE_ID(1033, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(1034, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Calendar_VT, virt_getTimeInMillis)(teavm_tmp_ptr_0)))) ? INT32_C(0) : INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_ju_Calendar_clear(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = INT32_C(0);
    while (1) {
        if (!(teavm_local_1 < INT32_C(17))) break;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_fields);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1035, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1036, teavm_checkBounds(teavm_local_1, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_1) = INT32_C(0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isSet);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1037, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1038, teavm_checkUpperBound(teavm_local_1, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int8_t, teavm_local_1) = INT32_C(0);
        teavm_local_1 = (teavm_local_1 + INT32_C(1));
    }
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(0);
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Calendar_clone(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_TRY
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1039, meth_jl_Object_clone(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1040, teavm_checkcast(teavm_local_1, &ju_Calendar_Cls, &supertypeof_ju_Calendar));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_fields);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1041, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(1042, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1043, teavm_checkcast(teavm_local_1, &Arr_I_Cls, &supertypeof_Arr_I));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1044, teavm_nullCheck(teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_FIELD(teavm_local_2, cls_ju_Calendar, fld_fields) = teavm_local_3;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isSet);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1045, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(1046, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1047, teavm_checkcast(teavm_local_1, &Arr_Z_Cls, &supertypeof_Arr_Z));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_FIELD(teavm_local_2, cls_ju_Calendar, fld_isSet) = teavm_local_3;
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_zone);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1048, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(1049, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_TimeZone_VT, virt_clone)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1050, teavm_checkcast(teavm_local_1, &ju_TimeZone_Cls, &supertypeof_ju_TimeZone));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_FIELD(teavm_local_2, cls_ju_Calendar, fld_zone) = teavm_local_1;
        TEAVM_RESTORE_JUMP_BUFFER;
        goto teavm_label_1;
    TEAVM_CATCH
        // CATCH java.lang.CloneNotSupportedException
        case 1: {
            goto teavm_label_2;
            break;
        }
    TEAVM_END_TRY
teavm_label_2:;
    teavm_local_2 = NULL;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_ju_Calendar_complete(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((!TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet))) {
        TEAVM_WITH_CALL_SITE_ID(1051, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_computeTime)(teavm_this_));
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(1);
    }
    if ((!TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet))) {
        TEAVM_WITH_CALL_SITE_ID(1052, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_computeFields)(teavm_this_));
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(1);
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Calendar_get(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1053, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_complete)(teavm_this_));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_fields);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1054, teavm_nullCheck(teavm_local_2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1055, teavm_checkBounds(teavm_local_1, teavm_local_2));
    teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_1);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Calendar_getFirstDayOfWeek(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_firstDayOfWeek);
}
void* meth_ju_Calendar_getInstance() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1056, teavm_initializeClass((TeaVM_Class*) &ju_Calendar_Cls, &initclass_ju_Calendar));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1057, meth_otr_Allocator_allocate(&ju_GregorianCalendar_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(1058, meth_ju_GregorianCalendar__init_(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Calendar_getInstance_0(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1059, teavm_initializeClass((TeaVM_Class*) &ju_Calendar_Cls, &initclass_ju_Calendar));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1060, meth_otr_Allocator_allocate(&ju_GregorianCalendar_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(1061, meth_ju_GregorianCalendar__init__0(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Calendar_getMinimalDaysInFirstWeek(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_minimalDaysInFirstWeek);
}
void* meth_ju_Calendar_getTime(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1062, meth_otr_Allocator_allocate(&ju_Date_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(1063, meth_ju_Date__init_(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(1064, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_getTimeInMillis)(teavm_this_))));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int64_t meth_ju_Calendar_getTimeInMillis(void* teavm_this_) {
    int64_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((!TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet))) {
        TEAVM_WITH_CALL_SITE_ID(1065, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_computeTime)(teavm_this_));
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(1);
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_time);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Calendar_getTimeZone(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_zone);
}
void meth_ju_Calendar_setTimeZone(void* teavm_this_, void* teavm_local_1) {
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_zone) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(0);
}
int32_t meth_ju_Calendar_isLenient(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_lenient);
}
void meth_ju_Calendar_set(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_fields);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1066, teavm_nullCheck(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1067, teavm_checkBounds(teavm_local_1, teavm_local_3));
    TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_1) = teavm_local_2;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isSet);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1068, teavm_nullCheck(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1069, teavm_checkUpperBound(teavm_local_1, teavm_local_3));
    TEAVM_ARRAY_AT(teavm_local_3, int8_t, teavm_local_1) = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(0);
    if (((teavm_local_1 > INT32_C(2)) && (teavm_local_1 < INT32_C(9)))) {
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_lastDateFieldSet) = teavm_local_1;
    }
    if ((!((teavm_local_1 != INT32_C(10)) && (teavm_local_1 != INT32_C(11))))) {
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_lastTimeFieldSet) = teavm_local_1;
    }
    if ((teavm_local_1 == INT32_C(9))) {
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_lastTimeFieldSet) = INT32_C(10);
    }
    TEAVM_RELEASE_STACK;
}
void meth_ju_Calendar_setFirstDayOfWeek(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_firstDayOfWeek) = teavm_local_1;
}
void meth_ju_Calendar_setLenient(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_lenient) = teavm_local_1;
}
void meth_ju_Calendar_setMinimalDaysInFirstWeek(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_minimalDaysInFirstWeek) = teavm_local_1;
}
void meth_ju_Calendar_setTime(void* teavm_this_, void* teavm_local_1) {
    int64_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1070, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1071, TEAVM_METHOD(teavm_local_1, ju_Date_VT, virt_getTime)(teavm_local_1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(1072, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_setTimeInMillis)(teavm_this_, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_ju_Calendar_setTimeInMillis(void* teavm_this_, int64_t teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((!(TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) && (TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) && (TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_time) == teavm_local_1))))) {
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_time) = teavm_local_1;
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_isTimeSet) = INT32_C(1);
        TEAVM_FIELD(teavm_this_, cls_ju_Calendar, fld_areFieldsSet) = INT32_C(0);
        TEAVM_WITH_CALL_SITE_ID(1073, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_complete)(teavm_this_));
    }
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Calendar_compareTo(void* teavm_this_, void* teavm_local_1) {
    int64_t teavm_local_2;
    int64_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((NULL != teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(1074, TEAVM_METHOD(teavm_this_, ju_Calendar_VT, virt_getTimeInMillis)(teavm_this_));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(1075, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(1076, TEAVM_METHOD(teavm_local_1, ju_Calendar_VT, virt_getTimeInMillis)(teavm_local_1));
        teavm_local_4 = teavm_compare_i64(teavm_local_2, teavm_local_3);
        teavm_local_4 = ((teavm_local_4 > INT32_C(0)) ? INT32_C(1) : (teavm_local_4 ? -INT32_C(1) : INT32_C(0)));
        TEAVM_RELEASE_STACK;
        return teavm_local_4;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(1077, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(1078, meth_jl_NullPointerException__init_(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(1079, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void meth_ju_Calendar__clinit_() {
    TEAVM_ALLOC_STACK(INT32_C(0));
    sfld_ju_Calendar_fieldNames = TEAVM_WITH_CALL_SITE_ID(1080, teavm_fillArray(meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), 17), TEAVM_GET_STRING(72), TEAVM_GET_STRING(73), TEAVM_GET_STRING(74), TEAVM_GET_STRING(75), TEAVM_GET_STRING(76), TEAVM_GET_STRING(77), TEAVM_GET_STRING(78), TEAVM_GET_STRING(79), TEAVM_GET_STRING(80), TEAVM_GET_STRING(81), TEAVM_GET_STRING(82), TEAVM_GET_STRING(83), TEAVM_GET_STRING(84), TEAVM_GET_STRING(85), TEAVM_GET_STRING(86), TEAVM_GET_STRING(87), TEAVM_GET_STRING(88)));
    sfld_ju_Calendar_firstDayOfWeekCache = -INT32_C(1);
    sfld_ju_Calendar_minimalDaysInFirstWeekCache = -INT32_C(1);
    TEAVM_RELEASE_STACK;
}
void initclass_ju_Calendar() {
    TeaVM_Class* cls = (TeaVM_Class*) &ju_Calendar_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_ju_Calendar__clinit_();
    }
}
int32_t supertypeof_ju_Calendar(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 101 || tag >= 105) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Calendar_Cls[4];
alignas(8) ju_Calendar_VT ju_Calendar_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Calendar), sizeof(void*)),
        .flags = 0,
        .tag = 101,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_Calendar,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_Calendar_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_clone = &meth_ju_Calendar_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_get_2 = &meth_ju_Calendar_get,
    .virt_getMinimalDaysInFirstWeek = &meth_ju_Calendar_getMinimalDaysInFirstWeek,
    .virt_set_1 = &meth_ju_Calendar_set,
    .virt_setLenient = &meth_ju_Calendar_setLenient,
    .virt_setTimeInMillis = &meth_ju_Calendar_setTimeInMillis,
    .virt_getTimeZone = &meth_ju_Calendar_getTimeZone,
    .virt_setTimeZone = &meth_ju_Calendar_setTimeZone,
    .virt_clear = &meth_ju_Calendar_clear,
    .virt_after = &meth_ju_Calendar_after,
    .virt_complete = &meth_ju_Calendar_complete,
    .virt_getTimeInMillis = &meth_ju_Calendar_getTimeInMillis,
    .virt_getTime_0 = &meth_ju_Calendar_getTime,
    .virt_setTime = &meth_ju_Calendar_setTime,
    .virt_getFirstDayOfWeek = &meth_ju_Calendar_getFirstDayOfWeek,
    .virt_setFirstDayOfWeek = &meth_ju_Calendar_setFirstDayOfWeek,
    .virt_isLenient = &meth_ju_Calendar_isLenient,
    .virt_setMinimalDaysInFirstWeek = &meth_ju_Calendar_setMinimalDaysInFirstWeek,
    .virt_compareTo_2 = &meth_ju_Calendar_compareTo,
    .virt_before = &meth_ju_Calendar_before
};
static void** teavm_gc_localStaticRoots_ju_Calendar_Cls[2] = {
(void**) &sfld_ju_Calendar_fieldNames, (void**) &sfld_ju_Calendar_cacheFor
};
static int16_t teavm_classLayouts_ju_Calendar_Cls[4] = {
INT16_C(3), (int16_t) offsetof(cls_ju_Calendar, fld_fields), (int16_t) offsetof(cls_ju_Calendar, fld_isSet), (int16_t) offsetof(cls_ju_Calendar, fld_zone)
};
void sysinitclass_ju_Calendar() {
sfld_ju_Calendar_fieldNames = NULL;
sfld_ju_Calendar_firstDayOfWeekCache = INT32_C(0);
sfld_ju_Calendar_minimalDaysInFirstWeekCache = INT32_C(0);
sfld_ju_Calendar_cacheFor = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_ju_Calendar_Cls, 2);
}
