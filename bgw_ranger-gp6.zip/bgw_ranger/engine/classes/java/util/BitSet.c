#include "BitSet.h"
#include "../lang/Object.h"
#include "../../../arrays/primitives/int.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/NegativeArraySizeException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "../lang/Integer.h"
#include "../lang/Math.h"
#include "Arrays.h"
#include "../../../strings.h"

void meth_ju_BitSet__init_(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5589, meth_jl_Object__init_(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5590, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(2)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_ju_BitSet__init__0(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5591, meth_jl_Object__init_(teavm_this_));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5592, meth_otr_Allocator_allocateArray(&Arr_I_Cls, (((teavm_local_1 + INT32_C(32)) - INT32_C(1)) / INT32_C(32))));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data) = teavm_local_2;
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5593, meth_otr_Allocator_allocate(&jl_NegativeArraySizeException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(5594, meth_jl_NegativeArraySizeException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(5595, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void meth_ju_BitSet_set(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = (teavm_local_1 / INT32_C(32));
        if ((teavm_local_1 >= TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length))) {
            teavm_local_3 = (teavm_local_2 + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(5596, meth_ju_BitSet_ensureCapacity(teavm_this_, teavm_local_3));
            TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = (teavm_local_1 + INT32_C(1));
        }
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5597, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5598, teavm_checkBounds(teavm_local_2, teavm_local_4));
        TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_2) = (TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_2) | (INT32_C(1) << (teavm_local_1 % INT32_C(32))));
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5599, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(5600, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(5601, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void meth_ju_BitSet_set_0(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_3 = teavm_compare_i32(teavm_local_1, teavm_local_2);
        if ((teavm_local_3 <= INT32_C(0))) {
            if (teavm_local_3) {
                teavm_local_4 = (teavm_local_1 / INT32_C(32));
                teavm_local_5 = (teavm_local_2 / INT32_C(32));
                if ((teavm_local_2 > TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length))) {
                    teavm_local_3 = (teavm_local_5 + INT32_C(1));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_WITH_CALL_SITE_ID(5602, meth_ju_BitSet_ensureCapacity(teavm_this_, teavm_local_3));
                    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = teavm_local_2;
                }
                if ((teavm_local_4 == teavm_local_5)) {
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5603, teavm_nullCheck(teavm_local_6));
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5604, teavm_checkBounds(teavm_local_4, teavm_local_6));
                    TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) | (TEAVM_WITH_CALL_SITE_ID(5605, meth_ju_BitSet_trailingZeroBits(teavm_this_, teavm_local_1)) & TEAVM_WITH_CALL_SITE_ID(5606, meth_ju_BitSet_trailingOneBits(teavm_this_, teavm_local_2))));
                } else {
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5607, teavm_nullCheck(teavm_local_6));
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5608, teavm_checkBounds(teavm_local_4, teavm_local_6));
                    TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) | TEAVM_WITH_CALL_SITE_ID(5609, meth_ju_BitSet_trailingZeroBits(teavm_this_, teavm_local_1)));
                    teavm_local_7 = (teavm_local_4 + INT32_C(1));
                    while (1) {
                        if (!(teavm_local_7 < teavm_local_5)) break;
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5610, teavm_nullCheck(teavm_local_6));
                        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5611, teavm_checkBounds(teavm_local_7, teavm_local_6));
                        TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_7) = -INT32_C(1);
                        teavm_local_7 = (teavm_local_7 + INT32_C(1));
                    }
                    if ((teavm_local_2 & INT32_C(31))) {
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5612, teavm_nullCheck(teavm_local_6));
                        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5613, teavm_checkBounds(teavm_local_5, teavm_local_6));
                        TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_5) = (TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_5) | TEAVM_WITH_CALL_SITE_ID(5614, meth_ju_BitSet_trailingOneBits(teavm_this_, teavm_local_2)));
                    }
                }
            }
            TEAVM_RELEASE_STACK;
            return;
        }
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5615, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(5616, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(5617, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_BitSet_trailingZeroBits(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    teavm_local_2 = (teavm_local_1 % INT32_C(32));
    return (-INT32_C(1) << teavm_local_2);
}
int32_t meth_ju_BitSet_trailingOneBits(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    teavm_local_2 = (teavm_local_1 % INT32_C(32));
    return ((!teavm_local_2) ? INT32_C(0) : ((int32_t) ((uint32_t) -INT32_C(1) >> (INT32_C(32) - teavm_local_2))));
}
void meth_ju_BitSet_clear(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = (teavm_local_1 / INT32_C(32));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5618, teavm_nullCheck(teavm_local_3))))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5619, teavm_nullCheck(teavm_local_3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5620, teavm_checkBounds(teavm_local_2, teavm_local_3));
            TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2) = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2) & TEAVM_WITH_CALL_SITE_ID(5621, meth_jl_Integer_rotateLeft(-INT32_C(2), (teavm_local_1 % INT32_C(32)))));
            if ((teavm_local_1 == (TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) - INT32_C(1)))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(5622, meth_ju_BitSet_recalculateLength(teavm_this_));
            }
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5623, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_WITH_CALL_SITE_ID(5624, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(5625, meth_otr_ExceptionHandling_throwException(teavm_local_4));
    TEAVM_UNREACHABLE
}
void meth_ju_BitSet_clear_0(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= teavm_local_2))) {
        if ((teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5626, meth_jl_Math_min(teavm_local_3, teavm_local_2));
            if ((teavm_local_1 != teavm_local_3)) {
                teavm_local_4 = (teavm_local_1 / INT32_C(32));
                teavm_local_5 = (teavm_local_3 / INT32_C(32));
                if ((teavm_local_4 == teavm_local_5)) {
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5627, teavm_nullCheck(teavm_local_6));
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5628, teavm_checkBounds(teavm_local_4, teavm_local_6));
                    TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) & (TEAVM_WITH_CALL_SITE_ID(5629, meth_ju_BitSet_trailingOneBits(teavm_this_, teavm_local_1)) | TEAVM_WITH_CALL_SITE_ID(5630, meth_ju_BitSet_trailingZeroBits(teavm_this_, teavm_local_3))));
                } else {
                    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5631, teavm_nullCheck(teavm_local_6));
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5632, teavm_checkBounds(teavm_local_4, teavm_local_6));
                    TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_4) & TEAVM_WITH_CALL_SITE_ID(5633, meth_ju_BitSet_trailingOneBits(teavm_this_, teavm_local_1)));
                    teavm_local_7 = (teavm_local_4 + INT32_C(1));
                    while (1) {
                        if (!(teavm_local_7 < teavm_local_5)) break;
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5634, teavm_nullCheck(teavm_local_6));
                        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5635, teavm_checkBounds(teavm_local_7, teavm_local_6));
                        TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_7) = INT32_C(0);
                        teavm_local_7 = (teavm_local_7 + INT32_C(1));
                    }
                    if ((teavm_local_3 & INT32_C(31))) {
                        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5636, teavm_nullCheck(teavm_local_6));
                        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5637, teavm_checkBounds(teavm_local_5, teavm_local_6));
                        TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_5) = (TEAVM_ARRAY_AT(teavm_local_6, int32_t, teavm_local_5) & TEAVM_WITH_CALL_SITE_ID(5638, meth_ju_BitSet_trailingZeroBits(teavm_this_, teavm_local_3)));
                    }
                }
                TEAVM_WITH_CALL_SITE_ID(5639, meth_ju_BitSet_recalculateLength(teavm_this_));
            }
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(5640, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(5641, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(5642, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_BitSet_get(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = (teavm_local_1 / INT32_C(32));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5643, teavm_nullCheck(teavm_local_3))))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5644, teavm_nullCheck(teavm_local_3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5645, teavm_checkBounds(teavm_local_2, teavm_local_3));
            if ((TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2) & (INT32_C(1) << (teavm_local_1 % INT32_C(32))))) {
                goto teavm_label_2;
            }
        }
        teavm_local_4 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_4 = INT32_C(1);
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_4;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5646, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(5647, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_5));
    TEAVM_WITH_CALL_SITE_ID(5648, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_BitSet_nextSetBit(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        if ((teavm_local_1 >= TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length))) {
            teavm_local_2 = -INT32_C(1);
        } else {
            teavm_local_3 = (teavm_local_1 / INT32_C(32));
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5649, teavm_nullCheck(teavm_local_4));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5650, teavm_checkBounds(teavm_local_3, teavm_local_4));
            teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_3);
            teavm_local_2 = ((int32_t) ((uint32_t) teavm_local_5 >> (teavm_local_1 % INT32_C(32))));
            if (teavm_local_2) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_2 = (TEAVM_WITH_CALL_SITE_ID(5651, meth_jl_Integer_numberOfTrailingZeros(teavm_local_2)) + teavm_local_1);
            } else {
                teavm_local_6 = ((TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) + INT32_C(31)) / INT32_C(32));
                teavm_local_7 = (teavm_local_3 + INT32_C(1));
                while (1) {
                    if (!(teavm_local_7 < teavm_local_6)) break;
                    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5652, teavm_nullCheck(teavm_local_4));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5653, teavm_checkBounds(teavm_local_7, teavm_local_4));
                    if (TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_7)) {
                        goto teavm_label_2;
                    }
                    teavm_local_7 = (teavm_local_7 + INT32_C(1));
                }
                teavm_local_2 = -INT32_C(1);
                goto teavm_label_1;
            teavm_label_2:;
                teavm_local_2 = (teavm_local_7 * INT32_C(32));
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5654, teavm_nullCheck(teavm_local_4));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5655, teavm_checkUpperBound(teavm_local_7, teavm_local_4));
                teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_7);
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_2 = (teavm_local_2 + TEAVM_WITH_CALL_SITE_ID(5656, meth_jl_Integer_numberOfTrailingZeros(teavm_local_8)));
            }
        }
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_2;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(5657, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(5658, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_9));
    TEAVM_WITH_CALL_SITE_ID(5659, meth_otr_ExceptionHandling_throwException(teavm_local_9));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_BitSet_nextClearBit(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        if ((teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length))) {
            teavm_local_2 = (teavm_local_1 / INT32_C(32));
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5660, teavm_nullCheck(teavm_local_3));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5661, teavm_checkBounds(teavm_local_2, teavm_local_3));
            teavm_local_4 = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2) ^ -INT32_C(1));
            teavm_local_5 = ((int32_t) ((uint32_t) teavm_local_4 >> (teavm_local_1 % INT32_C(32))));
            if (teavm_local_5) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_1 = (TEAVM_WITH_CALL_SITE_ID(5662, meth_jl_Integer_numberOfTrailingZeros(teavm_local_5)) + teavm_local_1);
            } else {
                teavm_local_6 = ((TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) + INT32_C(31)) / INT32_C(32));
                teavm_local_7 = (teavm_local_2 + INT32_C(1));
                while (1) {
                    if (!(teavm_local_7 < teavm_local_6)) break;
                    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5663, teavm_nullCheck(teavm_local_3));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5664, teavm_checkBounds(teavm_local_7, teavm_local_3));
                    if ((TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_7) != -INT32_C(1))) {
                        goto teavm_label_2;
                    }
                    teavm_local_7 = (teavm_local_7 + INT32_C(1));
                }
                teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length);
                goto teavm_label_1;
            teavm_label_2:;
                teavm_local_5 = (teavm_local_7 * INT32_C(32));
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5665, teavm_nullCheck(teavm_local_3));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5666, teavm_checkUpperBound(teavm_local_7, teavm_local_3));
                teavm_local_8 = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_7) ^ -INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_1 = (teavm_local_5 + TEAVM_WITH_CALL_SITE_ID(5667, meth_jl_Integer_numberOfTrailingZeros(teavm_local_8)));
            }
        }
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(5668, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(5669, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_9));
    TEAVM_WITH_CALL_SITE_ID(5670, meth_otr_ExceptionHandling_throwException(teavm_local_9));
    TEAVM_UNREACHABLE
}
void meth_ju_BitSet_ensureCapacity(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5671, teavm_nullCheck(teavm_local_2))) < teavm_local_1)) {
        teavm_local_3 = ((teavm_local_1 * INT32_C(3)) / INT32_C(2));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_4 = ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5672, teavm_nullCheck(teavm_local_2))) * INT32_C(2)) + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5673, meth_jl_Math_max(teavm_local_3, teavm_local_4));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5674, meth_ju_Arrays_copyOf_2(teavm_local_2, teavm_local_5));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data) = teavm_local_2;
    }
    TEAVM_RELEASE_STACK;
}
void meth_ju_BitSet_recalculateLength(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = ((TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) + INT32_C(31)) / INT32_C(32));
    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = (teavm_local_1 * INT32_C(32));
    teavm_local_2 = (teavm_local_1 - INT32_C(1));
    while (1) {
        if ((teavm_local_2 < INT32_C(0))) {
            goto teavm_label_1;
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(5675, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5676, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5677, meth_jl_Integer_numberOfLeadingZeros(teavm_local_4));
        if ((teavm_local_5 < INT32_C(32))) {
            goto teavm_label_2;
        }
        teavm_local_2 = (teavm_local_2 + -INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = (TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) - INT32_C(32));
    }
teavm_label_2:;
    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = (TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) - teavm_local_5);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_BitSet_intersects(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5678, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5679, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5680, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5681, meth_jl_Math_min(teavm_local_3, teavm_local_4));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_5)) break;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5682, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5683, teavm_checkBounds(teavm_local_6, teavm_local_2));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6);
        teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5684, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5685, teavm_checkUpperBound(teavm_local_6, teavm_local_2));
        if ((teavm_local_3 & TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6))) {
            goto teavm_label_2;
        }
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    teavm_local_3 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_ju_BitSet_and(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5686, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5687, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5688, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5689, meth_jl_Math_min(teavm_local_3, teavm_local_4));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_5)) break;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5690, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5691, teavm_checkBounds(teavm_local_6, teavm_local_2));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6);
        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5692, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5693, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6) = (teavm_local_3 & TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    while (1) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        if ((teavm_local_5 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5694, teavm_nullCheck(teavm_local_2))))) {
            goto teavm_label_2;
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5695, teavm_nullCheck(teavm_local_2));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5696, teavm_checkBounds(teavm_local_5, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_5) = INT32_C(0);
        teavm_local_5 = (teavm_local_5 + INT32_C(1));
    }
teavm_label_2:;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length);
    teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_length);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = TEAVM_WITH_CALL_SITE_ID(5697, meth_jl_Math_min(teavm_local_3, teavm_local_4));
    TEAVM_WITH_CALL_SITE_ID(5698, meth_ju_BitSet_recalculateLength(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_ju_BitSet_andNot(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5699, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5700, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_4 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5701, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5702, meth_jl_Math_min(teavm_local_3, teavm_local_4));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_5)) break;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5703, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5704, teavm_checkBounds(teavm_local_6, teavm_local_7));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
        teavm_local_2 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5705, teavm_nullCheck(teavm_local_2));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5706, teavm_checkUpperBound(teavm_local_6, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6) = (teavm_local_3 & (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_6) ^ -INT32_C(1)));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5707, meth_ju_BitSet_recalculateLength(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void meth_ju_BitSet_or(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5708, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_length);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = TEAVM_WITH_CALL_SITE_ID(5709, meth_jl_Math_max(teavm_local_2, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(5710, meth_ju_BitSet_ensureCapacity(teavm_this_, ((TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) + INT32_C(31)) / INT32_C(32))));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5711, teavm_nullCheck(teavm_local_4)));
    teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5712, teavm_nullCheck(teavm_local_4)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5713, meth_jl_Math_min(teavm_local_2, teavm_local_3));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_5)) break;
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5714, teavm_nullCheck(teavm_local_4));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5715, teavm_checkBounds(teavm_local_6, teavm_local_4));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_6);
        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5716, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5717, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_6) = (teavm_local_3 | TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
void meth_ju_BitSet_xor(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5718, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_length);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) = TEAVM_WITH_CALL_SITE_ID(5719, meth_jl_Math_max(teavm_local_2, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(5720, meth_ju_BitSet_ensureCapacity(teavm_this_, ((TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) + INT32_C(31)) / INT32_C(32))));
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5721, teavm_nullCheck(teavm_local_4)));
    teavm_local_4 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_3 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(5722, teavm_nullCheck(teavm_local_4)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(5723, meth_jl_Math_min(teavm_local_2, teavm_local_3));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_5)) break;
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(5724, teavm_nullCheck(teavm_local_4));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5725, teavm_checkBounds(teavm_local_6, teavm_local_4));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_6);
        teavm_local_7 = TEAVM_FIELD(teavm_local_1, cls_ju_BitSet, fld_data);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(5726, teavm_nullCheck(teavm_local_7));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(5727, teavm_checkUpperBound(teavm_local_6, teavm_local_7));
        TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_6) = (teavm_local_3 ^ TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6));
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5728, meth_ju_BitSet_recalculateLength(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_BitSet_isEmpty(void* teavm_this_) {
    return (TEAVM_FIELD(teavm_this_, cls_ju_BitSet, fld_length) ? INT32_C(0) : INT32_C(1));
}
int32_t supertypeof_ju_BitSet(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 259 || tag >= 261) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_BitSet_Cls[2];
alignas(8) ju_BitSet_VT ju_BitSet_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_BitSet), sizeof(void*)),
        .flags = 0,
        .tag = 259,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_BitSet,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_BitSet_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_intersects = &meth_ju_BitSet_intersects,
    .virt_and = &meth_ju_BitSet_and,
    .virt_set_1 = &meth_ju_BitSet_set_0,
    .virt_isEmpty = &meth_ju_BitSet_isEmpty,
    .virt_xor = &meth_ju_BitSet_xor,
    .virt_or = &meth_ju_BitSet_or,
    .virt_get_7 = &meth_ju_BitSet_get,
    .virt_clear_1 = &meth_ju_BitSet_clear_0,
    .virt_andNot = &meth_ju_BitSet_andNot,
    .virt_nextClearBit = &meth_ju_BitSet_nextClearBit,
    .virt_set_3 = &meth_ju_BitSet_set,
    .virt_nextSetBit = &meth_ju_BitSet_nextSetBit,
    .virt_clear_2 = &meth_ju_BitSet_clear
};
static int16_t teavm_classLayouts_ju_BitSet_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_BitSet, fld_data)
};
void sysinitclass_ju_BitSet() {
}
