#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Collections.h"

extern void sysinitclass_ju_Collections();
typedef struct cls_ju_Collections {
    struct TeaVM_Object parent;
} cls_ju_Collections;
extern void* sfld_ju_Collections_EMPTY_SET;
extern void* sfld_ju_Collections_EMPTY_MAP;
extern void* sfld_ju_Collections_EMPTY_LIST;
extern void* sfld_ju_Collections_EMPTY_ITERATOR;
extern void* sfld_ju_Collections_EMPTY_LIST_ITERATOR;
extern void* sfld_ju_Collections_reverseOrder;
extern void* meth_ju_Collections_emptyIterator();
extern void* meth_ju_Collections_emptyListIterator();
extern void* meth_ju_Collections_emptyList();
extern void* meth_ju_Collections_emptySet();
extern void* meth_ju_Collections_emptyMap();
extern void* meth_ju_Collections_singletonList(void*);
extern void* meth_ju_Collections_singleton(void*);
extern void meth_ju_Collections_sort_0(void*, void*);
extern void meth_ju_Collections_sort(void*);
extern void meth_ju_Collections_reverse(void*);
extern void meth_ju_Collections_reverse_0(void*, int32_t, int32_t);
extern void* meth_ju_Collections_unmodifiableList(void*);
extern void* meth_ju_Collections_unmodifiableIterator(void*);
extern void* meth_ju_Collections_unmodifiableSet(void*);
extern void* meth_ju_Collections_unmodifiableMap(void*);
extern void* meth_ju_Collections_unmodifiableMapEntrySet(void*);
extern void* meth_ju_Collections_unmodifiableMapEntryIterator(void*);
extern void* meth_ju_Collections_synchronizedMap(void*);
extern int32_t meth_ju_Collections_disjoint(void*, void*);
extern void meth_ju_Collections__clinit_();
extern void initclass_ju_Collections();
extern int32_t supertypeof_ju_Collections(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_VT {
    jl_Object_VT parent;
} ju_Collections_VT;
extern ju_Collections_VT ju_Collections_Cls;
