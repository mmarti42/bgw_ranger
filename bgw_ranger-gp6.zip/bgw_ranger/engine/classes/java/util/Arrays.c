#include "Arrays.h"
#include "../lang/Object.h"
#include "../../../arrays/primitives/char.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Math.h"
#include "../../../arrays/primitives/byte.h"
#include "../../../arrays/primitives/int.h"
#include "../../../arrays/primitives/long.h"
#include "../../../arrays/primitives/float.h"
#include "../../../arrays/primitives/double.h"
#include "../lang/Class.h"
#include "../lang/reflect/Array.h"
#include "../../../arrayclass.h"
#include "../../../strings.h"
#include "../lang/StringBuilder.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Comparator@dNaturalOrder.h"
#include "Comparator.h"
#include "../lang/Double.h"
#include "Objects.h"
#include "../lang/Integer.h"
#include "Arrays@dArrayAsList.h"

TeaVM_Array* meth_ju_Arrays_copyOf_1(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26647, meth_otr_Allocator_allocateArray(&Arr_C_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26648, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26649, meth_jl_Math_min(teavm_local_2, teavm_local_5));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26650, teavm_checkBounds(teavm_local_7, teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, char16_t, teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26651, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, char16_t, teavm_local_7) = teavm_local_5;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_ju_Arrays_copyOf_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26652, meth_otr_Allocator_allocateArray(&Arr_B_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26653, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26654, meth_jl_Math_min(teavm_local_2, teavm_local_5));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26655, teavm_checkBounds(teavm_local_7, teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, int8_t, teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26656, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, int8_t, teavm_local_7) = teavm_local_5;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_ju_Arrays_copyOf_2(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26657, meth_otr_Allocator_allocateArray(&Arr_I_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26658, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26659, meth_jl_Math_min(teavm_local_2, teavm_local_5));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26660, teavm_checkBounds(teavm_local_7, teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26661, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, int32_t, teavm_local_7) = teavm_local_5;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_ju_Arrays_copyOf_3(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int64_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26662, meth_otr_Allocator_allocateArray(&Arr_J_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26663, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26664, meth_jl_Math_min(teavm_local_2, teavm_local_5));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26665, teavm_checkBounds(teavm_local_7, teavm_local_4));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_4, int64_t, teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26666, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, int64_t, teavm_local_7) = teavm_local_9;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_ju_Arrays_copyOf_4(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    float teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26667, meth_otr_Allocator_allocateArray(&Arr_F_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26668, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26669, meth_jl_Math_min(teavm_local_2, teavm_local_5));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26670, teavm_checkBounds(teavm_local_7, teavm_local_4));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_4, float, teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26671, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, float, teavm_local_7) = teavm_local_9;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_ju_Arrays_copyOf_5(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    double teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26672, meth_otr_Allocator_allocateArray(&Arr_D_Cls, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26673, teavm_nullCheck(teavm_local_1));
    teavm_local_4 = teavm_local_1;
    teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26674, meth_jl_Math_min(teavm_local_2, teavm_local_5));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        teavm_local_8 = teavm_local_3;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26675, teavm_checkBounds(teavm_local_7, teavm_local_4));
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_4, double, teavm_local_7);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26676, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        TEAVM_ARRAY_AT(teavm_local_8, double, teavm_local_7) = teavm_local_9;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
TeaVM_Array* meth_ju_Arrays_copyOf(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26677, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = teavm_local_1;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26678, meth_jl_Object_getClass(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26679, meth_jl_Class_getComponentType(TEAVM_WITH_CALL_SITE_ID(26680, teavm_nullCheck(teavm_local_4))));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26681, meth_jlr_Array_newInstance(teavm_local_4, teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26682, teavm_checkcast(teavm_local_4, teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), &teavm_isSupertypeOfArray));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26683, meth_jl_Math_min(teavm_local_2, TEAVM_ARRAY_LENGTH(teavm_local_3)));
    teavm_local_7 = INT32_C(0);
    while (1) {
        if (!(teavm_local_7 < teavm_local_6)) break;
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26684, teavm_checkBounds(teavm_local_7, teavm_local_3));
        teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(26685, teavm_nullCheck(teavm_local_5));
        teavm_local_8 = teavm_local_5;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26686, teavm_checkUpperBound(teavm_local_7, teavm_local_8));
        teavm_gc_writeBarrier(teavm_local_8);
        TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_7) = teavm_local_4;
        teavm_local_7 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_ju_Arrays_toString(TeaVM_Array* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = TEAVM_GET_STRING(498);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26687, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(26688, meth_jl_StringBuilder__init_(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(26689, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(7031)));
        teavm_local_4 = INT32_C(0);
        while (1) {
            teavm_local_5 = teavm_local_1;
            if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(teavm_local_5))) {
                goto teavm_label_1;
            }
            if ((teavm_local_4 > INT32_C(0))) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                TEAVM_WITH_CALL_SITE_ID(26690, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(648)));
            }
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26691, teavm_checkLowerBound(teavm_local_4));
            teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(26692, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_1)(teavm_local_3, teavm_local_2));
            teavm_local_4 = (teavm_local_4 + INT32_C(1));
        }
    teavm_label_1:;
        TEAVM_WITH_CALL_SITE_ID(26693, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(95)));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26694, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_toString)(teavm_local_3));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_ju_Arrays_fill(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        while (1) {
            if (!(teavm_local_2 < teavm_local_3)) break;
            teavm_local_5 = (teavm_local_2 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26695, teavm_nullCheck(teavm_local_1));
            teavm_local_6 = teavm_local_1;
            TEAVM_ARRAY_AT(teavm_local_6, int32_t, TEAVM_WITH_CALL_SITE_ID(26696, teavm_checkBounds(teavm_local_2, teavm_local_6))) = teavm_local_4;
            teavm_local_2 = teavm_local_5;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26697, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(26698, meth_jl_IllegalArgumentException__init_(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(26699, meth_otr_ExceptionHandling_throwException(teavm_local_7));
    TEAVM_UNREACHABLE
}
void meth_ju_Arrays_fill_1(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26700, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(26701, meth_ju_Arrays_fill(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_ju_Arrays_fill_3(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        while (1) {
            if (!(teavm_local_2 < teavm_local_3)) break;
            teavm_local_5 = (teavm_local_2 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26702, teavm_nullCheck(teavm_local_1));
            teavm_local_6 = teavm_local_1;
            TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(26703, teavm_checkBounds(teavm_local_2, teavm_local_6))) = teavm_local_4;
            teavm_local_2 = teavm_local_5;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26704, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(26705, meth_jl_IllegalArgumentException__init_(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(26706, meth_otr_ExceptionHandling_throwException(teavm_local_7));
    TEAVM_UNREACHABLE
}
void meth_ju_Arrays_fill_4(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26707, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(26708, meth_ju_Arrays_fill_3(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_ju_Arrays_fill_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        while (1) {
            if (!(teavm_local_2 < teavm_local_3)) break;
            teavm_local_5 = (teavm_local_2 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26709, teavm_nullCheck(teavm_local_1));
            teavm_local_6 = teavm_local_1;
            TEAVM_ARRAY_AT(teavm_local_6, int8_t, TEAVM_WITH_CALL_SITE_ID(26710, teavm_checkBounds(teavm_local_2, teavm_local_6))) = teavm_local_4;
            teavm_local_2 = teavm_local_5;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26711, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
    TEAVM_WITH_CALL_SITE_ID(26712, meth_jl_IllegalArgumentException__init_(teavm_local_7));
    TEAVM_WITH_CALL_SITE_ID(26713, meth_otr_ExceptionHandling_throwException(teavm_local_7));
    TEAVM_UNREACHABLE
}
void meth_ju_Arrays_fill_5(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        while (1) {
            if (!(teavm_local_2 < teavm_local_3)) break;
            teavm_local_5 = (teavm_local_2 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26714, teavm_nullCheck(teavm_local_1));
            teavm_local_6 = teavm_local_1;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26715, teavm_checkBounds(teavm_local_2, teavm_local_6));
            teavm_gc_writeBarrier(teavm_local_6);
            TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_7) = teavm_local_4;
            teavm_local_2 = teavm_local_5;
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26716, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
    TEAVM_WITH_CALL_SITE_ID(26717, meth_jl_IllegalArgumentException__init_(teavm_local_8));
    TEAVM_WITH_CALL_SITE_ID(26718, meth_otr_ExceptionHandling_throwException(teavm_local_8));
    TEAVM_UNREACHABLE
}
void meth_ju_Arrays_fill_2(TeaVM_Array* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26719, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(26720, meth_ju_Arrays_fill_5(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_ju_Arrays_sort_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, void* teavm_local_4) {
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    TeaVM_Array* teavm_local_9;
    void* teavm_local_10;
    int32_t teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((teavm_local_2 <= teavm_local_3)) {
        if ((teavm_local_4 == NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(3));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26721, meth_ju_Comparator_NaturalOrder_instance());
        }
        teavm_local_5 = (teavm_local_3 - teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26722, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), teavm_local_5));
        teavm_local_7 = teavm_local_2;
        while (1) {
            if (!(teavm_local_7 < teavm_local_3)) break;
            teavm_local_8 = teavm_local_6;
            teavm_local_5 = (teavm_local_7 - teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26723, teavm_nullCheck(teavm_local_1));
            teavm_local_9 = teavm_local_1;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26724, teavm_checkBounds(teavm_local_7, teavm_local_9));
            teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_7);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_10);
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(26725, teavm_checkBounds(teavm_local_5, teavm_local_8));
            teavm_gc_writeBarrier(teavm_local_8);
            TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_11) = teavm_local_10;
            teavm_local_7 = (teavm_local_7 + INT32_C(1));
        }
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(26726, meth_ju_Arrays_sort(teavm_local_6, teavm_local_4));
        teavm_local_7 = teavm_local_2;
        while (1) {
            if (!(teavm_local_7 < teavm_local_3)) break;
            teavm_local_9 = teavm_local_6;
            teavm_local_5 = (teavm_local_7 - teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
            teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_9, void*, TEAVM_WITH_CALL_SITE_ID(26727, teavm_checkBounds(teavm_local_5, teavm_local_9)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26728, teavm_nullCheck(teavm_local_1));
            teavm_local_9 = teavm_local_1;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26729, teavm_checkBounds(teavm_local_7, teavm_local_9));
            teavm_gc_writeBarrier(teavm_local_9);
            TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_7) = teavm_local_10;
            teavm_local_7 = (teavm_local_7 + INT32_C(1));
        }
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26730, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(26731, meth_jl_IllegalArgumentException__init_(teavm_local_10));
    TEAVM_WITH_CALL_SITE_ID(26732, meth_otr_ExceptionHandling_throwException(teavm_local_10));
    TEAVM_UNREACHABLE
}
void meth_ju_Arrays_sort(TeaVM_Array* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    TeaVM_Array* teavm_local_12;
    TeaVM_Array* teavm_local_13;
    void* teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26733, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    if (teavm_local_3) {
        if ((teavm_local_2 == NULL)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26734, meth_ju_Comparator_NaturalOrder_instance());
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26735, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), teavm_local_3));
        teavm_local_5 = INT32_C(1);
        teavm_local_6 = teavm_local_1;
        while (1) {
            if (!(teavm_local_5 < teavm_local_3)) break;
            teavm_local_7 = INT32_C(0);
            while (1) {
                teavm_local_8 = TEAVM_ARRAY_LENGTH(teavm_local_6);
                if ((teavm_local_7 >= teavm_local_8)) {
                    goto teavm_label_2;
                }
                teavm_local_9 = (teavm_local_7 + teavm_local_5);
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26736, meth_jl_Math_min(teavm_local_8, teavm_local_9));
                teavm_local_10 = (teavm_local_7 + (INT32_C(2) * teavm_local_5));
                teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(26737, meth_jl_Math_min(teavm_local_8, teavm_local_10));
                TEAVM_WITH_CALL_SITE_ID(26738, meth_ju_Arrays_merge(teavm_local_6, teavm_local_4, teavm_local_7, teavm_local_9, teavm_local_11, teavm_local_2));
                teavm_local_7 = teavm_local_10;
            }
        teavm_label_2:;
            teavm_local_5 = (teavm_local_5 * INT32_C(2));
            teavm_local_12 = teavm_local_6;
            teavm_local_6 = teavm_local_4;
            teavm_local_4 = teavm_local_12;
        }
        if ((teavm_local_6 != teavm_local_1)) {
            teavm_local_10 = INT32_C(0);
            while (1) {
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_4);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26739, teavm_nullCheck(teavm_local_6));
                teavm_local_12 = teavm_local_6;
                if ((teavm_local_10 >= TEAVM_ARRAY_LENGTH(teavm_local_12))) {
                    goto teavm_label_3;
                }
                teavm_local_13 = teavm_local_4;
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26740, teavm_checkLowerBound(teavm_local_10));
                teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_12, void*, teavm_local_10);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
                teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26741, teavm_checkUpperBound(teavm_local_10, teavm_local_13));
                teavm_gc_writeBarrier(teavm_local_13);
                TEAVM_ARRAY_AT(teavm_local_13, void*, teavm_local_10) = teavm_local_14;
                teavm_local_10 = (teavm_local_10 + INT32_C(1));
            }
        }
    teavm_label_3:;
    }
    TEAVM_RELEASE_STACK;
}
void meth_ju_Arrays_merge(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5, void* teavm_local_6) {
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    int32_t teavm_local_13;
    void* teavm_local_14;
    TEAVM_ALLOC_STACK(INT32_C(5));
    teavm_local_7 = teavm_local_3;
    teavm_local_8 = teavm_local_4;
    while (1) {
        if (!(teavm_local_3 != teavm_local_4)) break;
        if ((teavm_local_8 == teavm_local_5)) {
            goto teavm_label_2;
        }
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(4), teavm_local_6);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26742, teavm_nullCheck(teavm_local_1));
        teavm_local_9 = teavm_local_1;
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26743, teavm_checkBounds(teavm_local_3, teavm_local_9));
        teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(26744, teavm_checkBounds(teavm_local_8, teavm_local_9));
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26745, teavm_nullCheck(teavm_local_6));
        if ((TEAVM_WITH_CALL_SITE_ID(26746, TEAVM_METHOD(teavm_local_6, ju_Comparator_VT, virt_compare)(teavm_local_6, teavm_local_10, teavm_local_11)) > INT32_C(0))) {
            teavm_local_12 = (teavm_local_7 + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26747, teavm_nullCheck(teavm_local_2));
            teavm_local_9 = teavm_local_2;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26748, teavm_checkBounds(teavm_local_7, teavm_local_9));
            teavm_gc_writeBarrier(teavm_local_9);
            TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_7) = teavm_local_11;
            teavm_local_8 = (teavm_local_8 + INT32_C(1));
        } else {
            teavm_local_12 = (teavm_local_7 + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26749, teavm_nullCheck(teavm_local_2));
            teavm_local_9 = teavm_local_2;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26750, teavm_checkBounds(teavm_local_7, teavm_local_9));
            teavm_gc_writeBarrier(teavm_local_9);
            TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_7) = teavm_local_10;
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
        teavm_local_7 = teavm_local_12;
    }
    while (1) {
        if ((teavm_local_8 >= teavm_local_5)) {
            goto teavm_label_1;
        }
        teavm_local_12 = (teavm_local_7 + INT32_C(1));
        teavm_local_13 = (teavm_local_8 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26751, teavm_nullCheck(teavm_local_1));
        teavm_local_9 = teavm_local_1;
        teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_9, void*, TEAVM_WITH_CALL_SITE_ID(26752, teavm_checkBounds(teavm_local_8, teavm_local_9)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26753, teavm_nullCheck(teavm_local_2));
        teavm_local_9 = teavm_local_2;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26754, teavm_checkBounds(teavm_local_7, teavm_local_9));
        teavm_gc_writeBarrier(teavm_local_9);
        TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_7) = teavm_local_14;
        teavm_local_7 = teavm_local_12;
        teavm_local_8 = teavm_local_13;
    }
teavm_label_2:;
    while (1) {
        if ((teavm_local_3 >= teavm_local_4)) {
            goto teavm_label_1;
        }
        teavm_local_13 = (teavm_local_7 + INT32_C(1));
        teavm_local_12 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(4));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26755, teavm_nullCheck(teavm_local_1));
        teavm_local_9 = teavm_local_1;
        teavm_local_14 = TEAVM_ARRAY_AT(teavm_local_9, void*, TEAVM_WITH_CALL_SITE_ID(26756, teavm_checkBounds(teavm_local_3, teavm_local_9)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_14);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26757, teavm_nullCheck(teavm_local_2));
        teavm_local_9 = teavm_local_2;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(26758, teavm_checkBounds(teavm_local_7, teavm_local_9));
        teavm_gc_writeBarrier(teavm_local_9);
        TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_7) = teavm_local_14;
        teavm_local_7 = teavm_local_13;
        teavm_local_3 = teavm_local_12;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Arrays_binarySearch_1(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26759, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26760, meth_ju_Arrays_binarySearch_2(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_Arrays_binarySearch_2(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    void* teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        teavm_local_5 = (teavm_local_3 - INT32_C(1));
        while (1) {
            if ((teavm_local_2 > teavm_local_5)) {
                goto teavm_label_2;
            }
            teavm_local_6 = ((teavm_local_2 + teavm_local_5) / INT32_C(2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26761, teavm_nullCheck(teavm_local_1));
            teavm_local_7 = teavm_local_1;
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26762, teavm_checkBounds(teavm_local_6, teavm_local_7));
            teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, int32_t, teavm_local_6);
            if ((teavm_local_8 == teavm_local_4)) {
                goto teavm_label_3;
            }
            if ((teavm_local_4 >= teavm_local_8)) {
                teavm_local_2 = (teavm_local_6 + INT32_C(1));
            } else {
                teavm_local_5 = (teavm_local_6 - INT32_C(1));
            }
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_6 = ((-teavm_local_2) - INT32_C(1));
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_6;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(26763, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
    TEAVM_WITH_CALL_SITE_ID(26764, meth_jl_IllegalArgumentException__init_(teavm_local_9));
    TEAVM_WITH_CALL_SITE_ID(26765, meth_otr_ExceptionHandling_throwException(teavm_local_9));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Arrays_binarySearch(TeaVM_Array* teavm_local_1, int64_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26766, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26767, meth_ju_Arrays_binarySearch_3(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_Arrays_binarySearch_3(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int64_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int64_t teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        teavm_local_5 = (teavm_local_3 - INT32_C(1));
        while (1) {
            if ((teavm_local_2 > teavm_local_5)) {
                goto teavm_label_2;
            }
            teavm_local_6 = ((teavm_local_2 + teavm_local_5) / INT32_C(2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26768, teavm_nullCheck(teavm_local_1));
            teavm_local_7 = teavm_local_1;
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26769, teavm_checkBounds(teavm_local_6, teavm_local_7));
            teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, int64_t, teavm_local_6);
            teavm_local_9 = teavm_compare_i64(teavm_local_8, teavm_local_4);
            if ((!teavm_local_9)) {
                goto teavm_label_3;
            }
            if ((teavm_local_9 <= INT32_C(0))) {
                teavm_local_2 = (teavm_local_6 + INT32_C(1));
            } else {
                teavm_local_5 = (teavm_local_6 - INT32_C(1));
            }
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_6 = ((-teavm_local_2) - INT32_C(1));
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_6;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26770, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(26771, meth_jl_IllegalArgumentException__init_(teavm_local_10));
    TEAVM_WITH_CALL_SITE_ID(26772, meth_otr_ExceptionHandling_throwException(teavm_local_10));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Arrays_binarySearch_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26773, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26774, meth_ju_Arrays_binarySearch_4(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_Arrays_binarySearch_4(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        teavm_local_5 = (teavm_local_3 - INT32_C(1));
        while (1) {
            if ((teavm_local_2 > teavm_local_5)) {
                goto teavm_label_2;
            }
            teavm_local_6 = ((teavm_local_2 + teavm_local_5) / INT32_C(2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26775, teavm_nullCheck(teavm_local_1));
            teavm_local_7 = teavm_local_1;
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26776, teavm_checkBounds(teavm_local_6, teavm_local_7));
            teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, int16_t, teavm_local_6);
            teavm_local_9 = teavm_compare_i32(teavm_local_8, teavm_local_4);
            if ((!teavm_local_9)) {
                goto teavm_label_3;
            }
            if ((teavm_local_9 <= INT32_C(0))) {
                teavm_local_2 = (teavm_local_6 + INT32_C(1));
            } else {
                teavm_local_5 = (teavm_local_6 - INT32_C(1));
            }
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_6 = ((-teavm_local_2) - INT32_C(1));
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_6;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26777, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(26778, meth_jl_IllegalArgumentException__init_(teavm_local_10));
    TEAVM_WITH_CALL_SITE_ID(26779, meth_otr_ExceptionHandling_throwException(teavm_local_10));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Arrays_binarySearch_5(TeaVM_Array* teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26780, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_LENGTH(teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(26781, meth_ju_Arrays_binarySearch_6(teavm_local_1, INT32_C(0), teavm_local_3, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_Arrays_binarySearch_6(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_2 <= teavm_local_3)) {
        teavm_local_5 = (teavm_local_3 - INT32_C(1));
        while (1) {
            if ((teavm_local_2 > teavm_local_5)) {
                goto teavm_label_2;
            }
            teavm_local_6 = ((teavm_local_2 + teavm_local_5) / INT32_C(2));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26782, teavm_nullCheck(teavm_local_1));
            teavm_local_7 = teavm_local_1;
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(26783, teavm_checkBounds(teavm_local_6, teavm_local_7));
            teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_7, char16_t, teavm_local_6);
            teavm_local_9 = teavm_compare_i32(teavm_local_8, teavm_local_4);
            if ((!teavm_local_9)) {
                goto teavm_label_3;
            }
            if ((teavm_local_9 <= INT32_C(0))) {
                teavm_local_2 = (teavm_local_6 + INT32_C(1));
            } else {
                teavm_local_5 = (teavm_local_6 - INT32_C(1));
            }
        }
    teavm_label_3:;
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_6 = ((-teavm_local_2) - INT32_C(1));
    teavm_label_1:;
        TEAVM_RELEASE_STACK;
        return teavm_local_6;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(26784, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(26785, meth_jl_IllegalArgumentException__init_(teavm_local_10));
    TEAVM_WITH_CALL_SITE_ID(26786, meth_otr_ExceptionHandling_throwException(teavm_local_10));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Arrays_mismatchImpl(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    double teavm_local_9;
    int32_t teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if ((teavm_local_6 >= teavm_local_5)) {
            goto teavm_label_2;
        }
        teavm_local_7 = (teavm_local_6 + teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26787, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, double, TEAVM_WITH_CALL_SITE_ID(26788, teavm_checkBounds(teavm_local_7, teavm_local_8)));
        teavm_local_10 = (teavm_local_6 + teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26789, teavm_nullCheck(teavm_local_3));
        teavm_local_8 = teavm_local_3;
        if (TEAVM_WITH_CALL_SITE_ID(26790, meth_jl_Double_compare(teavm_local_9, TEAVM_ARRAY_AT(teavm_local_8, double, TEAVM_WITH_CALL_SITE_ID(26791, teavm_checkBounds(teavm_local_10, teavm_local_8)))))) {
            goto teavm_label_3;
        }
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_6 = -INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_ju_Arrays_equals_0(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((teavm_local_1 == teavm_local_2)) {
        teavm_local_3 = INT32_C(1);
    } else {
        if (((teavm_local_1 != NULL) && (teavm_local_2 != NULL))) {
            teavm_local_4 = teavm_local_2;
            teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_1);
            if ((teavm_local_5 == TEAVM_ARRAY_LENGTH(teavm_local_4))) {
                goto teavm_label_2;
            }
        }
        teavm_local_3 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_3 = ((TEAVM_WITH_CALL_SITE_ID(26792, meth_ju_Arrays_mismatchImpl(teavm_local_1, INT32_C(0), teavm_local_2, INT32_C(0), teavm_local_5)) >= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Arrays_mismatchImpl_0(TeaVM_Array* teavm_local_1, int32_t teavm_local_2, TeaVM_Array* teavm_local_3, int32_t teavm_local_4, int32_t teavm_local_5) {
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    void* teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_local_11;
    TEAVM_ALLOC_STACK(INT32_C(4));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if ((teavm_local_6 >= teavm_local_5)) {
            goto teavm_label_2;
        }
        teavm_local_7 = (teavm_local_6 + teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(26793, teavm_nullCheck(teavm_local_1));
        teavm_local_8 = teavm_local_1;
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, void*, TEAVM_WITH_CALL_SITE_ID(26794, teavm_checkBounds(teavm_local_7, teavm_local_8)));
        teavm_local_10 = (teavm_local_6 + teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26795, teavm_nullCheck(teavm_local_3));
        teavm_local_8 = teavm_local_3;
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_8, void*, TEAVM_WITH_CALL_SITE_ID(26796, teavm_checkBounds(teavm_local_10, teavm_local_8)));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_11);
        if ((!TEAVM_WITH_CALL_SITE_ID(26797, meth_ju_Objects_equals(teavm_local_9, teavm_local_11)))) {
            goto teavm_label_3;
        }
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_6 = -INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_ju_Arrays_equals(TeaVM_Array* teavm_local_1, TeaVM_Array* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((teavm_local_1 == teavm_local_2)) {
        teavm_local_3 = INT32_C(1);
    } else {
        if (((teavm_local_1 != NULL) && (teavm_local_2 != NULL))) {
            teavm_local_4 = teavm_local_2;
            teavm_local_5 = TEAVM_ARRAY_LENGTH(teavm_local_1);
            if ((teavm_local_5 == TEAVM_ARRAY_LENGTH(teavm_local_4))) {
                goto teavm_label_2;
            }
        }
        teavm_local_3 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_3 = ((TEAVM_WITH_CALL_SITE_ID(26798, meth_ju_Arrays_mismatchImpl_0(teavm_local_1, INT32_C(0), teavm_local_2, INT32_C(0), teavm_local_5)) >= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Arrays_hashCode_0(TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = INT32_C(0);
    } else {
        teavm_local_2 = INT32_C(1);
        teavm_local_3 = INT32_C(0);
        while (1) {
            teavm_local_4 = teavm_local_1;
            if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(teavm_local_4))) {
                goto teavm_label_1;
            }
            teavm_local_5 = (INT32_C(31) * teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26799, teavm_checkLowerBound(teavm_local_3));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = (teavm_local_5 + TEAVM_WITH_CALL_SITE_ID(26800, meth_jl_Integer_hashCode(teavm_local_6)));
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Arrays_hashCode(TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = INT32_C(0);
    } else {
        teavm_local_2 = INT32_C(1);
        teavm_local_3 = INT32_C(0);
        while (1) {
            teavm_local_4 = teavm_local_1;
            if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(teavm_local_4))) {
                goto teavm_label_1;
            }
            teavm_local_5 = (INT32_C(31) * teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(26801, teavm_checkLowerBound(teavm_local_3));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_2 = (teavm_local_5 + TEAVM_WITH_CALL_SITE_ID(26802, meth_ju_Objects_hashCode(teavm_local_6)));
            teavm_local_3 = (teavm_local_3 + INT32_C(1));
        }
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Arrays_asList(TeaVM_Array* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(26803, meth_ju_Objects_requireNonNull(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(26804, meth_otr_Allocator_allocate(&ju_Arrays_ArrayAsList_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(26805, meth_ju_Arrays_ArrayAsList__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_Arrays(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1431 || tag >= 1433) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_Arrays_VT ju_Arrays_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Arrays), sizeof(void*)),
            .flags = 0,
            .tag = 1431,
            .modifiers = 1,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_Arrays,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
void sysinitclass_ju_Arrays() {
}
