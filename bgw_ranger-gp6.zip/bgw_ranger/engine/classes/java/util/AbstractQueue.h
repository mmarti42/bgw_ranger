#pragma once
#include "../../../runtime.h"
#include "AbstractCollection.h"
#include "AbstractQueue.h"

extern void sysinitclass_ju_AbstractQueue();
typedef struct cls_ju_AbstractQueue {
    struct cls_ju_AbstractCollection parent;
} cls_ju_AbstractQueue;
extern void meth_ju_AbstractQueue__init_(void*);
extern int32_t supertypeof_ju_AbstractQueue(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractQueue_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_forEach)(void*, void*); // 11
    void* (*virt_iterator)(void*); // 12
    void* (*virt_spliterator)(void*); // 13
    int32_t (*virt_remove_0)(void*, void*); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    int32_t (*virt_size)(void*); // 17
    void (*pad1)(); // 18
    void (*pad2)(); // 19
    void (*pad3)(); // 20
    void (*virt_clear)(void*); // 21
    void* (*virt_stream)(void*); // 22
    int32_t (*virt_addAll_0)(void*, void*); // 23
    void (*pad4)(); // 24
    int32_t (*virt_removeIf)(void*, void*); // 25
    TeaVM_Array* (*virt_toArray)(void*); // 26
    void (*pad5)(); // 27
    int32_t (*virt_removeAll)(void*, void*); // 28
    void (*pad6)(); // 29
    void (*pad7)(); // 30
    void (*pad8)(); // 31
    void (*pad9)(); // 32
    void (*pad10)(); // 33
    void (*pad11)(); // 34
    void (*pad12)(); // 35
    void (*pad13)(); // 36
    int32_t (*virt_add_2)(void*, void*); // 37
    TeaVM_Array* (*virt_toArray_0)(void*, TeaVM_Array*); // 38
    void (*pad14)(); // 39
    void (*pad15)(); // 40
    void (*pad16)(); // 41
    void (*pad17)(); // 42
    void (*pad18)(); // 43
    void (*pad19)(); // 44
    void (*pad20)(); // 45
    void (*pad21)(); // 46
    int32_t (*virt_containsAll)(void*, void*); // 47
    int32_t (*virt_contains)(void*, void*); // 48
    void* (*virt_remove_3)(void*); // 49
} ju_AbstractQueue_VT;
extern ju_AbstractQueue_VT ju_AbstractQueue_Cls;
