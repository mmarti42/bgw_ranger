#include "AbstractSet.h"
#include "AbstractCollection.h"
#include "Collection.h"
#include "Iterator.h"
#include "Set.h"
#include "../lang/Object.h"
#include "../../../strings.h"
#include "../lang/Iterable.h"

void meth_ju_AbstractSet__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(10116, meth_ju_AbstractCollection__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractSet_removeAll(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10117, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_size)(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(10118, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((teavm_local_3 >= TEAVM_WITH_CALL_SITE_ID(10119, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_size)(teavm_local_1)))) {
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10120, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_iterator)(teavm_local_1));
        while (1) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10121, teavm_nullCheck(teavm_local_4));
            if ((!TEAVM_WITH_CALL_SITE_ID(10122, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_hasNext)(teavm_local_4)))) {
                goto teavm_label_1;
            }
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(10123, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_next)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            if ((!TEAVM_WITH_CALL_SITE_ID(10124, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_remove_0)(teavm_this_, teavm_local_5)))) {
                goto teavm_cnt_1;
            }
            teavm_local_2 = INT32_C(1);
        teavm_cnt_1:;
        }
    teavm_label_1:;
    } else {
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10125, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
        while (1) {
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10126, teavm_nullCheck(teavm_local_4));
            if ((!TEAVM_WITH_CALL_SITE_ID(10127, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_hasNext)(teavm_local_4)))) {
                goto teavm_label_2;
            }
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(10128, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_next)(teavm_local_4));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            if (TEAVM_WITH_CALL_SITE_ID(10129, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_contains)(teavm_local_1, teavm_local_6))) {
                teavm_local_2 = INT32_C(1);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(10130, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_remove)(teavm_local_4));
            }
        }
    teavm_label_2:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_AbstractSet_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &ju_Set_Cls, &supertypeof_ju_Set))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10131, teavm_checkcast(teavm_local_1, &ju_Set_Cls, &supertypeof_ju_Set));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10132, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_size)(teavm_this_));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10133, teavm_nullCheck(teavm_local_3));
        if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(10134, TEAVM_METHOD(teavm_local_3, ju_Set_VT, virt_size)(teavm_local_3)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10135, TEAVM_METHOD(teavm_local_3, ju_Set_VT, virt_iterator)(teavm_local_3));
            while (1) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(10136, teavm_nullCheck(teavm_local_4));
                if ((!TEAVM_WITH_CALL_SITE_ID(10137, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_hasNext)(teavm_local_4)))) {
                    goto teavm_label_3;
                }
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(10138, TEAVM_METHOD(teavm_local_4, ju_Iterator_VT, virt_next)(teavm_local_4));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                if ((!TEAVM_WITH_CALL_SITE_ID(10139, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_contains)(teavm_this_, teavm_local_5)))) {
                    goto teavm_label_2;
                }
            }
        teavm_label_3:;
            teavm_local_2 = INT32_C(1);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(0);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_AbstractSet_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10140, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(10141, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(10142, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_1;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(10143, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        if ((teavm_local_3 != NULL)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_1 = (teavm_local_1 + TEAVM_WITH_CALL_SITE_ID(10144, TEAVM_METHOD(teavm_local_3, jl_Object_VT, virt_hashCode)(teavm_local_3)));
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_AbstractSet(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1294 || tag >= 1336) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_AbstractSet_VT ju_AbstractSet_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractSet), sizeof(void*)),
            .flags = 0,
            .tag = 1294,
            .modifiers = 1025,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_AbstractSet,
            .superclass = (TeaVM_Class*) &ju_AbstractCollection_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_ju_AbstractSet_hashCode,
        .virt_equals = &meth_ju_AbstractSet_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_ju_AbstractCollection_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_forEach = &meth_jl_Iterable_forEach,
        .virt_spliterator = &meth_ju_Collection_spliterator,
        .virt_remove_0 = &meth_ju_AbstractCollection_remove,
        .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
        .virt_stream = &meth_ju_Collection_stream,
        .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
        .virt_removeIf = &meth_ju_Collection_removeIf,
        .virt_toArray = &meth_ju_AbstractCollection_toArray,
        .virt_removeAll = &meth_ju_AbstractSet_removeAll,
        .virt_add_2 = &meth_ju_AbstractCollection_add,
        .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
        .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
        .virt_contains = &meth_ju_AbstractCollection_contains
    }
};
void sysinitclass_ju_AbstractSet() {
}
