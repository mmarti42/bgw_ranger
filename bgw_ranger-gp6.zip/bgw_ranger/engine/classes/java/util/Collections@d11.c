#include "Collections@d11.h"
#include "../lang/Object.h"
#include "Iterator.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"

void meth_ju_Collections_11__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Collections_11, fld_val_c) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(32748, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Collections_11_hasNext(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_11, fld_val_c);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32749, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32750, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Iterator_VT, virt_hasNext)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_11_next(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_11, fld_val_c);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32751, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32752, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Iterator_VT, virt_next)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ju_Collections_11_remove(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32753, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(32754, meth_jl_UnsupportedOperationException__init__0(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(32755, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_ju_Collections_11(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1629 || tag >= 1631) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Collections_11_Cls[2];
alignas(8) ju_Collections_11_VT ju_Collections_11_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_11), sizeof(void*)),
        .flags = 0,
        .tag = 1629,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_Collections_11,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_Collections_11_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_remove = &meth_ju_Collections_11_remove,
    .virt_next = &meth_ju_Collections_11_next,
    .virt_hasNext = &meth_ju_Collections_11_hasNext
};
static int16_t teavm_classLayouts_ju_Collections_11_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_Collections_11, fld_val_c)
};
void sysinitclass_ju_Collections_11() {
}
