#include "Collections@d15.h"
#include "../lang/Object.h"
#include "Iterator.h"
#include "AbstractMap@dSimpleImmutableEntry.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "Map@dEntry.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"

void meth_ju_Collections_15__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Collections_15, fld_val_c) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(32562, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Collections_15_hasNext(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_15, fld_val_c);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32563, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32564, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Iterator_VT, virt_hasNext)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_15_next(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32565, meth_otr_Allocator_allocate(&ju_AbstractMap_SimpleImmutableEntry_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_15, fld_val_c);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32566, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32567, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Iterator_VT, virt_next)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(32568, meth_ju_AbstractMap_SimpleImmutableEntry__init__0(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(32569, teavm_checkcast(teavm_local_2, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry))));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ju_Collections_15_remove(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32570, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(32571, meth_jl_UnsupportedOperationException__init__0(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(32572, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void* meth_ju_Collections_15_next_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32573, TEAVM_METHOD(teavm_this_, ju_Collections_15_VT, virt_next_1)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_Collections_15(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1611 || tag >= 1613) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Collections_15_Cls[2];
alignas(8) ju_Collections_15_VT ju_Collections_15_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_15), sizeof(void*)),
        .flags = 0,
        .tag = 1611,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_Collections_15,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_Collections_15_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_remove = &meth_ju_Collections_15_remove,
    .virt_next = &meth_ju_Collections_15_next_0,
    .virt_hasNext = &meth_ju_Collections_15_hasNext,
    .virt_next_1 = &meth_ju_Collections_15_next
};
static int16_t teavm_classLayouts_ju_Collections_15_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_Collections_15, fld_val_c)
};
void sysinitclass_ju_Collections_15() {
}
