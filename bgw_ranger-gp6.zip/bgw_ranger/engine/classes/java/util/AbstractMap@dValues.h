#pragma once
#include "../../../runtime.h"
#include "AbstractCollection.h"
#include "AbstractMap@dValues.h"

extern void sysinitclass_ju_AbstractMap_Values();
typedef struct cls_ju_AbstractMap_Values {
    struct cls_ju_AbstractCollection parent;
    void* fld_this_0;
} cls_ju_AbstractMap_Values;
extern void meth_ju_AbstractMap_Values__init_(void*, void*);
extern int32_t meth_ju_AbstractMap_Values_size(void*);
extern void* meth_ju_AbstractMap_Values_iterator(void*);
extern int32_t supertypeof_ju_AbstractMap_Values(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractMap_Values_VT {
    ju_AbstractCollection_VT parent;
} ju_AbstractMap_Values_VT;
extern ju_AbstractMap_Values_VT ju_AbstractMap_Values_Cls;
