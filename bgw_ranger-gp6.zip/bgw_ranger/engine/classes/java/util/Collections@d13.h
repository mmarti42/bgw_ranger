#pragma once
#include "../../../runtime.h"
#include "AbstractMap.h"
#include "Collections@d13.h"

extern void sysinitclass_ju_Collections_13();
typedef struct cls_ju_Collections_13 {
    struct cls_ju_AbstractMap parent;
    void* fld_entrySetCache;
    void* fld_val_m;
} cls_ju_Collections_13;
extern void meth_ju_Collections_13__init_(void*, void*);
extern void* meth_ju_Collections_13_entrySet(void*);
extern void* meth_ju_Collections_13_remove(void*, void*);
extern int32_t meth_ju_Collections_13_containsKey(void*, void*);
extern int32_t meth_ju_Collections_13_size(void*);
extern void* meth_ju_Collections_13_get(void*, void*);
extern int32_t meth_ju_Collections_13_isEmpty(void*);
extern int32_t supertypeof_ju_Collections_13(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_13_VT {
    ju_AbstractMap_VT parent;
} ju_Collections_13_VT;
extern ju_Collections_13_VT ju_Collections_13_Cls;
