#include "ArrayDeque@d1.h"
#include "../lang/Object.h"
#include "ArrayDeque.h"
#include "ConcurrentModificationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "NoSuchElementException.h"
#include "../lang/IllegalStateException.h"
#include "../../../strings.h"

void meth_ju_ArrayDeque_1__init_(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0) = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41083, meth_jl_Object__init_(teavm_this_));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_refVersion) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41084, teavm_nullCheck(teavm_local_2)), cls_ju_ArrayDeque, fld_version);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41085, teavm_nullCheck(teavm_local_2)), cls_ju_ArrayDeque, fld_head);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_lastIndex) = -INT32_C(1);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_left) = TEAVM_WITH_CALL_SITE_ID(41086, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41087, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_ArrayDeque_VT, virt_size)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_ArrayDeque_1_hasNext(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_left) <= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
}
void* meth_ju_ArrayDeque_1_next(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_left) - INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_left) = teavm_local_1;
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41088, teavm_nullCheck(teavm_local_2)), cls_ju_ArrayDeque, fld_version) <= TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_refVersion))) {
            TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_lastIndex) = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index);
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41089, teavm_nullCheck(teavm_local_2)), cls_ju_ArrayDeque, fld_array);
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41090, teavm_nullCheck(teavm_local_3));
            teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(41091, teavm_checkBounds(teavm_local_1, teavm_local_3)));
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index);
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_3 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41092, teavm_nullCheck(teavm_local_2)), cls_ju_ArrayDeque, fld_array);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(41093, teavm_nullCheck(teavm_local_3)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index) = TEAVM_WITH_CALL_SITE_ID(41094, meth_ju_ArrayDeque_modInc(teavm_local_1, teavm_local_5));
            TEAVM_RELEASE_STACK;
            return teavm_local_4;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41095, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(41096, meth_ju_ConcurrentModificationException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(41097, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(41098, meth_otr_Allocator_allocate(&ju_NoSuchElementException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(41099, meth_ju_NoSuchElementException__init_(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(41100, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void meth_ju_ArrayDeque_1_remove(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_lastIndex) >= INT32_C(0))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_lastIndex);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(41101, meth_ju_ArrayDeque_removeAt(TEAVM_WITH_CALL_SITE_ID(41102, teavm_nullCheck(teavm_local_1)), teavm_local_2));
        if (teavm_local_3) {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index);
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_this_0);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_4 = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(41103, teavm_nullCheck(teavm_local_1)), cls_ju_ArrayDeque, fld_array);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(41104, teavm_nullCheck(teavm_local_4)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_index) = TEAVM_WITH_CALL_SITE_ID(41105, meth_ju_ArrayDeque_modInc(teavm_local_2, teavm_local_5));
        }
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque_1, fld_lastIndex) = -INT32_C(1);
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41106, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(41107, meth_jl_IllegalStateException__init__0(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(41108, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_ju_ArrayDeque_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1907 || tag >= 1909) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_ArrayDeque_1_Cls[2];
alignas(8) ju_ArrayDeque_1_VT ju_ArrayDeque_1_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_ArrayDeque_1), sizeof(void*)),
        .flags = 0,
        .tag = 1907,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_ArrayDeque_1,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_ArrayDeque_1_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_remove = &meth_ju_ArrayDeque_1_remove,
    .virt_next = &meth_ju_ArrayDeque_1_next,
    .virt_hasNext = &meth_ju_ArrayDeque_1_hasNext
};
static int16_t teavm_classLayouts_ju_ArrayDeque_1_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_ArrayDeque_1, fld_this_0)
};
void sysinitclass_ju_ArrayDeque_1() {
}
