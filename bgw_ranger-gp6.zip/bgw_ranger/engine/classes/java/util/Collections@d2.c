#include "Collections@d2.h"
#include "TemplateCollections@dAbstractImmutableMap.h"
#include "Collections.h"
#include "../../../strings.h"
#include "AbstractMap.h"
#include "../lang/Object.h"
#include "Map.h"

void meth_ju_Collections_2__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5927, meth_ju_TemplateCollections_AbstractImmutableMap__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Collections_2_entrySet(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5928, meth_ju_Collections_emptySet());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_Collections_2_size(void* teavm_this_) {
    return INT32_C(0);
}
void* meth_ju_Collections_2_get(void* teavm_this_, void* teavm_local_1) {
    return NULL;
}
int32_t meth_ju_Collections_2_isEmpty(void* teavm_this_) {
    return INT32_C(1);
}
int32_t meth_ju_Collections_2_containsKey(void* teavm_this_, void* teavm_local_1) {
    return INT32_C(0);
}
int32_t supertypeof_ju_Collections_2(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1841 || tag >= 1843) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_Collections_2_VT ju_Collections_2_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_2), sizeof(void*)),
                .flags = 0,
                .tag = 1841,
                .modifiers = 0,
                .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(530),
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_ju_Collections_2,
                .superclass = (TeaVM_Class*) &ju_TemplateCollections_AbstractImmutableMap_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = (TeaVM_Class*) &ju_Collections_Cls,
                .init = NULL
            },
            .virt_hashCode = &meth_ju_AbstractMap_hashCode,
            .virt_equals = &meth_ju_AbstractMap_equals,
            .virt_toString = &meth_ju_AbstractMap_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_getOrDefault = &meth_ju_Map_getOrDefault,
            .virt_remove_2 = &meth_ju_TemplateCollections_AbstractImmutableMap_remove,
            .virt_isEmpty = &meth_ju_Collections_2_isEmpty,
            .virt_size = &meth_ju_Collections_2_size,
            .virt_containsKey = &meth_ju_Collections_2_containsKey,
            .virt_forEach_0 = &meth_ju_Map_forEach,
            .virt_entrySet = &meth_ju_Collections_2_entrySet,
            .virt_put = &meth_ju_TemplateCollections_AbstractImmutableMap_put,
            .virt_get_3 = &meth_ju_Collections_2_get,
            .virt_keySet = &meth_ju_AbstractMap_keySet,
            .virt_values = &meth_ju_AbstractMap_values
        }
    }
};
void sysinitclass_ju_Collections_2() {
}
