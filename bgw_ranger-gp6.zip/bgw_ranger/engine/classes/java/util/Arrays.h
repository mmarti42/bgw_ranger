#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Arrays.h"

extern void sysinitclass_ju_Arrays();
typedef struct cls_ju_Arrays {
    struct TeaVM_Object parent;
} cls_ju_Arrays;
extern TeaVM_Array* meth_ju_Arrays_copyOf_1(TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_ju_Arrays_copyOf_0(TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_ju_Arrays_copyOf_2(TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_ju_Arrays_copyOf_3(TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_ju_Arrays_copyOf_4(TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_ju_Arrays_copyOf_5(TeaVM_Array*, int32_t);
extern TeaVM_Array* meth_ju_Arrays_copyOf(TeaVM_Array*, int32_t);
extern void* meth_ju_Arrays_toString(TeaVM_Array*);
extern void meth_ju_Arrays_fill(TeaVM_Array*, int32_t, int32_t, int32_t);
extern void meth_ju_Arrays_fill_1(TeaVM_Array*, int32_t);
extern void meth_ju_Arrays_fill_3(TeaVM_Array*, int32_t, int32_t, int32_t);
extern void meth_ju_Arrays_fill_4(TeaVM_Array*, int32_t);
extern void meth_ju_Arrays_fill_0(TeaVM_Array*, int32_t, int32_t, int32_t);
extern void meth_ju_Arrays_fill_5(TeaVM_Array*, int32_t, int32_t, void*);
extern void meth_ju_Arrays_fill_2(TeaVM_Array*, void*);
extern void meth_ju_Arrays_sort_0(TeaVM_Array*, int32_t, int32_t, void*);
extern void meth_ju_Arrays_sort(TeaVM_Array*, void*);
extern void meth_ju_Arrays_merge(TeaVM_Array*, TeaVM_Array*, int32_t, int32_t, int32_t, void*);
extern int32_t meth_ju_Arrays_binarySearch_1(TeaVM_Array*, int32_t);
extern int32_t meth_ju_Arrays_binarySearch_2(TeaVM_Array*, int32_t, int32_t, int32_t);
extern int32_t meth_ju_Arrays_binarySearch(TeaVM_Array*, int64_t);
extern int32_t meth_ju_Arrays_binarySearch_3(TeaVM_Array*, int32_t, int32_t, int64_t);
extern int32_t meth_ju_Arrays_binarySearch_0(TeaVM_Array*, int32_t);
extern int32_t meth_ju_Arrays_binarySearch_4(TeaVM_Array*, int32_t, int32_t, int32_t);
extern int32_t meth_ju_Arrays_binarySearch_5(TeaVM_Array*, int32_t);
extern int32_t meth_ju_Arrays_binarySearch_6(TeaVM_Array*, int32_t, int32_t, int32_t);
extern int32_t meth_ju_Arrays_mismatchImpl(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern int32_t meth_ju_Arrays_equals_0(TeaVM_Array*, TeaVM_Array*);
extern int32_t meth_ju_Arrays_mismatchImpl_0(TeaVM_Array*, int32_t, TeaVM_Array*, int32_t, int32_t);
extern int32_t meth_ju_Arrays_equals(TeaVM_Array*, TeaVM_Array*);
extern int32_t meth_ju_Arrays_hashCode_0(TeaVM_Array*);
extern int32_t meth_ju_Arrays_hashCode(TeaVM_Array*);
extern void* meth_ju_Arrays_asList(TeaVM_Array*);
extern int32_t supertypeof_ju_Arrays(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Arrays_VT {
    jl_Object_VT parent;
} ju_Arrays_VT;
extern ju_Arrays_VT ju_Arrays_Cls;
