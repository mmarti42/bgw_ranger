#include "Collections@d3.h"
#include "TemplateCollections@dAbstractImmutableList.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Collections.h"
#include "../../../strings.h"
#include "AbstractList.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_Collections_3__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5846, meth_ju_TemplateCollections_AbstractImmutableList__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Collections_3_get(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5847, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5848, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(5849, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Collections_3_size(void* teavm_this_) {
    return INT32_C(0);
}
void* meth_ju_Collections_3_iterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5850, meth_ju_Collections_emptyIterator());
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_3_listIterator(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (teavm_local_1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5851, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(5852, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(5853, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5854, meth_ju_Collections_emptyListIterator());
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Collections_3_isEmpty(void* teavm_this_) {
    return INT32_C(1);
}
int32_t supertypeof_ju_Collections_3(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1348 || tag >= 1350) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_Collections_3_VT ju_Collections_3_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_3), sizeof(void*)),
                .flags = 0,
                .tag = 1348,
                .modifiers = 0,
                .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(521),
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_ju_Collections_3,
                .superclass = (TeaVM_Class*) &ju_TemplateCollections_AbstractImmutableList_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = (TeaVM_Class*) &ju_Collections_Cls,
                .init = NULL
            },
            .virt_hashCode = &meth_ju_AbstractList_hashCode,
            .virt_equals = &meth_ju_AbstractList_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_ju_AbstractCollection_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_forEach = &meth_jl_Iterable_forEach,
            .virt_iterator = &meth_ju_Collections_3_iterator,
            .virt_spliterator = &meth_ju_Collection_spliterator,
            .virt_remove_0 = &meth_ju_AbstractCollection_remove,
            .virt_isEmpty = &meth_ju_Collections_3_isEmpty,
            .virt_size = &meth_ju_Collections_3_size,
            .virt_get = &meth_ju_Collections_3_get,
            .virt_stream = &meth_ju_Collection_stream,
            .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
            .virt_listIterator = &meth_ju_Collections_3_listIterator,
            .virt_toArray = &meth_ju_AbstractCollection_toArray,
            .virt_removeAll = &meth_ju_TemplateCollections_AbstractImmutableList_removeAll,
            .virt_subList = &meth_ju_AbstractList_subList,
            .virt_listIterator_0 = &meth_ju_AbstractList_listIterator_0,
            .virt_add_1 = &meth_ju_AbstractList_add,
            .virt_remove_1 = &meth_ju_TemplateCollections_AbstractImmutableList_remove,
            .virt_indexOf = &meth_ju_AbstractList_indexOf,
            .virt_add_2 = &meth_ju_AbstractList_add_0,
            .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
            .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
            .virt_contains = &meth_ju_AbstractCollection_contains,
            .virt_set = &meth_ju_AbstractList_set
        }
    }
};
void sysinitclass_ju_Collections_3() {
}
