#include "Comparator.h"
#include "Comparator@dcomparingInt@dlambda@d_14_0.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "function/ToIntFunction.h"
#include "../lang/Integer.h"
#include "../../../strings.h"

void* meth_ju_Comparator_comparingInt(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16609, meth_otr_Allocator_allocate(&ju_Comparator_comparingInt_lambda__14_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(16610, meth_ju_Comparator_comparingInt_lambda__14_0__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Comparator_lambda_comparingInt_10(void* teavm_local_1, void* teavm_local_2, void* teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(16611, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(16612, TEAVM_METHOD(teavm_local_1, juf_ToIntFunction_VT, virt_applyAsInt)(teavm_local_1, teavm_local_2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(16613, TEAVM_METHOD(teavm_local_1, juf_ToIntFunction_VT, virt_applyAsInt)(teavm_local_1, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(16614, meth_jl_Integer_compare(teavm_local_4, teavm_local_5));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t supertypeof_ju_Comparator(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 77 || tag >= 2251) return INT32_C(0);
    if (tag >= 79 && tag < 181) return INT32_C(0);
    if (tag >= 183 && tag < 261) return INT32_C(0);
    if (tag >= 263 && tag < 267) return INT32_C(0);
    if (tag >= 269 && tag < 299) return INT32_C(0);
    if (tag >= 301 && tag < 301) return INT32_C(0);
    if (tag >= 303 && tag < 341) return INT32_C(0);
    if (tag >= 343 && tag < 557) return INT32_C(0);
    if (tag >= 559 && tag < 825) return INT32_C(0);
    if (tag >= 827 && tag < 1027) return INT32_C(0);
    if (tag >= 1029 && tag < 1167) return INT32_C(0);
    if (tag >= 1169 && tag < 1399) return INT32_C(0);
    if (tag >= 1401 && tag < 1451) return INT32_C(0);
    if (tag >= 1453 && tag < 1653) return INT32_C(0);
    if (tag >= 1655 && tag < 1679) return INT32_C(0);
    if (tag >= 1681 && tag < 1717) return INT32_C(0);
    if (tag >= 1719 && tag < 2249) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class ju_Comparator_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 77,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_ju_Comparator,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_ju_Comparator() {
}
