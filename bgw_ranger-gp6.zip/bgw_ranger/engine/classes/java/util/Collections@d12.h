#pragma once
#include "../../../runtime.h"
#include "AbstractSet.h"
#include "Collections@d12.h"

extern void sysinitclass_ju_Collections_12();
typedef struct cls_ju_Collections_12 {
    struct cls_ju_AbstractSet parent;
    void* fld_val_s;
} cls_ju_Collections_12;
extern void meth_ju_Collections_12__init_(void*, void*);
extern void* meth_ju_Collections_12_iterator(void*);
extern int32_t meth_ju_Collections_12_size(void*);
extern int32_t meth_ju_Collections_12_remove(void*, void*);
extern int32_t meth_ju_Collections_12_contains(void*, void*);
extern int32_t meth_ju_Collections_12_containsAll(void*, void*);
extern int32_t meth_ju_Collections_12_isEmpty(void*);
extern int32_t supertypeof_ju_Collections_12(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_12_VT {
    ju_AbstractSet_VT parent;
} ju_Collections_12_VT;
extern ju_Collections_12_VT ju_Collections_12_Cls;
