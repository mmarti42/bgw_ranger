#include "AbstractList@dSubAbstractList@dSubAbstractListIterator.h"
#include "../lang/Object.h"
#include "ListIterator.h"
#include "NoSuchElementException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"

void meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(41401, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_iterator) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_subList) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_start) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_end) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_start) + teavm_local_4);
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator_hasNext(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_iterator);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(41402, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41403, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_ListIterator_VT, virt_nextIndex)(teavm_tmp_ptr_0))) >= TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_end)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator_next(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_iterator);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    if ((TEAVM_WITH_CALL_SITE_ID(41404, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41405, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_ListIterator_VT, virt_nextIndex)(teavm_tmp_ptr_0))) < TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_end))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_iterator);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41406, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(41407, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_ListIterator_VT, virt_next)(teavm_tmp_ptr_0)));
        TEAVM_RELEASE_STACK;
        return teavm_local_1;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(41408, meth_otr_Allocator_allocate(&ju_NoSuchElementException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(41409, meth_ju_NoSuchElementException__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(41410, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_ju_AbstractList_SubAbstractList_SubAbstractListIterator(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1933 || tag >= 1935) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractList_SubAbstractList_SubAbstractListIterator_Cls[3];
alignas(8) ju_AbstractList_SubAbstractList_SubAbstractListIterator_VT ju_AbstractList_SubAbstractList_SubAbstractListIterator_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator), sizeof(void*)),
        .flags = 0,
        .tag = 1933,
        .modifiers = 16,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractList_SubAbstractList_SubAbstractListIterator,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractList_SubAbstractList_SubAbstractListIterator_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_next = &meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator_next,
    .virt_hasNext = &meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator_hasNext
};
static int16_t teavm_classLayouts_ju_AbstractList_SubAbstractList_SubAbstractListIterator_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_subList), (int16_t) offsetof(cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator, fld_iterator)
};
void sysinitclass_ju_AbstractList_SubAbstractList_SubAbstractListIterator() {
}
