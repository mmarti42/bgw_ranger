#pragma once
#include "../../../runtime.h"
#include "AbstractList.h"
#include "Collections@d9.h"

extern void sysinitclass_ju_Collections_9();
typedef struct cls_ju_Collections_9 {
    struct cls_ju_AbstractList parent;
    void* fld_val_list;
} cls_ju_Collections_9;
extern void meth_ju_Collections_9__init_(void*, void*);
extern void* meth_ju_Collections_9_get(void*, int32_t);
extern int32_t meth_ju_Collections_9_size(void*);
extern int32_t supertypeof_ju_Collections_9(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_9_VT {
    ju_AbstractList_VT parent;
} ju_Collections_9_VT;
extern ju_Collections_9_VT ju_Collections_9_Cls;
