#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Collections@d15.h"

extern void sysinitclass_ju_Collections_15();
typedef struct cls_ju_Collections_15 {
    struct TeaVM_Object parent;
    void* fld_val_c;
} cls_ju_Collections_15;
extern void meth_ju_Collections_15__init_(void*, void*);
extern int32_t meth_ju_Collections_15_hasNext(void*);
extern void* meth_ju_Collections_15_next(void*);
extern void meth_ju_Collections_15_remove(void*);
extern void* meth_ju_Collections_15_next_0(void*);
extern int32_t supertypeof_ju_Collections_15(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_15_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_remove)(void*); // 11
    void* (*virt_next)(void*); // 12
    int32_t (*virt_hasNext)(void*); // 13
    void (*pad0)(); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void (*pad8)(); // 22
    void (*pad9)(); // 23
    void (*pad10)(); // 24
    void (*pad11)(); // 25
    void (*pad12)(); // 26
    void (*pad13)(); // 27
    void* (*virt_next_1)(void*); // 28
    void (*pad14)(); // 29
    void (*pad15)(); // 30
    void (*pad16)(); // 31
    void (*pad17)(); // 32
    void (*pad18)(); // 33
    void (*pad19)(); // 34
    void (*pad20)(); // 35
    void (*pad21)(); // 36
    void (*pad22)(); // 37
    void (*pad23)(); // 38
    void (*pad24)(); // 39
    void (*pad25)(); // 40
    void (*pad26)(); // 41
    void (*pad27)(); // 42
    void (*pad28)(); // 43
    void (*pad29)(); // 44
    void (*pad30)(); // 45
    void (*pad31)(); // 46
    void (*pad32)(); // 47
    void (*pad33)(); // 48
    void (*pad34)(); // 49
} ju_Collections_15_VT;
extern ju_Collections_15_VT ju_Collections_15_Cls;
