#include "AbstractList@dSubAbstractList.h"
#include "AbstractList.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "ConcurrentModificationException.h"
#include "AbstractList@dSubAbstractList@dSubAbstractListIterator.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_AbstractList_SubAbstractList__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(17669, meth_ju_AbstractList__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList) = teavm_local_1;
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(17670, teavm_nullCheck(teavm_local_4)), cls_ju_AbstractList, fld_modCount);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_offset) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size) = (teavm_local_3 - teavm_local_2);
    TEAVM_RELEASE_STACK;
}
void* meth_ju_AbstractList_SubAbstractList_get(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 == TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(17671, teavm_nullCheck(teavm_local_3)), cls_ju_AbstractList, fld_modCount))) {
        if (((INT32_C(0) <= teavm_local_1) && (teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size)))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
            teavm_local_2 = (teavm_local_1 + TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_offset));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17672, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17673, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_get)(teavm_tmp_ptr_0, teavm_local_2)));
            TEAVM_RELEASE_STACK;
            return teavm_local_3;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17674, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(17675, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(17676, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17677, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(17678, meth_ju_ConcurrentModificationException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(17679, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void* meth_ju_AbstractList_SubAbstractList_iterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(17680, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_listIterator)(teavm_this_, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_AbstractList_SubAbstractList_listIterator(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((teavm_local_2 == TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(17681, teavm_nullCheck(teavm_local_3)), cls_ju_AbstractList, fld_modCount))) {
        if (((INT32_C(0) <= teavm_local_1) && (teavm_local_1 <= TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size)))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17682, meth_otr_Allocator_allocate(&ju_AbstractList_SubAbstractList_SubAbstractListIterator_Cls));
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
            teavm_local_2 = (teavm_local_1 + TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_offset));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17683, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17684, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_listIterator)(teavm_tmp_ptr_0, teavm_local_2)));
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_offset);
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(17685, meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator__init_(teavm_local_3, teavm_local_4, teavm_this_, teavm_local_2, teavm_local_5));
            TEAVM_RELEASE_STACK;
            return teavm_local_3;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17686, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(17687, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(17688, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17689, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(17690, meth_ju_ConcurrentModificationException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(17691, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void* meth_ju_AbstractList_SubAbstractList_remove(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((teavm_local_2 == TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(17692, teavm_nullCheck(teavm_local_3)), cls_ju_AbstractList, fld_modCount))) {
        if (((INT32_C(0) <= teavm_local_1) && (teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size)))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
            teavm_local_2 = (teavm_local_1 + TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_offset));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(17693, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(17694, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_remove_1)(teavm_tmp_ptr_0, teavm_local_2)));
            TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size) - INT32_C(1));
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(17695, teavm_nullCheck(teavm_local_3)), cls_ju_AbstractList, fld_modCount);
            TEAVM_RELEASE_STACK;
            return teavm_local_4;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17696, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(17697, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(17698, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(17699, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(17700, meth_ju_ConcurrentModificationException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(17701, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_AbstractList_SubAbstractList_size(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_fullList);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((teavm_local_1 != TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(17702, teavm_nullCheck(teavm_local_2)), cls_ju_AbstractList, fld_modCount))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17703, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(17704, meth_ju_ConcurrentModificationException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(17705, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_SubAbstractList, fld_size);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_AbstractList_SubAbstractList(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1355 || tag >= 1359) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractList_SubAbstractList_Cls[2];
alignas(8) ju_AbstractList_SubAbstractList_VT ju_AbstractList_SubAbstractList_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractList_SubAbstractList), sizeof(void*)),
            .flags = 0,
            .tag = 1355,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_AbstractList_SubAbstractList,
            .superclass = (TeaVM_Class*) &ju_AbstractList_Cls,
            .layout = teavm_classLayouts_ju_AbstractList_SubAbstractList_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_ju_AbstractList_hashCode,
        .virt_equals = &meth_ju_AbstractList_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_ju_AbstractCollection_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_forEach = &meth_jl_Iterable_forEach,
        .virt_iterator = &meth_ju_AbstractList_SubAbstractList_iterator,
        .virt_spliterator = &meth_ju_Collection_spliterator,
        .virt_remove_0 = &meth_ju_AbstractCollection_remove,
        .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
        .virt_size = &meth_ju_AbstractList_SubAbstractList_size,
        .virt_get = &meth_ju_AbstractList_SubAbstractList_get,
        .virt_stream = &meth_ju_Collection_stream,
        .virt_listIterator = &meth_ju_AbstractList_SubAbstractList_listIterator,
        .virt_removeIf = &meth_ju_Collection_removeIf,
        .virt_toArray = &meth_ju_AbstractCollection_toArray,
        .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
        .virt_subList = &meth_ju_AbstractList_subList,
        .virt_listIterator_0 = &meth_ju_AbstractList_listIterator_0,
        .virt_remove_1 = &meth_ju_AbstractList_SubAbstractList_remove,
        .virt_indexOf = &meth_ju_AbstractList_indexOf,
        .virt_add_2 = &meth_ju_AbstractList_add_0,
        .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
        .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
        .virt_contains = &meth_ju_AbstractCollection_contains
    }
};
static int16_t teavm_classLayouts_ju_AbstractList_SubAbstractList_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_AbstractList_SubAbstractList, fld_fullList)
};
void sysinitclass_ju_AbstractList_SubAbstractList() {
}
