#include "Collections.h"
#include "../lang/Object.h"
#include "TemplateCollections@dSingleElementList.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "TemplateCollections@dSingleElementSet.h"
#include "Comparator@dNaturalOrder.h"
#include "../../../arrayclass.h"
#include "List.h"
#include "Arrays.h"
#include "RandomAccess.h"
#include "ArrayList.h"
#include "Objects.h"
#include "Collections@d9.h"
#include "Collections@d11.h"
#include "Collections@d12.h"
#include "Collections@d13.h"
#include "Collections@d14.h"
#include "Collections@d15.h"
#include "Collection.h"
#include "Iterator.h"
#include "Collections@d1.h"
#include "Collections@d2.h"
#include "Collections@d3.h"
#include "Collections@d4.h"
#include "Collections@d5.h"
#include "Collections@d@lclinit@g@dlambda@d_59_0.h"
#include "../../../strings.h"

void* sfld_ju_Collections_EMPTY_SET;
void* sfld_ju_Collections_EMPTY_MAP;
void* sfld_ju_Collections_EMPTY_LIST;
void* sfld_ju_Collections_EMPTY_ITERATOR;
void* sfld_ju_Collections_EMPTY_LIST_ITERATOR;
void* sfld_ju_Collections_reverseOrder;
void* meth_ju_Collections_emptyIterator() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20240, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_1 = sfld_ju_Collections_EMPTY_ITERATOR;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_emptyListIterator() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20241, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_1 = sfld_ju_Collections_EMPTY_LIST_ITERATOR;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_emptyList() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20242, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_1 = sfld_ju_Collections_EMPTY_LIST;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_emptySet() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20243, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_1 = sfld_ju_Collections_EMPTY_SET;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_emptyMap() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20244, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_1 = sfld_ju_Collections_EMPTY_MAP;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_singletonList(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20245, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20246, meth_otr_Allocator_allocate(&ju_TemplateCollections_SingleElementList_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20247, meth_ju_TemplateCollections_SingleElementList__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_singleton(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20248, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20249, meth_otr_Allocator_allocate(&ju_TemplateCollections_SingleElementSet_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20250, meth_ju_TemplateCollections_SingleElementSet__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void meth_ju_Collections_sort_0(void* teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20251, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    if ((teavm_local_2 == NULL)) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20252, meth_ju_Comparator_NaturalOrder_instance());
    }
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20253, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20254, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), TEAVM_WITH_CALL_SITE_ID(20255, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_size)(teavm_local_1))));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(20256, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_toArray_0)(teavm_local_1, teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(20257, meth_ju_Arrays_sort(teavm_local_3, teavm_local_2));
    teavm_local_4 = INT32_C(0);
    while (1) {
        teavm_local_5 = teavm_local_3;
        if ((teavm_local_4 >= TEAVM_ARRAY_LENGTH(teavm_local_5))) {
            goto teavm_label_1;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20258, teavm_checkLowerBound(teavm_local_4));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(20259, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_set)(teavm_local_1, teavm_local_4, teavm_local_6));
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_ju_Collections_sort(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20260, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20261, meth_ju_Comparator_NaturalOrder_instance());
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20262, meth_ju_Collections_sort_0(teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_ju_Collections_reverse(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(20263, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    if (teavm_instanceof(teavm_local_1, &ju_RandomAccess_Cls, &supertypeof_ju_RandomAccess)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20264, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(20265, meth_ju_Collections_reverse_0(teavm_local_1, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(20266, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_size)(teavm_local_1))));
    } else {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20267, meth_otr_Allocator_allocate(&ju_ArrayList_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(20268, meth_ju_ArrayList__init__0(teavm_local_2, teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(20269, meth_ju_Collections_reverse_0(teavm_local_2, INT32_C(0), TEAVM_WITH_CALL_SITE_ID(20270, TEAVM_METHOD(teavm_local_2, ju_List_VT, virt_size)(teavm_local_2))));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20271, teavm_nullCheck(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(20272, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_clear)(teavm_local_1));
        TEAVM_WITH_CALL_SITE_ID(20273, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_addAll_0)(teavm_local_1, teavm_local_2));
    }
    TEAVM_RELEASE_STACK;
}
void meth_ju_Collections_reverse_0(void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20274, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_4 = ((teavm_local_2 + teavm_local_3) / INT32_C(2));
    teavm_local_5 = (teavm_local_3 - INT32_C(1));
    while (1) {
        if (!(teavm_local_2 < teavm_local_4)) break;
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20275, teavm_nullCheck(teavm_local_1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(20276, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_get)(teavm_local_1, teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(20277, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_get)(teavm_local_1, teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(20278, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_set)(teavm_local_1, teavm_local_2, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(20279, TEAVM_METHOD(teavm_local_1, ju_List_VT, virt_set)(teavm_local_1, teavm_local_5, teavm_local_6));
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
        teavm_local_5 = (teavm_local_5 + -INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Collections_unmodifiableList(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20280, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    TEAVM_WITH_CALL_SITE_ID(20281, meth_ju_Objects_requireNonNull(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20282, meth_otr_Allocator_allocate(&ju_Collections_9_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20283, meth_ju_Collections_9__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_unmodifiableIterator(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20284, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20285, meth_otr_Allocator_allocate(&ju_Collections_11_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20286, meth_ju_Collections_11__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_unmodifiableSet(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20287, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    TEAVM_WITH_CALL_SITE_ID(20288, meth_ju_Objects_requireNonNull(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20289, meth_otr_Allocator_allocate(&ju_Collections_12_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20290, meth_ju_Collections_12__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_unmodifiableMap(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20291, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    TEAVM_WITH_CALL_SITE_ID(20292, meth_ju_Objects_requireNonNull(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20293, meth_otr_Allocator_allocate(&ju_Collections_13_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20294, meth_ju_Collections_13__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_unmodifiableMapEntrySet(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20295, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20296, meth_otr_Allocator_allocate(&ju_Collections_14_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20297, meth_ju_Collections_14__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_unmodifiableMapEntryIterator(void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20298, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20299, meth_otr_Allocator_allocate(&ju_Collections_15_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(20300, meth_ju_Collections_15__init_(teavm_local_2, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_synchronizedMap(void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(20301, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_Collections_disjoint(void* teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(20302, teavm_initializeClass((TeaVM_Class*) &ju_Collections_Cls, &initclass_ju_Collections));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20303, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(20304, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_size)(teavm_local_1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(20305, teavm_nullCheck(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    if ((teavm_local_3 <= TEAVM_WITH_CALL_SITE_ID(20306, TEAVM_METHOD(teavm_local_2, ju_Collection_VT, virt_size)(teavm_local_2)))) {
        teavm_local_4 = teavm_local_2;
        teavm_local_2 = teavm_local_1;
        teavm_local_1 = teavm_local_4;
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(20307, TEAVM_METHOD(teavm_local_2, ju_Collection_VT, virt_iterator)(teavm_local_2));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(20308, teavm_nullCheck(teavm_local_5));
        if ((!TEAVM_WITH_CALL_SITE_ID(20309, TEAVM_METHOD(teavm_local_5, ju_Iterator_VT, virt_hasNext)(teavm_local_5)))) {
            goto teavm_label_3;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(20310, TEAVM_METHOD(teavm_local_5, ju_Iterator_VT, virt_next)(teavm_local_5));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        if (TEAVM_WITH_CALL_SITE_ID(20311, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_contains)(teavm_local_1, teavm_local_4))) {
            goto teavm_label_2;
        }
    }
teavm_label_3:;
    teavm_local_3 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_ju_Collections__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20312, meth_otr_Allocator_allocate(&ju_Collections_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20313, meth_ju_Collections_1__init_(teavm_local_1));
    sfld_ju_Collections_EMPTY_SET = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20314, meth_otr_Allocator_allocate(&ju_Collections_2_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20315, meth_ju_Collections_2__init_(teavm_local_1));
    sfld_ju_Collections_EMPTY_MAP = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20316, meth_otr_Allocator_allocate(&ju_Collections_3_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20317, meth_ju_Collections_3__init_(teavm_local_1));
    sfld_ju_Collections_EMPTY_LIST = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20318, meth_otr_Allocator_allocate(&ju_Collections_4_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20319, meth_ju_Collections_4__init_(teavm_local_1));
    sfld_ju_Collections_EMPTY_ITERATOR = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20320, meth_otr_Allocator_allocate(&ju_Collections_5_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20321, meth_ju_Collections_5__init_(teavm_local_1));
    sfld_ju_Collections_EMPTY_LIST_ITERATOR = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(20322, meth_otr_Allocator_allocate(&ju_Collections__clinit__lambda__59_0_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(20323, meth_ju_Collections__clinit__lambda__59_0__init_(teavm_local_1));
    sfld_ju_Collections_reverseOrder = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_ju_Collections() {
    TeaVM_Class* cls = (TeaVM_Class*) &ju_Collections_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_ju_Collections__clinit_();
    }
}
int32_t supertypeof_ju_Collections(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1213 || tag >= 1215) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_Collections_VT ju_Collections_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections), sizeof(void*)),
            .flags = 0,
            .tag = 1213,
            .modifiers = 17,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_Collections,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_ju_Collections_Cls[6] = {
(void**) &sfld_ju_Collections_EMPTY_SET, (void**) &sfld_ju_Collections_EMPTY_MAP, (void**) &sfld_ju_Collections_EMPTY_LIST, (void**) &sfld_ju_Collections_EMPTY_ITERATOR, (void**) &sfld_ju_Collections_EMPTY_LIST_ITERATOR, (void**) &sfld_ju_Collections_reverseOrder
};
void sysinitclass_ju_Collections() {
sfld_ju_Collections_EMPTY_SET = NULL;
sfld_ju_Collections_EMPTY_MAP = NULL;
sfld_ju_Collections_EMPTY_LIST = NULL;
sfld_ju_Collections_EMPTY_ITERATOR = NULL;
sfld_ju_Collections_EMPTY_LIST_ITERATOR = NULL;
sfld_ju_Collections_reverseOrder = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_ju_Collections_Cls, 6);
}
