#include "Collections@d14.h"
#include "AbstractSet.h"
#include "Set.h"
#include "Collections.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_Collections_14__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Collections_14, fld_val_c) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(32558, meth_ju_AbstractSet__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Collections_14_iterator(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_14, fld_val_c);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32559, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32560, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32561, meth_ju_Collections_unmodifiableMapEntryIterator(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_Collections_14(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1325 || tag >= 1327) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Collections_14_Cls[2];
alignas(8) ju_Collections_14_VT ju_Collections_14_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_14), sizeof(void*)),
                .flags = 0,
                .tag = 1325,
                .modifiers = 0,
                .name = NULL,
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_ju_Collections_14,
                .superclass = (TeaVM_Class*) &ju_AbstractSet_Cls,
                .layout = teavm_classLayouts_ju_Collections_14_Cls,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_hashCode = &meth_ju_AbstractSet_hashCode,
            .virt_equals = &meth_ju_AbstractSet_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_ju_AbstractCollection_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_forEach = &meth_jl_Iterable_forEach,
            .virt_iterator = &meth_ju_Collections_14_iterator,
            .virt_spliterator = &meth_ju_Collection_spliterator,
            .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
            .virt_stream = &meth_ju_Collection_stream,
            .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
            .virt_removeIf = &meth_ju_Collection_removeIf,
            .virt_toArray = &meth_ju_AbstractCollection_toArray,
            .virt_removeAll = &meth_ju_AbstractSet_removeAll,
            .virt_add_2 = &meth_ju_AbstractCollection_add,
            .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
            .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
            .virt_contains = &meth_ju_AbstractCollection_contains
        }
    }
};
static int16_t teavm_classLayouts_ju_Collections_14_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_Collections_14, fld_val_c)
};
void sysinitclass_ju_Collections_14() {
}
