#pragma once
#include "../../../runtime.h"
#include "TemplateCollections@dAbstractImmutableMap.h"
#include "Collections@d2.h"

extern void sysinitclass_ju_Collections_2();
typedef struct cls_ju_Collections_2 {
    struct cls_ju_TemplateCollections_AbstractImmutableMap parent;
} cls_ju_Collections_2;
extern void meth_ju_Collections_2__init_(void*);
extern void* meth_ju_Collections_2_entrySet(void*);
extern int32_t meth_ju_Collections_2_size(void*);
extern void* meth_ju_Collections_2_get(void*, void*);
extern int32_t meth_ju_Collections_2_isEmpty(void*);
extern int32_t meth_ju_Collections_2_containsKey(void*, void*);
extern int32_t supertypeof_ju_Collections_2(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_2_VT {
    ju_TemplateCollections_AbstractImmutableMap_VT parent;
} ju_Collections_2_VT;
extern ju_Collections_2_VT ju_Collections_2_Cls;
