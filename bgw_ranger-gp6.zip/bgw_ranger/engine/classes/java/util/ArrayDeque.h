#pragma once
#include "../../../runtime.h"
#include "AbstractCollection.h"
#include "ArrayDeque.h"

extern void sysinitclass_ju_ArrayDeque();
typedef struct cls_ju_ArrayDeque {
    struct cls_ju_AbstractCollection parent;
    int32_t fld_version;
    TeaVM_Array* fld_array;
    int32_t fld_head;
    int32_t fld_tail;
} cls_ju_ArrayDeque;
extern void meth_ju_ArrayDeque__init_(void*);
extern void meth_ju_ArrayDeque__init__0(void*, int32_t);
extern void meth_ju_ArrayDeque_addFirst(void*, void*);
extern void meth_ju_ArrayDeque_addLast(void*, void*);
extern void* meth_ju_ArrayDeque_removeFirst(void*);
extern void* meth_ju_ArrayDeque_pollFirst(void*);
extern void* meth_ju_ArrayDeque_peekFirst(void*);
extern int32_t meth_ju_ArrayDeque_add(void*, void*);
extern void* meth_ju_ArrayDeque_remove(void*);
extern void meth_ju_ArrayDeque_push(void*, void*);
extern void* meth_ju_ArrayDeque_pop(void*);
extern int32_t meth_ju_ArrayDeque_size(void*);
extern int32_t meth_ju_ArrayDeque_isEmpty(void*);
extern int32_t meth_ju_ArrayDeque_removeAt(void*, int32_t);
extern int32_t meth_ju_ArrayDeque_modInc(int32_t, int32_t);
extern int32_t meth_ju_ArrayDeque_modDec(int32_t, int32_t);
extern void* meth_ju_ArrayDeque_iterator(void*);
extern void meth_ju_ArrayDeque_ensureCapacity(void*, int32_t);
extern int32_t supertypeof_ju_ArrayDeque(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_ArrayDeque_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_forEach)(void*, void*); // 11
    void* (*virt_iterator)(void*); // 12
    void* (*virt_spliterator)(void*); // 13
    int32_t (*virt_remove_0)(void*, void*); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    int32_t (*virt_size)(void*); // 17
    void (*pad1)(); // 18
    void* (*virt_peekFirst)(void*); // 19
    void (*virt_addFirst)(void*, void*); // 20
    void (*virt_clear)(void*); // 21
    void* (*virt_stream)(void*); // 22
    int32_t (*virt_addAll_0)(void*, void*); // 23
    void* (*virt_pollFirst)(void*); // 24
    int32_t (*virt_removeIf)(void*, void*); // 25
    TeaVM_Array* (*virt_toArray)(void*); // 26
    void (*virt_addLast)(void*, void*); // 27
    int32_t (*virt_removeAll)(void*, void*); // 28
    void* (*virt_pop)(void*); // 29
    void (*virt_push)(void*, void*); // 30
    void* (*virt_removeFirst)(void*); // 31
    void (*pad2)(); // 32
    void (*pad3)(); // 33
    void (*pad4)(); // 34
    void (*pad5)(); // 35
    void (*pad6)(); // 36
    int32_t (*virt_add_2)(void*, void*); // 37
    TeaVM_Array* (*virt_toArray_0)(void*, TeaVM_Array*); // 38
    void (*pad7)(); // 39
    void (*pad8)(); // 40
    void (*pad9)(); // 41
    void (*pad10)(); // 42
    void (*pad11)(); // 43
    void (*pad12)(); // 44
    void (*pad13)(); // 45
    void (*pad14)(); // 46
    int32_t (*virt_containsAll)(void*, void*); // 47
    int32_t (*virt_contains)(void*, void*); // 48
    void* (*virt_remove_3)(void*); // 49
} ju_ArrayDeque_VT;
extern ju_ArrayDeque_VT ju_ArrayDeque_Cls;
