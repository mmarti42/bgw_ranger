#pragma once
#include "../../../runtime.h"
#include "AbstractList.h"
#include "Arrays@dArrayAsList.h"

extern void sysinitclass_ju_Arrays_ArrayAsList();
typedef struct cls_ju_Arrays_ArrayAsList {
    struct cls_ju_AbstractList parent;
    TeaVM_Array* fld_array;
} cls_ju_Arrays_ArrayAsList;
extern void meth_ju_Arrays_ArrayAsList__init_(void*, TeaVM_Array*);
extern void* meth_ju_Arrays_ArrayAsList_get(void*, int32_t);
extern int32_t meth_ju_Arrays_ArrayAsList_size(void*);
extern int32_t supertypeof_ju_Arrays_ArrayAsList(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Arrays_ArrayAsList_VT {
    ju_AbstractList_VT parent;
} ju_Arrays_ArrayAsList_VT;
extern ju_Arrays_ArrayAsList_VT ju_Arrays_ArrayAsList_Cls;
