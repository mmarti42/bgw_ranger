#include "AbstractList@dSubAbstractListRandomAccess.h"
#include "AbstractList@dSubAbstractList.h"
#include "../../../strings.h"
#include "AbstractList.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_AbstractList_SubAbstractListRandomAccess__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30191, meth_ju_AbstractList_SubAbstractList__init_(teavm_this_, teavm_local_1, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ju_AbstractList_SubAbstractListRandomAccess(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1356 || tag >= 1358) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_AbstractList_SubAbstractListRandomAccess_VT ju_AbstractList_SubAbstractListRandomAccess_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractList_SubAbstractListRandomAccess), sizeof(void*)),
                .flags = 0,
                .tag = 1356,
                .modifiers = 16,
                .name = NULL,
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_ju_AbstractList_SubAbstractListRandomAccess,
                .superclass = (TeaVM_Class*) &ju_AbstractList_SubAbstractList_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_hashCode = &meth_ju_AbstractList_hashCode,
            .virt_equals = &meth_ju_AbstractList_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_ju_AbstractCollection_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_forEach = &meth_jl_Iterable_forEach,
            .virt_iterator = &meth_ju_AbstractList_SubAbstractList_iterator,
            .virt_spliterator = &meth_ju_Collection_spliterator,
            .virt_remove_0 = &meth_ju_AbstractCollection_remove,
            .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
            .virt_size = &meth_ju_AbstractList_SubAbstractList_size,
            .virt_get = &meth_ju_AbstractList_SubAbstractList_get,
            .virt_stream = &meth_ju_Collection_stream,
            .virt_listIterator = &meth_ju_AbstractList_SubAbstractList_listIterator,
            .virt_removeIf = &meth_ju_Collection_removeIf,
            .virt_toArray = &meth_ju_AbstractCollection_toArray,
            .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
            .virt_subList = &meth_ju_AbstractList_subList,
            .virt_listIterator_0 = &meth_ju_AbstractList_listIterator_0,
            .virt_remove_1 = &meth_ju_AbstractList_SubAbstractList_remove,
            .virt_indexOf = &meth_ju_AbstractList_indexOf,
            .virt_add_2 = &meth_ju_AbstractList_add_0,
            .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
            .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
            .virt_contains = &meth_ju_AbstractCollection_contains
        }
    }
};
void sysinitclass_ju_AbstractList_SubAbstractListRandomAccess() {
}
