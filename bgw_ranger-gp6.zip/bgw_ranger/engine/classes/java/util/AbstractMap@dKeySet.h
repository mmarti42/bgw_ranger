#pragma once
#include "../../../runtime.h"
#include "AbstractSet.h"
#include "AbstractMap@dKeySet.h"

extern void sysinitclass_ju_AbstractMap_KeySet();
typedef struct cls_ju_AbstractMap_KeySet {
    struct cls_ju_AbstractSet parent;
    void* fld_this_0;
} cls_ju_AbstractMap_KeySet;
extern void meth_ju_AbstractMap_KeySet__init_(void*, void*);
extern void* meth_ju_AbstractMap_KeySet_iterator(void*);
extern int32_t meth_ju_AbstractMap_KeySet_size(void*);
extern int32_t meth_ju_AbstractMap_KeySet_contains(void*, void*);
extern int32_t meth_ju_AbstractMap_KeySet_remove(void*, void*);
extern int32_t supertypeof_ju_AbstractMap_KeySet(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractMap_KeySet_VT {
    ju_AbstractSet_VT parent;
} ju_AbstractMap_KeySet_VT;
extern ju_AbstractMap_KeySet_VT ju_AbstractMap_KeySet_Cls;
