#include "AbstractMap.h"
#include "../lang/Object.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "AbstractMap@dKeySet.h"
#include "AbstractMap@dValues.h"
#include "Map.h"
#include "Set.h"
#include "Iterator.h"
#include "Map@dEntry.h"
#include "Objects.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"

void meth_ju_AbstractMap__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(38663, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_AbstractMap_put(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38664, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(38665, meth_jl_UnsupportedOperationException__init__0(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(38666, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void* meth_ju_AbstractMap_keySet(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap, fld_cachedKeySet) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(38667, meth_otr_Allocator_allocate(&ju_AbstractMap_KeySet_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(38668, meth_ju_AbstractMap_KeySet__init_(teavm_local_1, teavm_this_));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap, fld_cachedKeySet) = teavm_local_1;
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap, fld_cachedKeySet);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_AbstractMap_values(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap, fld_cachedValues) == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(38669, meth_otr_Allocator_allocate(&ju_AbstractMap_Values_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(38670, meth_ju_AbstractMap_Values__init_(teavm_local_1, teavm_this_));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap, fld_cachedValues) = teavm_local_1;
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap, fld_cachedValues);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_AbstractMap_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void * volatile teavm_spill_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &ju_Map_Cls, &supertypeof_ju_Map))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38671, teavm_checkcast(teavm_local_1, &ju_Map_Cls, &supertypeof_ju_Map));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38672, TEAVM_METHOD(teavm_this_, ju_AbstractMap_VT, virt_size)(teavm_this_));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38673, teavm_nullCheck(teavm_local_3));
        if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(38674, TEAVM_METHOD(teavm_local_3, ju_Map_VT, virt_size)(teavm_local_3)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            TEAVM_TRY
                teavm_spill_5 = teavm_local_5;
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38675, TEAVM_METHOD(teavm_this_, ju_AbstractMap_VT, virt_entrySet)(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(38676, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(38677, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
                teavm_spill_5 = teavm_local_5;
            TEAVM_CATCH
                // CATCH java.lang.ClassCastException
                case 2: {
                    teavm_local_5 = teavm_spill_5;
                    goto teavm_label_2;
                    break;
                }
                // CATCH java.lang.NullPointerException
                case 1: {
                    teavm_local_5 = teavm_spill_5;
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
            TEAVM_TRY
                while (1) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
                    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(38678, teavm_nullCheck(teavm_local_5));
                    if ((!TEAVM_WITH_CALL_SITE_ID(38679, TEAVM_METHOD(teavm_local_5, ju_Iterator_VT, virt_hasNext)(teavm_local_5)))) {
                        goto teavm_label_5;
                    }
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38680, TEAVM_METHOD(teavm_local_5, ju_Iterator_VT, virt_next)(teavm_local_5));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(38681, teavm_checkcast(teavm_local_4, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(38682, teavm_nullCheck(teavm_local_6));
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38683, TEAVM_METHOD(teavm_local_6, ju_Map_Entry_VT, virt_getKey)(teavm_local_6));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
                    if ((!TEAVM_WITH_CALL_SITE_ID(38684, TEAVM_METHOD(teavm_local_3, ju_Map_VT, virt_containsKey)(teavm_local_3, teavm_local_4)))) {
                        TEAVM_RESTORE_JUMP_BUFFER;
                        goto teavm_label_3;
                    }
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38685, TEAVM_METHOD(teavm_local_6, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_6));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(38686, TEAVM_METHOD(teavm_local_6, ju_Map_Entry_VT, virt_getKey)(teavm_local_6));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(38687, TEAVM_METHOD(teavm_local_3, ju_Map_VT, virt_get_3)(teavm_local_3, teavm_local_7));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    if ((!TEAVM_WITH_CALL_SITE_ID(38688, meth_ju_Objects_equals(teavm_local_4, teavm_local_7)))) {
                        TEAVM_RESTORE_JUMP_BUFFER;
                        goto teavm_label_4;
                    }
                }
            teavm_label_5:;
            TEAVM_CATCH
                // CATCH java.lang.ClassCastException
                case 2: {
                    goto teavm_label_2;
                    break;
                }
                // CATCH java.lang.NullPointerException
                case 1: {
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
            teavm_local_2 = INT32_C(1);
            goto teavm_label_1;
        teavm_label_4:;
            TEAVM_TRY
                teavm_local_2 = INT32_C(0);
                TEAVM_RESTORE_JUMP_BUFFER;
                goto teavm_label_1;
            TEAVM_CATCH
                // CATCH java.lang.ClassCastException
                case 2: {
                    goto teavm_label_2;
                    break;
                }
                // CATCH java.lang.NullPointerException
                case 1: {
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
        teavm_label_3:;
            TEAVM_TRY
                teavm_local_2 = INT32_C(0);
                TEAVM_RESTORE_JUMP_BUFFER;
                goto teavm_label_1;
            TEAVM_CATCH
                // CATCH java.lang.ClassCastException
                case 2: {
                    goto teavm_label_2;
                    break;
                }
                // CATCH java.lang.NullPointerException
                case 1: {
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
        teavm_label_2:;
            teavm_local_2 = INT32_C(0);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_AbstractMap_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38689, TEAVM_METHOD(teavm_this_, ju_AbstractMap_VT, virt_entrySet)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38690, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(38691, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38692, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(38693, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_1;
        }
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38694, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38695, teavm_checkcast(teavm_local_2, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38696, teavm_nullCheck(teavm_local_4));
        teavm_local_1 = (teavm_local_1 + TEAVM_WITH_CALL_SITE_ID(38697, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_hashCode)(teavm_local_4)));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_AbstractMap_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(38698, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(38699, meth_jl_StringBuilder__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(38700, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(123)));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38701, TEAVM_METHOD(teavm_this_, ju_AbstractMap_VT, virt_entrySet)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38702, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(38703, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(38704, teavm_nullCheck(teavm_local_3));
    if (TEAVM_WITH_CALL_SITE_ID(38705, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38706, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38707, teavm_checkcast(teavm_local_2, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38708, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(38709, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getKey)(teavm_local_4)) != teavm_this_) ? TEAVM_WITH_CALL_SITE_ID(38710, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getKey)(teavm_local_4)) : TEAVM_GET_STRING(7951));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(38711, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_1)(teavm_local_1, teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(38712, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(61)));
        teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(38713, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_4)) != teavm_this_) ? TEAVM_WITH_CALL_SITE_ID(38714, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_4)) : TEAVM_GET_STRING(7951));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(38715, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_1)(teavm_local_1, teavm_local_2));
    }
    while (1) {
        if (!TEAVM_WITH_CALL_SITE_ID(38716, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3))) break;
        TEAVM_WITH_CALL_SITE_ID(38717, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_0)(teavm_local_1, TEAVM_GET_STRING(648)));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38718, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38719, teavm_checkcast(teavm_local_2, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(38720, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(38721, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getKey)(teavm_local_4)) != teavm_this_) ? TEAVM_WITH_CALL_SITE_ID(38722, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getKey)(teavm_local_4)) : TEAVM_GET_STRING(7951));
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(38723, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_1)(teavm_local_1, teavm_local_2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(38724, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(61)));
        teavm_local_2 = ((TEAVM_WITH_CALL_SITE_ID(38725, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_4)) != teavm_this_) ? TEAVM_WITH_CALL_SITE_ID(38726, TEAVM_METHOD(teavm_local_4, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_4)) : TEAVM_GET_STRING(7951));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(38727, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_1)(teavm_local_1, teavm_local_2));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(38728, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(125)));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(38729, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_toString)(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_AbstractMap(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1837 || tag >= 1869) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractMap_Cls[3];
alignas(8) ju_AbstractMap_VT ju_AbstractMap_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractMap), sizeof(void*)),
        .flags = 0,
        .tag = 1837,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractMap,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractMap_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_ju_AbstractMap_hashCode,
    .virt_equals = &meth_ju_AbstractMap_equals,
    .virt_toString = &meth_ju_AbstractMap_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getOrDefault = &meth_ju_Map_getOrDefault,
    .virt_putIfAbsent = &meth_ju_Map_putIfAbsent,
    .virt_forEach_0 = &meth_ju_Map_forEach,
    .virt_put = &meth_ju_AbstractMap_put,
    .virt_keySet = &meth_ju_AbstractMap_keySet,
    .virt_computeIfAbsent = &meth_ju_Map_computeIfAbsent,
    .virt_values = &meth_ju_AbstractMap_values,
    .virt_merge = &meth_ju_Map_merge
};
static int16_t teavm_classLayouts_ju_AbstractMap_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_ju_AbstractMap, fld_cachedKeySet), (int16_t) offsetof(cls_ju_AbstractMap, fld_cachedValues)
};
void sysinitclass_ju_AbstractMap() {
}
