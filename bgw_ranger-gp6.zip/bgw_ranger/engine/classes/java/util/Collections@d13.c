#include "Collections@d13.h"
#include "AbstractMap.h"
#include "Map.h"
#include "Collections.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../strings.h"
#include "../lang/Object.h"

void meth_ju_Collections_13__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_val_m) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(32592, meth_ju_AbstractMap__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Collections_13_entrySet(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_entrySetCache) == NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_val_m);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32593, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32594, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_entrySet)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(32595, meth_ju_Collections_unmodifiableMapEntrySet(teavm_local_1));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_entrySetCache) = teavm_local_1;
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_entrySetCache);
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collections_13_remove(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32596, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(32597, meth_jl_UnsupportedOperationException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(32598, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_Collections_13_containsKey(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_val_m);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(32599, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32600, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_containsKey)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Collections_13_size(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_val_m);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32601, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32602, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_size)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_Collections_13_get(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_val_m);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32603, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32604, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_get_3)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_Collections_13_isEmpty(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Collections_13, fld_val_m);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(32605, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(32606, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_VT, virt_isEmpty)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_Collections_13(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1862 || tag >= 1864) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Collections_13_Cls[3];
alignas(8) ju_Collections_13_VT ju_Collections_13_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_13), sizeof(void*)),
            .flags = 0,
            .tag = 1862,
            .modifiers = 0,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7597),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_Collections_13,
            .superclass = (TeaVM_Class*) &ju_AbstractMap_Cls,
            .layout = teavm_classLayouts_ju_Collections_13_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = (TeaVM_Class*) &ju_Collections_Cls,
            .init = NULL
        },
        .virt_hashCode = &meth_ju_AbstractMap_hashCode,
        .virt_equals = &meth_ju_AbstractMap_equals,
        .virt_toString = &meth_ju_AbstractMap_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_getOrDefault = &meth_ju_Map_getOrDefault,
        .virt_putIfAbsent = &meth_ju_Map_putIfAbsent,
        .virt_remove_2 = &meth_ju_Collections_13_remove,
        .virt_isEmpty = &meth_ju_Collections_13_isEmpty,
        .virt_size = &meth_ju_Collections_13_size,
        .virt_containsKey = &meth_ju_Collections_13_containsKey,
        .virt_forEach_0 = &meth_ju_Map_forEach,
        .virt_entrySet = &meth_ju_Collections_13_entrySet,
        .virt_put = &meth_ju_AbstractMap_put,
        .virt_get_3 = &meth_ju_Collections_13_get,
        .virt_keySet = &meth_ju_AbstractMap_keySet,
        .virt_computeIfAbsent = &meth_ju_Map_computeIfAbsent,
        .virt_values = &meth_ju_AbstractMap_values,
        .virt_merge = &meth_ju_Map_merge
    }
};
static int16_t teavm_classLayouts_ju_Collections_13_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_ju_Collections_13, fld_entrySetCache), (int16_t) offsetof(cls_ju_Collections_13, fld_val_m)
};
void sysinitclass_ju_Collections_13() {
}
