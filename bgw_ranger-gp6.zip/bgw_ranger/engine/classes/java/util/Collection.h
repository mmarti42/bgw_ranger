#pragma once
#include "../../../runtime.h"
#include "Collection.h"

extern void sysinitclass_ju_Collection();
extern void* meth_ju_Collection_spliterator(void*);
extern void* meth_ju_Collection_stream(void*);
extern int32_t meth_ju_Collection_removeIf(void*, void*);
extern int32_t supertypeof_ju_Collection(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collection_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_forEach)(void*, void*); // 11
    void* (*virt_iterator)(void*); // 12
    void* (*virt_spliterator)(void*); // 13
    int32_t (*virt_remove_0)(void*, void*); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    int32_t (*virt_size)(void*); // 17
    void (*pad1)(); // 18
    void (*pad2)(); // 19
    void (*pad3)(); // 20
    void (*virt_clear)(void*); // 21
    void* (*virt_stream)(void*); // 22
    int32_t (*virt_addAll_0)(void*, void*); // 23
    void (*pad4)(); // 24
    int32_t (*virt_removeIf)(void*, void*); // 25
    void (*pad5)(); // 26
    void (*pad6)(); // 27
    int32_t (*virt_removeAll)(void*, void*); // 28
    void (*pad7)(); // 29
    void (*pad8)(); // 30
    void (*pad9)(); // 31
    void (*pad10)(); // 32
    void (*pad11)(); // 33
    void (*pad12)(); // 34
    void (*pad13)(); // 35
    void (*pad14)(); // 36
    int32_t (*virt_add_2)(void*, void*); // 37
    void (*pad15)(); // 38
    void (*pad16)(); // 39
    void (*pad17)(); // 40
    void (*pad18)(); // 41
    void (*pad19)(); // 42
    void (*pad20)(); // 43
    void (*pad21)(); // 44
    void (*pad22)(); // 45
    void (*pad23)(); // 46
    int32_t (*virt_containsAll)(void*, void*); // 47
    int32_t (*virt_contains)(void*, void*); // 48
} ju_Collection_VT;
extern TeaVM_Class ju_Collection_Cls;
