#include "AbstractMap@dValues@d1.h"
#include "../lang/Object.h"
#include "Iterator.h"
#include "Map@dEntry.h"
#include "../../../strings.h"

void meth_ju_AbstractMap_Values_1__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values_1, fld_this_1) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values_1, fld_val_it) = teavm_local_2;
    TEAVM_WITH_CALL_SITE_ID(16, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractMap_Values_1_hasNext(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values_1, fld_val_it);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(17, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(18, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Iterator_VT, virt_hasNext)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_AbstractMap_Values_1_next(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values_1, fld_val_it);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(19, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(20, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Iterator_VT, virt_next)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(21, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(22, teavm_nullCheck(TEAVM_WITH_CALL_SITE_ID(23, teavm_checkcast(teavm_local_1, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry))))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Map_Entry_VT, virt_getValue_0)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_AbstractMap_Values_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 3 || tag >= 5) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractMap_Values_1_Cls[3];
alignas(8) ju_AbstractMap_Values_1_VT ju_AbstractMap_Values_1_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractMap_Values_1), sizeof(void*)),
        .flags = 0,
        .tag = 3,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractMap_Values_1,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractMap_Values_1_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_next = &meth_ju_AbstractMap_Values_1_next,
    .virt_hasNext = &meth_ju_AbstractMap_Values_1_hasNext
};
static int16_t teavm_classLayouts_ju_AbstractMap_Values_1_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_ju_AbstractMap_Values_1, fld_val_it), (int16_t) offsetof(cls_ju_AbstractMap_Values_1, fld_this_1)
};
void sysinitclass_ju_AbstractMap_Values_1() {
}
