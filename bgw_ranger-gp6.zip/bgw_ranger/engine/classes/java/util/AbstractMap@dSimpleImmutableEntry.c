#include "AbstractMap@dSimpleImmutableEntry.h"
#include "../lang/Object.h"
#include "Map@dEntry.h"
#include "Objects.h"
#include "../../../strings.h"

void meth_ju_AbstractMap_SimpleImmutableEntry__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(16253, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleImmutableEntry, fld_key) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleImmutableEntry, fld_value) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_ju_AbstractMap_SimpleImmutableEntry__init__0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(16254, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16255, TEAVM_METHOD(teavm_local_1, ju_Map_Entry_VT, virt_getKey)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(16256, TEAVM_METHOD(teavm_local_1, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(16257, meth_ju_AbstractMap_SimpleImmutableEntry__init_(teavm_this_, teavm_local_2, teavm_local_3));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_AbstractMap_SimpleImmutableEntry_getValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleImmutableEntry, fld_value);
}
void* meth_ju_AbstractMap_SimpleImmutableEntry_getKey(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleImmutableEntry, fld_key);
}
int32_t meth_ju_AbstractMap_SimpleImmutableEntry_hashCode(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleImmutableEntry, fld_key);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16258, meth_ju_Objects_hashCode(teavm_local_1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleImmutableEntry, fld_value);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = (teavm_local_2 ^ TEAVM_WITH_CALL_SITE_ID(16259, meth_ju_Objects_hashCode(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_AbstractMap_SimpleImmutableEntry(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 757 || tag >= 759) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractMap_SimpleImmutableEntry_Cls[3];
alignas(8) ju_AbstractMap_SimpleImmutableEntry_VT ju_AbstractMap_SimpleImmutableEntry_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractMap_SimpleImmutableEntry), sizeof(void*)),
        .flags = 0,
        .tag = 757,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractMap_SimpleImmutableEntry,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractMap_SimpleImmutableEntry_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_ju_AbstractMap_SimpleImmutableEntry_hashCode,
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_getKey = &meth_ju_AbstractMap_SimpleImmutableEntry_getKey,
    .virt_getValue_0 = &meth_ju_AbstractMap_SimpleImmutableEntry_getValue
};
static int16_t teavm_classLayouts_ju_AbstractMap_SimpleImmutableEntry_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_ju_AbstractMap_SimpleImmutableEntry, fld_key), (int16_t) offsetof(cls_ju_AbstractMap_SimpleImmutableEntry, fld_value)
};
void sysinitclass_ju_AbstractMap_SimpleImmutableEntry() {
}
