#include "AbstractMap@dSimpleEntry.h"
#include "../lang/Object.h"
#include "Map@dEntry.h"
#include "Objects.h"
#include "../lang/String.h"
#include "../lang/StringBuilder.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"

void meth_ju_AbstractMap_SimpleEntry__init_(void* teavm_this_, void* teavm_local_1, void* teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13360, meth_jl_Object__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_key) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_value) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void* meth_ju_AbstractMap_SimpleEntry_getValue(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_value);
}
void* meth_ju_AbstractMap_SimpleEntry_setValue(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_value);
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_value) = teavm_local_1;
    return teavm_local_2;
}
void* meth_ju_AbstractMap_SimpleEntry_getKey(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_key);
}
int32_t meth_ju_AbstractMap_SimpleEntry_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((teavm_this_ == teavm_local_1)) {
        teavm_local_2 = INT32_C(1);
    } else if ((!teavm_instanceof(teavm_local_1, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13361, teavm_checkcast(teavm_local_1, &ju_Map_Entry_Cls, &supertypeof_ju_Map_Entry));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_key);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13362, teavm_nullCheck(teavm_local_3));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13363, TEAVM_METHOD(teavm_local_3, ju_Map_Entry_VT, virt_getKey)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        if (TEAVM_WITH_CALL_SITE_ID(13364, meth_ju_Objects_equals(teavm_local_4, teavm_local_5))) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_value);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13365, TEAVM_METHOD(teavm_local_3, ju_Map_Entry_VT, virt_getValue_0)(teavm_local_3));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
            if (TEAVM_WITH_CALL_SITE_ID(13366, meth_ju_Objects_equals(teavm_local_4, teavm_local_5))) {
                goto teavm_label_2;
            }
        }
        teavm_local_2 = INT32_C(0);
        goto teavm_label_1;
    teavm_label_2:;
        teavm_local_2 = INT32_C(1);
    teavm_label_1:;
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_AbstractMap_SimpleEntry_hashCode(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_key);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13367, meth_ju_Objects_hashCode(teavm_local_1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_SimpleEntry, fld_value);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = (teavm_local_2 ^ TEAVM_WITH_CALL_SITE_ID(13368, meth_ju_Objects_hashCode(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_AbstractMap_SimpleEntry_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13369, TEAVM_METHOD(teavm_this_, ju_AbstractMap_SimpleEntry_VT, virt_getKey)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13370, meth_jl_String_valueOf(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13371, TEAVM_METHOD(teavm_this_, ju_AbstractMap_SimpleEntry_VT, virt_getValue_0)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13372, meth_jl_String_valueOf(teavm_local_2));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13373, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(13374, meth_jl_StringBuilder__init_(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13375, meth_jl_StringBuilder_append(teavm_local_3, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13376, meth_jl_StringBuilder_append_1(TEAVM_WITH_CALL_SITE_ID(13377, teavm_nullCheck(teavm_local_1)), INT32_C(61)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(13378, meth_jl_StringBuilder_append(TEAVM_WITH_CALL_SITE_ID(13379, teavm_nullCheck(teavm_local_1)), teavm_local_2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13380, meth_jl_StringBuilder_toString(teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_AbstractMap_SimpleEntry(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 591 || tag >= 595) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractMap_SimpleEntry_Cls[3];
alignas(8) ju_AbstractMap_SimpleEntry_VT ju_AbstractMap_SimpleEntry_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractMap_SimpleEntry), sizeof(void*)),
        .flags = 0,
        .tag = 591,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractMap_SimpleEntry,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractMap_SimpleEntry_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_ju_AbstractMap_SimpleEntry_hashCode,
    .virt_equals = &meth_ju_AbstractMap_SimpleEntry_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_ju_AbstractMap_SimpleEntry_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_setValue = &meth_ju_AbstractMap_SimpleEntry_setValue,
    .virt_getKey = &meth_ju_AbstractMap_SimpleEntry_getKey,
    .virt_getValue_0 = &meth_ju_AbstractMap_SimpleEntry_getValue
};
static int16_t teavm_classLayouts_ju_AbstractMap_SimpleEntry_Cls[3] = {
INT16_C(2), (int16_t) offsetof(cls_ju_AbstractMap_SimpleEntry, fld_key), (int16_t) offsetof(cls_ju_AbstractMap_SimpleEntry, fld_value)
};
void sysinitclass_ju_AbstractMap_SimpleEntry() {
}
