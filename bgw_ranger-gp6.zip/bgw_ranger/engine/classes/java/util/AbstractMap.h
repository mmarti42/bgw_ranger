#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "AbstractMap.h"

extern void sysinitclass_ju_AbstractMap();
typedef struct cls_ju_AbstractMap {
    struct TeaVM_Object parent;
    void* fld_cachedKeySet;
    void* fld_cachedValues;
} cls_ju_AbstractMap;
extern void meth_ju_AbstractMap__init_(void*);
extern void* meth_ju_AbstractMap_put(void*, void*, void*);
extern void* meth_ju_AbstractMap_keySet(void*);
extern void* meth_ju_AbstractMap_values(void*);
extern int32_t meth_ju_AbstractMap_equals(void*, void*);
extern int32_t meth_ju_AbstractMap_hashCode(void*);
extern void* meth_ju_AbstractMap_toString(void*);
extern int32_t supertypeof_ju_AbstractMap(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractMap_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_getOrDefault)(void*, void*, void*); // 11
    void* (*virt_putIfAbsent)(void*, void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_remove_2)(void*, void*); // 14
    void (*pad1)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    int32_t (*virt_size)(void*); // 17
    void (*pad2)(); // 18
    int32_t (*virt_containsKey)(void*, void*); // 19
    void (*virt_forEach_0)(void*, void*); // 20
    void (*virt_clear)(void*); // 21
    void* (*virt_entrySet)(void*); // 22
    void* (*virt_put)(void*, void*, void*); // 23
    void* (*virt_get_3)(void*, void*); // 24
    void (*pad3)(); // 25
    void (*pad4)(); // 26
    void (*virt_putAll)(void*, void*); // 27
    void* (*virt_keySet)(void*); // 28
    void (*pad5)(); // 29
    void (*pad6)(); // 30
    void* (*virt_computeIfAbsent)(void*, void*, void*); // 31
    void (*pad7)(); // 32
    void (*pad8)(); // 33
    void (*pad9)(); // 34
    void (*pad10)(); // 35
    void (*pad11)(); // 36
    void* (*virt_values)(void*); // 37
    void (*pad12)(); // 38
    void (*pad13)(); // 39
    void (*pad14)(); // 40
    void (*pad15)(); // 41
    void (*pad16)(); // 42
    void (*pad17)(); // 43
    void (*pad18)(); // 44
    void (*pad19)(); // 45
    void (*pad20)(); // 46
    void (*pad21)(); // 47
    void* (*virt_merge)(void*, void*, void*, void*); // 48
    void (*pad22)(); // 49
} ju_AbstractMap_VT;
extern ju_AbstractMap_VT ju_AbstractMap_Cls;
