#pragma once
#include "../../../runtime.h"
#include "AbstractList.h"
#include "AbstractList@dSubAbstractList.h"

extern void sysinitclass_ju_AbstractList_SubAbstractList();
typedef struct cls_ju_AbstractList_SubAbstractList {
    struct cls_ju_AbstractList parent;
    void* fld_fullList;
    int32_t fld_offset;
    int32_t fld_size;
} cls_ju_AbstractList_SubAbstractList;
extern void meth_ju_AbstractList_SubAbstractList__init_(void*, void*, int32_t, int32_t);
extern void* meth_ju_AbstractList_SubAbstractList_get(void*, int32_t);
extern void* meth_ju_AbstractList_SubAbstractList_iterator(void*);
extern void* meth_ju_AbstractList_SubAbstractList_listIterator(void*, int32_t);
extern void* meth_ju_AbstractList_SubAbstractList_remove(void*, int32_t);
extern int32_t meth_ju_AbstractList_SubAbstractList_size(void*);
extern int32_t supertypeof_ju_AbstractList_SubAbstractList(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractList_SubAbstractList_VT {
    ju_AbstractList_VT parent;
} ju_AbstractList_SubAbstractList_VT;
extern ju_AbstractList_SubAbstractList_VT ju_AbstractList_SubAbstractList_Cls;
