#pragma once
#include "../../../runtime.h"
#include "TemplateCollections@dAbstractImmutableList.h"
#include "Collections@d3.h"

extern void sysinitclass_ju_Collections_3();
typedef struct cls_ju_Collections_3 {
    struct cls_ju_TemplateCollections_AbstractImmutableList parent;
} cls_ju_Collections_3;
extern void meth_ju_Collections_3__init_(void*);
extern void* meth_ju_Collections_3_get(void*, int32_t);
extern int32_t meth_ju_Collections_3_size(void*);
extern void* meth_ju_Collections_3_iterator(void*);
extern void* meth_ju_Collections_3_listIterator(void*, int32_t);
extern int32_t meth_ju_Collections_3_isEmpty(void*);
extern int32_t supertypeof_ju_Collections_3(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_3_VT {
    ju_TemplateCollections_AbstractImmutableList_VT parent;
} ju_Collections_3_VT;
extern ju_Collections_3_VT ju_Collections_3_Cls;
