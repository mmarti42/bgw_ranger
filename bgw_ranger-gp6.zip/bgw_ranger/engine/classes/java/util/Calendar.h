#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Calendar.h"

extern void sysinitclass_ju_Calendar();
typedef struct cls_ju_Calendar {
    struct TeaVM_Object parent;
    int8_t fld_areFieldsSet;
    TeaVM_Array* fld_fields;
    TeaVM_Array* fld_isSet;
    int8_t fld_isTimeSet;
    int64_t fld_time;
    int32_t fld_lastTimeFieldSet;
    int32_t fld_lastDateFieldSet;
    int8_t fld_lenient;
    int32_t fld_firstDayOfWeek;
    int32_t fld_minimalDaysInFirstWeek;
    void* fld_zone;
} cls_ju_Calendar;
extern TeaVM_Array* sfld_ju_Calendar_fieldNames;
extern int32_t sfld_ju_Calendar_firstDayOfWeekCache;
extern int32_t sfld_ju_Calendar_minimalDaysInFirstWeekCache;
extern void* sfld_ju_Calendar_cacheFor;
extern void meth_ju_Calendar__init_(void*, void*);
extern void meth_ju_Calendar__init__0(void*, void*, void*);
extern int32_t meth_ju_Calendar_resolveFirstDayOfWeek(void*);
extern int32_t meth_ju_Calendar_resolveMinimalDaysInFirstWeek(void*);
extern int32_t meth_ju_Calendar_after(void*, void*);
extern int32_t meth_ju_Calendar_before(void*, void*);
extern void meth_ju_Calendar_clear(void*);
extern void* meth_ju_Calendar_clone(void*);
extern void meth_ju_Calendar_complete(void*);
extern int32_t meth_ju_Calendar_get(void*, int32_t);
extern int32_t meth_ju_Calendar_getFirstDayOfWeek(void*);
extern void* meth_ju_Calendar_getInstance();
extern void* meth_ju_Calendar_getInstance_0(void*);
extern int32_t meth_ju_Calendar_getMinimalDaysInFirstWeek(void*);
extern void* meth_ju_Calendar_getTime(void*);
extern int64_t meth_ju_Calendar_getTimeInMillis(void*);
extern void* meth_ju_Calendar_getTimeZone(void*);
extern void meth_ju_Calendar_setTimeZone(void*, void*);
extern int32_t meth_ju_Calendar_isLenient(void*);
extern void meth_ju_Calendar_set(void*, int32_t, int32_t);
extern void meth_ju_Calendar_setFirstDayOfWeek(void*, int32_t);
extern void meth_ju_Calendar_setLenient(void*, int32_t);
extern void meth_ju_Calendar_setMinimalDaysInFirstWeek(void*, int32_t);
extern void meth_ju_Calendar_setTime(void*, void*);
extern void meth_ju_Calendar_setTimeInMillis(void*, int64_t);
extern int32_t meth_ju_Calendar_compareTo(void*, void*);
extern void meth_ju_Calendar__clinit_();
extern void initclass_ju_Calendar();
extern int32_t supertypeof_ju_Calendar(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Calendar_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_get_2)(void*, int32_t); // 11
    int32_t (*virt_compareTo)(void*, void*); // 12
    int32_t (*virt_getMinimalDaysInFirstWeek)(void*); // 13
    void (*virt_set_1)(void*, int32_t, int32_t); // 14
    void (*pad0)(); // 15
    void (*virt_setLenient)(void*, int32_t); // 16
    void (*virt_setTimeInMillis)(void*, int64_t); // 17
    void (*pad1)(); // 18
    void* (*virt_getTimeZone)(void*); // 19
    void (*virt_setTimeZone)(void*, void*); // 20
    void (*virt_clear)(void*); // 21
    void (*virt_computeTime)(void*); // 22
    void (*virt_add_3)(void*, int32_t, int32_t); // 23
    int32_t (*virt_after)(void*, void*); // 24
    void (*virt_computeFields)(void*); // 25
    void (*virt_complete)(void*); // 26
    int32_t (*virt_getActualMaximum)(void*, int32_t); // 27
    int64_t (*virt_getTimeInMillis)(void*); // 28
    void* (*virt_getTime_0)(void*); // 29
    void (*virt_setTime)(void*, void*); // 30
    int32_t (*virt_getFirstDayOfWeek)(void*); // 31
    void (*pad2)(); // 32
    void (*pad3)(); // 33
    void (*pad4)(); // 34
    void (*pad5)(); // 35
    void (*pad6)(); // 36
    void (*virt_setFirstDayOfWeek)(void*, int32_t); // 37
    int32_t (*virt_isLenient)(void*); // 38
    void (*pad7)(); // 39
    void (*pad8)(); // 40
    void (*pad9)(); // 41
    void (*pad10)(); // 42
    void (*pad11)(); // 43
    void (*pad12)(); // 44
    void (*pad13)(); // 45
    void (*pad14)(); // 46
    void (*virt_setMinimalDaysInFirstWeek)(void*, int32_t); // 47
    int32_t (*virt_compareTo_2)(void*, void*); // 48
    int32_t (*virt_before)(void*, void*); // 49
} ju_Calendar_VT;
extern ju_Calendar_VT ju_Calendar_Cls;
