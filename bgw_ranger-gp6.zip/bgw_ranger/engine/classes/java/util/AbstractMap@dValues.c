#include "AbstractMap@dValues.h"
#include "AbstractCollection.h"
#include "AbstractMap.h"
#include "Set.h"
#include "AbstractMap@dValues@d1.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_AbstractMap_Values__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values, fld_this_0) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(44633, meth_ju_AbstractCollection__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractMap_Values_size(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44634, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(44635, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractMap_VT, virt_size)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_AbstractMap_Values_iterator(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_Values, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44636, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(44637, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractMap_VT, virt_entrySet)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44638, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(44639, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44640, meth_otr_Allocator_allocate(&ju_AbstractMap_Values_1_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(44641, meth_ju_AbstractMap_Values_1__init_(teavm_local_1, teavm_this_, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t supertypeof_ju_AbstractMap_Values(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1364 || tag >= 1366) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractMap_Values_Cls[2];
alignas(8) ju_AbstractMap_Values_VT ju_AbstractMap_Values_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractMap_Values), sizeof(void*)),
            .flags = 0,
            .tag = 1364,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_AbstractMap_Values,
            .superclass = (TeaVM_Class*) &ju_AbstractCollection_Cls,
            .layout = teavm_classLayouts_ju_AbstractMap_Values_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_ju_AbstractCollection_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_forEach = &meth_jl_Iterable_forEach,
        .virt_iterator = &meth_ju_AbstractMap_Values_iterator,
        .virt_spliterator = &meth_ju_Collection_spliterator,
        .virt_remove_0 = &meth_ju_AbstractCollection_remove,
        .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
        .virt_size = &meth_ju_AbstractMap_Values_size,
        .virt_stream = &meth_ju_Collection_stream,
        .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
        .virt_removeIf = &meth_ju_Collection_removeIf,
        .virt_toArray = &meth_ju_AbstractCollection_toArray,
        .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
        .virt_add_2 = &meth_ju_AbstractCollection_add,
        .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
        .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
        .virt_contains = &meth_ju_AbstractCollection_contains
    }
};
static int16_t teavm_classLayouts_ju_AbstractMap_Values_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_AbstractMap_Values, fld_this_0)
};
void sysinitclass_ju_AbstractMap_Values() {
}
