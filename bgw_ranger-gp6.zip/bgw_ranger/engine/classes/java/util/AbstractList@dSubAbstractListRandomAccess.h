#pragma once
#include "../../../runtime.h"
#include "AbstractList@dSubAbstractList.h"
#include "AbstractList@dSubAbstractListRandomAccess.h"

extern void sysinitclass_ju_AbstractList_SubAbstractListRandomAccess();
typedef struct cls_ju_AbstractList_SubAbstractListRandomAccess {
    struct cls_ju_AbstractList_SubAbstractList parent;
} cls_ju_AbstractList_SubAbstractListRandomAccess;
extern void meth_ju_AbstractList_SubAbstractListRandomAccess__init_(void*, void*, int32_t, int32_t);
extern int32_t supertypeof_ju_AbstractList_SubAbstractListRandomAccess(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractList_SubAbstractListRandomAccess_VT {
    ju_AbstractList_SubAbstractList_VT parent;
} ju_AbstractList_SubAbstractListRandomAccess_VT;
extern ju_AbstractList_SubAbstractListRandomAccess_VT ju_AbstractList_SubAbstractListRandomAccess_Cls;
