#include "ArrayList.h"
#include "AbstractList.h"
#include "../../../arrayclass.h"
#include "../lang/Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/IllegalArgumentException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Collection.h"
#include "Iterator.h"
#include "../lang/Math.h"
#include "Arrays.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "../../../strings.h"
#include "../lang/StringBuilder.h"
#include "Objects.h"
#include "AbstractCollection.h"

void meth_ju_ArrayList__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30034, meth_ju_ArrayList__init__1(teavm_this_, INT32_C(10)));
    TEAVM_RELEASE_STACK;
}
void meth_ju_ArrayList__init__1(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30035, meth_ju_AbstractList__init_(teavm_this_));
    if ((teavm_local_1 >= INT32_C(0))) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30036, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), teavm_local_1));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array) = teavm_local_2;
        TEAVM_RELEASE_STACK;
        return;
    }
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30037, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(30038, meth_jl_IllegalArgumentException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(30039, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void meth_ju_ArrayList__init__0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30040, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(30041, meth_ju_ArrayList__init__1(teavm_this_, TEAVM_WITH_CALL_SITE_ID(30042, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_size)(teavm_local_1))));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30043, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_iterator)(teavm_local_1));
    teavm_local_3 = INT32_C(0);
    while (1) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        if ((teavm_local_3 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(30044, teavm_nullCheck(teavm_local_4))))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30045, teavm_nullCheck(teavm_local_2));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(30046, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(30047, teavm_nullCheck(teavm_local_4));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30048, teavm_checkBounds(teavm_local_3, teavm_local_4));
        teavm_gc_writeBarrier(teavm_local_4);
        TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_3) = teavm_local_5;
        teavm_local_3 = (teavm_local_3 + INT32_C(1));
    }
teavm_label_1:;
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(30049, teavm_nullCheck(teavm_local_4)));
    TEAVM_RELEASE_STACK;
}
void meth_ju_ArrayList_ensureCapacity(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(30050, teavm_nullCheck(teavm_local_2))) < teavm_local_1)) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(30051, teavm_nullCheck(teavm_local_2))) >= INT32_C(1073741823))) {
            teavm_local_3 = INT32_C(2147483647);
        } else {
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_4 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(30052, teavm_nullCheck(teavm_local_2))) * INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30053, meth_jl_Math_max(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(30054, meth_jl_Math_max(teavm_local_4, INT32_C(5)))));
        }
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30055, meth_ju_Arrays_copyOf(teavm_local_2, teavm_local_3));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array) = teavm_local_2;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_ju_ArrayList_get(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30056, meth_ju_ArrayList_checkIndex(teavm_this_, teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30057, teavm_nullCheck(teavm_local_2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30058, teavm_checkBounds(teavm_local_1, teavm_local_2));
    teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_ArrayList_size(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size);
}
void* meth_ju_ArrayList_set(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    TeaVM_Array* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(30059, meth_ju_ArrayList_checkIndex(teavm_this_, teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30060, teavm_nullCheck(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30061, teavm_checkBounds(teavm_local_1, teavm_local_3));
    teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_1);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30062, teavm_nullCheck(teavm_local_3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30063, teavm_checkUpperBound(teavm_local_1, teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_1) = teavm_local_2;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_ArrayList_add(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(30064, TEAVM_METHOD(teavm_this_, ju_ArrayList_VT, virt_ensureCapacity)(teavm_this_, teavm_local_2));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) = (teavm_local_4 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30065, teavm_nullCheck(teavm_local_3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30066, teavm_checkBounds(teavm_local_4, teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) + INT32_C(1));
    TEAVM_RELEASE_STACK;
    return INT32_C(1);
}
void meth_ju_ArrayList_add_0(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(30067, meth_ju_ArrayList_checkIndexForAdd(teavm_this_, teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(30068, TEAVM_METHOD(teavm_this_, ju_ArrayList_VT, virt_ensureCapacity)(teavm_this_, (TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) + INT32_C(1))));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size);
    while (1) {
        if (!(teavm_local_3 > teavm_local_1)) break;
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        teavm_local_6 = (teavm_local_3 - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(30069, teavm_nullCheck(teavm_local_5));
        teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_5, void*, TEAVM_WITH_CALL_SITE_ID(30070, teavm_checkBounds(teavm_local_6, teavm_local_5)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(30071, teavm_nullCheck(teavm_local_4));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30072, teavm_checkBounds(teavm_local_3, teavm_local_5));
        teavm_gc_writeBarrier(teavm_local_5);
        TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_3) = teavm_local_7;
        teavm_local_3 = (teavm_local_3 + -INT32_C(1));
    }
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(30073, teavm_nullCheck(teavm_local_5));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30074, teavm_checkBounds(teavm_local_1, teavm_local_5));
    teavm_gc_writeBarrier(teavm_local_5);
    TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_1) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) + INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) + INT32_C(1));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_ArrayList_remove(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(30075, meth_ju_ArrayList_checkIndex(teavm_this_, teavm_local_1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30076, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30077, teavm_checkBounds(teavm_local_1, teavm_local_2));
    teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_3);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) - INT32_C(1));
    while (1) {
        if (!(teavm_local_3 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size))) break;
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        teavm_local_6 = (teavm_local_3 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30078, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(30079, teavm_checkBounds(teavm_local_6, teavm_local_2));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30080, teavm_nullCheck(teavm_local_5));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30081, teavm_checkBounds(teavm_local_3, teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_3) = teavm_local_8;
        teavm_local_3 = teavm_local_7;
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size);
    teavm_local_8 = NULL;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30082, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(30083, teavm_checkBounds(teavm_local_9, teavm_local_2))) = teavm_local_8;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) + INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_ArrayList_remove_0(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30084, TEAVM_METHOD(teavm_this_, ju_ArrayList_VT, virt_indexOf)(teavm_this_, teavm_local_1));
    if ((teavm_local_2 < INT32_C(0))) {
        teavm_local_3 = INT32_C(0);
    } else {
        TEAVM_WITH_CALL_SITE_ID(30085, TEAVM_METHOD(teavm_this_, ju_ArrayList_VT, virt_remove_1)(teavm_this_, teavm_local_2));
        teavm_local_3 = INT32_C(1);
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_ju_ArrayList_clear(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size);
    teavm_local_3 = NULL;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(30086, meth_ju_Arrays_fill_5(teavm_local_1, INT32_C(0), teavm_local_2, teavm_local_3));
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) + INT32_C(1));
    TEAVM_RELEASE_STACK;
}
void meth_ju_ArrayList_checkIndex(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size)))) {
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30087, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(30088, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(30089, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void meth_ju_ArrayList_checkIndexForAdd(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (((teavm_local_1 >= INT32_C(0)) && (teavm_local_1 <= TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size)))) {
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30090, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(30091, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(30092, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void* meth_ju_ArrayList_toString(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((!TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size))) {
        teavm_local_1 = TEAVM_GET_STRING(514);
    } else {
        teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) - INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(30093, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size) * INT32_C(16));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(30094, meth_jl_StringBuilder__init__0(teavm_local_3, teavm_local_4));
        TEAVM_WITH_CALL_SITE_ID(30095, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_28)(teavm_local_3, INT32_C(91)));
        teavm_local_5 = INT32_C(0);
        while (1) {
            if (!(teavm_local_5 < teavm_local_2)) break;
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(30096, teavm_nullCheck(teavm_local_6));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(30097, teavm_checkBounds(teavm_local_5, teavm_local_6));
            if ((TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_5) == teavm_this_)) {
                teavm_local_1 = TEAVM_GET_STRING(7034);
            } else {
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(30098, teavm_nullCheck(teavm_local_6));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(30099, teavm_checkUpperBound(teavm_local_5, teavm_local_6));
                teavm_local_1 = TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_5);
            }
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30100, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_1)(teavm_local_3, teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(30101, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(30102, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, TEAVM_GET_STRING(648))));
            teavm_local_5 = (teavm_local_5 + INT32_C(1));
        }
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(30103, teavm_nullCheck(teavm_local_6));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30104, teavm_checkBounds(teavm_local_2, teavm_local_6));
        if ((TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_2) == teavm_this_)) {
            teavm_local_1 = TEAVM_GET_STRING(7034);
        } else {
            teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(30105, teavm_nullCheck(teavm_local_6));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30106, teavm_checkUpperBound(teavm_local_2, teavm_local_6));
            teavm_local_1 = TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_2);
        }
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(30107, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_1)(teavm_local_3, teavm_local_1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30108, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_28)(teavm_local_3, INT32_C(93)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(30109, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(30110, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_ArrayList_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = INT32_C(1);
    teavm_local_2 = INT32_C(0);
    while (1) {
        if (!(teavm_local_2 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size))) break;
        teavm_local_3 = (INT32_C(31) * teavm_local_1);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(30111, teavm_nullCheck(teavm_local_4));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(30112, teavm_checkBounds(teavm_local_2, teavm_local_4));
        teavm_local_5 = TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_1 = (teavm_local_3 + TEAVM_WITH_CALL_SITE_ID(30113, meth_ju_Objects_hashCode(teavm_local_5)));
        teavm_local_2 = (teavm_local_2 + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ju_ArrayList_sort(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_array);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayList, fld_size);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(30114, meth_ju_Arrays_sort_0(teavm_local_2, INT32_C(0), teavm_local_3, teavm_local_1));
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount) + INT32_C(1));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ju_ArrayList(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1359 || tag >= 1361) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_ArrayList_Cls[2];
alignas(8) ju_ArrayList_VT ju_ArrayList_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_ArrayList), sizeof(void*)),
        .flags = 0,
        .tag = 1359,
        .modifiers = 1,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7485),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_ArrayList,
        .superclass = (TeaVM_Class*) &ju_AbstractList_Cls,
        .layout = teavm_classLayouts_ju_ArrayList_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_ju_ArrayList_hashCode,
    .virt_equals = &meth_ju_AbstractList_equals,
    .virt_toString = &meth_ju_ArrayList_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_iterator = &meth_ju_AbstractList_iterator,
    .virt_spliterator = &meth_ju_Collection_spliterator,
    .virt_remove_0 = &meth_ju_ArrayList_remove_0,
    .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
    .virt_size = &meth_ju_ArrayList_size,
    .virt_get = &meth_ju_ArrayList_get,
    .virt_sort = &meth_ju_ArrayList_sort,
    .virt_clear = &meth_ju_ArrayList_clear,
    .virt_stream = &meth_ju_Collection_stream,
    .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
    .virt_listIterator = &meth_ju_AbstractList_listIterator,
    .virt_removeIf = &meth_ju_Collection_removeIf,
    .virt_toArray = &meth_ju_AbstractCollection_toArray,
    .virt_ensureCapacity = &meth_ju_ArrayList_ensureCapacity,
    .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
    .virt_subList = &meth_ju_AbstractList_subList,
    .virt_listIterator_0 = &meth_ju_AbstractList_listIterator_0,
    .virt_add_1 = &meth_ju_ArrayList_add_0,
    .virt_remove_1 = &meth_ju_ArrayList_remove,
    .virt_indexOf = &meth_ju_AbstractList_indexOf,
    .virt_add_2 = &meth_ju_ArrayList_add,
    .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
    .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
    .virt_contains = &meth_ju_AbstractCollection_contains,
    .virt_set = &meth_ju_ArrayList_set
};
static int16_t teavm_classLayouts_ju_ArrayList_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_ArrayList, fld_array)
};
void sysinitclass_ju_ArrayList() {
}
