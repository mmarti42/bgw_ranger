#include "Collection.h"
#include "stream/impl/SpliteratorOverCollection.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "stream/impl/StreamOverSpliterator.h"
#include "Iterator.h"
#include "function/Predicate.h"
#include "../../../strings.h"

void* meth_ju_Collection_spliterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36976, meth_otr_Allocator_allocate(&jusi_SpliteratorOverCollection_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(36977, meth_jusi_SpliteratorOverCollection__init_(teavm_local_1, teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_Collection_stream(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36978, meth_otr_Allocator_allocate(&jusi_StreamOverSpliterator_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36979, TEAVM_METHOD(teavm_this_, ju_Collection_VT, virt_spliterator)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(36980, meth_jusi_StreamOverSpliterator__init_(teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_Collection_removeIf(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36981, TEAVM_METHOD(teavm_this_, ju_Collection_VT, virt_iterator)(teavm_this_));
    teavm_local_3 = INT32_C(0);
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(36982, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(36983, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(36984, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(36985, teavm_nullCheck(teavm_local_1));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(36986, TEAVM_METHOD(teavm_local_1, juf_Predicate_VT, virt_test)(teavm_local_1, teavm_local_4));
        if (teavm_local_5) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(36987, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_remove)(teavm_local_2));
            teavm_local_3 = INT32_C(1);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t supertypeof_ju_Collection(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1289 || tag >= 1579) return INT32_C(0);
    if (tag >= 1367 && tag < 1573) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) TeaVM_Class ju_Collection_Cls = {
    .size = 0,
    .flags = 0,
    .tag = 1289,
    .modifiers = 1537,
    .name = NULL,
    .simpleName = NULL,
    .arrayType = NULL,
    .itemType = NULL,
    .isSupertypeOf = &supertypeof_ju_Collection,
    .superclass = NULL,
    .layout = NULL,
    .enumValues = NULL,
    .declaringClass = NULL,
    .enclosingClass = NULL,
    .init = NULL
};
void sysinitclass_ju_Collection() {
}
