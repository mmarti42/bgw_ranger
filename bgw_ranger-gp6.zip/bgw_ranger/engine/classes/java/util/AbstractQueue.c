#include "AbstractQueue.h"
#include "AbstractCollection.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_AbstractQueue__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(16835, meth_ju_AbstractCollection__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ju_AbstractQueue(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1336 || tag >= 1340) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_AbstractQueue_VT ju_AbstractQueue_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractQueue), sizeof(void*)),
        .flags = 0,
        .tag = 1336,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractQueue,
        .superclass = (TeaVM_Class*) &ju_AbstractCollection_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_ju_AbstractCollection_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_forEach = &meth_jl_Iterable_forEach,
    .virt_spliterator = &meth_ju_Collection_spliterator,
    .virt_remove_0 = &meth_ju_AbstractCollection_remove,
    .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
    .virt_stream = &meth_ju_Collection_stream,
    .virt_removeIf = &meth_ju_Collection_removeIf,
    .virt_toArray = &meth_ju_AbstractCollection_toArray,
    .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
    .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
    .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
    .virt_contains = &meth_ju_AbstractCollection_contains
};
void sysinitclass_ju_AbstractQueue() {
}
