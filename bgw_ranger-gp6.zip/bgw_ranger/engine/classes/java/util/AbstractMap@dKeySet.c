#include "AbstractMap@dKeySet.h"
#include "AbstractSet.h"
#include "AbstractMap.h"
#include "Set.h"
#include "AbstractMap@dKeySet@d1.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_AbstractMap_KeySet__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_KeySet, fld_this_0) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(29117, meth_ju_AbstractSet__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_AbstractMap_KeySet_iterator(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_KeySet, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(29118, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(29119, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractMap_VT, virt_entrySet)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(29120, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(29121, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_Set_VT, virt_iterator)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(29122, meth_otr_Allocator_allocate(&ju_AbstractMap_KeySet_1_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(29123, meth_ju_AbstractMap_KeySet_1__init_(teavm_local_1, teavm_this_, teavm_local_2));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_AbstractMap_KeySet_size(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_KeySet, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(29124, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(29125, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractMap_VT, virt_size)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_AbstractMap_KeySet_contains(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_KeySet, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(29126, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(29127, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractMap_VT, virt_containsKey)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_AbstractMap_KeySet_remove(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractMap_KeySet, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = ((TEAVM_WITH_CALL_SITE_ID(29128, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(29129, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractMap_VT, virt_remove_2)(teavm_tmp_ptr_0, teavm_local_1))) == NULL) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t supertypeof_ju_AbstractMap_KeySet(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1323 || tag >= 1325) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractMap_KeySet_Cls[2];
alignas(8) ju_AbstractMap_KeySet_VT ju_AbstractMap_KeySet_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractMap_KeySet), sizeof(void*)),
                .flags = 0,
                .tag = 1323,
                .modifiers = 0,
                .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7385),
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_ju_AbstractMap_KeySet,
                .superclass = (TeaVM_Class*) &ju_AbstractSet_Cls,
                .layout = teavm_classLayouts_ju_AbstractMap_KeySet_Cls,
                .enumValues = NULL,
                .declaringClass = (TeaVM_Class*) &ju_AbstractMap_Cls,
                .enclosingClass = (TeaVM_Class*) &ju_AbstractMap_Cls,
                .init = NULL
            },
            .virt_hashCode = &meth_ju_AbstractSet_hashCode,
            .virt_equals = &meth_ju_AbstractSet_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_ju_AbstractCollection_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0,
            .virt_forEach = &meth_jl_Iterable_forEach,
            .virt_iterator = &meth_ju_AbstractMap_KeySet_iterator,
            .virt_spliterator = &meth_ju_Collection_spliterator,
            .virt_remove_0 = &meth_ju_AbstractMap_KeySet_remove,
            .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
            .virt_size = &meth_ju_AbstractMap_KeySet_size,
            .virt_stream = &meth_ju_Collection_stream,
            .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
            .virt_removeIf = &meth_ju_Collection_removeIf,
            .virt_toArray = &meth_ju_AbstractCollection_toArray,
            .virt_removeAll = &meth_ju_AbstractSet_removeAll,
            .virt_add_2 = &meth_ju_AbstractCollection_add,
            .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
            .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
            .virt_contains = &meth_ju_AbstractMap_KeySet_contains
        }
    }
};
static int16_t teavm_classLayouts_ju_AbstractMap_KeySet_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_AbstractMap_KeySet, fld_this_0)
};
void sysinitclass_ju_AbstractMap_KeySet() {
}
