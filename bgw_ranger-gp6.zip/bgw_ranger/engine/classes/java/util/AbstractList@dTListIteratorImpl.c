#include "AbstractList@dTListIteratorImpl.h"
#include "../lang/Object.h"
#include "AbstractList.h"
#include "NoSuchElementException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/IllegalStateException.h"
#include "ConcurrentModificationException.h"
#include "../../../strings.h"

void meth_ju_AbstractList_TListIteratorImpl__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3, int32_t teavm_local_4) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0) = teavm_local_1;
    TEAVM_WITH_CALL_SITE_ID(16220, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) = -INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_lastModCount) = teavm_local_3;
    TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_sz) = teavm_local_4;
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractList_TListIteratorImpl_hasNext(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) >= TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_sz)) ? INT32_C(0) : INT32_C(1));
}
void* meth_ju_AbstractList_TListIteratorImpl_next(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(16221, meth_ju_AbstractList_TListIteratorImpl_checkConcurrentModification(teavm_this_));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) != TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_sz))) {
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i);
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i);
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) = (teavm_local_2 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(16222, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(16223, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_get)(teavm_tmp_ptr_0, teavm_local_2)));
        TEAVM_RELEASE_STACK;
        return teavm_local_1;
    }
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(16224, meth_otr_Allocator_allocate(&ju_NoSuchElementException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(16225, meth_ju_NoSuchElementException__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(16226, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void meth_ju_AbstractList_TListIteratorImpl_remove(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) != -INT32_C(1))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(16227, meth_ju_AbstractList_TListIteratorImpl_checkConcurrentModification(teavm_this_));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(16228, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(16229, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_remove_1)(teavm_tmp_ptr_0, teavm_local_2)));
        if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) < TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i))) {
            TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) - INT32_C(1));
        }
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_sz) = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_sz) - INT32_C(1));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_lastModCount) = TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(16230, teavm_nullCheck(teavm_local_1)), cls_ju_AbstractList, fld_modCount);
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) = -INT32_C(1);
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(16231, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(16232, meth_jl_IllegalStateException__init__0(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(16233, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_AbstractList_TListIteratorImpl_hasPrevious(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) <= INT32_C(0)) ? INT32_C(0) : INT32_C(1));
}
void* meth_ju_AbstractList_TListIteratorImpl_previous(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(16234, meth_ju_AbstractList_TListIteratorImpl_checkConcurrentModification(teavm_this_));
    teavm_local_1 = (TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) - INT32_C(1));
    if ((teavm_local_1 >= INT32_C(0))) {
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i) = teavm_local_1;
        TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) = teavm_local_1;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16235, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(16236, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_get)(teavm_tmp_ptr_0, teavm_local_1)));
        TEAVM_RELEASE_STACK;
        return teavm_local_2;
    }
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16237, meth_otr_Allocator_allocate(&ju_NoSuchElementException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(16238, meth_ju_NoSuchElementException__init_(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(16239, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_AbstractList_TListIteratorImpl_nextIndex(void* teavm_this_) {
    return TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_i);
}
void meth_ju_AbstractList_TListIteratorImpl_set(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j) != -INT32_C(1))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(16240, meth_ju_AbstractList_TListIteratorImpl_checkConcurrentModification(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_j);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(16241, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(16242, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ju_AbstractList_VT, virt_set)(teavm_tmp_ptr_0, teavm_local_3, teavm_local_1)));
        TEAVM_RELEASE_STACK;
        return;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16243, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(16244, meth_jl_IllegalStateException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(16245, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void meth_ju_AbstractList_TListIteratorImpl_checkConcurrentModification(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_lastModCount);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList_TListIteratorImpl, fld_this_0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    if ((teavm_local_1 != TEAVM_FIELD(TEAVM_WITH_CALL_SITE_ID(16246, teavm_nullCheck(teavm_local_2)), cls_ju_AbstractList, fld_modCount))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(16247, meth_otr_Allocator_allocate(&ju_ConcurrentModificationException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(16248, meth_ju_ConcurrentModificationException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(16249, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ju_AbstractList_TListIteratorImpl(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 753 || tag >= 755) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_AbstractList_TListIteratorImpl_Cls[2];
alignas(8) ju_AbstractList_TListIteratorImpl_VT ju_AbstractList_TListIteratorImpl_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractList_TListIteratorImpl), sizeof(void*)),
        .flags = 0,
        .tag = 753,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractList_TListIteratorImpl,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_ju_AbstractList_TListIteratorImpl_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_remove = &meth_ju_AbstractList_TListIteratorImpl_remove,
    .virt_next = &meth_ju_AbstractList_TListIteratorImpl_next,
    .virt_hasNext = &meth_ju_AbstractList_TListIteratorImpl_hasNext,
    .virt_nextIndex = &meth_ju_AbstractList_TListIteratorImpl_nextIndex,
    .virt_hasPrevious = &meth_ju_AbstractList_TListIteratorImpl_hasPrevious,
    .virt_set_2 = &meth_ju_AbstractList_TListIteratorImpl_set,
    .virt_previous = &meth_ju_AbstractList_TListIteratorImpl_previous
};
static int16_t teavm_classLayouts_ju_AbstractList_TListIteratorImpl_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_AbstractList_TListIteratorImpl, fld_this_0)
};
void sysinitclass_ju_AbstractList_TListIteratorImpl() {
}
