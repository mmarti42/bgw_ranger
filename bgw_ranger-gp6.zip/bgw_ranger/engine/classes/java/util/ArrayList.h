#pragma once
#include "../../../runtime.h"
#include "AbstractList.h"
#include "ArrayList.h"

extern void sysinitclass_ju_ArrayList();
typedef struct cls_ju_ArrayList {
    struct cls_ju_AbstractList parent;
    TeaVM_Array* fld_array;
    int32_t fld_size;
} cls_ju_ArrayList;
extern void meth_ju_ArrayList__init_(void*);
extern void meth_ju_ArrayList__init__1(void*, int32_t);
extern void meth_ju_ArrayList__init__0(void*, void*);
extern void meth_ju_ArrayList_ensureCapacity(void*, int32_t);
extern void* meth_ju_ArrayList_get(void*, int32_t);
extern int32_t meth_ju_ArrayList_size(void*);
extern void* meth_ju_ArrayList_set(void*, int32_t, void*);
extern int32_t meth_ju_ArrayList_add(void*, void*);
extern void meth_ju_ArrayList_add_0(void*, int32_t, void*);
extern void* meth_ju_ArrayList_remove(void*, int32_t);
extern int32_t meth_ju_ArrayList_remove_0(void*, void*);
extern void meth_ju_ArrayList_clear(void*);
extern void meth_ju_ArrayList_checkIndex(void*, int32_t);
extern void meth_ju_ArrayList_checkIndexForAdd(void*, int32_t);
extern void* meth_ju_ArrayList_toString(void*);
extern int32_t meth_ju_ArrayList_hashCode(void*);
extern void meth_ju_ArrayList_sort(void*, void*);
extern int32_t supertypeof_ju_ArrayList(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_ArrayList_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_forEach)(void*, void*); // 11
    void* (*virt_iterator)(void*); // 12
    void* (*virt_spliterator)(void*); // 13
    int32_t (*virt_remove_0)(void*, void*); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    int32_t (*virt_size)(void*); // 17
    void (*pad1)(); // 18
    void* (*virt_get)(void*, int32_t); // 19
    void (*virt_sort)(void*, void*); // 20
    void (*virt_clear)(void*); // 21
    void* (*virt_stream)(void*); // 22
    int32_t (*virt_addAll_0)(void*, void*); // 23
    void* (*virt_listIterator)(void*, int32_t); // 24
    int32_t (*virt_removeIf)(void*, void*); // 25
    TeaVM_Array* (*virt_toArray)(void*); // 26
    void (*virt_ensureCapacity)(void*, int32_t); // 27
    int32_t (*virt_removeAll)(void*, void*); // 28
    void (*pad2)(); // 29
    void* (*virt_subList)(void*, int32_t, int32_t); // 30
    void* (*virt_listIterator_0)(void*); // 31
    void (*virt_add_1)(void*, int32_t, void*); // 32
    void* (*virt_remove_1)(void*, int32_t); // 33
    void (*pad3)(); // 34
    void (*pad4)(); // 35
    int32_t (*virt_indexOf)(void*, void*); // 36
    int32_t (*virt_add_2)(void*, void*); // 37
    TeaVM_Array* (*virt_toArray_0)(void*, TeaVM_Array*); // 38
    void (*pad5)(); // 39
    void (*pad6)(); // 40
    void (*pad7)(); // 41
    void (*pad8)(); // 42
    void (*pad9)(); // 43
    void (*pad10)(); // 44
    void (*pad11)(); // 45
    void (*pad12)(); // 46
    int32_t (*virt_containsAll)(void*, void*); // 47
    int32_t (*virt_contains)(void*, void*); // 48
    void* (*virt_set)(void*, int32_t, void*); // 49
} ju_ArrayList_VT;
extern ju_ArrayList_VT ju_ArrayList_Cls;
