#pragma once
#include "../../../runtime.h"
#include "AbstractSet.h"
#include "Collections@d14.h"

extern void sysinitclass_ju_Collections_14();
typedef struct cls_ju_Collections_14 {
    struct cls_ju_AbstractSet parent;
    void* fld_val_c;
} cls_ju_Collections_14;
extern void meth_ju_Collections_14__init_(void*, void*);
extern void* meth_ju_Collections_14_iterator(void*);
extern int32_t supertypeof_ju_Collections_14(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_14_VT {
    ju_AbstractSet_VT parent;
} ju_Collections_14_VT;
extern ju_Collections_14_VT ju_Collections_14_Cls;
