#pragma once
#include "../../../runtime.h"
#include "TemplateCollections@dAbstractImmutableSet.h"
#include "Collections@d1.h"

extern void sysinitclass_ju_Collections_1();
typedef struct cls_ju_Collections_1 {
    struct cls_ju_TemplateCollections_AbstractImmutableSet parent;
} cls_ju_Collections_1;
extern void meth_ju_Collections_1__init_(void*);
extern int32_t meth_ju_Collections_1_size(void*);
extern void* meth_ju_Collections_1_iterator(void*);
extern int32_t meth_ju_Collections_1_isEmpty(void*);
extern int32_t meth_ju_Collections_1_contains(void*, void*);
extern int32_t meth_ju_Collections_1_containsAll(void*, void*);
extern int32_t supertypeof_ju_Collections_1(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_1_VT {
    ju_TemplateCollections_AbstractImmutableSet_VT parent;
} ju_Collections_1_VT;
extern ju_Collections_1_VT ju_Collections_1_Cls;
