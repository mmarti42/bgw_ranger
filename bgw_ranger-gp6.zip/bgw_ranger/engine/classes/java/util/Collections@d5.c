#include "Collections@d5.h"
#include "../lang/Object.h"
#include "NoSuchElementException.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "../lang/IllegalStateException.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../../strings.h"

void meth_ju_Collections_5__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(5827, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_Collections_5_hasNext(void* teavm_this_) {
    return INT32_C(0);
}
void* meth_ju_Collections_5_next(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5828, meth_otr_Allocator_allocate(&ju_NoSuchElementException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(5829, meth_ju_NoSuchElementException__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(5830, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void meth_ju_Collections_5_remove(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(5831, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(5832, meth_jl_IllegalStateException__init__0(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(5833, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void meth_ju_Collections_5_set(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(5834, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(5835, meth_jl_UnsupportedOperationException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(5836, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t supertypeof_ju_Collections_5(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 265 || tag >= 267) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_Collections_5_VT ju_Collections_5_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Collections_5), sizeof(void*)),
        .flags = 0,
        .tag = 265,
        .modifiers = 0,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_Collections_5,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_remove = &meth_ju_Collections_5_remove,
    .virt_next = &meth_ju_Collections_5_next,
    .virt_hasNext = &meth_ju_Collections_5_hasNext,
    .virt_set_2 = &meth_ju_Collections_5_set
};
void sysinitclass_ju_Collections_5() {
}
