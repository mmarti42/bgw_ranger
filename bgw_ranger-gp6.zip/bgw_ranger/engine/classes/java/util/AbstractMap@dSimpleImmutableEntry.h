#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "AbstractMap@dSimpleImmutableEntry.h"

extern void sysinitclass_ju_AbstractMap_SimpleImmutableEntry();
typedef struct cls_ju_AbstractMap_SimpleImmutableEntry {
    struct TeaVM_Object parent;
    void* fld_key;
    void* fld_value;
} cls_ju_AbstractMap_SimpleImmutableEntry;
extern void meth_ju_AbstractMap_SimpleImmutableEntry__init_(void*, void*, void*);
extern void meth_ju_AbstractMap_SimpleImmutableEntry__init__0(void*, void*);
extern void* meth_ju_AbstractMap_SimpleImmutableEntry_getValue(void*);
extern void* meth_ju_AbstractMap_SimpleImmutableEntry_getKey(void*);
extern int32_t meth_ju_AbstractMap_SimpleImmutableEntry_hashCode(void*);
extern int32_t supertypeof_ju_AbstractMap_SimpleImmutableEntry(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractMap_SimpleImmutableEntry_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*pad0)(); // 11
    void (*pad1)(); // 12
    void (*pad2)(); // 13
    void (*pad3)(); // 14
    void (*pad4)(); // 15
    void (*pad5)(); // 16
    void (*pad6)(); // 17
    void (*pad7)(); // 18
    void (*pad8)(); // 19
    void (*pad9)(); // 20
    void* (*virt_getKey)(void*); // 21
    void* (*virt_getValue_0)(void*); // 22
    void (*pad10)(); // 23
    void (*pad11)(); // 24
    void (*pad12)(); // 25
    void (*pad13)(); // 26
    void (*pad14)(); // 27
    void (*pad15)(); // 28
    void (*pad16)(); // 29
    void (*pad17)(); // 30
    void (*pad18)(); // 31
    void (*pad19)(); // 32
    void (*pad20)(); // 33
    void (*pad21)(); // 34
    void (*pad22)(); // 35
    void (*pad23)(); // 36
    void (*pad24)(); // 37
    void (*pad25)(); // 38
    void (*pad26)(); // 39
    void (*pad27)(); // 40
    void (*pad28)(); // 41
    void (*pad29)(); // 42
    void (*pad30)(); // 43
    void (*pad31)(); // 44
    void (*pad32)(); // 45
    void (*pad33)(); // 46
    void (*pad34)(); // 47
    void (*pad35)(); // 48
    void (*pad36)(); // 49
} ju_AbstractMap_SimpleImmutableEntry_VT;
extern ju_AbstractMap_SimpleImmutableEntry_VT ju_AbstractMap_SimpleImmutableEntry_Cls;
