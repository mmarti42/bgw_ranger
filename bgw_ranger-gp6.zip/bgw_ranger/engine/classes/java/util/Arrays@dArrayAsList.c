#include "Arrays@dArrayAsList.h"
#include "AbstractList.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "AbstractCollection.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_Arrays_ArrayAsList__init_(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(44946, meth_ju_AbstractList__init_(teavm_this_));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_Arrays_ArrayAsList, fld_array) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_ju_Arrays_ArrayAsList_get(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_Arrays_ArrayAsList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(44947, teavm_nullCheck(teavm_local_2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(44948, teavm_checkBounds(teavm_local_1, teavm_local_2));
    teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1);
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
int32_t meth_ju_Arrays_ArrayAsList_size(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_ju_Arrays_ArrayAsList, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(44949, teavm_nullCheck(teavm_local_1)));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_Arrays_ArrayAsList(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1361 || tag >= 1363) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_Arrays_ArrayAsList_Cls[2];
alignas(8) ju_Arrays_ArrayAsList_VT ju_Arrays_ArrayAsList_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_Arrays_ArrayAsList), sizeof(void*)),
            .flags = 0,
            .tag = 1361,
            .modifiers = 0,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_ju_Arrays_ArrayAsList,
            .superclass = (TeaVM_Class*) &ju_AbstractList_Cls,
            .layout = teavm_classLayouts_ju_Arrays_ArrayAsList_Cls,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_ju_AbstractList_hashCode,
        .virt_equals = &meth_ju_AbstractList_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_ju_AbstractCollection_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_forEach = &meth_jl_Iterable_forEach,
        .virt_iterator = &meth_ju_AbstractList_iterator,
        .virt_spliterator = &meth_ju_Collection_spliterator,
        .virt_remove_0 = &meth_ju_AbstractCollection_remove,
        .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
        .virt_size = &meth_ju_Arrays_ArrayAsList_size,
        .virt_get = &meth_ju_Arrays_ArrayAsList_get,
        .virt_stream = &meth_ju_Collection_stream,
        .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
        .virt_listIterator = &meth_ju_AbstractList_listIterator,
        .virt_removeIf = &meth_ju_Collection_removeIf,
        .virt_toArray = &meth_ju_AbstractCollection_toArray,
        .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
        .virt_subList = &meth_ju_AbstractList_subList,
        .virt_listIterator_0 = &meth_ju_AbstractList_listIterator_0,
        .virt_add_1 = &meth_ju_AbstractList_add,
        .virt_remove_1 = &meth_ju_AbstractList_remove,
        .virt_indexOf = &meth_ju_AbstractList_indexOf,
        .virt_add_2 = &meth_ju_AbstractList_add_0,
        .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
        .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
        .virt_contains = &meth_ju_AbstractCollection_contains
    }
};
static int16_t teavm_classLayouts_ju_Arrays_ArrayAsList_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_Arrays_ArrayAsList, fld_array)
};
void sysinitclass_ju_Arrays_ArrayAsList() {
}
