#include "AbstractList.h"
#include "AbstractCollection.h"
#include "AbstractList@d1.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Objects.h"
#include "AbstractList@dTListIteratorImpl.h"
#include "RandomAccess.h"
#include "AbstractList@dSubAbstractList.h"
#include "AbstractList@dSubAbstractListRandomAccess.h"
#include "../lang/IndexOutOfBoundsException.h"
#include "../lang/IllegalArgumentException.h"
#include "Iterator.h"
#include "List.h"
#include "../../../strings.h"
#include "../lang/Object.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_AbstractList__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18243, meth_ju_AbstractCollection__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractList_add_0(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(18244, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_add_1)(teavm_this_, TEAVM_WITH_CALL_SITE_ID(18245, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_size)(teavm_this_)), teavm_local_1));
    TEAVM_RELEASE_STACK;
    return INT32_C(1);
}
void* meth_ju_AbstractList_iterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18246, meth_otr_Allocator_allocate(&ju_AbstractList_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(18247, meth_ju_AbstractList_1__init_(teavm_local_1, teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_AbstractList_set(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18248, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(18249, meth_jl_UnsupportedOperationException__init__0(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(18250, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void meth_ju_AbstractList_add(void* teavm_this_, int32_t teavm_local_1, void* teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18251, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(18252, meth_jl_UnsupportedOperationException__init__0(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(18253, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void* meth_ju_AbstractList_remove(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18254, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(18255, meth_jl_UnsupportedOperationException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(18256, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_AbstractList_indexOf(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18257, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_size)(teavm_this_));
    teavm_local_3 = INT32_C(0);
    while (1) {
        if ((teavm_local_3 >= teavm_local_2)) {
            goto teavm_label_2;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(18258, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_get)(teavm_this_, teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        if (TEAVM_WITH_CALL_SITE_ID(18259, meth_ju_Objects_equals(teavm_local_1, teavm_local_4))) {
            goto teavm_label_3;
        }
        teavm_local_3 = (teavm_local_3 + INT32_C(1));
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_3 = -INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_ju_AbstractList_listIterator_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(18260, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_listIterator)(teavm_this_, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_AbstractList_listIterator(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18261, meth_otr_Allocator_allocate(&ju_AbstractList_TListIteratorImpl_Cls));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_AbstractList, fld_modCount);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(18262, meth_ju_AbstractList_TListIteratorImpl__init_(teavm_local_2, teavm_this_, teavm_local_1, teavm_local_3, TEAVM_WITH_CALL_SITE_ID(18263, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_size)(teavm_this_))));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_AbstractList_subList(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 <= teavm_local_2)) {
        if ((teavm_local_1 >= INT32_C(0))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if ((teavm_local_2 <= TEAVM_WITH_CALL_SITE_ID(18264, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_size)(teavm_this_)))) {
                if ((!teavm_instanceof(teavm_this_, &ju_RandomAccess_Cls, &supertypeof_ju_RandomAccess))) {
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18265, meth_otr_Allocator_allocate(&ju_AbstractList_SubAbstractList_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                    TEAVM_WITH_CALL_SITE_ID(18266, meth_ju_AbstractList_SubAbstractList__init_(teavm_local_3, teavm_this_, teavm_local_1, teavm_local_2));
                } else {
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18267, meth_otr_Allocator_allocate(&ju_AbstractList_SubAbstractListRandomAccess_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                    TEAVM_WITH_CALL_SITE_ID(18268, meth_ju_AbstractList_SubAbstractListRandomAccess__init_(teavm_local_3, teavm_this_, teavm_local_1, teavm_local_2));
                }
                TEAVM_RELEASE_STACK;
                return teavm_local_3;
            }
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18269, meth_otr_Allocator_allocate(&jl_IndexOutOfBoundsException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(18270, meth_jl_IndexOutOfBoundsException__init__0(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(18271, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18272, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(18273, meth_jl_IllegalArgumentException__init_(teavm_local_3));
    TEAVM_WITH_CALL_SITE_ID(18274, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_AbstractList_hashCode(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = INT32_C(1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18275, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18276, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(18277, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_1;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18278, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        teavm_local_4 = (INT32_C(31) * teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_1 = (teavm_local_4 + TEAVM_WITH_CALL_SITE_ID(18279, meth_ju_Objects_hashCode(teavm_local_3)));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_AbstractList_equals(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(3));
    if ((!teavm_instanceof(teavm_local_1, &ju_List_Cls, &supertypeof_ju_List))) {
        teavm_local_2 = INT32_C(0);
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18280, teavm_checkcast(teavm_local_1, &ju_List_Cls, &supertypeof_ju_List));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(18281, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_size)(teavm_this_));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(18282, teavm_nullCheck(teavm_local_3));
        if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(18283, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_size)(teavm_local_3)))) {
            teavm_local_2 = INT32_C(0);
        } else {
            teavm_local_4 = INT32_C(0);
            while (1) {
                if (!(teavm_local_4 < TEAVM_WITH_CALL_SITE_ID(18284, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_size)(teavm_local_3)))) break;
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(18285, TEAVM_METHOD(teavm_this_, ju_AbstractList_VT, virt_get)(teavm_this_, teavm_local_4));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(18286, TEAVM_METHOD(teavm_local_3, ju_List_VT, virt_get)(teavm_local_3, teavm_local_4));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
                if ((!TEAVM_WITH_CALL_SITE_ID(18287, meth_ju_Objects_equals(teavm_local_5, teavm_local_6)))) {
                    goto teavm_label_2;
                }
                teavm_local_4 = (teavm_local_4 + INT32_C(1));
            }
            teavm_local_2 = INT32_C(1);
            goto teavm_label_1;
        teavm_label_2:;
            teavm_local_2 = INT32_C(0);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t supertypeof_ju_AbstractList(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1342 || tag >= 1364) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_AbstractList_VT ju_AbstractList_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractList), sizeof(void*)),
        .flags = 0,
        .tag = 1342,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractList,
        .superclass = (TeaVM_Class*) &ju_AbstractCollection_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_ju_AbstractList_hashCode,
    .virt_equals = &meth_ju_AbstractList_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_ju_AbstractCollection_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_forEach = &meth_jl_Iterable_forEach,
    .virt_iterator = &meth_ju_AbstractList_iterator,
    .virt_spliterator = &meth_ju_Collection_spliterator,
    .virt_remove_0 = &meth_ju_AbstractCollection_remove,
    .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
    .virt_stream = &meth_ju_Collection_stream,
    .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
    .virt_listIterator = &meth_ju_AbstractList_listIterator,
    .virt_removeIf = &meth_ju_Collection_removeIf,
    .virt_toArray = &meth_ju_AbstractCollection_toArray,
    .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
    .virt_subList = &meth_ju_AbstractList_subList,
    .virt_listIterator_0 = &meth_ju_AbstractList_listIterator_0,
    .virt_add_1 = &meth_ju_AbstractList_add,
    .virt_remove_1 = &meth_ju_AbstractList_remove,
    .virt_indexOf = &meth_ju_AbstractList_indexOf,
    .virt_add_2 = &meth_ju_AbstractList_add_0,
    .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
    .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
    .virt_contains = &meth_ju_AbstractCollection_contains,
    .virt_set = &meth_ju_AbstractList_set
};
void sysinitclass_ju_AbstractList() {
}
