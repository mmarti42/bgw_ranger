#pragma once
#include "../../../runtime.h"
#include "AbstractCollection.h"
#include "AbstractList.h"

extern void sysinitclass_ju_AbstractList();
typedef struct cls_ju_AbstractList {
    struct cls_ju_AbstractCollection parent;
    int32_t fld_modCount;
} cls_ju_AbstractList;
extern void meth_ju_AbstractList__init_(void*);
extern int32_t meth_ju_AbstractList_add_0(void*, void*);
extern void* meth_ju_AbstractList_iterator(void*);
extern void* meth_ju_AbstractList_set(void*, int32_t, void*);
extern void meth_ju_AbstractList_add(void*, int32_t, void*);
extern void* meth_ju_AbstractList_remove(void*, int32_t);
extern int32_t meth_ju_AbstractList_indexOf(void*, void*);
extern void* meth_ju_AbstractList_listIterator_0(void*);
extern void* meth_ju_AbstractList_listIterator(void*, int32_t);
extern void* meth_ju_AbstractList_subList(void*, int32_t, int32_t);
extern int32_t meth_ju_AbstractList_hashCode(void*);
extern int32_t meth_ju_AbstractList_equals(void*, void*);
extern int32_t supertypeof_ju_AbstractList(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractList_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_forEach)(void*, void*); // 11
    void* (*virt_iterator)(void*); // 12
    void* (*virt_spliterator)(void*); // 13
    int32_t (*virt_remove_0)(void*, void*); // 14
    void (*pad0)(); // 15
    int32_t (*virt_isEmpty)(void*); // 16
    int32_t (*virt_size)(void*); // 17
    void (*pad1)(); // 18
    void* (*virt_get)(void*, int32_t); // 19
    void (*virt_sort)(void*, void*); // 20
    void (*virt_clear)(void*); // 21
    void* (*virt_stream)(void*); // 22
    int32_t (*virt_addAll_0)(void*, void*); // 23
    void* (*virt_listIterator)(void*, int32_t); // 24
    int32_t (*virt_removeIf)(void*, void*); // 25
    TeaVM_Array* (*virt_toArray)(void*); // 26
    void (*pad2)(); // 27
    int32_t (*virt_removeAll)(void*, void*); // 28
    void (*pad3)(); // 29
    void* (*virt_subList)(void*, int32_t, int32_t); // 30
    void* (*virt_listIterator_0)(void*); // 31
    void (*virt_add_1)(void*, int32_t, void*); // 32
    void* (*virt_remove_1)(void*, int32_t); // 33
    void (*pad4)(); // 34
    void (*pad5)(); // 35
    int32_t (*virt_indexOf)(void*, void*); // 36
    int32_t (*virt_add_2)(void*, void*); // 37
    TeaVM_Array* (*virt_toArray_0)(void*, TeaVM_Array*); // 38
    void (*pad6)(); // 39
    void (*pad7)(); // 40
    void (*pad8)(); // 41
    void (*pad9)(); // 42
    void (*pad10)(); // 43
    void (*pad11)(); // 44
    void (*pad12)(); // 45
    void (*pad13)(); // 46
    int32_t (*virt_containsAll)(void*, void*); // 47
    int32_t (*virt_contains)(void*, void*); // 48
    void* (*virt_set)(void*, int32_t, void*); // 49
} ju_AbstractList_VT;
extern ju_AbstractList_VT ju_AbstractList_Cls;
