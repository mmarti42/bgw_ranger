#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "Collections@d11.h"

extern void sysinitclass_ju_Collections_11();
typedef struct cls_ju_Collections_11 {
    struct TeaVM_Object parent;
    void* fld_val_c;
} cls_ju_Collections_11;
extern void meth_ju_Collections_11__init_(void*, void*);
extern int32_t meth_ju_Collections_11_hasNext(void*);
extern void* meth_ju_Collections_11_next(void*);
extern void meth_ju_Collections_11_remove(void*);
extern int32_t supertypeof_ju_Collections_11(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_Collections_11_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_remove)(void*); // 11
    void* (*virt_next)(void*); // 12
    int32_t (*virt_hasNext)(void*); // 13
    void (*pad0)(); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void (*pad7)(); // 21
    void (*pad8)(); // 22
    void (*pad9)(); // 23
    void (*pad10)(); // 24
    void (*pad11)(); // 25
    void (*pad12)(); // 26
    void (*pad13)(); // 27
    void (*pad14)(); // 28
    void (*pad15)(); // 29
    void (*pad16)(); // 30
    void (*pad17)(); // 31
    void (*pad18)(); // 32
    void (*pad19)(); // 33
    void (*pad20)(); // 34
    void (*pad21)(); // 35
    void (*pad22)(); // 36
    void (*pad23)(); // 37
    void (*pad24)(); // 38
    void (*pad25)(); // 39
    void (*pad26)(); // 40
    void (*pad27)(); // 41
    void (*pad28)(); // 42
    void (*pad29)(); // 43
    void (*pad30)(); // 44
    void (*pad31)(); // 45
    void (*pad32)(); // 46
    void (*pad33)(); // 47
    void (*pad34)(); // 48
    void (*pad35)(); // 49
} ju_Collections_11_VT;
extern ju_Collections_11_VT ju_Collections_11_Cls;
