#pragma once
#include "../../../runtime.h"
#include "../lang/Object.h"
#include "AbstractList@dSubAbstractList@dSubAbstractListIterator.h"

extern void sysinitclass_ju_AbstractList_SubAbstractList_SubAbstractListIterator();
typedef struct cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator {
    struct TeaVM_Object parent;
    void* fld_subList;
    void* fld_iterator;
    int32_t fld_start;
    int32_t fld_end;
} cls_ju_AbstractList_SubAbstractList_SubAbstractListIterator;
extern void meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator__init_(void*, void*, void*, int32_t, int32_t);
extern int32_t meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator_hasNext(void*);
extern void* meth_ju_AbstractList_SubAbstractList_SubAbstractListIterator_next(void*);
extern int32_t supertypeof_ju_AbstractList_SubAbstractList_SubAbstractListIterator(TeaVM_Class*, TeaVM_Class*);
typedef struct ju_AbstractList_SubAbstractList_SubAbstractListIterator_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void (*virt_remove)(void*); // 11
    void* (*virt_next)(void*); // 12
    int32_t (*virt_hasNext)(void*); // 13
    int32_t (*virt_nextIndex)(void*); // 14
    void (*pad0)(); // 15
    void (*pad1)(); // 16
    void (*pad2)(); // 17
    void (*pad3)(); // 18
    void (*pad4)(); // 19
    void (*pad5)(); // 20
    int32_t (*virt_hasPrevious)(void*); // 21
    void (*virt_set_2)(void*, void*); // 22
    void (*pad6)(); // 23
    void (*pad7)(); // 24
    void (*pad8)(); // 25
    void (*pad9)(); // 26
    void (*pad10)(); // 27
    void* (*virt_previous)(void*); // 28
    void (*pad11)(); // 29
    void (*pad12)(); // 30
    void (*pad13)(); // 31
    void (*pad14)(); // 32
    void (*pad15)(); // 33
    void (*pad16)(); // 34
    void (*pad17)(); // 35
    void (*pad18)(); // 36
    void (*pad19)(); // 37
    void (*pad20)(); // 38
    void (*pad21)(); // 39
    void (*pad22)(); // 40
    void (*pad23)(); // 41
    void (*pad24)(); // 42
    void (*pad25)(); // 43
    void (*pad26)(); // 44
    void (*pad27)(); // 45
    void (*pad28)(); // 46
    void (*pad29)(); // 47
    void (*pad30)(); // 48
    void (*pad31)(); // 49
} ju_AbstractList_SubAbstractList_SubAbstractListIterator_VT;
extern ju_AbstractList_SubAbstractList_SubAbstractListIterator_VT ju_AbstractList_SubAbstractList_SubAbstractListIterator_Cls;
