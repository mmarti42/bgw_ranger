#include "ArrayDeque.h"
#include "AbstractCollection.h"
#include "../../../arrayclass.h"
#include "../lang/Object.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "Objects.h"
#include "NoSuchElementException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "ArrayDeque@d1.h"
#include "../lang/Math.h"
#include "../../../strings.h"
#include "../lang/Iterable.h"
#include "Collection.h"

void meth_ju_ArrayDeque__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9164, meth_ju_ArrayDeque__init__0(teavm_this_, INT32_C(8)));
    TEAVM_RELEASE_STACK;
}
void meth_ju_ArrayDeque__init__0(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9165, meth_ju_AbstractCollection__init_(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9166, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), (teavm_local_1 + INT32_C(1))));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array) = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void meth_ju_ArrayDeque_addFirst(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9167, meth_ju_Objects_requireNonNull(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(9168, meth_ju_ArrayDeque_ensureCapacity(teavm_this_, (TEAVM_WITH_CALL_SITE_ID(9169, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_size)(teavm_this_)) + INT32_C(1))));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9170, teavm_nullCheck(teavm_local_3)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) = TEAVM_WITH_CALL_SITE_ID(9171, meth_ju_ArrayDeque_modDec(teavm_local_2, teavm_local_4));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9172, teavm_nullCheck(teavm_local_3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9173, teavm_checkBounds(teavm_local_2, teavm_local_3));
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_1;
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_version) = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_version) + INT32_C(1));
    TEAVM_RELEASE_STACK;
}
void meth_ju_ArrayDeque_addLast(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9174, meth_ju_Objects_requireNonNull(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(9175, meth_ju_ArrayDeque_ensureCapacity(teavm_this_, (TEAVM_WITH_CALL_SITE_ID(9176, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_size)(teavm_this_)) + INT32_C(1))));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9177, teavm_nullCheck(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9178, teavm_checkBounds(teavm_local_3, teavm_local_2));
    teavm_gc_writeBarrier(teavm_local_2);
    TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_3) = teavm_local_1;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_4 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9179, teavm_nullCheck(teavm_local_2)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) = TEAVM_WITH_CALL_SITE_ID(9180, meth_ju_ArrayDeque_modInc(teavm_local_3, teavm_local_4));
    TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_version) = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_version) + INT32_C(1));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_ArrayDeque_removeFirst(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9181, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_pollFirst)(teavm_this_));
    if ((teavm_local_1 == NULL)) {
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9182, meth_otr_Allocator_allocate(&ju_NoSuchElementException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(9183, meth_ju_NoSuchElementException__init_(teavm_local_2));
        TEAVM_WITH_CALL_SITE_ID(9184, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_ArrayDeque_pollFirst(void* teavm_this_) {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) == TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) {
        teavm_local_1 = NULL;
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9185, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(9186, teavm_checkBounds(teavm_local_3, teavm_local_2)));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
        teavm_local_4 = NULL;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9187, teavm_nullCheck(teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(9188, teavm_checkBounds(teavm_local_3, teavm_local_2))) = teavm_local_4;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_5 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9189, teavm_nullCheck(teavm_local_2)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) = TEAVM_WITH_CALL_SITE_ID(9190, meth_ju_ArrayDeque_modInc(teavm_local_3, teavm_local_5));
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_version) = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_version) + INT32_C(1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_ju_ArrayDeque_peekFirst(void* teavm_this_) {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if (TEAVM_WITH_CALL_SITE_ID(9191, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_isEmpty)(teavm_this_))) {
        teavm_local_1 = NULL;
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9192, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(9193, teavm_checkBounds(teavm_local_3, teavm_local_2)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_ArrayDeque_add(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9194, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_addLast)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
    return INT32_C(1);
}
void* meth_ju_ArrayDeque_remove(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9195, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_removeFirst)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ju_ArrayDeque_push(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(9196, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_addFirst)(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
void* meth_ju_ArrayDeque_pop(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9197, TEAVM_METHOD(teavm_this_, ju_ArrayDeque_VT, virt_removeFirst)(teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_ArrayDeque_size(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) >= TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head))) {
        teavm_local_1 = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) - TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head));
    } else {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_1 = ((TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9198, teavm_nullCheck(teavm_local_2))) - TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head)) + TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail));
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_ArrayDeque_isEmpty(void* teavm_this_) {
    return ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) != TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail)) ? INT32_C(0) : INT32_C(1));
}
int32_t meth_ju_ArrayDeque_removeAt(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) < TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) {
        if (((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) - teavm_local_1) >= (teavm_local_1 - TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head)))) {
            teavm_local_2 = (teavm_local_1 - INT32_C(1));
            while (1) {
                if (!(teavm_local_2 >= TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head))) break;
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                teavm_local_4 = (teavm_local_2 + INT32_C(1));
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9199, teavm_nullCheck(teavm_local_5));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9200, teavm_checkBounds(teavm_local_2, teavm_local_5));
                teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_2);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9201, teavm_nullCheck(teavm_local_3));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9202, teavm_checkBounds(teavm_local_4, teavm_local_3));
                teavm_gc_writeBarrier(teavm_local_3);
                TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_4) = teavm_local_6;
                teavm_local_2 = (teavm_local_2 + -INT32_C(1));
            }
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
            TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) = (teavm_local_7 + INT32_C(1));
            teavm_local_6 = NULL;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9203, teavm_nullCheck(teavm_local_3));
            TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(9204, teavm_checkBounds(teavm_local_7, teavm_local_3))) = teavm_local_6;
            teavm_local_4 = INT32_C(0);
        } else {
            teavm_local_2 = (teavm_local_1 + INT32_C(1));
            while (1) {
                if (!(teavm_local_2 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) break;
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                teavm_local_4 = (teavm_local_2 - INT32_C(1));
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9205, teavm_nullCheck(teavm_local_5));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9206, teavm_checkBounds(teavm_local_2, teavm_local_5));
                teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_2);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9207, teavm_nullCheck(teavm_local_3));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9208, teavm_checkBounds(teavm_local_4, teavm_local_3));
                teavm_gc_writeBarrier(teavm_local_3);
                TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_4) = teavm_local_6;
                teavm_local_2 = (teavm_local_2 + INT32_C(1));
            }
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
            teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) - INT32_C(1));
            TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) = teavm_local_4;
            teavm_local_6 = NULL;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9209, teavm_nullCheck(teavm_local_3));
            TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(9210, teavm_checkBounds(teavm_local_4, teavm_local_3))) = teavm_local_6;
            teavm_local_4 = INT32_C(1);
        }
    } else if ((teavm_local_1 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head))) {
        teavm_local_2 = (teavm_local_1 + INT32_C(1));
        while (1) {
            if (!(teavm_local_2 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) break;
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
            teavm_local_4 = (teavm_local_2 - INT32_C(1));
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9211, teavm_nullCheck(teavm_local_5));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9212, teavm_checkBounds(teavm_local_2, teavm_local_5));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9213, teavm_nullCheck(teavm_local_3));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9214, teavm_checkBounds(teavm_local_4, teavm_local_3));
            teavm_gc_writeBarrier(teavm_local_3);
            TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_4) = teavm_local_6;
            teavm_local_2 = (teavm_local_2 + INT32_C(1));
        }
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_7 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9215, teavm_nullCheck(teavm_local_3)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) = TEAVM_WITH_CALL_SITE_ID(9216, meth_ju_ArrayDeque_modDec(teavm_local_4, teavm_local_7));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail);
        teavm_local_6 = NULL;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9217, teavm_nullCheck(teavm_local_3));
        TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(9218, teavm_checkBounds(teavm_local_4, teavm_local_3))) = teavm_local_6;
        teavm_local_4 = INT32_C(1);
    } else {
        teavm_local_2 = (teavm_local_1 - INT32_C(1));
        while (1) {
            if (!(teavm_local_2 >= TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head))) break;
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
            teavm_local_4 = (teavm_local_2 + INT32_C(1));
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9219, teavm_nullCheck(teavm_local_5));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9220, teavm_checkBounds(teavm_local_2, teavm_local_5));
            teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9221, teavm_nullCheck(teavm_local_3));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9222, teavm_checkBounds(teavm_local_4, teavm_local_3));
            teavm_gc_writeBarrier(teavm_local_3);
            TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_4) = teavm_local_6;
            teavm_local_2 = (teavm_local_2 + -INT32_C(1));
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
        teavm_local_6 = NULL;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9223, teavm_nullCheck(teavm_local_3));
        TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(9224, teavm_checkBounds(teavm_local_4, teavm_local_3))) = teavm_local_6;
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_7 = TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9225, teavm_nullCheck(teavm_local_3)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) = TEAVM_WITH_CALL_SITE_ID(9226, meth_ju_ArrayDeque_modInc(teavm_local_4, teavm_local_7));
        teavm_local_4 = INT32_C(0);
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_ArrayDeque_modInc(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    teavm_local_3 = (teavm_local_1 + INT32_C(1));
    if ((teavm_local_3 == teavm_local_2)) {
        teavm_local_3 = INT32_C(0);
    }
    return teavm_local_3;
}
int32_t meth_ju_ArrayDeque_modDec(int32_t teavm_local_1, int32_t teavm_local_2) {
    int32_t teavm_local_3;
    teavm_local_3 = (teavm_local_1 + -INT32_C(1));
    if ((teavm_local_3 == -INT32_C(1))) {
        teavm_local_3 = (teavm_local_2 - INT32_C(1));
    }
    return teavm_local_3;
}
void* meth_ju_ArrayDeque_iterator(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(9227, meth_otr_Allocator_allocate(&ju_ArrayDeque_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(9228, meth_ju_ArrayDeque_1__init_(teavm_local_1, teavm_this_));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_ju_ArrayDeque_ensureCapacity(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TeaVM_Array* teavm_local_9;
    void* teavm_local_10;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    if ((teavm_local_1 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9229, teavm_nullCheck(teavm_local_2))))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = (TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9230, teavm_nullCheck(teavm_local_2))) * INT32_C(2));
        teavm_local_4 = (((teavm_local_1 * INT32_C(3)) / INT32_C(2)) + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(9231, meth_jl_Math_max(teavm_local_3, teavm_local_4));
        if ((teavm_local_5 < INT32_C(1))) {
            teavm_local_5 = INT32_C(2147483647);
        }
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(9232, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), teavm_local_5));
        teavm_local_7 = INT32_C(0);
        if ((TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) <= TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) {
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
            while (1) {
                if (!(teavm_local_8 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) break;
                teavm_local_9 = teavm_local_6;
                teavm_local_4 = (teavm_local_7 + INT32_C(1));
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_9);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9233, teavm_nullCheck(teavm_local_2));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(9234, teavm_checkBounds(teavm_local_8, teavm_local_2));
                teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_8);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(9235, teavm_checkBounds(teavm_local_7, teavm_local_9));
                teavm_gc_writeBarrier(teavm_local_9);
                TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_3) = teavm_local_10;
                teavm_local_8 = (teavm_local_8 + INT32_C(1));
                teavm_local_7 = teavm_local_4;
            }
        } else {
            teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head);
            while (1) {
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                if ((teavm_local_8 >= TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(9236, teavm_nullCheck(teavm_local_2))))) {
                    goto teavm_label_2;
                }
                teavm_local_9 = teavm_local_6;
                teavm_local_3 = (teavm_local_7 + INT32_C(1));
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9237, teavm_nullCheck(teavm_local_2));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(9238, teavm_checkBounds(teavm_local_8, teavm_local_2));
                teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_8);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9239, teavm_checkBounds(teavm_local_7, teavm_local_9));
                teavm_gc_writeBarrier(teavm_local_9);
                TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_4) = teavm_local_10;
                teavm_local_8 = (teavm_local_8 + INT32_C(1));
                teavm_local_7 = teavm_local_3;
            }
        teavm_label_2:;
            teavm_local_8 = INT32_C(0);
            while (1) {
                if (!(teavm_local_8 < TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail))) break;
                teavm_local_9 = teavm_local_6;
                teavm_local_3 = (teavm_local_7 + INT32_C(1));
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(9240, teavm_nullCheck(teavm_local_2));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(9241, teavm_checkBounds(teavm_local_8, teavm_local_2));
                teavm_local_10 = TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_8);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(9242, teavm_checkBounds(teavm_local_7, teavm_local_9));
                teavm_gc_writeBarrier(teavm_local_9);
                TEAVM_ARRAY_AT(teavm_local_9, void*, teavm_local_4) = teavm_local_10;
                teavm_local_8 = (teavm_local_8 + INT32_C(1));
                teavm_local_7 = teavm_local_3;
            }
        }
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_head) = INT32_C(0);
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_tail) = teavm_local_7;
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_ju_ArrayDeque, fld_array) = teavm_local_6;
    }
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_ju_ArrayDeque(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1292 || tag >= 1294) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_ju_ArrayDeque_Cls[2];
alignas(8) ju_ArrayDeque_VT ju_ArrayDeque_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_ArrayDeque), sizeof(void*)),
        .flags = 0,
        .tag = 1292,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_ArrayDeque,
        .superclass = (TeaVM_Class*) &ju_AbstractCollection_Cls,
        .layout = teavm_classLayouts_ju_ArrayDeque_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_toString = &meth_ju_AbstractCollection_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_forEach = &meth_jl_Iterable_forEach,
    .virt_iterator = &meth_ju_ArrayDeque_iterator,
    .virt_spliterator = &meth_ju_Collection_spliterator,
    .virt_remove_0 = &meth_ju_AbstractCollection_remove,
    .virt_isEmpty = &meth_ju_ArrayDeque_isEmpty,
    .virt_size = &meth_ju_ArrayDeque_size,
    .virt_peekFirst = &meth_ju_ArrayDeque_peekFirst,
    .virt_addFirst = &meth_ju_ArrayDeque_addFirst,
    .virt_stream = &meth_ju_Collection_stream,
    .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
    .virt_pollFirst = &meth_ju_ArrayDeque_pollFirst,
    .virt_removeIf = &meth_ju_Collection_removeIf,
    .virt_toArray = &meth_ju_AbstractCollection_toArray,
    .virt_addLast = &meth_ju_ArrayDeque_addLast,
    .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
    .virt_pop = &meth_ju_ArrayDeque_pop,
    .virt_push = &meth_ju_ArrayDeque_push,
    .virt_removeFirst = &meth_ju_ArrayDeque_removeFirst,
    .virt_add_2 = &meth_ju_ArrayDeque_add,
    .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
    .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
    .virt_contains = &meth_ju_AbstractCollection_contains,
    .virt_remove_3 = &meth_ju_ArrayDeque_remove
};
static int16_t teavm_classLayouts_ju_ArrayDeque_Cls[2] = {
INT16_C(1), (int16_t) offsetof(cls_ju_ArrayDeque, fld_array)
};
void sysinitclass_ju_ArrayDeque() {
}
