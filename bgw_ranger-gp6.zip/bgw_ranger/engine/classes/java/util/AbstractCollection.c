#include "AbstractCollection.h"
#include "../lang/Object.h"
#include "Iterator.h"
#include "Objects.h"
#include "../../../arrayclass.h"
#include "../../org/teavm/runtime/Allocator.h"
#include "../lang/Class.h"
#include "../lang/reflect/Array.h"
#include "../lang/UnsupportedOperationException.h"
#include "../../org/teavm/runtime/ExceptionHandling.h"
#include "Collection.h"
#include "../lang/StringBuilder.h"
#include "../../../strings.h"
#include "../lang/Iterable.h"

void meth_ju_AbstractCollection__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(22362, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t meth_ju_AbstractCollection_isEmpty(void* teavm_this_) {
    int32_t teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = (TEAVM_WITH_CALL_SITE_ID(22363, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_size)(teavm_this_)) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_AbstractCollection_contains(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22364, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22365, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(22366, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_3;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22367, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if (TEAVM_WITH_CALL_SITE_ID(22368, meth_ju_Objects_equals(teavm_local_3, teavm_local_1))) {
            goto teavm_label_2;
        }
    }
teavm_label_3:;
    teavm_local_4 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_4 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
TeaVM_Array* meth_ju_AbstractCollection_toArray(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22369, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), TEAVM_WITH_CALL_SITE_ID(22370, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_size)(teavm_this_))));
    teavm_local_2 = INT32_C(0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22371, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22372, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(22373, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = teavm_local_1;
        teavm_local_5 = (teavm_local_2 + INT32_C(1));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(22374, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(22375, teavm_checkBounds(teavm_local_2, teavm_local_4));
        teavm_gc_writeBarrier(teavm_local_4);
        TEAVM_ARRAY_AT(teavm_local_4, void*, teavm_local_7) = teavm_local_6;
        teavm_local_2 = teavm_local_5;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
TeaVM_Array* meth_ju_AbstractCollection_toArray_0(void* teavm_this_, TeaVM_Array* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22376, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_size)(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22377, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = teavm_local_1;
    teavm_local_4 = TEAVM_ARRAY_LENGTH(teavm_local_3);
    if ((teavm_local_4 >= teavm_local_2)) {
        while (1) {
            if (!(teavm_local_2 < teavm_local_4)) break;
            teavm_local_5 = NULL;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22378, teavm_checkLowerBound(teavm_local_2));
            TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_2) = teavm_local_5;
            teavm_local_2 = (teavm_local_2 + INT32_C(1));
        }
    } else {
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(22379, meth_jl_Object_getClass(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(22380, meth_jl_Class_getComponentType(TEAVM_WITH_CALL_SITE_ID(22381, teavm_nullCheck(teavm_local_5))));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(22382, meth_jlr_Array_newInstance(teavm_local_5, teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22383, teavm_checkcast(teavm_local_5, teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), &teavm_isSupertypeOfArray));
    }
    teavm_local_2 = INT32_C(0);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(22384, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_6);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(22385, teavm_nullCheck(teavm_local_6));
        if ((!TEAVM_WITH_CALL_SITE_ID(22386, TEAVM_METHOD(teavm_local_6, ju_Iterator_VT, virt_hasNext)(teavm_local_6)))) {
            goto teavm_label_2;
        }
        teavm_local_7 = (teavm_local_2 + INT32_C(1));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(22387, TEAVM_METHOD(teavm_local_6, ju_Iterator_VT, virt_next)(teavm_local_6));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22388, teavm_nullCheck(teavm_local_1));
        teavm_local_3 = teavm_local_1;
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(22389, teavm_checkBounds(teavm_local_2, teavm_local_3));
        teavm_gc_writeBarrier(teavm_local_3);
        TEAVM_ARRAY_AT(teavm_local_3, void*, teavm_local_4) = teavm_local_5;
        teavm_local_2 = teavm_local_7;
    }
teavm_label_2:;
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_ju_AbstractCollection_add(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22390, meth_otr_Allocator_allocate(&jl_UnsupportedOperationException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(22391, meth_jl_UnsupportedOperationException__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(22392, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
int32_t meth_ju_AbstractCollection_remove(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22393, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22394, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(22395, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_3;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22396, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if (TEAVM_WITH_CALL_SITE_ID(22397, meth_ju_Objects_equals(teavm_local_3, teavm_local_1))) {
            goto teavm_label_2;
        }
    }
teavm_label_3:;
    teavm_local_4 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(22398, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_remove)(teavm_local_2));
    teavm_local_4 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_AbstractCollection_containsAll(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22399, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22400, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22401, teavm_nullCheck(teavm_local_2));
        if ((!TEAVM_WITH_CALL_SITE_ID(22402, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2)))) {
            goto teavm_label_3;
        }
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22403, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        if ((!TEAVM_WITH_CALL_SITE_ID(22404, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_contains)(teavm_this_, teavm_local_3)))) {
            goto teavm_label_2;
        }
    }
teavm_label_3:;
    teavm_local_4 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_4 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t meth_ju_AbstractCollection_addAll(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22405, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22406, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_iterator)(teavm_local_1));
    while (1) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22407, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(22408, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(22409, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        if ((!TEAVM_WITH_CALL_SITE_ID(22410, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_add_2)(teavm_this_, teavm_local_4)))) {
            goto teavm_cnt_1;
        }
        teavm_local_2 = INT32_C(1);
    teavm_cnt_1:;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_ju_AbstractCollection_removeAll(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(22411, meth_ju_Objects_requireNonNull(teavm_local_1));
    teavm_local_2 = INT32_C(0);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22412, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    while (1) {
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_1);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22413, teavm_nullCheck(teavm_local_3));
        if ((!TEAVM_WITH_CALL_SITE_ID(22414, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_hasNext)(teavm_local_3)))) {
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(22415, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_next)(teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22416, teavm_nullCheck(teavm_local_1));
        if (TEAVM_WITH_CALL_SITE_ID(22417, TEAVM_METHOD(teavm_local_1, ju_Collection_VT, virt_contains)(teavm_local_1, teavm_local_4))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(22418, TEAVM_METHOD(teavm_local_3, ju_Iterator_VT, virt_remove)(teavm_local_3));
            teavm_local_2 = INT32_C(1);
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_ju_AbstractCollection_toString(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(22419, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(22420, meth_jl_StringBuilder__init_(teavm_local_1));
    TEAVM_WITH_CALL_SITE_ID(22421, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(91)));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22422, TEAVM_METHOD(teavm_this_, ju_AbstractCollection_VT, virt_iterator)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(22423, teavm_nullCheck(teavm_local_2));
    if (TEAVM_WITH_CALL_SITE_ID(22424, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2))) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22425, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        if ((teavm_local_3 == teavm_this_)) {
            teavm_local_3 = TEAVM_GET_STRING(7034);
        }
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(22426, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_1)(teavm_local_1, teavm_local_3));
    }
    while (1) {
        if (!TEAVM_WITH_CALL_SITE_ID(22427, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_hasNext)(teavm_local_2))) break;
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(22428, TEAVM_METHOD(teavm_local_2, ju_Iterator_VT, virt_next)(teavm_local_2));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(22429, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_0)(teavm_local_1, TEAVM_GET_STRING(648)));
        if ((teavm_local_3 == teavm_this_)) {
            teavm_local_3 = TEAVM_GET_STRING(7034);
        }
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(22430, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(22431, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_3)));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(22432, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_28)(teavm_local_1, INT32_C(93)));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(22433, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_toString)(teavm_local_1));
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
int32_t supertypeof_ju_AbstractCollection(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1289 || tag >= 1367) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) ju_AbstractCollection_VT ju_AbstractCollection_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_ju_AbstractCollection), sizeof(void*)),
        .flags = 0,
        .tag = 1289,
        .modifiers = 1025,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_ju_AbstractCollection,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_ju_AbstractCollection_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_forEach = &meth_jl_Iterable_forEach,
    .virt_spliterator = &meth_ju_Collection_spliterator,
    .virt_remove_0 = &meth_ju_AbstractCollection_remove,
    .virt_isEmpty = &meth_ju_AbstractCollection_isEmpty,
    .virt_stream = &meth_ju_Collection_stream,
    .virt_addAll_0 = &meth_ju_AbstractCollection_addAll,
    .virt_removeIf = &meth_ju_Collection_removeIf,
    .virt_toArray = &meth_ju_AbstractCollection_toArray,
    .virt_removeAll = &meth_ju_AbstractCollection_removeAll,
    .virt_add_2 = &meth_ju_AbstractCollection_add,
    .virt_toArray_0 = &meth_ju_AbstractCollection_toArray_0,
    .virt_containsAll = &meth_ju_AbstractCollection_containsAll,
    .virt_contains = &meth_ju_AbstractCollection_contains
};
void sysinitclass_ju_AbstractCollection() {
}
