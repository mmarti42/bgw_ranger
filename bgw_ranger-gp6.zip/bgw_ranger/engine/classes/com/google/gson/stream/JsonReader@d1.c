#include "JsonReader@d1.h"
#include "../internal/JsonReaderInternalAccess.h"
#include "../../../../../strings.h"
#include "../../../../java/lang/Object.h"

void meth_cggs_JsonReader_1__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(12697, meth_cggi_JsonReaderInternalAccess__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_cggs_JsonReader_1(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 518 || tag >= 520) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) cggs_JsonReader_1_VT cggs_JsonReader_1_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_cggs_JsonReader_1), sizeof(void*)),
                .flags = 0,
                .tag = 518,
                .modifiers = 0,
                .name = NULL,
                .simpleName = NULL,
                .arrayType = NULL,
                .itemType = NULL,
                .isSupertypeOf = &supertypeof_cggs_JsonReader_1,
                .superclass = (TeaVM_Class*) &cggi_JsonReaderInternalAccess_Cls,
                .layout = NULL,
                .enumValues = NULL,
                .declaringClass = NULL,
                .enclosingClass = NULL,
                .init = NULL
            },
            .virt_hashCode = &meth_jl_Object_hashCode,
            .virt_equals = &meth_jl_Object_equals,
            .virt_clone = &meth_jl_Object_clone,
            .virt_toString = &meth_jl_Object_toString,
            .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
            .virt_getClass = &meth_jl_Object_getClass,
            .virt_identity = &meth_jl_Object_identity,
            .virt_notifyAll = &meth_jl_Object_notifyAll,
            .virt_wait = &meth_jl_Object_wait,
            .virt_waitImpl = &meth_jl_Object_waitImpl,
            .virt_wait_0 = &meth_jl_Object_wait_0
        }
    }
};
void sysinitclass_cggs_JsonReader_1() {
}
