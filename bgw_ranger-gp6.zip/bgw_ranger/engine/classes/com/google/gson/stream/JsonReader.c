#include "JsonReader.h"
#include "../../../../java/lang/Object.h"
#include "../../../../../arrays/primitives/char.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../arrays/primitives/int.h"
#include "../../../../../arrayclass.h"
#include "../../../../java/lang/String.h"
#include "../../../../java/lang/NullPointerException.h"
#include "../../../../../strings.h"
#include "../../../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../../java/lang/IllegalStateException.h"
#include "../../../../java/lang/StringBuilder.h"
#include "JsonToken.h"
#include "../../../../java/lang/AssertionError.h"
#include "../../../../java/lang/Long.h"
#include "../../../../java/lang/Double.h"
#include "../../../../java/lang/NumberFormatException.h"
#include "../../../../java/lang/Math.h"
#include "../../../../java/lang/Integer.h"
#include "../../../../java/io/Reader.h"
#include "../../../../java/util/Arrays.h"
#include "../../../../java/lang/System.h"
#include "../../../../java/io/EOFException.h"
#include "MalformedJsonException.h"
#include "JsonReader@d1.h"
#include "../internal/JsonReaderInternalAccess.h"

void meth_cggs_JsonReader__init_(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(42925, teavm_initializeClass((TeaVM_Class*) &cggs_JsonReader_Cls, &initclass_cggs_JsonReader));
    TEAVM_WITH_CALL_SITE_ID(42926, meth_jl_Object__init_(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lenient) = INT32_C(0);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42927, meth_otr_Allocator_allocateArray(&Arr_C_Cls, INT32_C(1024)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42928, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(32)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = INT32_C(0);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = (teavm_local_3 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42929, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, int32_t, TEAVM_WITH_CALL_SITE_ID(42930, teavm_checkBounds(teavm_local_3, teavm_local_2))) = INT32_C(6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42931, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(32)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames) = teavm_local_2;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42932, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(32)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices) = teavm_local_2;
    if ((teavm_local_1 == NULL)) {
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42933, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(42934, meth_jl_NullPointerException__init__0(teavm_local_4, TEAVM_GET_STRING(8098)));
        TEAVM_WITH_CALL_SITE_ID(42935, meth_otr_ExceptionHandling_throwException(teavm_local_4));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_in) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_setLenient(void* teavm_this_, int32_t teavm_local_1) {
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lenient) = teavm_local_1;
}
void meth_cggs_JsonReader_beginArray(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(42936, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 != INT32_C(3))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42937, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42938, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42939, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42940, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(8099)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42941, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42942, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42943, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42944, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42945, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42946, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42947, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42948, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42949, meth_jl_IllegalStateException__init_(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(42950, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(42951, meth_cggs_JsonReader_push(teavm_this_, INT32_C(1)));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
    teavm_local_6 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(42952, teavm_nullCheck(teavm_local_5));
    TEAVM_ARRAY_AT(teavm_local_5, int32_t, TEAVM_WITH_CALL_SITE_ID(42953, teavm_checkBounds(teavm_local_6, teavm_local_5))) = INT32_C(0);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_endArray(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(42954, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 != INT32_C(4))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42955, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42956, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42957, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42958, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(8100)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42959, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42960, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42961, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42962, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42963, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42964, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42965, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42966, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42967, meth_jl_IllegalStateException__init_(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(42968, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
    teavm_local_6 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(42969, teavm_nullCheck(teavm_local_5));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(42970, teavm_checkBounds(teavm_local_6, teavm_local_5));
    TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_7) = (TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_7) + INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_beginObject(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(42971, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 != INT32_C(1))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42972, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42973, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42974, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42975, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(8101)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42976, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42977, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42978, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42979, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42980, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42981, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42982, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42983, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42984, meth_jl_IllegalStateException__init_(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(42985, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_WITH_CALL_SITE_ID(42986, meth_cggs_JsonReader_push(teavm_this_, INT32_C(3)));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_endObject(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(42987, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 != INT32_C(2))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(42988, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42989, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(42990, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42991, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(8102)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42992, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42993, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42994, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(42995, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42996, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42997, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(42998, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(42999, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(43000, meth_jl_IllegalStateException__init_(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(43001, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames);
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize);
    teavm_local_3 = NULL;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43002, teavm_nullCheck(teavm_local_5));
    TEAVM_ARRAY_AT(teavm_local_5, void*, TEAVM_WITH_CALL_SITE_ID(43003, teavm_checkBounds(teavm_local_6, teavm_local_5))) = teavm_local_3;
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
    teavm_local_6 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43004, teavm_nullCheck(teavm_local_5));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43005, teavm_checkBounds(teavm_local_6, teavm_local_5));
    TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_7) = (TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_7) + INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    TEAVM_RELEASE_STACK;
}
int32_t meth_cggs_JsonReader_hasNext(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43006, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    teavm_local_2 = ((!((teavm_local_1 != INT32_C(2)) && ((teavm_local_1 != INT32_C(4)) && (teavm_local_1 != INT32_C(17))))) ? INT32_C(0) : INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_cggs_JsonReader_peek(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43007, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    switch (teavm_local_1) {
        case 1:
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43008, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
            teavm_local_2 = sfld_cggs_JsonToken_BEGIN_OBJECT;
            goto teavm_label_1;
        case 2:
            goto teavm_label_10;
        case 3:
            goto teavm_label_9;
        case 4:
            goto teavm_label_8;
        case 5:
        case 6:
            goto teavm_label_7;
        case 7:
            goto teavm_label_6;
        case 8:
        case 9:
        case 10:
        case 11:
            goto teavm_label_5;
        case 12:
        case 13:
        case 14:
            goto teavm_label_4;
        case 15:
        case 16:
            goto teavm_label_3;
        case 17:
            goto teavm_label_2;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43009, meth_otr_Allocator_allocate(&jl_AssertionError_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(43010, meth_jl_AssertionError__init__0(teavm_local_2));
    TEAVM_WITH_CALL_SITE_ID(43011, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
teavm_label_10:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43012, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_END_OBJECT;
    goto teavm_label_1;
teavm_label_9:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43013, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_BEGIN_ARRAY;
    goto teavm_label_1;
teavm_label_8:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43014, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_END_ARRAY;
    goto teavm_label_1;
teavm_label_7:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43015, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_BOOLEAN;
    goto teavm_label_1;
teavm_label_6:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43016, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_NULL;
    goto teavm_label_1;
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43017, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_STRING;
    goto teavm_label_1;
teavm_label_4:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43018, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_NAME;
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43019, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_NUMBER;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43020, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_2 = sfld_cggs_JsonToken_END_DOCUMENT;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_cggs_JsonReader_doPeek(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
    teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43021, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(43022, teavm_checkBounds(teavm_local_2, teavm_local_1)));
    teavm_local_2 = teavm_compare_i32(teavm_local_3, INT32_C(1));
    if ((!teavm_local_2)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
        teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43023, teavm_nullCheck(teavm_local_1));
        TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(43024, teavm_checkBounds(teavm_local_4, teavm_local_1))) = INT32_C(2);
    } else if ((teavm_local_3 == INT32_C(2))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43025, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(1)));
        switch (teavm_local_5) {
            case 44:
                goto teavm_label_3;
            case 59:
                TEAVM_WITH_CALL_SITE_ID(43026, meth_cggs_JsonReader_checkLenient(teavm_this_));
                goto teavm_label_3;
            case 93:
                goto teavm_label_5;
            default:
                goto teavm_label_4;
        }
    teavm_label_5:;
        teavm_local_6 = INT32_C(4);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
        goto teavm_label_1;
    teavm_label_4:;
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43027, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8103)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(43028, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43029, teavm_nullCheck(teavm_local_7))));
        TEAVM_UNREACHABLE
    teavm_label_3:;
    } else {
        if ((!((teavm_local_3 != INT32_C(3)) && (teavm_local_3 != INT32_C(5))))) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
            teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43030, teavm_nullCheck(teavm_local_1));
            TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(43031, teavm_checkBounds(teavm_local_2, teavm_local_1))) = INT32_C(4);
            teavm_local_2 = teavm_compare_i32(teavm_local_3, INT32_C(5));
            if ((!teavm_local_2)) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43032, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(1)));
                switch (teavm_local_5) {
                    case 44:
                        goto teavm_label_6;
                    case 59:
                        TEAVM_WITH_CALL_SITE_ID(43033, meth_cggs_JsonReader_checkLenient(teavm_this_));
                        goto teavm_label_6;
                    case 125:
                        goto teavm_label_8;
                    default:
                        goto teavm_label_7;
                }
            teavm_label_8:;
                teavm_local_6 = INT32_C(2);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
                goto teavm_label_1;
            teavm_label_7:;
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43034, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8104)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                TEAVM_WITH_CALL_SITE_ID(43035, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43036, teavm_nullCheck(teavm_local_7))));
                TEAVM_UNREACHABLE
            teavm_label_6:;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43037, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(1)));
            switch (teavm_local_5) {
                case 34:
                    goto teavm_label_12;
                case 39:
                    goto teavm_label_11;
                case 125:
                    goto teavm_label_10;
                default:
                    goto teavm_label_9;
            }
        teavm_label_12:;
            teavm_local_6 = INT32_C(13);
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
            goto teavm_label_1;
        teavm_label_11:;
            TEAVM_WITH_CALL_SITE_ID(43038, meth_cggs_JsonReader_checkLenient(teavm_this_));
            teavm_local_6 = INT32_C(12);
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
            goto teavm_label_1;
        teavm_label_10:;
            if (teavm_local_2) {
                teavm_local_6 = INT32_C(2);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
                goto teavm_label_1;
            }
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43039, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8105)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(43040, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43041, teavm_nullCheck(teavm_local_7))));
            TEAVM_UNREACHABLE
        teavm_label_9:;
            TEAVM_WITH_CALL_SITE_ID(43042, meth_cggs_JsonReader_checkLenient(teavm_this_));
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - INT32_C(1));
            if (TEAVM_WITH_CALL_SITE_ID(43043, meth_cggs_JsonReader_isLiteral(teavm_this_, TEAVM_TO_CHAR(teavm_local_5)))) {
                teavm_local_6 = INT32_C(14);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
                goto teavm_label_1;
            }
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43044, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8105)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(43045, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43046, teavm_nullCheck(teavm_local_7))));
            TEAVM_UNREACHABLE
        }
        if ((teavm_local_3 != INT32_C(4))) {
            if ((teavm_local_3 == INT32_C(6))) {
                if (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lenient)) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    TEAVM_WITH_CALL_SITE_ID(43047, meth_cggs_JsonReader_consumeNonExecutePrefix(teavm_this_));
                }
                teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
                teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
                teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43048, teavm_nullCheck(teavm_local_1));
                TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(43049, teavm_checkBounds(teavm_local_4, teavm_local_1))) = INT32_C(7);
                goto teavm_label_2;
            }
            if ((teavm_local_3 == INT32_C(7))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43050, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(0)));
                if ((teavm_local_5 == -INT32_C(1))) {
                    teavm_local_6 = INT32_C(17);
                    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
                    goto teavm_label_1;
                }
                TEAVM_WITH_CALL_SITE_ID(43051, meth_cggs_JsonReader_checkLenient(teavm_this_));
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - INT32_C(1));
                goto teavm_label_2;
            }
            if ((teavm_local_3 != INT32_C(8))) {
                goto teavm_label_2;
            }
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43052, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
            TEAVM_WITH_CALL_SITE_ID(43053, meth_jl_IllegalStateException__init_(teavm_local_7, TEAVM_GET_STRING(8106)));
            TEAVM_WITH_CALL_SITE_ID(43054, meth_otr_ExceptionHandling_throwException(teavm_local_7));
            TEAVM_UNREACHABLE
        }
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
        teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43055, teavm_nullCheck(teavm_local_1));
        TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(43056, teavm_checkBounds(teavm_local_4, teavm_local_1))) = INT32_C(5);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43057, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(1)));
        switch (teavm_local_5) {
            case 58:
                goto teavm_label_13;
            case 61:
                goto teavm_label_14;
        }
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43058, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8107)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(43059, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43060, teavm_nullCheck(teavm_local_7))));
        TEAVM_UNREACHABLE
    teavm_label_14:;
        TEAVM_WITH_CALL_SITE_ID(43061, meth_cggs_JsonReader_checkLenient(teavm_this_));
        if ((!((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) >= TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit)) && (!TEAVM_WITH_CALL_SITE_ID(43062, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))))) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43063, teavm_nullCheck(teavm_local_1));
            if ((TEAVM_ARRAY_AT(teavm_local_1, char16_t, TEAVM_WITH_CALL_SITE_ID(43064, teavm_checkBounds(teavm_local_4, teavm_local_1))) == INT32_C(62))) {
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
            }
        }
    teavm_label_13:;
    }
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43065, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(1)));
    switch (teavm_local_5) {
        case 34:
            goto teavm_label_22;
        case 39:
            goto teavm_label_19;
        case 44:
        case 59:
            goto teavm_label_17;
        case 91:
            goto teavm_label_21;
        case 93:
            goto teavm_label_18;
        case 123:
            goto teavm_label_20;
        default:
            goto teavm_label_16;
    }
teavm_label_22:;
    teavm_local_6 = INT32_C(9);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
    goto teavm_label_1;
teavm_label_21:;
    teavm_local_6 = INT32_C(3);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
    goto teavm_label_1;
teavm_label_20:;
    teavm_local_6 = INT32_C(1);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
    goto teavm_label_1;
teavm_label_19:;
    TEAVM_WITH_CALL_SITE_ID(43066, meth_cggs_JsonReader_checkLenient(teavm_this_));
    teavm_local_6 = INT32_C(8);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
    goto teavm_label_1;
teavm_label_18:;
    if ((!teavm_local_2)) {
        teavm_local_6 = INT32_C(4);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
        goto teavm_label_1;
    }
teavm_label_17:;
    if ((teavm_local_2 && (teavm_local_3 != INT32_C(2)))) {
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43067, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8108)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(43068, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43069, teavm_nullCheck(teavm_local_7))));
        TEAVM_UNREACHABLE
    }
    TEAVM_WITH_CALL_SITE_ID(43070, meth_cggs_JsonReader_checkLenient(teavm_this_));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - INT32_C(1));
    teavm_local_6 = INT32_C(7);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
    goto teavm_label_1;
teavm_label_16:;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - INT32_C(1));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43071, meth_cggs_JsonReader_peekKeyword(teavm_this_));
    if ((!teavm_local_6)) {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43072, meth_cggs_JsonReader_peekNumber(teavm_this_));
        if ((!teavm_local_6)) {
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43073, teavm_nullCheck(teavm_local_1));
            teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, TEAVM_WITH_CALL_SITE_ID(43074, teavm_checkBounds(teavm_local_2, teavm_local_1)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if (TEAVM_WITH_CALL_SITE_ID(43075, meth_cggs_JsonReader_isLiteral(teavm_this_, teavm_local_2))) {
                TEAVM_WITH_CALL_SITE_ID(43076, meth_cggs_JsonReader_checkLenient(teavm_this_));
                teavm_local_6 = INT32_C(10);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
            } else {
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43077, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8109)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
                TEAVM_WITH_CALL_SITE_ID(43078, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43079, teavm_nullCheck(teavm_local_7))));
                TEAVM_UNREACHABLE
            }
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_cggs_JsonReader_peekKeyword(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43080, teavm_nullCheck(teavm_local_1));
    teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, TEAVM_WITH_CALL_SITE_ID(43081, teavm_checkBounds(teavm_local_2, teavm_local_1)));
    if ((!((teavm_local_3 != INT32_C(116)) && (teavm_local_3 != INT32_C(84))))) {
        teavm_local_4 = TEAVM_GET_STRING(29);
        teavm_local_5 = TEAVM_GET_STRING(560);
        teavm_local_6 = INT32_C(5);
    } else if ((!((teavm_local_3 != INT32_C(102)) && (teavm_local_3 != INT32_C(70))))) {
        teavm_local_4 = TEAVM_GET_STRING(30);
        teavm_local_5 = TEAVM_GET_STRING(562);
        teavm_local_6 = INT32_C(6);
    } else {
        if (((teavm_local_3 != INT32_C(110)) && (teavm_local_3 != INT32_C(78)))) {
            teavm_local_6 = INT32_C(0);
            goto teavm_label_1;
        }
        teavm_local_4 = TEAVM_GET_STRING(498);
        teavm_local_5 = TEAVM_GET_STRING(7711);
        teavm_local_6 = INT32_C(7);
    }
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43082, meth_jl_String_length(teavm_local_4));
    teavm_local_8 = INT32_C(1);
    while (1) {
        if ((teavm_local_8 >= teavm_local_7)) {
            goto teavm_label_2;
        }
        if (((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_8) >= TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) {
            teavm_local_2 = (teavm_local_8 + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            if ((!TEAVM_WITH_CALL_SITE_ID(43083, meth_cggs_JsonReader_fillBuffer(teavm_this_, teavm_local_2)))) {
                goto teavm_label_3;
            }
        }
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43084, teavm_nullCheck(teavm_local_1));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, TEAVM_WITH_CALL_SITE_ID(43085, teavm_checkBounds(teavm_local_2, teavm_local_1)));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(43086, meth_jl_String_charAt(teavm_local_4, teavm_local_8)))) {
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43087, teavm_nullCheck(teavm_local_5));
            if ((teavm_local_2 != TEAVM_WITH_CALL_SITE_ID(43088, meth_jl_String_charAt(teavm_local_5, teavm_local_8)))) {
                goto teavm_label_4;
            }
        }
        teavm_local_8 = (teavm_local_8 + INT32_C(1));
    }
teavm_label_4:;
    teavm_local_6 = INT32_C(0);
    goto teavm_label_1;
teavm_label_3:;
    teavm_local_6 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    if (((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_7) >= TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) {
        teavm_local_2 = (teavm_local_7 + INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((!TEAVM_WITH_CALL_SITE_ID(43089, meth_cggs_JsonReader_fillBuffer(teavm_this_, teavm_local_2)))) {
            goto teavm_label_5;
        }
    }
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_7);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43090, teavm_nullCheck(teavm_local_1));
    teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, TEAVM_WITH_CALL_SITE_ID(43091, teavm_checkBounds(teavm_local_2, teavm_local_1)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if (TEAVM_WITH_CALL_SITE_ID(43092, meth_cggs_JsonReader_isLiteral(teavm_this_, teavm_local_2))) {
        teavm_local_6 = INT32_C(0);
        goto teavm_label_1;
    }
teavm_label_5:;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_7);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_6;
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_cggs_JsonReader_peekNumber(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    int64_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    int64_t teavm_local_12;
    int32_t teavm_local_13;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
    teavm_local_4 = INT64_C(0);
    teavm_local_5 = INT32_C(0);
    teavm_local_6 = INT32_C(1);
    teavm_local_7 = INT32_C(0);
    teavm_local_8 = INT32_C(0);
    while (1) {
        if (((teavm_local_2 + teavm_local_8) == teavm_local_3)) {
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43093, teavm_nullCheck(teavm_local_1));
            if ((teavm_local_8 == TEAVM_ARRAY_LENGTH(teavm_local_1))) {
                goto teavm_label_10;
            }
            if ((!TEAVM_WITH_CALL_SITE_ID(43094, meth_cggs_JsonReader_fillBuffer(teavm_this_, (teavm_local_8 + INT32_C(1)))))) {
                goto teavm_label_4;
            }
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        }
        teavm_local_9 = (teavm_local_2 + teavm_local_8);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43095, teavm_nullCheck(teavm_local_1));
        teavm_local_10 = teavm_local_1;
        teavm_local_11 = TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(43096, teavm_checkBounds(teavm_local_9, teavm_local_10)));
        switch (teavm_local_11) {
            case 43:
                goto teavm_label_16;
            case 45:
                goto teavm_label_14;
            case 46:
                goto teavm_label_15;
            case 69:
            case 101:
                goto teavm_label_13;
            default:
                goto teavm_label_12;
        }
    teavm_label_16:;
        if ((teavm_local_7 != INT32_C(5))) {
            goto teavm_label_9;
        }
        teavm_local_7 = INT32_C(6);
        goto teavm_label_11;
    teavm_label_15:;
        if ((teavm_local_7 != INT32_C(2))) {
            goto teavm_label_7;
        }
        teavm_local_7 = INT32_C(3);
        goto teavm_label_11;
    teavm_label_14:;
        if ((!teavm_local_7)) {
            teavm_local_5 = INT32_C(1);
            teavm_local_7 = INT32_C(1);
            goto teavm_label_11;
        }
        if ((teavm_local_7 != INT32_C(5))) {
            goto teavm_label_8;
        }
        teavm_local_7 = INT32_C(6);
        goto teavm_label_11;
    teavm_label_13:;
        if (((teavm_local_7 != INT32_C(2)) && (teavm_local_7 != INT32_C(4)))) {
            goto teavm_label_6;
        }
        teavm_local_7 = INT32_C(5);
        goto teavm_label_11;
    teavm_label_12:;
        if ((teavm_local_11 < INT32_C(48))) {
            goto teavm_label_3;
        }
        if ((teavm_local_11 > INT32_C(57))) {
            goto teavm_label_3;
        }
        if ((!((teavm_local_7 != INT32_C(1)) && teavm_local_7))) {
            teavm_local_4 = ((int64_t) (-(teavm_local_11 - INT32_C(48))));
            teavm_local_7 = INT32_C(2);
        } else if ((teavm_local_7 != INT32_C(2))) {
            if ((teavm_local_7 == INT32_C(3))) {
                teavm_local_7 = INT32_C(4);
            } else if ((!((teavm_local_7 != INT32_C(5)) && (teavm_local_7 != INT32_C(6))))) {
                teavm_local_7 = INT32_C(7);
            }
        } else {
            if ((teavm_local_4 == INT64_C(0))) {
                goto teavm_label_5;
            }
            teavm_local_12 = ((teavm_local_4 * INT64_C(10)) - ((int64_t) (teavm_local_11 - INT32_C(48))));
            teavm_local_13 = teavm_compare_i64(teavm_local_4, -INT64_C(922337203685477580));
            if ((teavm_local_13 <= INT32_C(0))) {
                if (teavm_local_13) {
                    goto teavm_label_18;
                }
                if ((teavm_local_12 >= teavm_local_4)) {
                    goto teavm_label_18;
                }
            }
            teavm_local_13 = INT32_C(1);
            goto teavm_label_17;
        teavm_label_18:;
            teavm_local_13 = INT32_C(0);
        teavm_label_17:;
            teavm_local_6 = (teavm_local_6 & teavm_local_13);
            teavm_local_4 = teavm_local_12;
        }
    teavm_label_11:;
        teavm_local_8 = (teavm_local_8 + INT32_C(1));
    }
teavm_label_10:;
    teavm_local_13 = INT32_C(0);
    goto teavm_label_1;
teavm_label_9:;
    teavm_local_13 = INT32_C(0);
    goto teavm_label_1;
teavm_label_8:;
    teavm_local_13 = INT32_C(0);
    goto teavm_label_1;
teavm_label_7:;
    teavm_local_13 = INT32_C(0);
    goto teavm_label_1;
teavm_label_6:;
    teavm_local_13 = INT32_C(0);
    goto teavm_label_1;
teavm_label_5:;
    teavm_local_13 = INT32_C(0);
    goto teavm_label_1;
teavm_label_4:;
    goto teavm_label_2;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    if (TEAVM_WITH_CALL_SITE_ID(43097, meth_cggs_JsonReader_isLiteral(teavm_this_, teavm_local_11))) {
        teavm_local_13 = INT32_C(0);
        goto teavm_label_1;
    }
teavm_label_2:;
    teavm_local_13 = teavm_compare_i32(teavm_local_7, INT32_C(2));
    if (((!teavm_local_13) && (teavm_local_6 && ((!((teavm_local_4 == (int64_t) INT64_C(0x8000000000000000)) && (!teavm_local_5))) && (!((teavm_local_4 == INT64_C(0)) && (INT32_C(0) != teavm_local_5))))))) {
        if ((!teavm_local_5)) {
            teavm_local_4 = (-teavm_local_4);
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedLong) = teavm_local_4;
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_8);
        teavm_local_13 = INT32_C(15);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_13;
    } else if ((teavm_local_13 && ((teavm_local_7 != INT32_C(4)) && (teavm_local_7 != INT32_C(7))))) {
        teavm_local_13 = INT32_C(0);
    } else {
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength) = teavm_local_8;
        teavm_local_13 = INT32_C(16);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = teavm_local_13;
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_13;
}
int32_t meth_cggs_JsonReader_isLiteral(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    switch (teavm_local_1) {
        case 9:
        case 10:
        case 12:
        case 13:
        case 32:
        case 44:
        case 58:
        case 91:
        case 93:
        case 123:
        case 125:
            goto teavm_label_2;
        case 35:
        case 47:
        case 59:
        case 61:
        case 92:
            goto teavm_label_3;
    }
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_WITH_CALL_SITE_ID(43098, meth_cggs_JsonReader_checkLenient(teavm_this_));
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_cggs_JsonReader_nextName(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43099, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 == INT32_C(14))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43100, meth_cggs_JsonReader_nextUnquotedValue(teavm_this_));
    } else if ((teavm_local_1 == INT32_C(12))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43101, meth_cggs_JsonReader_nextQuotedValue(teavm_this_, INT32_C(39)));
    } else {
        if ((teavm_local_1 != INT32_C(13))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43102, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43103, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(43104, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43105, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_0)(teavm_local_4, TEAVM_GET_STRING(8110)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43106, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43107, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43108, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_5)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43109, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43110, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43111, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_5)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43112, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43113, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(43114, meth_jl_IllegalStateException__init_(teavm_local_3, teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43115, meth_otr_ExceptionHandling_throwException(teavm_local_3));
            TEAVM_UNREACHABLE
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43116, meth_cggs_JsonReader_nextQuotedValue(teavm_this_, INT32_C(34)));
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames);
    teavm_local_7 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43117, teavm_nullCheck(teavm_local_6));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43118, teavm_checkBounds(teavm_local_7, teavm_local_6));
    teavm_gc_writeBarrier(teavm_local_6);
    TEAVM_ARRAY_AT(teavm_local_6, void*, teavm_local_7) = teavm_local_2;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_cggs_JsonReader_nextString(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    int64_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43119, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 == INT32_C(10))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43120, meth_cggs_JsonReader_nextUnquotedValue(teavm_this_));
    } else if ((teavm_local_1 == INT32_C(8))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43121, meth_cggs_JsonReader_nextQuotedValue(teavm_this_, INT32_C(39)));
    } else if ((teavm_local_1 == INT32_C(9))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43122, meth_cggs_JsonReader_nextQuotedValue(teavm_this_, INT32_C(34)));
    } else if ((teavm_local_1 == INT32_C(11))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = NULL;
    } else if ((teavm_local_1 == INT32_C(15))) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedLong);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43123, meth_jl_Long_toString(teavm_local_3));
    } else if ((teavm_local_1 == INT32_C(16))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43124, meth_otr_Allocator_allocate(&jl_String_Cls));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(43125, meth_jl_String__init_(teavm_local_2, teavm_local_4, teavm_local_5, teavm_local_6));
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43126, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43127, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_WITH_CALL_SITE_ID(43128, meth_jl_StringBuilder__init_(teavm_local_8));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43129, TEAVM_METHOD(teavm_local_8, jl_StringBuilder_VT, virt_append_0)(teavm_local_8, TEAVM_GET_STRING(8111)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43130, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43131, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43132, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_9)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43133, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43134, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43135, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_9)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43136, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43137, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
        TEAVM_WITH_CALL_SITE_ID(43138, meth_jl_IllegalStateException__init_(teavm_local_7, teavm_local_8));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(43139, meth_otr_ExceptionHandling_throwException(teavm_local_7));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
    teavm_local_5 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43140, teavm_nullCheck(teavm_local_4));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43141, teavm_checkBounds(teavm_local_5, teavm_local_4));
    TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_10) = (TEAVM_ARRAY_AT(teavm_local_4, int32_t, teavm_local_10) + INT32_C(1));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
int32_t meth_cggs_JsonReader_nextBoolean(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43142, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 == INT32_C(5))) {
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43143, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43144, teavm_checkBounds(teavm_local_3, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) + INT32_C(1));
        teavm_local_3 = INT32_C(1);
    } else {
        if ((teavm_local_1 != INT32_C(6))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43145, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_5);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43146, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(43147, meth_jl_StringBuilder__init_(teavm_local_6));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43148, TEAVM_METHOD(teavm_local_6, jl_StringBuilder_VT, virt_append_0)(teavm_local_6, TEAVM_GET_STRING(8112)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43149, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43150, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43151, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_7)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43152, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43153, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43154, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_7)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43155, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43156, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(43157, meth_jl_IllegalStateException__init_(teavm_local_5, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43158, meth_otr_ExceptionHandling_throwException(teavm_local_5));
            TEAVM_UNREACHABLE
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43159, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43160, teavm_checkBounds(teavm_local_3, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) + INT32_C(1));
        teavm_local_3 = INT32_C(0);
    }
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void meth_cggs_JsonReader_nextNull(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43161, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 != INT32_C(7))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43162, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43163, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(43164, meth_jl_StringBuilder__init_(teavm_local_3));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43165, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(8113)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43166, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43167, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43168, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43169, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43170, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43171, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43172, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43173, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(43174, meth_jl_IllegalStateException__init_(teavm_local_2, teavm_local_3));
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(43175, meth_otr_ExceptionHandling_throwException(teavm_local_2));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
    teavm_local_6 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43176, teavm_nullCheck(teavm_local_5));
    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43177, teavm_checkBounds(teavm_local_6, teavm_local_5));
    TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_7) = (TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_7) + INT32_C(1));
    TEAVM_RELEASE_STACK;
}
int64_t meth_cggs_JsonReader_nextLong(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int64_t teavm_local_5;
    void* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    void* teavm_local_9;
    double teavm_local_10;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43178, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 == INT32_C(15))) {
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43179, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43180, teavm_checkBounds(teavm_local_3, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) + INT32_C(1));
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedLong);
    } else {
        if ((teavm_local_1 == INT32_C(16))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43181, meth_otr_Allocator_allocate(&jl_String_Cls));
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(43182, meth_jl_String__init_(teavm_local_6, teavm_local_2, teavm_local_3, teavm_local_7));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = teavm_local_6;
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength));
        } else {
            teavm_local_3 = teavm_compare_i32(teavm_local_1, INT32_C(8));
            if ((teavm_local_3 && ((teavm_local_1 != INT32_C(9)) && (teavm_local_1 != INT32_C(10))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43183, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43184, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(43185, meth_jl_StringBuilder__init_(teavm_local_8));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43186, TEAVM_METHOD(teavm_local_8, jl_StringBuilder_VT, virt_append_0)(teavm_local_8, TEAVM_GET_STRING(8114)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43187, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43188, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43189, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_9)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43190, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43191, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43192, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_9)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43193, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43194, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
                TEAVM_WITH_CALL_SITE_ID(43195, meth_jl_IllegalStateException__init_(teavm_local_6, teavm_local_8));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(43196, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                TEAVM_UNREACHABLE
            }
            if ((teavm_local_1 == INT32_C(10))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43197, meth_cggs_JsonReader_nextUnquotedValue(teavm_this_));
                teavm_gc_writeBarrier(teavm_this_);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = teavm_local_6;
            } else {
                teavm_local_3 = (teavm_local_3 ? INT32_C(34) : INT32_C(39));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43198, meth_cggs_JsonReader_nextQuotedValue(teavm_this_, teavm_local_3));
                teavm_gc_writeBarrier(teavm_this_);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = teavm_local_6;
            }
            TEAVM_TRY
                teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43199, meth_jl_Long_parseLong_0(teavm_local_6));
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
                teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43200, teavm_nullCheck(teavm_local_2));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43201, teavm_checkBounds(teavm_local_3, teavm_local_2));
                TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) + INT32_C(1));
                TEAVM_RESTORE_JUMP_BUFFER;
                goto teavm_label_1;
            TEAVM_CATCH
                // CATCH java.lang.NumberFormatException
                case 1: {
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
        teavm_label_2:;
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(11);
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43202, meth_jl_Double_parseDouble(teavm_local_6));
        teavm_local_5 = ((int64_t) teavm_local_10);
        if ((((double) teavm_local_5) != teavm_local_10)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43203, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43204, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            TEAVM_WITH_CALL_SITE_ID(43205, meth_jl_StringBuilder__init_(teavm_local_8));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43206, TEAVM_METHOD(teavm_local_8, jl_StringBuilder_VT, virt_append_0)(teavm_local_8, TEAVM_GET_STRING(8114)));
            teavm_local_9 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43207, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43208, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_9)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43209, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_9);
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43210, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43211, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_9)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43212, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43213, teavm_nullCheck(teavm_local_8))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_8);
            TEAVM_WITH_CALL_SITE_ID(43214, meth_jl_NumberFormatException__init_(teavm_local_6, teavm_local_8));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(43215, meth_otr_ExceptionHandling_throwException(teavm_local_6));
            TEAVM_UNREACHABLE
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = NULL;
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43216, teavm_nullCheck(teavm_local_2));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43217, teavm_checkBounds(teavm_local_3, teavm_local_2));
        TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) = (TEAVM_ARRAY_AT(teavm_local_2, int32_t, teavm_local_4) + INT32_C(1));
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_5;
}
void* meth_cggs_JsonReader_nextQuotedValue(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    int32_t teavm_local_9;
    int32_t teavm_local_10;
    void* teavm_local_11;
    int32_t teavm_local_12;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_3 = NULL;
    while (1) {
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        teavm_local_6 = teavm_local_4;
        while (1) {
            if (!(teavm_local_6 < teavm_local_5)) break;
            teavm_local_7 = (teavm_local_6 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43218, teavm_nullCheck(teavm_local_2));
            teavm_local_8 = teavm_local_2;
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, char16_t, TEAVM_WITH_CALL_SITE_ID(43219, teavm_checkBounds(teavm_local_6, teavm_local_8)));
            if ((teavm_local_9 == teavm_local_1)) {
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_7;
                teavm_local_10 = ((teavm_local_7 - teavm_local_4) - INT32_C(1));
                if ((teavm_local_3 != NULL)) {
                    TEAVM_WITH_CALL_SITE_ID(43220, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_52)(teavm_local_3, teavm_local_2, teavm_local_4, teavm_local_10));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(43221, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_toString)(teavm_local_3));
                } else {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(43222, meth_otr_Allocator_allocate(&jl_String_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
                    TEAVM_WITH_CALL_SITE_ID(43223, meth_jl_String__init_(teavm_local_11, teavm_local_2, teavm_local_4, teavm_local_10));
                }
                TEAVM_RELEASE_STACK;
                return teavm_local_11;
            }
            if ((teavm_local_9 != INT32_C(92))) {
                if ((teavm_local_9 != INT32_C(10))) {
                    teavm_local_6 = teavm_local_7;
                } else {
                    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
                    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = teavm_local_7;
                    teavm_local_6 = teavm_local_7;
                }
            } else {
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_7;
                teavm_local_10 = ((teavm_local_7 - teavm_local_4) - INT32_C(1));
                if ((teavm_local_3 == NULL)) {
                    teavm_local_12 = ((teavm_local_10 + INT32_C(1)) * INT32_C(2));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43224, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                    TEAVM_WITH_CALL_SITE_ID(43225, meth_jl_StringBuilder__init__0(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(43226, meth_jl_Math_max(teavm_local_12, INT32_C(16)))));
                }
                TEAVM_WITH_CALL_SITE_ID(43227, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_52)(teavm_local_3, teavm_local_2, teavm_local_4, teavm_local_10));
                TEAVM_WITH_CALL_SITE_ID(43228, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_28)(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(43229, meth_cggs_JsonReader_readEscapeCharacter(teavm_this_))));
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
                teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
                teavm_local_6 = teavm_local_4;
            }
        }
        if ((teavm_local_3 == NULL)) {
            teavm_local_12 = ((teavm_local_6 - teavm_local_4) * INT32_C(2));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43230, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(43231, meth_jl_StringBuilder__init__0(teavm_local_3, TEAVM_WITH_CALL_SITE_ID(43232, meth_jl_Math_max(teavm_local_12, INT32_C(16)))));
        }
        teavm_local_7 = (teavm_local_6 - teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(43233, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_52)(teavm_local_3, teavm_local_2, teavm_local_4, teavm_local_7));
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_6;
        if ((!TEAVM_WITH_CALL_SITE_ID(43234, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))) {
            goto teavm_label_1;
        }
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(43235, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8115)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_11);
    TEAVM_WITH_CALL_SITE_ID(43236, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43237, teavm_nullCheck(teavm_local_11))));
    TEAVM_UNREACHABLE
}
void* meth_cggs_JsonReader_nextUnquotedValue(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = NULL;
    teavm_local_2 = INT32_C(0);
    while (1) {
        if (((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_2) < TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
            teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43238, teavm_nullCheck(teavm_local_3));
            switch (TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43239, teavm_checkBounds(teavm_local_4, teavm_local_3)))) {
                case 9:
                case 10:
                case 12:
                case 13:
                case 32:
                case 44:
                case 58:
                case 91:
                case 93:
                case 123:
                case 125:
                    goto teavm_label_2;
                case 35:
                case 47:
                case 59:
                case 61:
                case 92:
                    goto teavm_label_3;
            }
            teavm_local_2 = (teavm_local_2 + INT32_C(1));
            goto teavm_cnt_5;
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        if ((teavm_local_2 < TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(43240, teavm_nullCheck(teavm_local_3))))) {
            teavm_local_4 = (teavm_local_2 + INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            if ((!TEAVM_WITH_CALL_SITE_ID(43241, meth_cggs_JsonReader_fillBuffer(teavm_this_, teavm_local_4)))) {
                goto teavm_label_4;
            }
            goto teavm_cnt_5;
        }
        if ((teavm_local_1 == NULL)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43242, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(43243, meth_jl_StringBuilder__init__0(teavm_local_1, TEAVM_WITH_CALL_SITE_ID(43244, meth_jl_Math_max(teavm_local_2, INT32_C(16)))));
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(43245, TEAVM_METHOD(teavm_local_1, jl_StringBuilder_VT, virt_append_52)(teavm_local_1, teavm_local_3, teavm_local_4, teavm_local_2));
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_2);
        teavm_local_2 = INT32_C(0);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        if ((!TEAVM_WITH_CALL_SITE_ID(43246, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))) {
            goto teavm_label_5;
        }
    teavm_cnt_5:;
    }
teavm_label_5:;
    goto teavm_label_1;
teavm_label_4:;
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(43247, meth_cggs_JsonReader_checkLenient(teavm_this_));
teavm_label_2:;
teavm_label_1:;
    if ((NULL != teavm_local_1)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43248, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43249, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_52)(teavm_tmp_ptr_0, teavm_local_3, teavm_local_5, teavm_local_2)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43250, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43251, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43252, meth_otr_Allocator_allocate(&jl_String_Cls));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(43253, meth_jl_String__init_(teavm_local_7, teavm_local_3, teavm_local_5, teavm_local_2));
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_2);
    TEAVM_RELEASE_STACK;
    return teavm_local_7;
}
void meth_cggs_JsonReader_skipQuotedValue(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TeaVM_Array* teavm_local_6;
    int32_t teavm_local_7;
    void* teavm_local_8;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    while (1) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        while (1) {
            if (!(teavm_local_3 < teavm_local_4)) break;
            teavm_local_5 = (teavm_local_3 + INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43254, teavm_nullCheck(teavm_local_2));
            teavm_local_6 = teavm_local_2;
            teavm_local_7 = TEAVM_ARRAY_AT(teavm_local_6, char16_t, TEAVM_WITH_CALL_SITE_ID(43255, teavm_checkBounds(teavm_local_3, teavm_local_6)));
            if ((teavm_local_7 == teavm_local_1)) {
                goto teavm_label_1;
            }
            if ((teavm_local_7 == INT32_C(92))) {
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_5;
                TEAVM_WITH_CALL_SITE_ID(43256, meth_cggs_JsonReader_readEscapeCharacter(teavm_this_));
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
                teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
            } else if ((teavm_local_7 != INT32_C(10))) {
                teavm_local_3 = teavm_local_5;
            } else {
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = teavm_local_5;
                teavm_local_3 = teavm_local_5;
            }
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_3;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        if ((!TEAVM_WITH_CALL_SITE_ID(43257, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43258, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8115)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_8);
            TEAVM_WITH_CALL_SITE_ID(43259, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43260, teavm_nullCheck(teavm_local_8))));
            TEAVM_UNREACHABLE
        }
    }
teavm_label_1:;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_5;
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_skipUnquotedValue(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    while (1) {
        teavm_local_1 = INT32_C(0);
        while (1) {
            if (!((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_1) < TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) break;
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
            teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43261, teavm_nullCheck(teavm_local_2));
            switch (TEAVM_ARRAY_AT(teavm_local_2, char16_t, TEAVM_WITH_CALL_SITE_ID(43262, teavm_checkBounds(teavm_local_3, teavm_local_2)))) {
                case 9:
                case 10:
                case 12:
                case 13:
                case 32:
                case 44:
                case 58:
                case 91:
                case 93:
                case 123:
                case 125:
                    goto teavm_label_2;
                case 35:
                case 47:
                case 59:
                case 61:
                case 92:
                    goto teavm_label_3;
            }
            teavm_local_1 = (teavm_local_1 + INT32_C(1));
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if (TEAVM_WITH_CALL_SITE_ID(43263, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1)))) {
            goto teavm_cnt_4;
        } else {
            goto teavm_label_4;
        }
    teavm_cnt_4:;
    }
teavm_label_4:;
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43264, meth_cggs_JsonReader_checkLenient(teavm_this_));
teavm_label_2:;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_cggs_JsonReader_nextInt(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    double teavm_local_10;
    int64_t teavm_local_11;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
    if ((!teavm_local_1)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43265, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
    }
    if ((teavm_local_1 != INT32_C(15))) {
        if ((teavm_local_1 == INT32_C(16))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43266, meth_otr_Allocator_allocate(&jl_String_Cls));
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
            TEAVM_WITH_CALL_SITE_ID(43267, meth_jl_String__init_(teavm_local_2, teavm_local_3, teavm_local_4, teavm_local_5));
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = teavm_local_2;
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength));
        } else {
            teavm_local_4 = teavm_compare_i32(teavm_local_1, INT32_C(8));
            if ((teavm_local_4 && ((teavm_local_1 != INT32_C(9)) && (teavm_local_1 != INT32_C(10))))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43268, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43269, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_WITH_CALL_SITE_ID(43270, meth_jl_StringBuilder__init_(teavm_local_6));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43271, TEAVM_METHOD(teavm_local_6, jl_StringBuilder_VT, virt_append_0)(teavm_local_6, TEAVM_GET_STRING(8116)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43272, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_peek)(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43273, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43274, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_7)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43275, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43276, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43277, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_7)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43278, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43279, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
                TEAVM_WITH_CALL_SITE_ID(43280, meth_jl_IllegalStateException__init_(teavm_local_2, teavm_local_6));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_WITH_CALL_SITE_ID(43281, meth_otr_ExceptionHandling_throwException(teavm_local_2));
                TEAVM_UNREACHABLE
            }
            if ((teavm_local_1 == INT32_C(10))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43282, meth_cggs_JsonReader_nextUnquotedValue(teavm_this_));
                teavm_gc_writeBarrier(teavm_this_);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = teavm_local_2;
            } else {
                teavm_local_4 = (teavm_local_4 ? INT32_C(34) : INT32_C(39));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43283, meth_cggs_JsonReader_nextQuotedValue(teavm_this_, teavm_local_4));
                teavm_gc_writeBarrier(teavm_this_);
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = teavm_local_2;
            }
            TEAVM_TRY
                teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43284, meth_jl_Integer_parseInt_0(teavm_local_2));
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
                teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43285, teavm_nullCheck(teavm_local_3));
                teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43286, teavm_checkBounds(teavm_local_4, teavm_local_3));
                TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_9) = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_9) + INT32_C(1));
                TEAVM_RESTORE_JUMP_BUFFER;
                goto teavm_label_1;
            TEAVM_CATCH
                // CATCH java.lang.NumberFormatException
                case 1: {
                    goto teavm_label_2;
                    break;
                }
            TEAVM_END_TRY
        teavm_label_2:;
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(11);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43287, meth_jl_Double_parseDouble(teavm_local_2));
        teavm_local_8 = ((int32_t) teavm_local_10);
        if ((((double) teavm_local_8) != teavm_local_10)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43288, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43289, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(43290, meth_jl_StringBuilder__init_(teavm_local_6));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43291, TEAVM_METHOD(teavm_local_6, jl_StringBuilder_VT, virt_append_0)(teavm_local_6, TEAVM_GET_STRING(8116)));
            teavm_local_7 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43292, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43293, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_7)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43294, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43295, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43296, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_7)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43297, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43298, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(43299, meth_jl_NumberFormatException__init_(teavm_local_2, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(43300, meth_otr_ExceptionHandling_throwException(teavm_local_2));
            TEAVM_UNREACHABLE
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedString) = NULL;
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43301, teavm_nullCheck(teavm_local_3));
        teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43302, teavm_checkBounds(teavm_local_4, teavm_local_3));
        TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_9) = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_9) + INT32_C(1));
    } else {
        teavm_local_8 = ((int32_t) TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedLong));
        if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedLong) == ((int64_t) teavm_local_8))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
            teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43303, teavm_nullCheck(teavm_local_3));
            teavm_local_9 = TEAVM_WITH_CALL_SITE_ID(43304, teavm_checkBounds(teavm_local_4, teavm_local_3));
            TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_9) = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_9) + INT32_C(1));
        } else {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43305, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43306, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(43307, meth_jl_StringBuilder__init_(teavm_local_6));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43308, TEAVM_METHOD(teavm_local_6, jl_StringBuilder_VT, virt_append_0)(teavm_local_6, TEAVM_GET_STRING(8116)));
            teavm_local_11 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedLong);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43309, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43310, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_26)(teavm_tmp_ptr_0, teavm_local_11)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43311, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_7);
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43312, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43313, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_7)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43314, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43315, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
            TEAVM_WITH_CALL_SITE_ID(43316, meth_jl_NumberFormatException__init_(teavm_local_2, teavm_local_6));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(43317, meth_otr_ExceptionHandling_throwException(teavm_local_2));
            TEAVM_UNREACHABLE
        }
    }
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_8;
}
void meth_cggs_JsonReader_close(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43318, teavm_nullCheck(teavm_local_1));
    TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(43319, teavm_checkUpperBound(INT32_C(0), teavm_local_1))) = INT32_C(8);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = INT32_C(1);
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_in);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(43320, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43321, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Reader_VT, virt_close)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_skipValue(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = INT32_C(0);
    while (1) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked);
        if ((!teavm_local_2)) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43322, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_doPeek)(teavm_this_));
        }
        if ((teavm_local_2 == INT32_C(3))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43323, meth_cggs_JsonReader_push(teavm_this_, INT32_C(1)));
            teavm_local_1 = (teavm_local_1 + INT32_C(1));
            goto teavm_label_2;
        }
        if ((teavm_local_2 == INT32_C(1))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43324, meth_cggs_JsonReader_push(teavm_this_, INT32_C(3)));
            teavm_local_1 = (teavm_local_1 + INT32_C(1));
            goto teavm_label_2;
        }
        if ((teavm_local_2 == INT32_C(4))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
            teavm_local_1 = (teavm_local_1 + -INT32_C(1));
            goto teavm_label_2;
        }
        if ((teavm_local_2 == INT32_C(2))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
            teavm_local_1 = (teavm_local_1 + -INT32_C(1));
            goto teavm_label_2;
        }
        if ((!((teavm_local_2 != INT32_C(14)) && (teavm_local_2 != INT32_C(10))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43325, meth_cggs_JsonReader_skipUnquotedValue(teavm_this_));
            goto teavm_label_2;
        }
        if ((!((teavm_local_2 != INT32_C(8)) && (teavm_local_2 != INT32_C(12))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43326, meth_cggs_JsonReader_skipQuotedValue(teavm_this_, INT32_C(39)));
            goto teavm_label_2;
        }
        if ((!((teavm_local_2 != INT32_C(9)) && (teavm_local_2 != INT32_C(13))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(43327, meth_cggs_JsonReader_skipQuotedValue(teavm_this_, INT32_C(34)));
            goto teavm_label_2;
        }
        if ((teavm_local_2 != INT32_C(16))) {
            goto teavm_label_2;
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peekedNumberLength));
    teavm_label_2:;
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_peeked) = INT32_C(0);
        if ((!teavm_local_1)) {
            goto teavm_label_1;
        }
    }
teavm_label_1:;
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
    teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43328, teavm_nullCheck(teavm_local_3));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43329, teavm_checkBounds(teavm_local_4, teavm_local_3));
    TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_5) = (TEAVM_ARRAY_AT(teavm_local_3, int32_t, teavm_local_5) + INT32_C(1));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames);
    teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43330, teavm_nullCheck(teavm_local_3));
    TEAVM_ARRAY_AT(teavm_local_3, void*, TEAVM_WITH_CALL_SITE_ID(43331, teavm_checkBounds(teavm_local_4, teavm_local_3))) = TEAVM_GET_STRING(498);
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_push(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 == TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(43332, teavm_nullCheck(teavm_local_3))))) {
        teavm_local_4 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) * INT32_C(2));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43333, meth_ju_Arrays_copyOf_2(teavm_local_3, teavm_local_4));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack) = teavm_local_3;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43334, meth_ju_Arrays_copyOf_2(teavm_local_3, teavm_local_4));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices) = teavm_local_3;
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43335, meth_ju_Arrays_copyOf(teavm_local_3, teavm_local_4));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43336, teavm_checkcast(teavm_local_3, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames) = teavm_local_3;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) = (teavm_local_5 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43337, teavm_nullCheck(teavm_local_3));
    TEAVM_ARRAY_AT(teavm_local_3, int32_t, TEAVM_WITH_CALL_SITE_ID(43338, teavm_checkBounds(teavm_local_5, teavm_local_3))) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_cggs_JsonReader_fillBuffer(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    void* teavm_local_5;
    int32_t teavm_local_6;
    TeaVM_Array* teavm_local_7;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) - TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos));
    if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) == TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos))) {
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) = INT32_C(0);
    } else {
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) - TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(43339, meth_jl_System_fastArraycopy(teavm_local_2, teavm_local_3, teavm_local_2, INT32_C(0), teavm_local_4));
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = INT32_C(0);
    while (1) {
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_in);
        teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43340, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = teavm_local_2;
        teavm_local_3 = (TEAVM_ARRAY_LENGTH(teavm_local_7) - TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit));
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43341, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43342, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Reader_VT, virt_read_4)(teavm_tmp_ptr_0, teavm_local_2, teavm_local_6, teavm_local_3)));
        if ((teavm_local_6 == -INT32_C(1))) {
            goto teavm_label_3;
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) + teavm_local_6);
        if (((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber)) && ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart)) && (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) > INT32_C(0))))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if ((TEAVM_ARRAY_AT(teavm_local_7, char16_t, TEAVM_WITH_CALL_SITE_ID(43343, teavm_checkUpperBound(INT32_C(0), teavm_local_7))) == INT32_C(65279))) {
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
                TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) + INT32_C(1));
                teavm_local_1 = (teavm_local_1 + INT32_C(1));
            }
        }
        if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit) >= teavm_local_1)) {
            goto teavm_label_2;
        }
    }
teavm_label_3:;
    teavm_local_6 = INT32_C(0);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_6 = INT32_C(1);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_6;
}
int32_t meth_cggs_JsonReader_nextNonWhitespace(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    int32_t teavm_local_9;
    TeaVM_Array* teavm_local_10;
    int32_t teavm_local_11;
    int32_t teavm_local_12;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
    while (1) {
        if ((teavm_local_3 != teavm_local_4)) {
            teavm_local_5 = teavm_local_3;
        } else {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_3;
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_GC_ROOT_RELEASE(INT32_C(2));
            if ((!TEAVM_WITH_CALL_SITE_ID(43344, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))) {
                if (teavm_local_1) {
                    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43345, meth_otr_Allocator_allocate(&ji_EOFException_Cls));
                    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43346, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    TEAVM_WITH_CALL_SITE_ID(43347, meth_jl_StringBuilder__init_(teavm_local_7));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43348, TEAVM_METHOD(teavm_local_7, jl_StringBuilder_VT, virt_append_0)(teavm_local_7, TEAVM_GET_STRING(8117)));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    teavm_local_8 = TEAVM_WITH_CALL_SITE_ID(43349, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
                    TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43350, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43351, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_8)));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                    teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43352, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43353, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
                    TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
                    TEAVM_WITH_CALL_SITE_ID(43354, meth_ji_EOFException__init_(teavm_local_6, teavm_local_7));
                    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                    TEAVM_WITH_CALL_SITE_ID(43355, meth_otr_ExceptionHandling_throwException(teavm_local_6));
                    TEAVM_UNREACHABLE
                }
                teavm_local_9 = -INT32_C(1);
                goto teavm_label_1;
            }
            teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        }
        teavm_local_3 = (teavm_local_5 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43356, teavm_nullCheck(teavm_local_2));
        teavm_local_10 = teavm_local_2;
        teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(43357, teavm_checkBounds(teavm_local_5, teavm_local_10)));
        if ((teavm_local_9 == INT32_C(10))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = teavm_local_3;
            goto teavm_cnt_5;
        }
        if ((teavm_local_9 == INT32_C(32))) {
            goto teavm_cnt_5;
        }
        if ((teavm_local_9 == INT32_C(13))) {
            goto teavm_cnt_5;
        }
        if ((teavm_local_9 == INT32_C(9))) {
            goto teavm_cnt_5;
        }
        if ((teavm_local_9 != INT32_C(47))) {
            if ((teavm_local_9 != INT32_C(35))) {
                goto teavm_label_3;
            }
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_3;
            TEAVM_WITH_CALL_SITE_ID(43358, meth_cggs_JsonReader_checkLenient(teavm_this_));
            TEAVM_WITH_CALL_SITE_ID(43359, meth_cggs_JsonReader_skipToEndOfLine(teavm_this_));
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
            goto teavm_cnt_5;
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_3;
        if ((teavm_local_3 == teavm_local_4)) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - INT32_C(1));
            teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(43360, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(2)));
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
            if ((!teavm_local_11)) {
                goto teavm_label_4;
            }
        }
        TEAVM_WITH_CALL_SITE_ID(43361, meth_cggs_JsonReader_checkLenient(teavm_this_));
        teavm_local_12 = TEAVM_ARRAY_AT(teavm_local_10, char16_t, TEAVM_WITH_CALL_SITE_ID(43362, teavm_checkBounds(TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos), teavm_local_10)));
        switch (teavm_local_12) {
            case 42:
                goto teavm_label_6;
            case 47:
                goto teavm_label_7;
            default:
                goto teavm_label_5;
        }
    teavm_label_7:;
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(43363, meth_cggs_JsonReader_skipToEndOfLine(teavm_this_));
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
        goto teavm_cnt_5;
    teavm_label_6:;
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
        if ((!TEAVM_WITH_CALL_SITE_ID(43364, meth_cggs_JsonReader_skipTo(teavm_this_, TEAVM_GET_STRING(8118))))) {
            goto teavm_label_2;
        }
        teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(2));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit);
    teavm_cnt_5:;
    }
teavm_label_5:;
    goto teavm_label_1;
teavm_label_4:;
    goto teavm_label_1;
teavm_label_3:;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = teavm_local_3;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(43365, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8119)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(43366, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43367, teavm_nullCheck(teavm_local_6))));
    TEAVM_UNREACHABLE
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_9;
}
void meth_cggs_JsonReader_checkLenient(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lenient))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43368, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8120)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(43369, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43370, teavm_nullCheck(teavm_local_1))));
        TEAVM_UNREACHABLE
    }
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader_skipToEndOfLine(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    while (1) {
        if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) >= TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) {
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            if ((!TEAVM_WITH_CALL_SITE_ID(43371, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))) {
                goto teavm_label_1;
            }
        }
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (teavm_local_2 + INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43372, teavm_nullCheck(teavm_local_1));
        teavm_local_3 = TEAVM_ARRAY_AT(teavm_local_1, char16_t, TEAVM_WITH_CALL_SITE_ID(43373, teavm_checkBounds(teavm_local_2, teavm_local_1)));
        if ((teavm_local_3 == INT32_C(10))) {
            goto teavm_label_2;
        }
        if ((teavm_local_3 == INT32_C(13))) {
            goto teavm_label_3;
        }
    }
teavm_label_3:;
    goto teavm_label_1;
teavm_label_2:;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
int32_t meth_cggs_JsonReader_skipTo(void* teavm_this_, void* teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43374, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43375, meth_jl_String_length(teavm_local_1));
    while (1) {
        if ((((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_2) > TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit)) && (!TEAVM_WITH_CALL_SITE_ID(43376, meth_cggs_JsonReader_fillBuffer(teavm_this_, teavm_local_2))))) {
            goto teavm_label_2;
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43377, teavm_nullCheck(teavm_local_3));
        if ((TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43378, teavm_checkBounds(teavm_local_4, teavm_local_3))) == INT32_C(10))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
        } else {
            teavm_local_5 = INT32_C(0);
            while (1) {
                if ((teavm_local_5 >= teavm_local_2)) {
                    goto teavm_label_3;
                }
                teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
                teavm_local_6 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + teavm_local_5);
                TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
                teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43379, teavm_nullCheck(teavm_local_3));
                teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43380, teavm_checkBounds(teavm_local_6, teavm_local_3)));
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                if ((teavm_local_4 != TEAVM_WITH_CALL_SITE_ID(43381, meth_jl_String_charAt(teavm_local_1, teavm_local_5)))) {
                    goto teavm_label_4;
                }
                teavm_local_5 = (teavm_local_5 + INT32_C(1));
            }
        teavm_label_4:;
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(1));
    }
teavm_label_3:;
    teavm_local_4 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_4 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
}
void* meth_cggs_JsonReader_locationString(void* teavm_this_) {
    int32_t teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    teavm_local_1 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
    teavm_local_2 = ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart)) + INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43382, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(43383, meth_jl_StringBuilder__init_(teavm_local_3));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43384, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, TEAVM_GET_STRING(8121)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43385, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43386, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_24)(teavm_tmp_ptr_0, teavm_local_1)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43387, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43388, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, TEAVM_GET_STRING(8122))));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43389, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43390, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_24)(teavm_tmp_ptr_0, teavm_local_2)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43391, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43392, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, TEAVM_GET_STRING(8123))));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43393, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_getPath)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43394, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43395, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43396, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43397, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_3;
}
void* meth_cggs_JsonReader_getPath(void* teavm_this_, int32_t teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    TeaVM_Array* teavm_local_5;
    int32_t teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43398, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(43399, meth_jl_StringBuilder__init_(teavm_local_2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43400, TEAVM_METHOD(teavm_local_2, jl_StringBuilder_VT, virt_append_28)(teavm_local_2, INT32_C(36)));
    teavm_local_4 = INT32_C(0);
    while (1) {
        if (!(teavm_local_4 < TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize))) break;
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stack);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43401, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43402, teavm_checkBounds(teavm_local_4, teavm_local_5));
        switch (TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_4)) {
            case 1:
            case 2:
                goto teavm_label_3;
            case 3:
            case 4:
            case 5:
                goto teavm_label_4;
            case 6:
            case 7:
            case 8:
                goto teavm_label_5;
        }
    teavm_label_5:;
        goto teavm_label_2;
    teavm_label_4:;
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43403, teavm_nullCheck(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(43404, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_28)(teavm_local_3, INT32_C(46)));
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43405, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43406, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
        if ((TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4) == NULL)) {
            goto teavm_label_2;
        }
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathNames);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43407, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43408, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_5, void*, teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(43409, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, teavm_local_2));
        goto teavm_label_2;
    teavm_label_3:;
        teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pathIndices);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(43410, teavm_nullCheck(teavm_local_5));
        teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43411, teavm_checkUpperBound(teavm_local_4, teavm_local_5));
        teavm_local_6 = TEAVM_ARRAY_AT(teavm_local_5, int32_t, teavm_local_4);
        if ((teavm_local_1 && ((teavm_local_6 > INT32_C(0)) && (teavm_local_4 == (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_stackSize) - INT32_C(1)))))) {
            teavm_local_6 = (teavm_local_6 + -INT32_C(1));
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43412, teavm_nullCheck(teavm_local_3));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43413, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_28)(teavm_local_3, INT32_C(91)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43414, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43415, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_24)(teavm_tmp_ptr_0, teavm_local_6)));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(43416, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43417, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_28)(teavm_tmp_ptr_0, INT32_C(93))));
    teavm_label_2:;
        teavm_local_4 = (teavm_local_4 + INT32_C(1));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43418, teavm_nullCheck(teavm_local_3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43419, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_toString)(teavm_local_3));
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_cggs_JsonReader_getPath_0(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43420, meth_cggs_JsonReader_getPath(teavm_this_, INT32_C(0)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
int32_t meth_cggs_JsonReader_readEscapeCharacter(void* teavm_this_) {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    int32_t teavm_local_8;
    int32_t teavm_local_9;
    void* teavm_local_10;
    void* teavm_local_11;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) == TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        if ((!TEAVM_WITH_CALL_SITE_ID(43421, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(1))))) {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43422, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8124)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(43423, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43424, teavm_nullCheck(teavm_local_1))));
            TEAVM_UNREACHABLE
        }
    }
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (teavm_local_3 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43425, teavm_nullCheck(teavm_local_2));
    teavm_local_4 = TEAVM_ARRAY_AT(teavm_local_2, char16_t, TEAVM_WITH_CALL_SITE_ID(43426, teavm_checkBounds(teavm_local_3, teavm_local_2)));
    switch (teavm_local_4) {
        case 10:
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineNumber) + INT32_C(1));
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_lineStart) = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
            goto teavm_label_4;
        case 34:
        case 39:
        case 47:
        case 92:
            goto teavm_label_4;
        case 98:
            goto teavm_label_10;
        case 102:
            goto teavm_label_9;
        case 110:
            goto teavm_label_8;
        case 114:
            goto teavm_label_7;
        case 116:
            goto teavm_label_6;
        case 117:
            goto teavm_label_3;
        default:
            goto teavm_label_5;
    }
teavm_label_10:;
    teavm_local_4 = INT32_C(8);
    goto teavm_label_2;
teavm_label_9:;
    teavm_local_4 = INT32_C(12);
    goto teavm_label_2;
teavm_label_8:;
    teavm_local_4 = INT32_C(10);
    goto teavm_label_2;
teavm_label_7:;
    teavm_local_4 = INT32_C(13);
    goto teavm_label_2;
teavm_label_6:;
    teavm_local_4 = INT32_C(9);
    goto teavm_label_2;
teavm_label_5:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43427, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8125)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(43428, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43429, teavm_nullCheck(teavm_local_1))));
    TEAVM_UNREACHABLE
teavm_label_4:;
    goto teavm_label_2;
teavm_label_3:;
    if (((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(4)) > TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        if ((!TEAVM_WITH_CALL_SITE_ID(43430, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(4))))) {
            teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43431, meth_cggs_JsonReader_syntaxError(teavm_this_, TEAVM_GET_STRING(8124)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_WITH_CALL_SITE_ID(43432, meth_otr_ExceptionHandling_throwException(TEAVM_WITH_CALL_SITE_ID(43433, teavm_nullCheck(teavm_local_1))));
            TEAVM_UNREACHABLE
        }
    }
    teavm_local_4 = INT32_C(0);
    teavm_local_5 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
    teavm_local_6 = (teavm_local_5 + INT32_C(4));
    while (1) {
        if (!(teavm_local_5 < teavm_local_6)) break;
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43434, teavm_nullCheck(teavm_local_2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(43435, teavm_checkBounds(teavm_local_5, teavm_local_2));
        teavm_local_8 = TEAVM_ARRAY_AT(teavm_local_2, char16_t, teavm_local_7);
        teavm_local_9 = TEAVM_TO_CHAR((teavm_local_4 << INT32_C(4)));
        if (((teavm_local_8 >= INT32_C(48)) && (teavm_local_8 <= INT32_C(57)))) {
            teavm_local_4 = TEAVM_TO_CHAR((teavm_local_9 + (teavm_local_8 - INT32_C(48))));
        } else if (((teavm_local_8 >= INT32_C(97)) && (teavm_local_8 <= INT32_C(102)))) {
            teavm_local_4 = TEAVM_TO_CHAR((teavm_local_9 + ((teavm_local_8 - INT32_C(97)) + INT32_C(10))));
        } else {
            if ((teavm_local_8 < INT32_C(65))) {
                goto teavm_label_1;
            }
            if ((teavm_local_8 > INT32_C(70))) {
                goto teavm_label_1;
            }
            teavm_local_4 = TEAVM_TO_CHAR((teavm_local_9 + ((teavm_local_8 - INT32_C(65)) + INT32_C(10))));
        }
        teavm_local_5 = (teavm_local_7 + INT32_C(1));
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(4));
teavm_label_2:;
    TEAVM_RELEASE_STACK;
    return teavm_local_4;
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43436, meth_otr_Allocator_allocate(&jl_NumberFormatException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43437, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(43438, meth_jl_StringBuilder__init_(teavm_local_10));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43439, TEAVM_METHOD(teavm_local_10, jl_StringBuilder_VT, virt_append_0)(teavm_local_10, TEAVM_GET_STRING(8126)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
    teavm_local_11 = TEAVM_WITH_CALL_SITE_ID(43440, meth_otr_Allocator_allocate(&jl_String_Cls));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_11);
    TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(43441, meth_jl_String__init_(teavm_local_11, teavm_local_2, teavm_local_3, INT32_C(4)));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43442, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43443, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_11)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_10 = TEAVM_WITH_CALL_SITE_ID(43444, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43445, teavm_nullCheck(teavm_local_10))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_10);
    TEAVM_WITH_CALL_SITE_ID(43446, meth_jl_NumberFormatException__init_(teavm_local_1, teavm_local_10));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(43447, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
}
void* meth_cggs_JsonReader_syntaxError(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43448, meth_otr_Allocator_allocate(&cggs_MalformedJsonException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43449, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(43450, meth_jl_StringBuilder__init_(teavm_local_3));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43451, TEAVM_METHOD(teavm_local_3, jl_StringBuilder_VT, virt_append_0)(teavm_local_3, teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(43452, TEAVM_METHOD(teavm_this_, cggs_JsonReader_VT, virt_locationString)(teavm_this_));
    TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43453, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43454, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_4)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(43455, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(43456, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(43457, meth_cggs_MalformedJsonException__init_(teavm_local_2, teavm_local_3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(43458, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
}
void meth_cggs_JsonReader_consumeNonExecutePrefix(void* teavm_this_) {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(43459, meth_cggs_JsonReader_nextNonWhitespace(teavm_this_, INT32_C(1)));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) - INT32_C(1));
    if ((!(((TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(5)) > TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_limit)) && (!TEAVM_WITH_CALL_SITE_ID(43460, meth_cggs_JsonReader_fillBuffer(teavm_this_, INT32_C(5))))))) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos);
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_buffer);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(43461, teavm_nullCheck(teavm_local_2));
        teavm_local_3 = teavm_local_2;
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43462, teavm_checkBounds(teavm_local_1, teavm_local_3));
        if (((TEAVM_ARRAY_AT(teavm_local_3, char16_t, teavm_local_1) == INT32_C(41)) && ((TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43463, teavm_checkBounds((teavm_local_1 + INT32_C(1)), teavm_local_3))) == INT32_C(93)) && ((TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43464, teavm_checkBounds((teavm_local_1 + INT32_C(2)), teavm_local_3))) == INT32_C(125)) && ((TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43465, teavm_checkBounds((teavm_local_1 + INT32_C(3)), teavm_local_3))) == INT32_C(39)) && (TEAVM_ARRAY_AT(teavm_local_3, char16_t, TEAVM_WITH_CALL_SITE_ID(43466, teavm_checkBounds((teavm_local_1 + INT32_C(4)), teavm_local_3))) == INT32_C(10))))))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonReader, fld_pos) + INT32_C(5));
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonReader__clinit_() {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(43467, meth_otr_Allocator_allocate(&cggs_JsonReader_1_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(43468, meth_cggs_JsonReader_1__init_(teavm_local_1));
    sfld_cggi_JsonReaderInternalAccess_INSTANCE = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void initclass_cggs_JsonReader() {
    TeaVM_Class* cls = (TeaVM_Class*) &cggs_JsonReader_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_cggs_JsonReader__clinit_();
    }
}
int32_t supertypeof_cggs_JsonReader(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 1951 || tag >= 1953) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_cggs_JsonReader_Cls[7];
alignas(8) cggs_JsonReader_VT cggs_JsonReader_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_cggs_JsonReader), sizeof(void*)),
        .flags = 0,
        .tag = 1951,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_cggs_JsonReader,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_cggs_JsonReader_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_nextBoolean = &meth_cggs_JsonReader_nextBoolean,
    .virt_peek = &meth_cggs_JsonReader_peek,
    .virt_hasNext = &meth_cggs_JsonReader_hasNext,
    .virt_skipValue = &meth_cggs_JsonReader_skipValue,
    .virt_setLenient = &meth_cggs_JsonReader_setLenient,
    .virt_nextName = &meth_cggs_JsonReader_nextName,
    .virt_beginArray = &meth_cggs_JsonReader_beginArray,
    .virt_nextNull = &meth_cggs_JsonReader_nextNull,
    .virt_endObject = &meth_cggs_JsonReader_endObject,
    .virt_nextLong = &meth_cggs_JsonReader_nextLong,
    .virt_nextString = &meth_cggs_JsonReader_nextString,
    .virt_locationString = &meth_cggs_JsonReader_locationString,
    .virt_getPath = &meth_cggs_JsonReader_getPath_0,
    .virt_doPeek = &meth_cggs_JsonReader_doPeek,
    .virt_close = &meth_cggs_JsonReader_close,
    .virt_endArray = &meth_cggs_JsonReader_endArray,
    .virt_beginObject = &meth_cggs_JsonReader_beginObject,
    .virt_nextInt = &meth_cggs_JsonReader_nextInt
};
static int16_t teavm_classLayouts_cggs_JsonReader_Cls[7] = {
INT16_C(6), (int16_t) offsetof(cls_cggs_JsonReader, fld_in), (int16_t) offsetof(cls_cggs_JsonReader, fld_buffer), (int16_t) offsetof(cls_cggs_JsonReader, fld_peekedString), (int16_t) offsetof(cls_cggs_JsonReader, fld_stack), (int16_t) offsetof(cls_cggs_JsonReader, fld_pathNames), (int16_t) offsetof(cls_cggs_JsonReader, fld_pathIndices)
};
void sysinitclass_cggs_JsonReader() {
}
