#pragma once
#include "../../../../../runtime.h"
#include "../internal/JsonReaderInternalAccess.h"
#include "JsonReader@d1.h"

extern void sysinitclass_cggs_JsonReader_1();
typedef struct cls_cggs_JsonReader_1 {
    struct cls_cggi_JsonReaderInternalAccess parent;
} cls_cggs_JsonReader_1;
extern void meth_cggs_JsonReader_1__init_(void*);
extern int32_t supertypeof_cggs_JsonReader_1(TeaVM_Class*, TeaVM_Class*);
typedef struct cggs_JsonReader_1_VT {
    cggi_JsonReaderInternalAccess_VT parent;
} cggs_JsonReader_1_VT;
extern cggs_JsonReader_1_VT cggs_JsonReader_1_Cls;
