#pragma once
#include "../../../../../runtime.h"
#include "../../../../java/lang/Object.h"
#include "JsonWriter.h"

extern void sysinitclass_cggs_JsonWriter();
typedef struct cls_cggs_JsonWriter {
    struct TeaVM_Object parent;
    void* fld_out;
    TeaVM_Array* fld_stack;
    int32_t fld_stackSize;
    void* fld_indent;
    void* fld_separator;
    int8_t fld_lenient;
    int8_t fld_htmlSafe;
    void* fld_deferredName;
    int8_t fld_serializeNulls;
} cls_cggs_JsonWriter;
extern void* sfld_cggs_JsonWriter_VALID_JSON_NUMBER_PATTERN;
extern TeaVM_Array* sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
extern TeaVM_Array* sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
extern void meth_cggs_JsonWriter__init_(void*, void*);
extern void* meth_cggs_JsonWriter_beginArray(void*);
extern void* meth_cggs_JsonWriter_endArray(void*);
extern void* meth_cggs_JsonWriter_beginObject(void*);
extern void* meth_cggs_JsonWriter_endObject(void*);
extern void* meth_cggs_JsonWriter_open(void*, int32_t, int32_t);
extern void* meth_cggs_JsonWriter_close(void*, int32_t, int32_t, int32_t);
extern void meth_cggs_JsonWriter_push(void*, int32_t);
extern int32_t meth_cggs_JsonWriter_peek(void*);
extern void meth_cggs_JsonWriter_replaceTop(void*, int32_t);
extern void* meth_cggs_JsonWriter_name(void*, void*);
extern void meth_cggs_JsonWriter_writeDeferredName(void*);
extern void* meth_cggs_JsonWriter_value(void*, void*);
extern void* meth_cggs_JsonWriter_nullValue(void*);
extern void* meth_cggs_JsonWriter_value_0(void*, void*);
extern int32_t meth_cggs_JsonWriter_isTrustedNumberType(void*);
extern void* meth_cggs_JsonWriter_value_1(void*, void*);
extern void meth_cggs_JsonWriter_close_0(void*);
extern void meth_cggs_JsonWriter_string(void*, void*);
extern void meth_cggs_JsonWriter_newline(void*);
extern void meth_cggs_JsonWriter_beforeName(void*);
extern void meth_cggs_JsonWriter_beforeValue(void*);
extern void meth_cggs_JsonWriter__clinit_();
extern void initclass_cggs_JsonWriter();
extern int32_t supertypeof_cggs_JsonWriter(TeaVM_Class*, TeaVM_Class*);
typedef struct cggs_JsonWriter_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    void* (*virt_name_0)(void*, void*); // 11
    void* (*virt_value_0)(void*, void*); // 12
    void (*pad0)(); // 13
    void* (*virt_beginArray_0)(void*); // 14
    void (*pad1)(); // 15
    void (*pad2)(); // 16
    void (*pad3)(); // 17
    void (*pad4)(); // 18
    void (*pad5)(); // 19
    void (*pad6)(); // 20
    void* (*virt_endArray_0)(void*); // 21
    void* (*virt_value_1)(void*, void*); // 22
    void* (*virt_value)(void*, void*); // 23
    void (*pad7)(); // 24
    void (*pad8)(); // 25
    void (*pad9)(); // 26
    void (*pad10)(); // 27
    void* (*virt_endObject_0)(void*); // 28
    void (*pad11)(); // 29
    void (*pad12)(); // 30
    void (*pad13)(); // 31
    void (*pad14)(); // 32
    void (*virt_close)(void*); // 33
    void (*pad15)(); // 34
    void (*pad16)(); // 35
    void (*pad17)(); // 36
    void* (*virt_nullValue)(void*); // 37
    void (*pad18)(); // 38
    void (*pad19)(); // 39
    void (*pad20)(); // 40
    void (*pad21)(); // 41
    void (*pad22)(); // 42
    void (*pad23)(); // 43
    void (*pad24)(); // 44
    void (*pad25)(); // 45
    void (*pad26)(); // 46
    void (*pad27)(); // 47
    void* (*virt_beginObject_0)(void*); // 48
    void (*pad28)(); // 49
} cggs_JsonWriter_VT;
extern cggs_JsonWriter_VT cggs_JsonWriter_Cls;
