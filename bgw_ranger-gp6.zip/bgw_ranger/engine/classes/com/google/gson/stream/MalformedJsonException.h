#pragma once
#include "../../../../../runtime.h"
#include "../../../../java/io/IOException.h"
#include "MalformedJsonException.h"

extern void sysinitclass_cggs_MalformedJsonException();
typedef struct cls_cggs_MalformedJsonException {
    struct cls_ji_IOException parent;
} cls_cggs_MalformedJsonException;
extern void meth_cggs_MalformedJsonException__init_(void*, void*);
extern int32_t supertypeof_cggs_MalformedJsonException(TeaVM_Class*, TeaVM_Class*);
typedef struct cggs_MalformedJsonException_VT {
    ji_IOException_VT parent;
} cggs_MalformedJsonException_VT;
extern cggs_MalformedJsonException_VT cggs_MalformedJsonException_Cls;
