#include "JsonToken.h"
#include "../../../../java/lang/Enum.h"
#include "../../../../java/lang/Object.h"
#include "../../../../../arrayclass.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../strings.h"

void* sfld_cggs_JsonToken_BEGIN_ARRAY;
void* sfld_cggs_JsonToken_END_ARRAY;
void* sfld_cggs_JsonToken_BEGIN_OBJECT;
void* sfld_cggs_JsonToken_END_OBJECT;
void* sfld_cggs_JsonToken_NAME;
void* sfld_cggs_JsonToken_STRING;
void* sfld_cggs_JsonToken_NUMBER;
void* sfld_cggs_JsonToken_BOOLEAN;
void* sfld_cggs_JsonToken_NULL;
void* sfld_cggs_JsonToken_END_DOCUMENT;
TeaVM_Array* sfld_cggs_JsonToken__VALUES;
TeaVM_Array* meth_cggs_JsonToken_values() {
    TeaVM_Array* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34562, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    teavm_local_1 = sfld_cggs_JsonToken__VALUES;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34563, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(34564, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34565, teavm_checkcast(teavm_local_2, teavm_getArrayClass((TeaVM_Class*) &cggs_JsonToken_Cls), &teavm_isSupertypeOfArray));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void meth_cggs_JsonToken__init_(void* teavm_this_, void* teavm_local_1, int32_t teavm_local_2) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(34566, teavm_initializeClass((TeaVM_Class*) &cggs_JsonToken_Cls, &initclass_cggs_JsonToken));
    TEAVM_WITH_CALL_SITE_ID(34567, meth_jl_Enum__init_(teavm_this_, teavm_local_1, teavm_local_2));
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonToken__clinit_() {
    void* teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34568, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34569, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7703), INT32_C(0)));
    sfld_cggs_JsonToken_BEGIN_ARRAY = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34570, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34571, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7704), INT32_C(1)));
    sfld_cggs_JsonToken_END_ARRAY = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34572, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34573, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7705), INT32_C(2)));
    sfld_cggs_JsonToken_BEGIN_OBJECT = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34574, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34575, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7706), INT32_C(3)));
    sfld_cggs_JsonToken_END_OBJECT = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34576, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34577, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7707), INT32_C(4)));
    sfld_cggs_JsonToken_NAME = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34578, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34579, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7708), INT32_C(5)));
    sfld_cggs_JsonToken_STRING = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34580, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34581, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7709), INT32_C(6)));
    sfld_cggs_JsonToken_NUMBER = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34582, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34583, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7710), INT32_C(7)));
    sfld_cggs_JsonToken_BOOLEAN = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34584, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34585, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7711), INT32_C(8)));
    sfld_cggs_JsonToken_NULL = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(34586, meth_otr_Allocator_allocate(&cggs_JsonToken_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(34587, meth_cggs_JsonToken__init_(teavm_local_1, TEAVM_GET_STRING(7712), INT32_C(9)));
    sfld_cggs_JsonToken_END_DOCUMENT = teavm_local_1;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(34588, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &cggs_JsonToken_Cls), INT32_C(10)));
    teavm_local_3 = teavm_local_2;
    teavm_local_1 = sfld_cggs_JsonToken_BEGIN_ARRAY;
    teavm_gc_writeBarrier(teavm_local_3);
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(0)) = teavm_local_1;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(1)) = sfld_cggs_JsonToken_END_ARRAY;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(2)) = sfld_cggs_JsonToken_BEGIN_OBJECT;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(3)) = sfld_cggs_JsonToken_END_OBJECT;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(4)) = sfld_cggs_JsonToken_NAME;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(5)) = sfld_cggs_JsonToken_STRING;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(6)) = sfld_cggs_JsonToken_NUMBER;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(7)) = sfld_cggs_JsonToken_BOOLEAN;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(8)) = sfld_cggs_JsonToken_NULL;
    TEAVM_ARRAY_AT(teavm_local_3, void*, INT32_C(9)) = sfld_cggs_JsonToken_END_DOCUMENT;
    sfld_cggs_JsonToken__VALUES = teavm_local_2;
    TEAVM_RELEASE_STACK;
}
void initclass_cggs_JsonToken() {
    TeaVM_Class* cls = (TeaVM_Class*) &cggs_JsonToken_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_cggs_JsonToken__clinit_();
    }
}
int32_t supertypeof_cggs_JsonToken(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 2200 || tag >= 2202) return INT32_C(0);
    return INT32_C(1);
}
static void* cggs_JsonToken_Cls_enumConstants[11] = { (void*) (intptr_t) 10, &sfld_cggs_JsonToken_BEGIN_ARRAY, &sfld_cggs_JsonToken_END_ARRAY, &sfld_cggs_JsonToken_BEGIN_OBJECT, &sfld_cggs_JsonToken_END_OBJECT, &sfld_cggs_JsonToken_NAME, &sfld_cggs_JsonToken_STRING, &sfld_cggs_JsonToken_NUMBER, &sfld_cggs_JsonToken_BOOLEAN, &sfld_cggs_JsonToken_NULL, &sfld_cggs_JsonToken_END_DOCUMENT };
alignas(8) cggs_JsonToken_VT cggs_JsonToken_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_cggs_JsonToken), sizeof(void*)),
            .flags = 0,
            .tag = 2200,
            .modifiers = 65553,
            .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(7713),
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_cggs_JsonToken,
            .superclass = (TeaVM_Class*) &jl_Enum_Cls,
            .layout = NULL,
            .enumValues = cggs_JsonToken_Cls_enumConstants,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Enum_hashCode,
        .virt_equals = &meth_jl_Enum_equals,
        .virt_toString = &meth_jl_Enum_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0,
        .virt_name = &meth_jl_Enum_name,
        .virt_compareTo = &meth_jl_Enum_compareTo,
        .virt_getDeclaringClass = &meth_jl_Enum_getDeclaringClass,
        .virt_compareTo_0 = &meth_jl_Enum_compareTo_0,
        .virt_ordinal = &meth_jl_Enum_ordinal
    }
};
static void** teavm_gc_localStaticRoots_cggs_JsonToken_Cls[11] = {
(void**) &sfld_cggs_JsonToken_BEGIN_ARRAY, (void**) &sfld_cggs_JsonToken_END_ARRAY, (void**) &sfld_cggs_JsonToken_BEGIN_OBJECT, (void**) &sfld_cggs_JsonToken_END_OBJECT, (void**) &sfld_cggs_JsonToken_NAME, (void**) &sfld_cggs_JsonToken_STRING, (void**) &sfld_cggs_JsonToken_NUMBER, (void**) &sfld_cggs_JsonToken_BOOLEAN, (void**) &sfld_cggs_JsonToken_NULL, (void**) &sfld_cggs_JsonToken_END_DOCUMENT, (void**) &sfld_cggs_JsonToken__VALUES
};
void sysinitclass_cggs_JsonToken() {
sfld_cggs_JsonToken_BEGIN_ARRAY = NULL;
sfld_cggs_JsonToken_END_ARRAY = NULL;
sfld_cggs_JsonToken_BEGIN_OBJECT = NULL;
sfld_cggs_JsonToken_END_OBJECT = NULL;
sfld_cggs_JsonToken_NAME = NULL;
sfld_cggs_JsonToken_STRING = NULL;
sfld_cggs_JsonToken_NUMBER = NULL;
sfld_cggs_JsonToken_BOOLEAN = NULL;
sfld_cggs_JsonToken_NULL = NULL;
sfld_cggs_JsonToken_END_DOCUMENT = NULL;
sfld_cggs_JsonToken__VALUES = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_cggs_JsonToken_Cls, 11);
}
