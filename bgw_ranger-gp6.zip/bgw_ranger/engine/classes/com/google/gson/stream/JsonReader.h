#pragma once
#include "../../../../../runtime.h"
#include "../../../../java/lang/Object.h"
#include "JsonReader.h"

extern void sysinitclass_cggs_JsonReader();
typedef struct cls_cggs_JsonReader {
    struct TeaVM_Object parent;
    void* fld_in;
    int8_t fld_lenient;
    TeaVM_Array* fld_buffer;
    int32_t fld_pos;
    int32_t fld_limit;
    int32_t fld_lineNumber;
    int32_t fld_lineStart;
    int32_t fld_peeked;
    int64_t fld_peekedLong;
    int32_t fld_peekedNumberLength;
    void* fld_peekedString;
    TeaVM_Array* fld_stack;
    int32_t fld_stackSize;
    TeaVM_Array* fld_pathNames;
    TeaVM_Array* fld_pathIndices;
} cls_cggs_JsonReader;
extern void meth_cggs_JsonReader__init_(void*, void*);
extern void meth_cggs_JsonReader_setLenient(void*, int32_t);
extern void meth_cggs_JsonReader_beginArray(void*);
extern void meth_cggs_JsonReader_endArray(void*);
extern void meth_cggs_JsonReader_beginObject(void*);
extern void meth_cggs_JsonReader_endObject(void*);
extern int32_t meth_cggs_JsonReader_hasNext(void*);
extern void* meth_cggs_JsonReader_peek(void*);
extern int32_t meth_cggs_JsonReader_doPeek(void*);
extern int32_t meth_cggs_JsonReader_peekKeyword(void*);
extern int32_t meth_cggs_JsonReader_peekNumber(void*);
extern int32_t meth_cggs_JsonReader_isLiteral(void*, int32_t);
extern void* meth_cggs_JsonReader_nextName(void*);
extern void* meth_cggs_JsonReader_nextString(void*);
extern int32_t meth_cggs_JsonReader_nextBoolean(void*);
extern void meth_cggs_JsonReader_nextNull(void*);
extern int64_t meth_cggs_JsonReader_nextLong(void*);
extern void* meth_cggs_JsonReader_nextQuotedValue(void*, int32_t);
extern void* meth_cggs_JsonReader_nextUnquotedValue(void*);
extern void meth_cggs_JsonReader_skipQuotedValue(void*, int32_t);
extern void meth_cggs_JsonReader_skipUnquotedValue(void*);
extern int32_t meth_cggs_JsonReader_nextInt(void*);
extern void meth_cggs_JsonReader_close(void*);
extern void meth_cggs_JsonReader_skipValue(void*);
extern void meth_cggs_JsonReader_push(void*, int32_t);
extern int32_t meth_cggs_JsonReader_fillBuffer(void*, int32_t);
extern int32_t meth_cggs_JsonReader_nextNonWhitespace(void*, int32_t);
extern void meth_cggs_JsonReader_checkLenient(void*);
extern void meth_cggs_JsonReader_skipToEndOfLine(void*);
extern int32_t meth_cggs_JsonReader_skipTo(void*, void*);
extern void* meth_cggs_JsonReader_locationString(void*);
extern void* meth_cggs_JsonReader_getPath(void*, int32_t);
extern void* meth_cggs_JsonReader_getPath_0(void*);
extern int32_t meth_cggs_JsonReader_readEscapeCharacter(void*);
extern void* meth_cggs_JsonReader_syntaxError(void*, void*);
extern void meth_cggs_JsonReader_consumeNonExecutePrefix(void*);
extern void meth_cggs_JsonReader__clinit_();
extern void initclass_cggs_JsonReader();
extern int32_t supertypeof_cggs_JsonReader(TeaVM_Class*, TeaVM_Class*);
typedef struct cggs_JsonReader_VT {
    TeaVM_Class parent;
    int32_t (*virt_hashCode)(void*); // 0
    int32_t (*virt_equals)(void*, void*); // 1
    void* (*virt_clone)(void*); // 2
    void* (*virt_toString)(void*); // 3
    int32_t (*virt_isEmptyMonitor)(void*); // 4
    void* (*virt_getClass)(void*); // 5
    int32_t (*virt_identity)(void*); // 6
    void (*virt_notifyAll)(void*); // 7
    void (*virt_wait)(void*, int64_t); // 8
    void (*virt_waitImpl)(void*, int64_t, int32_t, void*); // 9
    void (*virt_wait_0)(void*); // 10
    int32_t (*virt_nextBoolean)(void*); // 11
    void* (*virt_peek)(void*); // 12
    int32_t (*virt_hasNext)(void*); // 13
    void (*virt_skipValue)(void*); // 14
    void (*pad0)(); // 15
    void (*virt_setLenient)(void*, int32_t); // 16
    void (*pad1)(); // 17
    void (*pad2)(); // 18
    void* (*virt_nextName)(void*); // 19
    void (*virt_beginArray)(void*); // 20
    void (*virt_nextNull)(void*); // 21
    void (*virt_endObject)(void*); // 22
    int64_t (*virt_nextLong)(void*); // 23
    void* (*virt_nextString)(void*); // 24
    void (*pad3)(); // 25
    void (*pad4)(); // 26
    void* (*virt_locationString)(void*); // 27
    void* (*virt_getPath)(void*); // 28
    void (*pad5)(); // 29
    void (*pad6)(); // 30
    int32_t (*virt_doPeek)(void*); // 31
    void (*pad7)(); // 32
    void (*virt_close)(void*); // 33
    void (*pad8)(); // 34
    void (*pad9)(); // 35
    void (*pad10)(); // 36
    void (*virt_endArray)(void*); // 37
    void (*pad11)(); // 38
    void (*pad12)(); // 39
    void (*pad13)(); // 40
    void (*pad14)(); // 41
    void (*pad15)(); // 42
    void (*pad16)(); // 43
    void (*pad17)(); // 44
    void (*pad18)(); // 45
    void (*pad19)(); // 46
    void (*virt_beginObject)(void*); // 47
    int32_t (*virt_nextInt)(void*); // 48
    void (*pad20)(); // 49
} cggs_JsonReader_VT;
extern cggs_JsonReader_VT cggs_JsonReader_Cls;
