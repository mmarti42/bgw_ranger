#pragma once
#include "../../../../../runtime.h"
#include "../../../../java/lang/Enum.h"
#include "JsonToken.h"

extern void sysinitclass_cggs_JsonToken();
typedef struct cls_cggs_JsonToken {
    struct cls_jl_Enum parent;
} cls_cggs_JsonToken;
extern void* sfld_cggs_JsonToken_BEGIN_ARRAY;
extern void* sfld_cggs_JsonToken_END_ARRAY;
extern void* sfld_cggs_JsonToken_BEGIN_OBJECT;
extern void* sfld_cggs_JsonToken_END_OBJECT;
extern void* sfld_cggs_JsonToken_NAME;
extern void* sfld_cggs_JsonToken_STRING;
extern void* sfld_cggs_JsonToken_NUMBER;
extern void* sfld_cggs_JsonToken_BOOLEAN;
extern void* sfld_cggs_JsonToken_NULL;
extern void* sfld_cggs_JsonToken_END_DOCUMENT;
extern TeaVM_Array* sfld_cggs_JsonToken__VALUES;
extern TeaVM_Array* meth_cggs_JsonToken_values();
extern void meth_cggs_JsonToken__init_(void*, void*, int32_t);
extern void meth_cggs_JsonToken__clinit_();
extern void initclass_cggs_JsonToken();
extern int32_t supertypeof_cggs_JsonToken(TeaVM_Class*, TeaVM_Class*);
typedef struct cggs_JsonToken_VT {
    jl_Enum_VT parent;
} cggs_JsonToken_VT;
extern cggs_JsonToken_VT cggs_JsonToken_Cls;
