#include "JsonWriter.h"
#include "../../../../java/lang/Object.h"
#include "../../../../../arrays/primitives/int.h"
#include "../../../../org/teavm/runtime/Allocator.h"
#include "../../../../../strings.h"
#include "../../../../java/lang/NullPointerException.h"
#include "../../../../org/teavm/runtime/ExceptionHandling.h"
#include "../../../../java/io/Writer.h"
#include "../../../../java/lang/IllegalStateException.h"
#include "../../../../java/lang/StringBuilder.h"
#include "../../../../java/util/Arrays.h"
#include "../../../../java/lang/Boolean.h"
#include "../../../../java/lang/Integer.h"
#include "../../../../java/lang/Long.h"
#include "../../../../java/lang/Double.h"
#include "../../../../java/lang/Float.h"
#include "../../../../java/lang/Byte.h"
#include "../../../../java/lang/Short.h"
#include "../../../../java/math/BigDecimal.h"
#include "../../../../java/math/BigInteger.h"
#include "../../../../java/util/concurrent/atomic/AtomicInteger.h"
#include "../../../../java/util/concurrent/atomic/AtomicLong.h"
#include "../../../../java/lang/String.h"
#include "../../../../java/util/regex/Pattern.h"
#include "../../../../java/util/regex/Matcher.h"
#include "../../../../java/lang/IllegalArgumentException.h"
#include "../../../../java/io/IOException.h"
#include "../../../../../arrayclass.h"

void* sfld_cggs_JsonWriter_VALID_JSON_NUMBER_PATTERN;
TeaVM_Array* sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
TeaVM_Array* sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
void meth_cggs_JsonWriter__init_(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13021, teavm_initializeClass((TeaVM_Class*) &cggs_JsonWriter_Cls, &initclass_cggs_JsonWriter));
    TEAVM_WITH_CALL_SITE_ID(13022, meth_jl_Object__init_(teavm_this_));
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13023, meth_otr_Allocator_allocateArray(&Arr_I_Cls, INT32_C(32)));
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack) = teavm_local_2;
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) = INT32_C(0);
    TEAVM_WITH_CALL_SITE_ID(13024, meth_cggs_JsonWriter_push(teavm_this_, INT32_C(6)));
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_separator) = TEAVM_GET_STRING(615);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_serializeNulls) = INT32_C(1);
    if ((teavm_local_1 == NULL)) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13025, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(13026, meth_jl_NullPointerException__init__0(teavm_local_3, TEAVM_GET_STRING(1311)));
        TEAVM_WITH_CALL_SITE_ID(13027, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    teavm_gc_writeBarrier(teavm_this_);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_cggs_JsonWriter_beginArray(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13028, meth_cggs_JsonWriter_writeDeferredName(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13029, meth_cggs_JsonWriter_open(teavm_this_, INT32_C(1), INT32_C(91)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_cggs_JsonWriter_endArray(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13030, meth_cggs_JsonWriter_close(teavm_this_, INT32_C(1), INT32_C(2), INT32_C(93)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_cggs_JsonWriter_beginObject(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13031, meth_cggs_JsonWriter_writeDeferredName(teavm_this_));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13032, meth_cggs_JsonWriter_open(teavm_this_, INT32_C(3), INT32_C(123)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_cggs_JsonWriter_endObject(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13033, meth_cggs_JsonWriter_close(teavm_this_, INT32_C(3), INT32_C(5), INT32_C(125)));
    TEAVM_RELEASE_STACK;
    return teavm_local_1;
}
void* meth_cggs_JsonWriter_open(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2) {
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13034, meth_cggs_JsonWriter_beforeValue(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(13035, meth_cggs_JsonWriter_push(teavm_this_, teavm_local_1));
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(13036, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13037, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_0)(teavm_tmp_ptr_0, teavm_local_2)));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_cggs_JsonWriter_close(void* teavm_this_, int32_t teavm_local_1, int32_t teavm_local_2, int32_t teavm_local_3) {
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    void* teavm_local_6;
    void* teavm_local_7;
    void* teavm_local_8;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(3));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13038, meth_cggs_JsonWriter_peek(teavm_this_));
    teavm_local_5 = teavm_compare_i32(teavm_local_4, teavm_local_2);
    if ((teavm_local_5 && (teavm_local_4 != teavm_local_1))) {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(13039, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        TEAVM_WITH_CALL_SITE_ID(13040, meth_jl_IllegalStateException__init_(teavm_local_6, TEAVM_GET_STRING(1312)));
        TEAVM_WITH_CALL_SITE_ID(13041, meth_otr_ExceptionHandling_throwException(teavm_local_6));
        TEAVM_UNREACHABLE
    }
    if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) != NULL)) {
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(13042, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13043, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(13044, meth_jl_StringBuilder__init_(teavm_local_7));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13045, TEAVM_METHOD(teavm_local_7, jl_StringBuilder_VT, virt_append_0)(teavm_local_7, TEAVM_GET_STRING(1313)));
        teavm_local_8 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_8);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13046, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13047, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_8)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13048, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13049, teavm_nullCheck(teavm_local_7))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_7);
        TEAVM_WITH_CALL_SITE_ID(13050, meth_jl_IllegalStateException__init_(teavm_local_6, teavm_local_7));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(13051, meth_otr_ExceptionHandling_throwException(teavm_local_6));
        TEAVM_UNREACHABLE
    }
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) - INT32_C(1));
    if ((!teavm_local_5)) {
        TEAVM_WITH_CALL_SITE_ID(13052, meth_cggs_JsonWriter_newline(teavm_this_));
    }
    teavm_local_6 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    TEAVM_WITH_CALL_SITE_ID(13053, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13054, teavm_nullCheck(teavm_local_6))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_0)(teavm_tmp_ptr_0, teavm_local_3)));
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_cggs_JsonWriter_push(void* teavm_this_, int32_t teavm_local_1) {
    int32_t teavm_local_2;
    TeaVM_Array* teavm_local_3;
    int32_t teavm_local_4;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize);
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    if ((teavm_local_2 == TEAVM_ARRAY_LENGTH(TEAVM_WITH_CALL_SITE_ID(13055, teavm_nullCheck(teavm_local_3))))) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack);
        teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) * INT32_C(2));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13056, meth_ju_Arrays_copyOf_2(teavm_local_3, teavm_local_2));
        teavm_gc_writeBarrier(teavm_this_);
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack) = teavm_local_3;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack);
    teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize);
    TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) = (teavm_local_4 + INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13057, teavm_nullCheck(teavm_local_3));
    TEAVM_ARRAY_AT(teavm_local_3, int32_t, TEAVM_WITH_CALL_SITE_ID(13058, teavm_checkBounds(teavm_local_4, teavm_local_3))) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
int32_t meth_cggs_JsonWriter_peek(void* teavm_this_) {
    TeaVM_Array* teavm_local_1;
    int32_t teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if (TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack);
        teavm_local_2 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) - INT32_C(1));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13059, teavm_nullCheck(teavm_local_1));
        teavm_local_2 = TEAVM_ARRAY_AT(teavm_local_1, int32_t, TEAVM_WITH_CALL_SITE_ID(13060, teavm_checkBounds(teavm_local_2, teavm_local_1)));
        TEAVM_RELEASE_STACK;
        return teavm_local_2;
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13061, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(13062, meth_jl_IllegalStateException__init_(teavm_local_3, TEAVM_GET_STRING(1314)));
    TEAVM_WITH_CALL_SITE_ID(13063, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void meth_cggs_JsonWriter_replaceTop(void* teavm_this_, int32_t teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    int32_t teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack);
    teavm_local_3 = (TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) - INT32_C(1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13064, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, int32_t, TEAVM_WITH_CALL_SITE_ID(13065, teavm_checkBounds(teavm_local_3, teavm_local_2))) = teavm_local_1;
    TEAVM_RELEASE_STACK;
}
void* meth_cggs_JsonWriter_name(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((teavm_local_1 != NULL)) {
        if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) == NULL)) {
            if ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize))) {
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13066, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
                TEAVM_WITH_CALL_SITE_ID(13067, meth_jl_IllegalStateException__init_(teavm_local_2, TEAVM_GET_STRING(1314)));
                TEAVM_WITH_CALL_SITE_ID(13068, meth_otr_ExceptionHandling_throwException(teavm_local_2));
                TEAVM_UNREACHABLE
            }
            teavm_gc_writeBarrier(teavm_this_);
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) = teavm_local_1;
            TEAVM_RELEASE_STACK;
            return teavm_this_;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13069, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(13070, meth_jl_IllegalStateException__init__0(teavm_local_3));
        TEAVM_WITH_CALL_SITE_ID(13071, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13072, meth_otr_Allocator_allocate(&jl_NullPointerException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_WITH_CALL_SITE_ID(13073, meth_jl_NullPointerException__init__0(teavm_local_3, TEAVM_GET_STRING(1315)));
    TEAVM_WITH_CALL_SITE_ID(13074, meth_otr_ExceptionHandling_throwException(teavm_local_3));
    TEAVM_UNREACHABLE
}
void meth_cggs_JsonWriter_writeDeferredName(void* teavm_this_) {
    void* teavm_local_1;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) != NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(13075, meth_cggs_JsonWriter_beforeName(teavm_this_));
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_WITH_CALL_SITE_ID(13076, meth_cggs_JsonWriter_string(teavm_this_, teavm_local_1));
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) = NULL;
    }
    TEAVM_RELEASE_STACK;
}
void* meth_cggs_JsonWriter_value(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    if ((teavm_local_1 == NULL)) {
        teavm_this_ = TEAVM_WITH_CALL_SITE_ID(13077, TEAVM_METHOD(teavm_this_, cggs_JsonWriter_VT, virt_nullValue)(teavm_this_));
    } else {
        TEAVM_WITH_CALL_SITE_ID(13078, meth_cggs_JsonWriter_writeDeferredName(teavm_this_));
        TEAVM_WITH_CALL_SITE_ID(13079, meth_cggs_JsonWriter_beforeValue(teavm_this_));
        TEAVM_WITH_CALL_SITE_ID(13080, meth_cggs_JsonWriter_string(teavm_this_, teavm_local_1));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_cggs_JsonWriter_nullValue(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) != NULL)) {
        if ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_serializeNulls))) {
            TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_deferredName) = NULL;
            goto teavm_label_1;
        }
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_WITH_CALL_SITE_ID(13081, meth_cggs_JsonWriter_writeDeferredName(teavm_this_));
    }
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13082, meth_cggs_JsonWriter_beforeValue(teavm_this_));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(13083, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13084, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_1)(teavm_tmp_ptr_0, TEAVM_GET_STRING(498))));
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void* meth_cggs_JsonWriter_value_0(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((teavm_local_1 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        teavm_this_ = TEAVM_WITH_CALL_SITE_ID(13085, TEAVM_METHOD(teavm_this_, cggs_JsonWriter_VT, virt_nullValue)(teavm_this_));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(13086, meth_cggs_JsonWriter_writeDeferredName(teavm_this_));
        TEAVM_WITH_CALL_SITE_ID(13087, meth_cggs_JsonWriter_beforeValue(teavm_this_));
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = ((!TEAVM_WITH_CALL_SITE_ID(13088, TEAVM_METHOD(teavm_local_1, jl_Boolean_VT, virt_booleanValue)(teavm_local_1))) ? TEAVM_GET_STRING(30) : TEAVM_GET_STRING(29));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(13089, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13090, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_1)(teavm_tmp_ptr_0, teavm_local_3)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
int32_t meth_cggs_JsonWriter_isTrustedNumberType(void* teavm_local_1) {
    int32_t teavm_local_2;
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13091, teavm_initializeClass((TeaVM_Class*) &cggs_JsonWriter_Cls, &initclass_cggs_JsonWriter));
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jl_Integer_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jl_Long_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jl_Double_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jl_Float_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jl_Byte_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jl_Short_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jm_BigDecimal_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &jm_BigInteger_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 == teavm_getClassObject((TeaVM_Class*) &juca_AtomicInteger_Cls))) {
        goto teavm_label_3;
    }
    if ((teavm_local_1 != teavm_getClassObject((TeaVM_Class*) &juca_AtomicLong_Cls))) {
        goto teavm_label_2;
    }
teavm_label_3:;
    teavm_local_2 = INT32_C(1);
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_2 = INT32_C(0);
teavm_label_1:;
    TEAVM_RELEASE_STACK;
    return teavm_local_2;
}
void* meth_cggs_JsonWriter_value_1(void* teavm_this_, void* teavm_local_1) {
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_local_4;
    void* teavm_local_5;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((teavm_local_1 == NULL)) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        teavm_this_ = TEAVM_WITH_CALL_SITE_ID(13092, TEAVM_METHOD(teavm_this_, cggs_JsonWriter_VT, virt_nullValue)(teavm_this_));
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(13093, meth_cggs_JsonWriter_writeDeferredName(teavm_this_));
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13094, TEAVM_METHOD(teavm_local_1, jl_Object_VT, virt_toString)(teavm_local_1));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13095, teavm_nullCheck(teavm_local_2));
        if (((!TEAVM_WITH_CALL_SITE_ID(13096, meth_jl_String_equals(teavm_local_2, TEAVM_GET_STRING(1316)))) && ((!TEAVM_WITH_CALL_SITE_ID(13097, meth_jl_String_equals(teavm_local_2, TEAVM_GET_STRING(1317)))) && (!TEAVM_WITH_CALL_SITE_ID(13098, meth_jl_String_equals(teavm_local_2, TEAVM_GET_STRING(1318))))))) {
            teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13099, meth_jl_Object_getClass(teavm_local_1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
            if (TEAVM_WITH_CALL_SITE_ID(13100, meth_cggs_JsonWriter_isTrustedNumberType(teavm_local_3))) {
                goto teavm_label_1;
            }
            teavm_local_4 = sfld_cggs_JsonWriter_VALID_JSON_NUMBER_PATTERN;
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13101, meth_jur_Pattern_matcher(TEAVM_WITH_CALL_SITE_ID(13102, teavm_nullCheck(teavm_local_4)), teavm_local_2));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
            if (TEAVM_WITH_CALL_SITE_ID(13103, meth_jur_Matcher_matches(TEAVM_WITH_CALL_SITE_ID(13104, teavm_nullCheck(teavm_local_4))))) {
                goto teavm_label_1;
            } else {
                TEAVM_GC_ROOT_RELEASE(INT32_C(2));
                teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13105, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
                TEAVM_GC_ROOT(INT32_C(2), teavm_local_4);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13106, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
                TEAVM_WITH_CALL_SITE_ID(13107, meth_jl_StringBuilder__init_(teavm_local_5));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13108, TEAVM_METHOD(teavm_local_5, jl_StringBuilder_VT, virt_append_0)(teavm_local_5, TEAVM_GET_STRING(1319)));
                TEAVM_GC_ROOT(INT32_C(3), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13109, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13110, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_1)(teavm_tmp_ptr_0, teavm_local_3)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                TEAVM_GC_ROOT_RELEASE(INT32_C(3));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13111, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13112, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, TEAVM_GET_STRING(1320))));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13113, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13114, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_2)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                TEAVM_GC_ROOT_RELEASE(INT32_C(1));
                teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13115, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13116, teavm_nullCheck(teavm_local_5))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
                TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
                TEAVM_WITH_CALL_SITE_ID(13117, meth_jl_IllegalArgumentException__init__0(teavm_local_4, teavm_local_5));
                TEAVM_GC_ROOT_RELEASE(INT32_C(0));
                TEAVM_WITH_CALL_SITE_ID(13118, meth_otr_ExceptionHandling_throwException(teavm_local_4));
                TEAVM_UNREACHABLE
            }
        }
        if ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_lenient))) {
            teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13119, meth_otr_Allocator_allocate(&jl_IllegalArgumentException_Cls));
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_5);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13120, meth_otr_Allocator_allocate(&jl_StringBuilder_Cls));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(13121, meth_jl_StringBuilder__init_(teavm_local_4));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13122, TEAVM_METHOD(teavm_local_4, jl_StringBuilder_VT, virt_append_0)(teavm_local_4, TEAVM_GET_STRING(1321)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13123, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13124, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_append_0)(teavm_tmp_ptr_0, teavm_local_2)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13125, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13126, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_StringBuilder_VT, virt_toString)(teavm_tmp_ptr_0)));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(13127, meth_jl_IllegalArgumentException__init__0(teavm_local_5, teavm_local_4));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_WITH_CALL_SITE_ID(13128, meth_otr_ExceptionHandling_throwException(teavm_local_5));
            TEAVM_UNREACHABLE
        }
    teavm_label_1:;
        TEAVM_WITH_CALL_SITE_ID(13129, meth_cggs_JsonWriter_beforeValue(teavm_this_));
        teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
        TEAVM_WITH_CALL_SITE_ID(13130, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13131, teavm_nullCheck(teavm_local_4))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_append_31)(teavm_tmp_ptr_0, teavm_local_2)));
    }
    TEAVM_RELEASE_STACK;
    return teavm_this_;
}
void meth_cggs_JsonWriter_close_0(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(13132, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13133, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_close)(teavm_tmp_ptr_0)));
    teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize);
    teavm_local_3 = teavm_compare_i32(teavm_local_2, INT32_C(1));
    if ((teavm_local_3 <= INT32_C(0))) {
        if ((!teavm_local_3)) {
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stack);
            teavm_local_3 = (teavm_local_2 - INT32_C(1));
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_4);
            teavm_local_4 = TEAVM_WITH_CALL_SITE_ID(13134, teavm_nullCheck(teavm_local_4));
            if ((TEAVM_ARRAY_AT(teavm_local_4, int32_t, TEAVM_WITH_CALL_SITE_ID(13135, teavm_checkBounds(teavm_local_3, teavm_local_4))) != INT32_C(7))) {
                goto teavm_label_1;
            }
        }
        TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize) = INT32_C(0);
        TEAVM_RELEASE_STACK;
        return;
    }
teavm_label_1:;
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13136, meth_otr_Allocator_allocate(&ji_IOException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_5);
    TEAVM_WITH_CALL_SITE_ID(13137, meth_ji_IOException__init_(teavm_local_5, TEAVM_GET_STRING(1322)));
    TEAVM_WITH_CALL_SITE_ID(13138, meth_otr_ExceptionHandling_throwException(teavm_local_5));
    TEAVM_UNREACHABLE
}
void meth_cggs_JsonWriter_string(void* teavm_this_, void* teavm_local_1) {
    TeaVM_Array* teavm_local_2;
    void* teavm_local_3;
    int32_t teavm_local_4;
    int32_t teavm_local_5;
    int32_t teavm_local_6;
    int32_t teavm_local_7;
    TeaVM_Array* teavm_local_8;
    void* teavm_local_9;
    int32_t teavm_local_10;
    int32_t teavm_local_11;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(4));
    if ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_htmlSafe))) {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(13139, teavm_initializeClass((TeaVM_Class*) &cggs_JsonWriter_Cls, &initclass_cggs_JsonWriter));
        teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    } else {
        TEAVM_GC_ROOT_RELEASE(INT32_C(0));
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_GC_ROOT_RELEASE(INT32_C(2));
        TEAVM_GC_ROOT_RELEASE(INT32_C(3));
        TEAVM_WITH_CALL_SITE_ID(13140, teavm_initializeClass((TeaVM_Class*) &cggs_JsonWriter_Cls, &initclass_cggs_JsonWriter));
        teavm_local_2 = sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
    TEAVM_GC_ROOT_RELEASE(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(3));
    TEAVM_WITH_CALL_SITE_ID(13141, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13142, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_0)(teavm_tmp_ptr_0, INT32_C(34))));
    teavm_local_4 = INT32_C(0);
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13143, teavm_nullCheck(teavm_local_1));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13144, meth_jl_String_length(teavm_local_1));
    teavm_local_6 = INT32_C(0);
    while (1) {
        if (!(teavm_local_6 < teavm_local_5)) break;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
        teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13145, meth_jl_String_charAt(teavm_local_1, teavm_local_6));
        if ((teavm_local_7 < INT32_C(128))) {
            teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13146, teavm_nullCheck(teavm_local_2));
            teavm_local_8 = teavm_local_2;
            teavm_local_7 = TEAVM_WITH_CALL_SITE_ID(13147, teavm_checkBounds(teavm_local_7, teavm_local_8));
            teavm_local_9 = TEAVM_ARRAY_AT(teavm_local_8, void*, teavm_local_7);
            if ((teavm_local_9 == NULL)) {
                goto teavm_label_2;
            }
        } else if ((teavm_local_7 == INT32_C(8232))) {
            teavm_local_9 = TEAVM_GET_STRING(1323);
        } else {
            if ((teavm_local_7 != INT32_C(8233))) {
                goto teavm_label_2;
            }
            teavm_local_9 = TEAVM_GET_STRING(1324);
        }
        if ((teavm_local_4 < teavm_local_6)) {
            teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
            teavm_local_10 = (teavm_local_6 - teavm_local_4);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
            TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
            TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(13148, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13149, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_2)(teavm_tmp_ptr_0, teavm_local_1, teavm_local_4, teavm_local_10)));
        }
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_9);
        TEAVM_GC_ROOT(INT32_C(2), teavm_local_3);
        TEAVM_GC_ROOT(INT32_C(3), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(13150, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13151, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_1)(teavm_tmp_ptr_0, teavm_local_9)));
        teavm_local_4 = (teavm_local_6 + INT32_C(1));
    teavm_label_2:;
        teavm_local_6 = (teavm_local_6 + INT32_C(1));
    }
    if ((teavm_local_4 < teavm_local_5)) {
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
        teavm_local_11 = (teavm_local_5 - teavm_local_4);
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(13152, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13153, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_2)(teavm_tmp_ptr_0, teavm_local_1, teavm_local_4, teavm_local_11)));
    }
    teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    TEAVM_WITH_CALL_SITE_ID(13154, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13155, teavm_nullCheck(teavm_local_3))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_0)(teavm_tmp_ptr_0, INT32_C(34))));
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonWriter_newline(void* teavm_this_) {
    void* teavm_local_1;
    int32_t teavm_local_2;
    int32_t teavm_local_3;
    void* teavm_local_4;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    if ((TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_indent) != NULL)) {
        teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
        TEAVM_GC_ROOT_RELEASE(INT32_C(1));
        TEAVM_WITH_CALL_SITE_ID(13156, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13157, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_0)(teavm_tmp_ptr_0, INT32_C(10))));
        teavm_local_2 = INT32_C(1);
        teavm_local_3 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_stackSize);
        while (1) {
            if (!(teavm_local_2 < teavm_local_3)) break;
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
            teavm_local_4 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_indent);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
            TEAVM_WITH_CALL_SITE_ID(13158, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13159, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_1)(teavm_tmp_ptr_0, teavm_local_4)));
            teavm_local_2 = (teavm_local_2 + INT32_C(1));
        }
    }
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonWriter_beforeName(void* teavm_this_) {
    int32_t teavm_local_1;
    void* teavm_local_2;
    void* teavm_local_3;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(1));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13160, meth_cggs_JsonWriter_peek(teavm_this_));
    if ((teavm_local_1 == INT32_C(5))) {
        teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        TEAVM_WITH_CALL_SITE_ID(13161, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13162, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_write_0)(teavm_tmp_ptr_0, INT32_C(44))));
    } else if ((teavm_local_1 != INT32_C(3))) {
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13163, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_3);
        TEAVM_WITH_CALL_SITE_ID(13164, meth_jl_IllegalStateException__init_(teavm_local_3, TEAVM_GET_STRING(1312)));
        TEAVM_WITH_CALL_SITE_ID(13165, meth_otr_ExceptionHandling_throwException(teavm_local_3));
        TEAVM_UNREACHABLE
    }
    TEAVM_WITH_CALL_SITE_ID(13166, meth_cggs_JsonWriter_newline(teavm_this_));
    TEAVM_WITH_CALL_SITE_ID(13167, meth_cggs_JsonWriter_replaceTop(teavm_this_, INT32_C(4)));
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonWriter_beforeValue(void* teavm_this_) {
    void* teavm_local_1;
    void* teavm_local_2;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    switch (TEAVM_WITH_CALL_SITE_ID(13168, meth_cggs_JsonWriter_peek(teavm_this_))) {
        case 1:
            TEAVM_WITH_CALL_SITE_ID(13169, meth_cggs_JsonWriter_replaceTop(teavm_this_, INT32_C(2)));
            TEAVM_WITH_CALL_SITE_ID(13170, meth_cggs_JsonWriter_newline(teavm_this_));
            goto teavm_label_1;
        case 2:
            goto teavm_label_5;
        case 3:
        case 5:
            goto teavm_label_6;
        case 4:
            teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
            teavm_local_2 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_separator);
            TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
            TEAVM_GC_ROOT(INT32_C(1), teavm_local_2);
            TEAVM_WITH_CALL_SITE_ID(13171, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13172, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_append_31)(teavm_tmp_ptr_0, teavm_local_2)));
            TEAVM_GC_ROOT_RELEASE(INT32_C(0));
            TEAVM_GC_ROOT_RELEASE(INT32_C(1));
            TEAVM_WITH_CALL_SITE_ID(13173, meth_cggs_JsonWriter_replaceTop(teavm_this_, INT32_C(5)));
            goto teavm_label_1;
        case 6:
            goto teavm_label_3;
        case 7:
            goto teavm_label_4;
    }
teavm_label_6:;
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13174, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    TEAVM_WITH_CALL_SITE_ID(13175, meth_jl_IllegalStateException__init_(teavm_local_2, TEAVM_GET_STRING(1312)));
    TEAVM_WITH_CALL_SITE_ID(13176, meth_otr_ExceptionHandling_throwException(teavm_local_2));
    TEAVM_UNREACHABLE
teavm_label_5:;
    teavm_local_1 = TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_out);
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(13177, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13178, teavm_nullCheck(teavm_local_1))), TEAVM_METHOD(teavm_tmp_ptr_0, ji_Writer_VT, virt_append_32)(teavm_tmp_ptr_0, INT32_C(44))));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(13179, meth_cggs_JsonWriter_newline(teavm_this_));
    goto teavm_label_1;
teavm_label_4:;
    if ((!TEAVM_FIELD(teavm_this_, cls_cggs_JsonWriter, fld_lenient))) {
        goto teavm_label_2;
    }
teavm_label_3:;
    TEAVM_WITH_CALL_SITE_ID(13180, meth_cggs_JsonWriter_replaceTop(teavm_this_, INT32_C(7)));
    goto teavm_label_1;
teavm_label_2:;
    teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13181, meth_otr_Allocator_allocate(&jl_IllegalStateException_Cls));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_1);
    TEAVM_WITH_CALL_SITE_ID(13182, meth_jl_IllegalStateException__init_(teavm_local_1, TEAVM_GET_STRING(1325)));
    TEAVM_WITH_CALL_SITE_ID(13183, meth_otr_ExceptionHandling_throwException(teavm_local_1));
    TEAVM_UNREACHABLE
teavm_label_1:;
    TEAVM_RELEASE_STACK;
}
void meth_cggs_JsonWriter__clinit_() {
    int32_t teavm_local_1;
    TeaVM_Array* teavm_local_2;
    TeaVM_Array* teavm_local_3;
    TeaVM_Array* teavm_local_4;
    void* teavm_local_5;
    void* teavm_local_6;
    void* teavm_tmp_ptr_0;
    TEAVM_ALLOC_STACK(INT32_C(2));
    TEAVM_GC_ROOT_RELEASE(INT32_C(0));
    TEAVM_GC_ROOT_RELEASE(INT32_C(1));
    sfld_cggs_JsonWriter_VALID_JSON_NUMBER_PATTERN = TEAVM_WITH_CALL_SITE_ID(13184, meth_jur_Pattern_compile(TEAVM_GET_STRING(1326)));
    sfld_cggs_JsonWriter_REPLACEMENT_CHARS = TEAVM_WITH_CALL_SITE_ID(13185, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), INT32_C(128)));
    teavm_local_1 = INT32_C(0);
    while (1) {
        if (!(teavm_local_1 <= INT32_C(31))) break;
        teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
        TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
        teavm_local_3 = TEAVM_WITH_CALL_SITE_ID(13186, meth_otr_Allocator_allocateArray(teavm_getArrayClass((TeaVM_Class*) &jl_Object_Cls), INT32_C(1)));
        teavm_local_4 = teavm_local_3;
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_4);
        teavm_local_5 = TEAVM_WITH_CALL_SITE_ID(13187, meth_jl_Integer_valueOf_0(teavm_local_1));
        teavm_gc_writeBarrier(teavm_local_4);
        TEAVM_ARRAY_AT(teavm_local_4, void*, INT32_C(0)) = teavm_local_5;
        teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(13188, meth_jl_String_format(TEAVM_GET_STRING(1327), teavm_local_3));
        TEAVM_GC_ROOT(INT32_C(1), teavm_local_6);
        teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13189, teavm_nullCheck(teavm_local_2));
        teavm_local_1 = TEAVM_WITH_CALL_SITE_ID(13190, teavm_checkBounds(teavm_local_1, teavm_local_2));
        teavm_gc_writeBarrier(teavm_local_2);
        TEAVM_ARRAY_AT(teavm_local_2, void*, teavm_local_1) = teavm_local_6;
        teavm_local_1 = (teavm_local_1 + INT32_C(1));
    }
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13191, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13192, teavm_checkUpperBound(INT32_C(34), teavm_local_2))) = TEAVM_GET_STRING(1328);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13193, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13194, teavm_checkUpperBound(INT32_C(92), teavm_local_2))) = TEAVM_GET_STRING(1329);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13195, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13196, teavm_checkUpperBound(INT32_C(9), teavm_local_2))) = TEAVM_GET_STRING(1330);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13197, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13198, teavm_checkUpperBound(INT32_C(8), teavm_local_2))) = TEAVM_GET_STRING(1331);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13199, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13200, teavm_checkUpperBound(INT32_C(10), teavm_local_2))) = TEAVM_GET_STRING(1332);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13201, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13202, teavm_checkUpperBound(INT32_C(13), teavm_local_2))) = TEAVM_GET_STRING(1333);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13203, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13204, teavm_checkUpperBound(INT32_C(12), teavm_local_2))) = TEAVM_GET_STRING(1334);
    teavm_local_2 = sfld_cggs_JsonWriter_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_6 = TEAVM_WITH_CALL_SITE_ID(13205, ((teavm_tmp_ptr_0 = TEAVM_WITH_CALL_SITE_ID(13206, teavm_nullCheck(teavm_local_2))), TEAVM_METHOD(teavm_tmp_ptr_0, jl_Object_VT, virt_clone)(teavm_tmp_ptr_0)));
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_6);
    sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS = TEAVM_WITH_CALL_SITE_ID(13207, teavm_checkcast(teavm_local_6, teavm_getArrayClass((TeaVM_Class*) &jl_String_Cls), &teavm_isSupertypeOfArray));
    teavm_local_2 = sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13208, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13209, teavm_checkUpperBound(INT32_C(60), teavm_local_2))) = TEAVM_GET_STRING(1335);
    teavm_local_2 = sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13210, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13211, teavm_checkUpperBound(INT32_C(62), teavm_local_2))) = TEAVM_GET_STRING(1336);
    teavm_local_2 = sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13212, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13213, teavm_checkUpperBound(INT32_C(38), teavm_local_2))) = TEAVM_GET_STRING(1337);
    teavm_local_2 = sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13214, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13215, teavm_checkUpperBound(INT32_C(61), teavm_local_2))) = TEAVM_GET_STRING(1338);
    teavm_local_2 = sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS;
    TEAVM_GC_ROOT(INT32_C(0), teavm_local_2);
    teavm_local_2 = TEAVM_WITH_CALL_SITE_ID(13216, teavm_nullCheck(teavm_local_2));
    TEAVM_ARRAY_AT(teavm_local_2, void*, TEAVM_WITH_CALL_SITE_ID(13217, teavm_checkUpperBound(INT32_C(39), teavm_local_2))) = TEAVM_GET_STRING(1339);
    TEAVM_RELEASE_STACK;
}
void initclass_cggs_JsonWriter() {
    TeaVM_Class* cls = (TeaVM_Class*) &cggs_JsonWriter_Cls;
    if (!(cls->flags & INT32_C(1))) {
        cls->flags |= INT32_C(1);
        meth_cggs_JsonWriter__clinit_();
    }
}
int32_t supertypeof_cggs_JsonWriter(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 569 || tag >= 571) return INT32_C(0);
    return INT32_C(1);
}
static int16_t teavm_classLayouts_cggs_JsonWriter_Cls[6];
alignas(8) cggs_JsonWriter_VT cggs_JsonWriter_Cls = {
    .parent = {
        .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_cggs_JsonWriter), sizeof(void*)),
        .flags = 0,
        .tag = 569,
        .modifiers = 1,
        .name = NULL,
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = NULL,
        .isSupertypeOf = &supertypeof_cggs_JsonWriter,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = teavm_classLayouts_cggs_JsonWriter_Cls,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0,
    .virt_name_0 = &meth_cggs_JsonWriter_name,
    .virt_value_0 = &meth_cggs_JsonWriter_value_1,
    .virt_beginArray_0 = &meth_cggs_JsonWriter_beginArray,
    .virt_endArray_0 = &meth_cggs_JsonWriter_endArray,
    .virt_value_1 = &meth_cggs_JsonWriter_value_0,
    .virt_value = &meth_cggs_JsonWriter_value,
    .virt_endObject_0 = &meth_cggs_JsonWriter_endObject,
    .virt_close = &meth_cggs_JsonWriter_close_0,
    .virt_nullValue = &meth_cggs_JsonWriter_nullValue,
    .virt_beginObject_0 = &meth_cggs_JsonWriter_beginObject
};
static void** teavm_gc_localStaticRoots_cggs_JsonWriter_Cls[3] = {
(void**) &sfld_cggs_JsonWriter_VALID_JSON_NUMBER_PATTERN, (void**) &sfld_cggs_JsonWriter_REPLACEMENT_CHARS, (void**) &sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS
};
static int16_t teavm_classLayouts_cggs_JsonWriter_Cls[6] = {
INT16_C(5), (int16_t) offsetof(cls_cggs_JsonWriter, fld_out), (int16_t) offsetof(cls_cggs_JsonWriter, fld_stack), (int16_t) offsetof(cls_cggs_JsonWriter, fld_indent), (int16_t) offsetof(cls_cggs_JsonWriter, fld_separator), (int16_t) offsetof(cls_cggs_JsonWriter, fld_deferredName)
};
void sysinitclass_cggs_JsonWriter() {
sfld_cggs_JsonWriter_VALID_JSON_NUMBER_PATTERN = NULL;
sfld_cggs_JsonWriter_REPLACEMENT_CHARS = NULL;
sfld_cggs_JsonWriter_HTML_SAFE_REPLACEMENT_CHARS = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_cggs_JsonWriter_Cls, 3);
}
