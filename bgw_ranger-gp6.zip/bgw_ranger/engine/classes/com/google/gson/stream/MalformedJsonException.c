#include "MalformedJsonException.h"
#include "../../../../java/io/IOException.h"
#include "../../../../../strings.h"
#include "../../../../java/lang/Object.h"
#include "../../../../java/lang/Throwable.h"

void meth_cggs_MalformedJsonException__init_(void* teavm_this_, void* teavm_local_1) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(17961, meth_ji_IOException__init_(teavm_this_, teavm_local_1));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_cggs_MalformedJsonException(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 856 || tag >= 858) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) cggs_MalformedJsonException_VT cggs_MalformedJsonException_Cls = {
    .parent = {
        .parent = {
            .parent = {
                .parent = {
                    .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_cggs_MalformedJsonException), sizeof(void*)),
                    .flags = 0,
                    .tag = 856,
                    .modifiers = 17,
                    .name = NULL,
                    .simpleName = NULL,
                    .arrayType = NULL,
                    .itemType = NULL,
                    .isSupertypeOf = &supertypeof_cggs_MalformedJsonException,
                    .superclass = (TeaVM_Class*) &ji_IOException_Cls,
                    .layout = NULL,
                    .enumValues = NULL,
                    .declaringClass = NULL,
                    .enclosingClass = NULL,
                    .init = NULL
                },
                .virt_hashCode = &meth_jl_Object_hashCode,
                .virt_equals = &meth_jl_Object_equals,
                .virt_clone = &meth_jl_Object_clone,
                .virt_toString = &meth_jl_Throwable_toString,
                .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
                .virt_getClass = &meth_jl_Object_getClass,
                .virt_identity = &meth_jl_Object_identity,
                .virt_notifyAll = &meth_jl_Object_notifyAll,
                .virt_wait = &meth_jl_Object_wait,
                .virt_waitImpl = &meth_jl_Object_waitImpl,
                .virt_wait_0 = &meth_jl_Object_wait_0,
                .virt_fillInStackTrace = &meth_jl_Throwable_fillInStackTrace,
                .virt_printStackTrace = &meth_jl_Throwable_printStackTrace,
                .virt_printStackTrace_0 = &meth_jl_Throwable_printStackTrace_0,
                .virt_getMessage = &meth_jl_Throwable_getMessage,
                .virt_addSuppressed = &meth_jl_Throwable_addSuppressed,
                .virt_getLocalizedMessage = &meth_jl_Throwable_getLocalizedMessage
            }
        }
    }
};
void sysinitclass_cggs_MalformedJsonException() {
}
