#pragma once
#include "../../../../../runtime.h"
#include "../../../../java/lang/Object.h"
#include "JsonReaderInternalAccess.h"

extern void sysinitclass_cggi_JsonReaderInternalAccess();
typedef struct cls_cggi_JsonReaderInternalAccess {
    struct TeaVM_Object parent;
} cls_cggi_JsonReaderInternalAccess;
extern void* sfld_cggi_JsonReaderInternalAccess_INSTANCE;
extern void meth_cggi_JsonReaderInternalAccess__init_(void*);
extern int32_t supertypeof_cggi_JsonReaderInternalAccess(TeaVM_Class*, TeaVM_Class*);
typedef struct cggi_JsonReaderInternalAccess_VT {
    jl_Object_VT parent;
} cggi_JsonReaderInternalAccess_VT;
extern cggi_JsonReaderInternalAccess_VT cggi_JsonReaderInternalAccess_Cls;
