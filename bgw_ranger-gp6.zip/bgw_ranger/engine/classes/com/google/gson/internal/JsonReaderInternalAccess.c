#include "JsonReaderInternalAccess.h"
#include "../../../../java/lang/Object.h"
#include "../../../../../strings.h"

void* sfld_cggi_JsonReaderInternalAccess_INSTANCE;
void meth_cggi_JsonReaderInternalAccess__init_(void* teavm_this_) {
    TEAVM_ALLOC_STACK(INT32_C(0));
    TEAVM_WITH_CALL_SITE_ID(10682, meth_jl_Object__init_(teavm_this_));
    TEAVM_RELEASE_STACK;
}
int32_t supertypeof_cggi_JsonReaderInternalAccess(TeaVM_Class* supercls, TeaVM_Class* cls) {
    int32_t tag = cls->tag;
    if (tag < 517 || tag >= 521) return INT32_C(0);
    return INT32_C(1);
}
alignas(8) cggi_JsonReaderInternalAccess_VT cggi_JsonReaderInternalAccess_Cls = {
    .parent = {
        .parent = {
            .size = (int32_t) (intptr_t) TEAVM_ALIGN(sizeof(cls_cggi_JsonReaderInternalAccess), sizeof(void*)),
            .flags = 0,
            .tag = 517,
            .modifiers = 1025,
            .name = NULL,
            .simpleName = NULL,
            .arrayType = NULL,
            .itemType = NULL,
            .isSupertypeOf = &supertypeof_cggi_JsonReaderInternalAccess,
            .superclass = (TeaVM_Class*) &jl_Object_Cls,
            .layout = NULL,
            .enumValues = NULL,
            .declaringClass = NULL,
            .enclosingClass = NULL,
            .init = NULL
        },
        .virt_hashCode = &meth_jl_Object_hashCode,
        .virt_equals = &meth_jl_Object_equals,
        .virt_clone = &meth_jl_Object_clone,
        .virt_toString = &meth_jl_Object_toString,
        .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
        .virt_getClass = &meth_jl_Object_getClass,
        .virt_identity = &meth_jl_Object_identity,
        .virt_notifyAll = &meth_jl_Object_notifyAll,
        .virt_wait = &meth_jl_Object_wait,
        .virt_waitImpl = &meth_jl_Object_waitImpl,
        .virt_wait_0 = &meth_jl_Object_wait_0
    }
};
static void** teavm_gc_localStaticRoots_cggi_JsonReaderInternalAccess_Cls[1] = {
(void**) &sfld_cggi_JsonReaderInternalAccess_INSTANCE
};
void sysinitclass_cggi_JsonReaderInternalAccess() {
sfld_cggi_JsonReaderInternalAccess_INSTANCE = NULL;
teavm_registerStaticGcRoots(teavm_gc_localStaticRoots_cggi_JsonReaderInternalAccess_Cls, 1);
}
