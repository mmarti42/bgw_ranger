#pragma once
#include "../../runtime.h"
#include "../../classes/java/lang/Object.h"

extern void sysinitclass_Arr_Z();
extern int32_t supertypeof_Arr_Z(TeaVM_Class*, TeaVM_Class*);
extern jl_Object_VT Arr_Z_Cls;
