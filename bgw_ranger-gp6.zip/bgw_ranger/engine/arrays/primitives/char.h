#pragma once
#include "../../runtime.h"
#include "../../classes/java/lang/Object.h"

extern void sysinitclass_Arr_C();
extern int32_t supertypeof_Arr_C(TeaVM_Class*, TeaVM_Class*);
extern jl_Object_VT Arr_C_Cls;
