#include "boolean.h"
#include "../../classes/java/lang/Object.h"
#include "../../primitives/boolean.h"
#include "../../strings.h"

int32_t supertypeof_Arr_Z(TeaVM_Class* supercls, TeaVM_Class* cls) {
    TeaVM_Class* itemType = cls->itemType;
    if (itemType == NULL) return INT32_C(0);
    return itemType == &Z_Cls;
}
alignas(8) jl_Object_VT Arr_Z_Cls = {
    .parent = {
        .size = sizeof(int8_t),
        .flags = 0,
        .tag = 0,
        .modifiers = 0,
        .name = (TeaVM_Object**) TEAVM_GET_STRING_ADDRESS(8191),
        .simpleName = NULL,
        .arrayType = NULL,
        .itemType = (TeaVM_Class*) &Z_Cls,
        .isSupertypeOf = &supertypeof_Arr_Z,
        .superclass = (TeaVM_Class*) &jl_Object_Cls,
        .layout = NULL,
        .enumValues = NULL,
        .declaringClass = NULL,
        .enclosingClass = NULL,
        .init = NULL
    },
    .virt_hashCode = &meth_jl_Object_hashCode,
    .virt_equals = &meth_jl_Object_equals,
    .virt_clone = &meth_jl_Object_clone,
    .virt_toString = &meth_jl_Object_toString,
    .virt_isEmptyMonitor = &meth_jl_Object_isEmptyMonitor,
    .virt_getClass = &meth_jl_Object_getClass,
    .virt_identity = &meth_jl_Object_identity,
    .virt_notifyAll = &meth_jl_Object_notifyAll,
    .virt_wait = &meth_jl_Object_wait,
    .virt_waitImpl = &meth_jl_Object_waitImpl,
    .virt_wait_0 = &meth_jl_Object_wait_0
};
void sysinitclass_Arr_Z() {
}
